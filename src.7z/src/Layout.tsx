import React, { useEffect, useState } from 'react';
// import Script from 'next/script';
import { GoogleTagManager } from '@next/third-parties/google'
import Head from 'next/head';
import { Placeholder, LayoutServiceData, Field, HTMLLink } from '@sitecore-jss/sitecore-jss-nextjs';
import { getPublicUrl } from '@sitecore-jss/sitecore-jss-nextjs/utils';
// import Scripts from 'src/Scripts';
import styles from './Layout.module.scss';
import { CommonProvider } from './contexts/CommonContext';
import HeaderImage from 'components/HeaderImage/HeaderImage';
import {
  KEY_PAGE_HEADLINE,
  KEY_PAGE_ABSTRACT,
  KEY_ENVIRONMENTS,
  KEY_AZURE_AD_CODE,
  GRAPH_API_ACCESS_TOKEN_KEY,
  KEY_MAIN_CONTENT_TRANSLATION_ID,
  KEY_SELECTED_LANGUAGE,
  KEY_AZURE_AD_URL,
  KEY_IS_PREVIEW,
  PAGE_UNDER_CONSTRUCTION,
  KEY_PAGE_LANGUAGE,
  KEY_COOKIE_PAGE_MODE,
  DEFAULT_DATE_VALUE
} from 'src/constants/general';
import { dictionaryService } from 'src/services/dictionary.service';

import {
  checkIsLanguageExistsInUrl,
  checkEnvExistsinUrl,
  checkIsPreviewOrEditorMode,
  setToStorage,
  getFromStorage,
  getGraphApiToken,
  checkIfLanguageExistsInArray,
  formatLayoutLanguageData,
  setToLocalStorage,
  setCookie,
  getCookie
} from 'src/core/utils/utils.helper';
import { useDispatch, useSelector } from 'react-redux';
import { SET_PREVIEWMODE } from 'src/redux/reducers/isPreviewModeSlice';
import { fetchProfileData } from 'src/redux/reducers/profileSlice';
import { SET_IS_LANGAUGE_SELECTED, SET_LANGUAGE_DATA } from 'src/redux/reducers/languageSlice';
import BayerTranslate from 'components/BayerTranslate/BayerTranslate';
import useDataLayer from './hooks/useDataLayer';
import { getDataLayer } from './redux/reducers/commonSlice';

// adding dataLayer property to window 
// declare global {
//   interface Window { dataLayer: Array<any>; }
// }

// Prefix public assets with a public URL to enable compatibility with Sitecore editors.
// If you're not supporting Sitecore editors, you can remove this.
const publicUrl = getPublicUrl();

interface LayoutProps {
  layoutData: LayoutServiceData;
  headLinks: HTMLLink[];
}

interface RouteFields {
  [key: string]: unknown;
  pageTitle: Field;
}

const Layout = ({ layoutData }: LayoutProps): JSX.Element => {

  const { isLangaugeSelected } = useSelector((state: any) => state.language);
  const gtmDataLayer = useSelector((state:any)=>state.common.gtmDataLayer);
  const { route, context } = layoutData.sitecore;
  const fields: any = route?.fields as RouteFields;
  const dispatch = useDispatch<any>();

  const contextData: any = null;
  const [headData, setHeadData] = useState<any>(null);
  const [anchor, setAnchor] = useState<any>(null);
  // const [urlReferrer, setUrlReferrer] = useState('');
  const formattedLanguageData: any = formatLayoutLanguageData(
    route &&
      route.placeholders &&
      route.placeholders['jss-language'] &&
      route.placeholders['jss-language'][0]
  );
  /** check and saves value in redux store if the site open in experience editor */
  useEffect(() => {
    /** check and saves value in redux store if the site open in previewmode */
    dispatch(SET_PREVIEWMODE(checkIsPreviewOrEditorMode(KEY_IS_PREVIEW)));
    dispatch(SET_IS_LANGAUGE_SELECTED(false));

    // Removing selected language from session storage
    setToStorage(KEY_SELECTED_LANGUAGE, '');
    setToLocalStorage(KEY_PAGE_LANGUAGE, context.language);


    /**
     * For updating cookie value for page mode edit/preview for fixing bug #183108
     */
    const isFound: any = checkEnvExistsinUrl(KEY_ENVIRONMENTS.ENV_CM);
    const currentURL : any = window.location;
    if (isFound && !String(currentURL).includes('sc_mode')){
      const cookie = getCookie(KEY_COOKIE_PAGE_MODE);
      if(cookie === 'edit') {
        setCookie(KEY_COOKIE_PAGE_MODE, '');
        location.reload();
      }
    } 
    
  }, []);
  //meta data
  useEffect(() => {
    // setting previous url value
    // setUrlReferrer(document.referrer);
    if (route && route.fields) {
      const scheduledDate: any = route.fields['Scheduled Date'] && route.fields['Scheduled Date'];

      if (scheduledDate && scheduledDate.value && scheduledDate.value != DEFAULT_DATE_VALUE) {
        const scheduled = Date.parse(scheduledDate.value);
        const date = new Date();
        const current = date.getTime();
        if (scheduled > current) {
          window.location.href = `${process.env.SITECORE_API_HOST}/${PAGE_UNDER_CONSTRUCTION}`;
        }
        setHeadData(route && route.fields);
      } else {
        setHeadData(route && route.fields);
      }
    }
  }, [route]);

  /**cookie layout data */
  const cookiePlaceHolderData: any =
    route &&
    route.placeholders &&
    route.placeholders['jss-cookie'] &&
    route.placeholders['jss-cookie'][0];

  /**
   * @description fetching data from dictionary service api
   */
  useEffect(() => {
    //dictionary api calling and updates value to the provider
    let currentUrl = typeof window !== 'undefined' ? window.location.href : '';
    const locale: any = checkIfLanguageExistsInArray(currentUrl.split('/')[3]);
    dictionaryService.fetchDictionaryData(locale).then((data: any) => {
      if (data && Object.keys(data).length !== 0) {
        dispatch(SET_LANGUAGE_DATA(data));
      }
    });
    /***********************custom layout service api call ********************/
    // check whether current env is exist inside the cd environment array
    const isFound: any = checkEnvExistsinUrl(KEY_ENVIRONMENTS.ENV_CD);

    // check the environment is localhost
    const isEnvLocalHost: any = checkEnvExistsinUrl(KEY_ENVIRONMENTS.ENV_LOCAL);

    //check is language exists in url
    const isLanguageExistsInUrl: boolean = checkIsLanguageExistsInUrl();

    //trim language and HR identification key from the url path eg : removes this key "/en/My_HR" from url path
    let currentPath: any = window.location.pathname.split('/').filter((e) => e.trim().length);

    // format path based on current environment and language code (if available)
    isFound && !isEnvLocalHost && isLanguageExistsInUrl
      ? currentPath.splice(0, 2)
      : isFound && !isEnvLocalHost && !isLanguageExistsInUrl
      ? currentPath.splice(0, 1)
      : !isFound && isEnvLocalHost && isLanguageExistsInUrl
      ? currentPath.splice(0, 1)
      : console.info('env else condition');

    // const path: any = currentPath.join('/').toLowerCase();
    // const locale: any = context.language ?? packageInfo.config.language;

    //custom layout service call for getting personalised content
    // layoutService.fetchLayoutData(decodeURI(path), locale).then((data: any) => {
    //   setContextData(data && data.sitecore);
    //   setHeadData(data.sitecore && data.sitecore.route && data.sitecore.route.fields);
    // });

    //get userdata from api and saves in redux store
    dispatch(fetchProfileData());

    // get dataLayer data
    dispatch(getDataLayer());
    /*
     * For getting ID TOKEN from graph api for calling MS teams apis
     */
    const currentURL = window.location.search;
    const queryParams = new URLSearchParams(currentURL);
    const code: any = queryParams.get('code');
    // const state: any = queryParams.get('state');

    if (code && code != '') {
      setToStorage(KEY_AZURE_AD_CODE, code);

      (async () => {
        const url = getFromStorage(KEY_AZURE_AD_URL);
        const resp: any = await getGraphApiToken(code);
        if (resp && resp.status === 200) {
          const output = JSON.parse(resp.response);
          const accessToken = output && output.access_token ? output.access_token : '';
          setToStorage(GRAPH_API_ACCESS_TOKEN_KEY, accessToken);
          window.location.replace(url);
        } else {
          window.location.replace(url);
        }
      })();
    }
  }, [context]);
  
  useDataLayer({
    userCountry: gtmDataLayer?.Country || '',
    userCity: gtmDataLayer?.Location || '',
    userDivision: gtmDataLayer?.Division || '',
    userFunction: gtmDataLayer?.Function || '',
    userBusinessPartner: gtmDataLayer?.BusinessPartner || '',
    userToolboxCount: gtmDataLayer?.ToolBoxCount?.toString() || '',
    'article.ReleaseDate': gtmDataLayer?.ArticleReleaseDate || '',
    clientId: gtmDataLayer?.ClientId || ''
  });

  return (
    <CommonProvider value={{ anchor, setAnchor, formattedLanguageData }}>
      {/* <Script
        src={`https://www.googletagmanager.com/gtm.js?id=GTM-MGPXFNK`}
        strategy="afterInteractive"
      /> */}
      {gtmDataLayer?.ClientId && gtmDataLayer?.Country && gtmDataLayer?.Division && cookiePlaceHolderData &&
          cookiePlaceHolderData.fields &&
          cookiePlaceHolderData.fields.CookieStatus &&(
        <GoogleTagManager gtmId={process.env.GTM_ID || ''} 
        //   dataLayer={{
        //   userCountry: gtmDataLayer?.Country || '',
        //   userCity: gtmDataLayer?.Location || '',
        //   userDivision: gtmDataLayer?.Division || '',
        //   userFunction: gtmDataLayer?.Function || '',
        //   userBusinessPartner: gtmDataLayer?.BusinessPartner || '',
        //   userToolboxCount: gtmDataLayer?.ToolBoxCount?.toString() || '',
        //   'article.ReleaseDate': gtmDataLayer?.ArticleReleaseDate || '',
        //   clientId: gtmDataLayer?.ClientId || '',
        //   urlReferrer: urlReferrer,
        // }}
        />
      )}
      <Head>
        <title>
          {headData && headData['Page Headline'] && headData['Page Headline'].value
            ? headData['Page Headline'].value
            : 'Bayernet'}
           
        </title>
        {/* <script dangerouslySetInnerHTML={{__html:`window.dataLayer = window.dataLayer || [];`}}/>
        <script src="https://www.googletagmanager.com/gtm.js?id=GTM-MGPXFNK" />
        {cookiePlaceHolderData &&
          cookiePlaceHolderData.fields &&
          cookiePlaceHolderData.fields.CookieStatus ? (
          <Scripts />
          ) : (
            ''
        )} */}
        <meta
          name="abstract"
          content={
            headData && headData['Meta Abstract'] && headData['Meta Abstract'].value
              ? headData['Meta Abstract'].value
              : ''
          }
        />
        <meta
          name="author"
          content={
            headData && headData['Meta Author'] && headData['Meta Author'].value
              ? headData['Meta Author'].value
              : ''
          }
        />
        <meta
          name="authorEmail"
          content={
            headData && headData['Meta Author Email'] && headData['Meta Author Email'].value
              ? headData['Meta Author Email'].value
              : ''
          }
        />
        <meta
          name="description"
          content={
            headData && headData['Meta Description'] && headData['Meta Description'].value
              ? headData['Meta Description'].value
              : ''
          }
        />
        <meta
          name="keywords"
          content={
            headData && headData['Meta Keywords'] && headData['Meta Keywords'].value
              ? headData['Meta Keywords'].value
              : ''
          }
        />
        <meta
          name="publisher"
          content={
            headData && headData['Meta Publisher'] && headData['Meta Publisher'].value
              ? headData['Meta Publisher'].value
              : ''
          }
        />
        <meta
          name="revisitAfter"
          content={
            headData && headData['Meta RevisitAfter'] && headData['Meta RevisitAfter'].value
              ? headData['Meta RevisitAfter'].value
              : ''
          }
        />
        <meta
          name="robots"
          content={
            headData && headData['Meta Robots'] && headData['Meta Robots'].value
              ? headData['Meta Robots'].value
              : ''
          }
        />
        {/* <meta name='viewPort' content={headData && headData['Meta Viewport'] && headData['Meta Viewport'].value ? headData['Meta Viewport'].value : ''} /> */}
        {/* <meta name="viewport" content="width=device-width, initial-scale=1.0"></meta> */}
        <meta
          name="browserTitle"
          content={
            headData && headData['Meta BrowserTitle'] && headData['Meta BrowserTitle'].value
              ? headData['Meta BrowserTitle'].value
              : ''
          }
        />
        <meta
          name="pageTitle"
          content={
            headData && headData['Meta PageTitle'] && headData['Meta PageTitle'].value
              ? headData['Meta PageTitle'].value
              : ''
          }
        />
        <meta
          name="thumbnailUrl"
          content={
            headData && headData['Meta Thumbnail URL'] && headData['Meta Thumbnail URL'].value
              ? headData['Meta Thumbnail URL'].value
              : ''
          }
        />

        <link rel="icon" href={`${publicUrl}/favicon.ico`} />
        {/* <body data-language={context && context.language} /> */}
      </Head>
      {/* <noscript
      dangerouslySetInnerHTML={{__html:`<iframe src=https://www.googletagmanager.com/ns.html?id=GTM-MGPXFNK
      height="0" width="0" style={{display:'none',visibility:'hidden'}}></iframe>`}}
      >
        </noscript> */}
      <Placeholder
        name="jss-header"
        rendering={contextData && contextData.route ? contextData.route : route}
      />
      {/* </div> */}

      <div className={styles.breadcrumb__container}>
        <div className={styles.breadcrumb__wrapper}>
          <Placeholder
            name="jss-breadcrumb"
            rendering={contextData && contextData.route ? contextData.route : route}
          />
        </div>

        <Placeholder
          name="jss-language"
          rendering={contextData && contextData.route ? contextData.route : route}
        />
        {/* <Languages /> */}
      </div>

      <div className={styles.header_hero_clusternav_wrapper}>
        <div className={styles.clusternav__container}>
          <Placeholder
            name="jss-clusternav"
            rendering={contextData && contextData.route ? contextData.route : route}
          />
        </div>
        <div className={styles.header_image__container}>
          <HeaderImage imageData={route && route.fields && route.fields.Image} />
        </div>
      </div>
      <div>
        {/* root placeholder for the app, which we add components to using route data */}
        <div className={`${styles.container}`}>
          <div className={styles.wrapper}>
            <div className={`${styles.inner_wrapper} ${KEY_MAIN_CONTENT_TRANSLATION_ID}`}>
              <div style={{ display: isLangaugeSelected ? 'block' : 'none' }}>
                <BayerTranslate />
              </div>

              {fields?.[KEY_PAGE_HEADLINE]?.value && (
                <div className={styles.template_heading_content__wrapper}>
                  <h1 className={styles.template__heading}>
                    {(fields && fields?.[KEY_PAGE_HEADLINE]?.value) || ''}
                  </h1>
                  <h5 className={styles.template__description}>
                    {(fields && fields?.[KEY_PAGE_ABSTRACT]?.value) || ''}
                  </h5>
                </div>
              )}

              <Placeholder
                name="jss-main"
                rendering={contextData && contextData.route ? contextData.route : route}
              />
            </div>
          </div>
        </div>

        <div className="container-footer">
          <Placeholder
            name="jss-footer"
            rendering={contextData && contextData.route ? contextData.route : route}
          />
        </div>
      </div>
      <Placeholder
        name="jss-cookie"
        rendering={contextData && contextData.route ? contextData.route : route}
      />
      {/* <div className={styles.header_parent__container}> */}
    </CommonProvider>
  );
};

export default Layout;
