import { useState, useEffect, useRef } from 'react';
import CalendarSection from 'components/CalendarSection/CalendarSection';
import {
  setHashString,
  groupCalendarEvents,
  getHashString,
  getMonthNameById
} from 'src/core/utils/utils.helper';
import styles from './MonthlyTabDesktop.module.scss';
import MonthlyView from '../MonthlyView/MonthlyView';
import { KEY_HR_TASK_LAYOUT_SERVICE_RESPONSE } from 'src/constants/general';
import { useLanguageTranslate } from 'src/hooks/useLanguageTranslate';
import {
  KEY_MONTH_APR,
  KEY_MONTH_AUG,
  KEY_MONTH_DEC,
  KEY_MONTH_FEB,
  KEY_MONTH_JAN,
  KEY_MONTH_JUL,
  KEY_MONTH_JUN,
  KEY_MONTH_MAR,
  KEY_MONTH_MAY,
  KEY_MONTH_NOV,
  KEY_MONTH_OCT,
  KEY_MONTH_SEP,
} from 'src/constants/dictonary';

export function MonthlyTabDesktop(props: any) {


  const [eventList, setEventList] = useState<any>(null);
  const [active, setActive] = useState<any>();
  const [page, setPage] = useState<any>(1);
  const containerRef = useRef<any>(null);
  const [activeMonthSet, setActiveMonthSet] = useState<any>(null);
  const [monthSet1, setMonthSet1] = useState<any>([]);
  const [monthSet2, setMonthSet2] = useState<any>([]);
  const [selectedMonthName, setSelectedMonthName] = useState<any>();
  const handleTabChange = (id: any, month : any = null) => {
    setHashString(id);
    setActive(id);
    setSelectedMonthName(month)
  };

  const { translatedKey } = useLanguageTranslate();
  const handleArrowNavigation = (page: any) => {
    setPage(page);
    if (page === 1) {
      setActiveMonthSet(monthSet1);
    } else {
      setActiveMonthSet(monthSet2);
    }
  };

  const d = new Date();

  const set1 = [
    { id: KEY_MONTH_JAN, name: translatedKey(KEY_MONTH_JAN).toLowerCase() },
    { id: KEY_MONTH_FEB, name: translatedKey(KEY_MONTH_FEB).toLowerCase() },
    { id: KEY_MONTH_MAR, name: translatedKey(KEY_MONTH_MAR).toLowerCase() },
    { id: KEY_MONTH_APR, name: translatedKey(KEY_MONTH_APR).toLowerCase() },
    { id: KEY_MONTH_MAY, name: translatedKey(KEY_MONTH_MAY).toLowerCase() },
    { id: KEY_MONTH_JUN, name: translatedKey(KEY_MONTH_JUN).toLowerCase() }
  ]

  const set2 = [
    { id: KEY_MONTH_JUL, name: translatedKey(KEY_MONTH_JUL).toLowerCase() },
    { id: KEY_MONTH_AUG, name: translatedKey(KEY_MONTH_AUG).toLowerCase() },
    { id: KEY_MONTH_SEP, name: translatedKey(KEY_MONTH_SEP).toLowerCase() },
    { id: KEY_MONTH_OCT, name: translatedKey(KEY_MONTH_OCT).toLowerCase() },
    { id: KEY_MONTH_NOV, name: translatedKey(KEY_MONTH_NOV).toLowerCase() },
    { id: KEY_MONTH_DEC, name: translatedKey(KEY_MONTH_DEC).toLowerCase() }
  ]

  useEffect(() => {
    //event list will change for months in future enhancement
    // if (props && active && active === 'all') {
    //   const { calendarData } = props;
    //   const calendarItems = calendarData && calendarData.fields && calendarData.fields[KEY_HR_TASK_LAYOUT_SERVICE_RESPONSE];
    //   setEventList(groupCalendarEvents(calendarItems));
    // } else {
    //   setEventList(null);
    // }

    setMonthSet1(set1);
    setMonthSet2(set2);

    const hashObj = getHashString();

    if (hashObj.month != '') {
      setActive(hashObj.month);
      const exists =  set1.filter(function(el) {
        return el.id.toLowerCase() === hashObj.month;
      }); 

      const exists2 =  set2.filter(function(el) {
        return el.id.toLowerCase() === hashObj.month;
      });  

      if(exists.length > 0) {  
        setPage(1);
        setActiveMonthSet(set1);
        setSelectedMonthName(exists && exists[0] && exists[0].name);
      } else if(exists2.length > 0) {
        setPage(2);
        setActiveMonthSet(set2);               
        setSelectedMonthName(exists2 && exists2[0] && exists2[0].name);
      } else {
        setPage(1);
        setActiveMonthSet(set1);
      }
    } else {
      const currentMonth = getMonthNameById(d.getMonth() + 1);
      setActive(currentMonth);

      const exists =  set1.filter(function(el) {
        return el.id.toLowerCase() === currentMonth;
      }); 

      const exists2 =  set2.filter(function(el) {
        return el.id.toLowerCase() === currentMonth;
      });

      if(exists.length > 0) {
        setPage(1);
        setActiveMonthSet(set1);
        setSelectedMonthName(exists && exists[0] && exists[0].name);
      } else if (exists2.length > 0) {                 
        setPage(2);
        setActiveMonthSet(set2);        
        setSelectedMonthName(exists2 && exists2[0] && exists2[0].name);
      } else {
        setActiveMonthSet(set1);
      }
    }    
  }, [props]);

  useEffect(() => {
    if (props && active && active === 'all') {
      const { calendarData } = props;
     
      const calendarItems = calendarData && calendarData.fields && calendarData.fields[KEY_HR_TASK_LAYOUT_SERVICE_RESPONSE];
      setEventList(groupCalendarEvents(calendarItems));
      
    } else {
      setEventList(null);
    }
  
  }, [active, props.calendarData]);

  return (
    <>
      <div className={styles.arrows_wrapper}>
        <div
          className={`${styles.prev_icon} ${page === 1 ? styles.inactive : styles.active}`}
          onClick={() => {
            handleArrowNavigation(1);
          }}
        ></div>
        <div
          className={`${styles.next_icon} ${page === 2 ? styles.inactive : styles.active}`}
          onClick={() => {
            handleArrowNavigation(2);
          }}
        ></div>
      </div>
      <div className={styles.monthy_tab_container}>
        <div className={styles.months_view}>
          <div
            className={`${styles.all_month_wrapper} ${
              active === 'all' ? styles.active : undefined
            }`}
            id="all"
            onClick={() => {
              handleTabChange('all');
            }}
          >
            <div className={styles.month}>ALL</div>
          </div>
          <div className={styles.months} ref={containerRef}>
            {activeMonthSet &&
              activeMonthSet.map((item: any) => {
                return item && item.name && item.name != '' ? (
                  <div
                    className={`${styles.month_wrapper} ${
                      active === item.id.toLowerCase() ? styles.active : undefined
                    } `}
                    // id={item}
                    key={item.name}
                    id={item.name}
                    onClick={() => {
                      handleTabChange(item && item.id && item.id.toLowerCase(), item.name);
                    }}
                  >
                    <div className={styles.month}>{item.name}</div>
                  </div>
                ) : (
                  ''
                );
              })}
          </div>
        </div>

        {active && active === 'all' ? (
          <div className={styles.month_content}>
            {eventList &&
              eventList.map((event: any, index: any) => (
                <CalendarSection
                  taskList={event}
                  page={page}
                  key={index}
                  monthsWidth={
                    containerRef && containerRef.current && containerRef.current.clientWidth
                      ? containerRef.current.clientWidth
                      : 0
                  }
                  id={index}
                />
              ))}
          </div>
        ) : (
          <div className={styles.month_content}>
            <MonthlyView
              taskList={props.calendarData}
              monthSelected={active}
              linkboxData={props.linkboxData && props.linkboxData}
              activeTab={props.activeTab && props.activeTab}
              selectedMonthName={selectedMonthName}
            ></MonthlyView>
          </div>
        )}
      </div>
    </>
  );
}
