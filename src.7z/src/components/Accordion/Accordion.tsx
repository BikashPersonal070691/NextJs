import { useEffect, useRef, useState } from 'react';
import { getParentClassReference, getParentAttributeReference } from 'src/core/utils/utils.helper';
import { Collapse } from 'components/Elements/Collapse/Collapse';
import { CONTENT_100 } from 'src/constants/contentDivider';
import { Field, useSitecoreContext } from '@sitecore-jss/sitecore-jss-nextjs';
import { ACCORDION_ITEM_TITLE } from 'src/constants/general';
import { ComponentProps } from 'lib/component-props';
import { StyleguideSpecimenFields } from 'lib/component-props/styleguide';
import styles from './Accordion.module.scss';

type AccordionComponentProps = ComponentProps &
  StyleguideSpecimenFields & {
    fields: {
      [ACCORDION_ITEM_TITLE]: Field<string>;
    };
  };

const Accordion = (props: AccordionComponentProps): JSX.Element => {
  /**
   * @important This code needs to be used in every components inorder to get the content dividers reference
   * @important Also set the reference (ref) and className to the html wrapper as implemented below
   */
  // starts
  const nodeRef = useRef(null);
  const [parentRef, setParentRef] = useState<any>(null);
  const [parentAttr, setParentAttr] = useState<any>(null);
  const { sitecoreContext } = useSitecoreContext();
  const isExperienceEditor = sitecoreContext && sitecoreContext.pageEditing;


  useEffect(() => {
    const child: any = nodeRef.current;
    if (child !== null || child !== undefined) {
      setParentRef(getParentClassReference(child));
      setParentAttr(getParentAttributeReference(child, 'data-id'));
    } else {
      setParentRef(CONTENT_100);
    }
  }, []);

  //ends
  return (
    <div ref={nodeRef} className={`${parentAttr && styles[parentAttr]}`}>
      {isExperienceEditor && (
        // <Text tag="h1" field={formattedAnchorData && formattedAnchorData[KEY_ANCHOR_HEADING]} />
        <h2>Accordion Component (This will not be displayed in frontend)</h2>
      )}
      <Collapse listData={props} id={parentRef} isTab={parentAttr && parentAttr} />
    </div>
  );
};

export default Accordion;
