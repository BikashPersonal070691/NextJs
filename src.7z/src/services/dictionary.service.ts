import { AxiosResponse } from 'axios';
import { AxiosDataFetcher, RestDictionaryService } from '@sitecore-jss/sitecore-jss-nextjs';
import config from 'temp/config';

// define your custom data fetcher
function dataFetcher(url: string, data?: unknown): Promise<AxiosResponse<any>> {
  return new AxiosDataFetcher({ withCredentials: false }).fetch(url, data);
}

export const dictionaryService = new RestDictionaryService({
  apiHost: process.env && process.env.SITECORE_API_HOST ? process.env.SITECORE_API_HOST : '',
  apiKey: config.sitecoreApiKey,
  siteName: config.jssAppName,
  // provide your custom data fetcher to the service instance
  dataFetcher,
});
