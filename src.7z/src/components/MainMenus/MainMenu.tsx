import React, { useEffect, useState, useContext } from 'react';
import styles from './MainMenu.module.scss';
import { formatCurrentUrl } from 'src/helpers/menu.helper';
import { MenuProvider } from 'src/contexts/MenuContext';
import { HeaderContext } from 'src/contexts/HeaderContext';
// import useSWR from 'swr';
import { MainMenuList } from 'components/MainMenuList/MainMenuList';
import { MegaMenu } from 'components/MegaMenu/MegaMenu';
import { getMainMenus } from 'src/services/menu.service';
import { MegaMenuMobileView } from 'components/MegaMenuMobileView/MegaMenuMobileView';
import { KEY_BREAKPOINT_MEDIUM_LARGE } from 'src/constants/general';
// const fetcher = (url: any) => fetch(url).then(res => res.json());

const MainMenu = (props: any) => {
  // const { data } = useSWR('/api/getMenuData', fetcher);
  const { setMainMenuOpen, initialLoad, stickyClass } = useContext(HeaderContext);
  const [currentLevel, setCurrentLevel] = useState<any>(1);
  const [menuData, setMenuData] = useState<any>({});
  const [selectedItems, setSelectedItems] = useState<any>({});
  const [listLevel, setListLevel] = useState(0);
  const [activeMenu, setActiveMenu] = useState<any>({});
  const currentUrl = formatCurrentUrl();
  const [secondLevelItems, setSecondLevelItems] = useState<any>({});
  const [thirdLevelItems, setThirdLevelItems] = useState<any>({});
  const [fourthLevelItems, setFourthLevelItems] = useState<any>({});
  const [fifthLevelItems, setFifthLevelItems] = useState<any>({});
  const [openMenuMobileView, setOpenMenuMobileView] = useState(false); // only for devices
  const [sixthLevelItems, setSixthLevelItems] = useState<any>({});
  const [displayClass, setDisplayClass] = useState<any>();
  const [displayClassMobile, setDisplayClassMobile] = useState<any>(styles.display_none_menu);
  const [windowWidth, setWindowWidth] = useState<any>();
  const { mobileView } = props;
  const { setMobileView } = useContext(HeaderContext);
  useEffect(() => {
    let width = window.innerWidth;
    setWindowWidth(width);
    // Resize Event
    window.addEventListener('resize', function () {
      if (window.innerWidth != width) {
        width = window.innerWidth;
        this.location.reload();
      }
    });
  }, []);
  useEffect(() => {
    if (!mobileView) {
      document.body.style.overflow = 'visible';
    } else {
      document.body.style.overflow = 'hidden';
    }
  }, [mobileView]);

  useEffect(() => {
    if (windowWidth && windowWidth <= KEY_BREAKPOINT_MEDIUM_LARGE) {
      setOpenMenuMobileView(true);
    } else {
      setOpenMenuMobileView(false);
    }

    if (!initialLoad) {
      if (mobileView) {
        // setDisplayClassMobile(styles.display_none);
        // setTimeout(function () {
        //   setDisplayClassMobile(styles.display_block);
        // }, 300);
        setDisplayClassMobile(styles.display_block);
      } else {
        // setTimeout(function () {
        //   setDisplayClassMobile(styles.display_none);
        // }, 300);
        setDisplayClassMobile(styles.display_none);
      }
    }
  }, [windowWidth, mobileView]);

  useEffect(() => {
    getMainMenus().then((data: any) => {
      if (data && data.data) {
        setMenuData(data.data);
      }
    });
    // setMenuData({
    //   MainNavigation: [
    //     {
    //       NavigationTitle: 'Home',
    //       URL: '/en/',
    //       ExternalURL: '',
    //       OpenInNewWindow: false,
    //       IsActive: false,
    //       TemplateID: '25a4c23b-14cb-404e-a68a-4292229d9e05',
    //       HasChildren: false,
    //       InActiveInNavigation: false,
    //     },
    //     {
    //       NavigationTitle: 'Bayer',
    //       URL: '/en/bayer',
    //       ExternalURL: '/en/bayer/our-mission',
    //       OpenInNewWindow: false,
    //       IsActive: false,
    //       TemplateID: '91ee7cef-587d-41e5-bfee-f3168c0230c3',
    //       HasChildren: true,
    //       InActiveInNavigation: false,
    //     },
    //     {
    //       NavigationTitle: 'Organization',
    //       URL: '/en/organization',
    //       ExternalURL: '',
    //       OpenInNewWindow: false,
    //       IsActive: false,
    //       TemplateID: 'e7ee4866-09be-45f3-8080-337299ee7629',
    //       HasChildren: true,
    //       InActiveInNavigation: false,
    //     },
    //     {
    //       NavigationTitle: 'Location',
    //       URL: '/en/location',
    //       ExternalURL: '',
    //       OpenInNewWindow: false,
    //       IsActive: false,
    //       TemplateID: '7dbc1632-cbf0-45b7-9b93-ec431c01c486',
    //       HasChildren: true,
    //       InActiveInNavigation: false,
    //     },
    //     {
    //       NavigationTitle: 'MyHR',
    //       URL: '/en/people',
    //       ExternalURL: '/en/people/hrcalendar',
    //       OpenInNewWindow: false,
    //       IsActive: false,
    //       TemplateID: '036f2d50-f8d6-4641-bf98-1ea03319d540',
    //       HasChildren: true,
    //       InActiveInNavigation: false,
    //     },
    //     {
    //       NavigationTitle: 'MyIT',
    //       URL: '/en/myit',
    //       ExternalURL: '',
    //       OpenInNewWindow: false,
    //       IsActive: false,
    //       TemplateID: '149e0109-a567-4e42-a3aa-117eaf8d9f4d',
    //       HasChildren: true,
    //       InActiveInNavigation: false,
    //     },
    //     {
    //       NavigationTitle: 'Services',
    //       URL: '/en/service',
    //       ExternalURL: '/en/service/employee-channels/bayernet-20',
    //       OpenInNewWindow: false,
    //       IsActive: false,
    //       TemplateID: '15f4a36f-c271-4a8a-b762-cede810d9959',
    //       HasChildren: true,
    //       InActiveInNavigation: false,
    //     },
    //   ],
    //   SubNavigation: {
    //     '25a4c23b-14cb-404e-a68a-4292229d9e05': { General: [], Personalized: null, Header: null },
    //     '91ee7cef-587d-41e5-bfee-f3168c0230c3': {
    //       General: [
    //         {
    //           Text: 'Our Mission',
    //           URL: '/en/bayer/our-mission',
    //           HasChildren: true,
    //           Children: null,
    //           RootID: '{3CD20B33-420C-4496-907A-C988827707F4}',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //         {
    //           Text: 'Test Text',
    //           URL: '/en/bayer/test-text',
    //           HasChildren: false,
    //           Children: null,
    //           RootID: '{563C1BC4-C68E-4574-A183-ACB35ED32A5B}',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //         {
    //           Text: 'Text T',
    //           URL: '/en/bayer/text-t',
    //           HasChildren: false,
    //           Children: null,
    //           RootID: '{54C6B1F1-6BAD-4708-B46A-A661E50F1D47}',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //         {
    //           Text: 'Creating the best Bayer',
    //           URL: '/en/bayer/creating-the-best-bayer',
    //           HasChildren: true,
    //           Children: null,
    //           RootID: '{210C64DF-8915-4F81-9507-3F8B70B23D11}',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //         {
    //           Text: 'One Company, One Brand',
    //           URL: '/en/bayer/brand',
    //           HasChildren: true,
    //           Children: null,
    //           RootID: '{2F0A6A95-C663-431F-B9CC-0BA8D14A141F}',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //         {
    //           Text: 'Values and Culture',
    //           URL: '/en/bayer/values-and-culture',
    //           HasChildren: true,
    //           Children: null,
    //           RootID: '{ACBCA513-18C9-49AA-A086-C9BBE95358CC}',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: true,
    //         },
    //         {
    //           Text: 'Innovation',
    //           URL: '/en/bayer/innovation',
    //           HasChildren: true,
    //           Children: null,
    //           RootID: '{B354C24F-4715-43B4-8320-9277B576EDEA}',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //         {
    //           Text: 'Digital',
    //           URL: '/en/bayer/digital',
    //           HasChildren: true,
    //           Children: null,
    //           RootID: '{1434D462-1271-4968-ACFD-F6B3BF31AEE6}',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //         {
    //           Text: 'Health & Safety',
    //           URL: '/en/bayer/health_safety',
    //           HasChildren: true,
    //           Children: null,
    //           RootID: '{C7B8B3FC-C41F-4590-A25D-6E8D26CF1A75}',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //         {
    //           Text: 'Sustainability',
    //           URL: '/en/bayer/sustainability',
    //           HasChildren: true,
    //           Children: null,
    //           RootID: '{0361ADEB-A442-4A04-96A7-ED5496A3DF89}',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //         {
    //           Text: 'Compliance & Data Privacy',
    //           URL: '/en/bayer/compliance',
    //           HasChildren: true,
    //           Children: null,
    //           RootID: '{C4512908-6D1F-4E77-86A7-E49A4C8B11F4}',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //         {
    //           Text: 'Social Engagement',
    //           URL: '/en/bayer/societal-engagement',
    //           HasChildren: true,
    //           Children: null,
    //           RootID: '{DB401429-6D15-4049-BCE7-EDA07BF88F02}',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //         {
    //           Text: 'Controversial Topics',
    //           URL: '/en/bayer/controversial-topics',
    //           HasChildren: true,
    //           Children: null,
    //           RootID: '{5B4C3BE2-9F31-447C-9E50-F9A17EFE55EE}',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //       ],
    //       Personalized: null,
    //       Header: null,
    //     },
    //     'e7ee4866-09be-45f3-8080-337299ee7629': {
    //       General: [
    //         {
    //           Text: 'Pharmaceuticals',
    //           URL: '/en/organization/pharmaceuticals/home',
    //           HasChildren: true,
    //           Children: null,
    //           RootID: '{CDA017AB-B6F0-40E7-8762-704454181568}',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //         {
    //           Text: 'Bayer Vital',
    //           URL: '/en/organization/bayer-vital/home/ueber-uns',
    //           HasChildren: true,
    //           Children: null,
    //           RootID: '{BF697398-2DA2-4DE6-A34F-834F81193E4F}',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //         {
    //           Text: 'Crop Science',
    //           URL: '/en/organization/crop-science/home',
    //           HasChildren: true,
    //           Children: null,
    //           RootID: '{EEA56400-42D5-4F39-82C3-AF1BFC3F126D}',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //         {
    //           Text: 'Enabling Functions',
    //           URL: '/en/organization/enabling-functions/home',
    //           HasChildren: true,
    //           Children: null,
    //           RootID: '{BDCFC4F4-C6DB-42FE-A99B-6FC050AC5688}',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //       ],
    //       Personalized: [
    //         {
    //           Text: 'FR Consumer Health',
    //           URL: '/en/france/home/organization/fr-consumer-health/home',
    //           HasChildren: true,
    //           Children: null,
    //           RootID: '{139D7C81-FB3C-4DC9-8FD3-42DB1FB4DE11}',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //         {
    //           Text: 'CH Finance',
    //           URL: '/en/organization/consumer-health/ch-finance/home',
    //           HasChildren: true,
    //           Children: null,
    //           RootID: '{A35590E9-24A0-4C04-B9DA-55701E72D978}',
    //           NewWindow: true,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //         {
    //           Text: 'Consumer Health',
    //           URL: '/en/organization/consumer-health/home',
    //           HasChildren: true,
    //           Children: null,
    //           RootID: '{2FCFC27B-FDE7-44B3-A428-67F2AA524FA7}',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //       ],
    //       Header: null,
    //     },
    //     '7dbc1632-cbf0-45b7-9b93-ec431c01c486': {
    //       General: [
    //         {
    //           Text: 'Find more locations',
    //           URL: '/en/location?source=more_locations',
    //           HasChildren: false,
    //           Children: null,
    //           RootID: null,
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //       ],
    //       Personalized: [
    //         {
    //           Text: 'France',
    //           URL: '/en/france/home',
    //           HasChildren: true,
    //           Children: null,
    //           RootID: '{6B04254F-5D18-4149-9573-FFC9B4906D90}',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //         {
    //           Text: 'Autry le Chatel',
    //           URL: '/en/france/autry-le-chatel/home',
    //           HasChildren: false,
    //           Children: null,
    //           RootID: '{0DC97E8B-06BC-4367-AD0F-395A61E5FC93}',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //         {
    //           Text: 'Sites in France',
    //           URL: '/en/location',
    //           HasChildren: true,
    //           Children: null,
    //           RootID: 'sitesInMenu',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //       ],
    //       Header: 'MY LOCATION',
    //     },
    //     '036f2d50-f8d6-4641-bf98-1ea03319d540': {
    //       General: [
    //         {
    //           Text: 'ContributoryTest',
    //           URL: '/en/people/contributorytest',
    //           HasChildren: true,
    //           Children: null,
    //           RootID: '{6A362816-7950-4854-A20A-16486B327033}',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //         {
    //           Text: 'HR Calendar',
    //           URL: '/en/people/hrcalendar',
    //           HasChildren: false,
    //           Children: null,
    //           RootID: '{56ACB7D2-B1B3-4A62-B1F1-4AF713D68BCD}',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //         {
    //           Text: 'AskHR',
    //           URL: '/en/people/ask-hr',
    //           HasChildren: true,
    //           Children: null,
    //           RootID: '{F6E02722-C801-4100-BC26-E41D8CA8E333}',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: true,
    //         },
    //         {
    //           Text: 'HR A-Z',
    //           URL: '/en/people/hr-az',
    //           HasChildren: true,
    //           Children: null,
    //           RootID: '{2B040EB4-FCCB-4C2C-89A3-C0520DA6AC02}',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //       ],
    //       Personalized: null,
    //       Header: null,
    //     },
    //     '149e0109-a567-4e42-a3aa-117eaf8d9f4d': {
    //       General: [
    //         {
    //           Text: 'Support',
    //           URL: '/en/myit/support',
    //           HasChildren: false,
    //           Children: null,
    //           RootID: '{D4324C29-19CE-4E10-9D9E-3A66CB9343AD}',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //         {
    //           Text: 'Cyber Security Risk Management ',
    //           URL: '/en/myit/csrm',
    //           HasChildren: true,
    //           Children: null,
    //           RootID: '{42223CBA-1FC3-4D0B-A6E1-E36DB7667EF9}',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //       ],
    //       Personalized: null,
    //       Header: null,
    //     },
    //     '15f4a36f-c271-4a8a-b762-cede810d9959': {
    //       General: [
    //         {
    //           Text: 'News Overview',
    //           URL: '/en/newsoverview',
    //           HasChildren: false,
    //           Children: null,
    //           RootID: '{EF7FA14E-0CCE-4181-87E3-354032561B54}',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //         {
    //           Text: 'Event Overview',
    //           URL: '/en/eventoverview',
    //           HasChildren: false,
    //           Children: null,
    //           RootID: '{A2F2FBE2-B86E-4963-B7E4-C4C394E7EE6E}',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //         {
    //           Text: 'Tools & Resources',
    //           URL: '/en/tools-and-resources-overview',
    //           HasChildren: false,
    //           Children: null,
    //           RootID: '{9FD857C4-3483-4058-82F0-143B65BA24B9}',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //         {
    //           Text: 'Support and Solutions',
    //           URL: '/en/service/support-und-solutions/enabling-functions-directory',
    //           HasChildren: true,
    //           Children: null,
    //           RootID: '{E3B2247E-21FC-427D-B23F-87BCD153A07E}',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //         {
    //           Text: 'Employee Channels',
    //           URL: '/en/service/employee-channels',
    //           HasChildren: true,
    //           Children: null,
    //           RootID: '{3B8B3E54-F9E0-4457-AFD7-CECF255898B4}',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //         {
    //           Text: 'Travel',
    //           URL: '/en/service/travel',
    //           HasChildren: true,
    //           Children: null,
    //           RootID: '{EDD4396F-AB4A-44F7-B7E2-0D88E93C8BB5}',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //         {
    //           Text: 'LPC Contracting France',
    //           URL: '/en/france/home/services/lpc-france/lpc-contracting-france',
    //           HasChildren: false,
    //           Children: null,
    //           RootID: '{52A7C691-66EF-41A9-9335-D25727A2863F}',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //         {
    //           Text: 'LPC France',
    //           URL: '/en/france/home/services/lpc-france',
    //           HasChildren: true,
    //           Children: null,
    //           RootID: '{347C11C6-85F8-4DB1-903B-9A8237BE59BE}',
    //           NewWindow: false,
    //           IsActive: false,
    //           InActiveInNavigation: false,
    //         },
    //       ],
    //       Personalized: null,
    //       Header: null,
    //     },
    //   },
    // });
  }, []);

  /**
   * @description this is to check if the submenu is opened if so set setMainMenuOpen to true
   */
  useEffect(() => {
    if (selectedItems && Object.keys(selectedItems).length !== 0) {
      setMainMenuOpen(true);
    } else {
      setMainMenuOpen(false);
    }
  }, [selectedItems]);

  useEffect(() => {
    if (mobileView) {
      setMainMenuOpen(true);
    } else {
      setMainMenuOpen(false);
    }
  }, [mobileView]);

  const setFirstLevelItems = (item: any) => {
    setDisplayClass(styles.display_none);
    const { SubNavigation } = menuData;

    if (SubNavigation) {
      setTimeout(function () {
        setSelectedItems(SubNavigation[item.TemplateID]);
        setDisplayClass(styles.display_block);
      }, 300);
    }
  };

  return (
    <MenuProvider
      value={{
        thirdLevelItems,
        setThirdLevelItems,
        fourthLevelItems,
        setFourthLevelItems,
        fifthLevelItems,
        setFifthLevelItems,
        sixthLevelItems,
        setSixthLevelItems,
        secondLevelItems,
        setSecondLevelItems,
        menuData,
        setFirstLevelItems,
        selectedItems,
        setSelectedItems,
        listLevel,
        setListLevel,
        activeMenu,
        setActiveMenu,
        currentUrl,
        setCurrentLevel,
        currentLevel,
      }}
    >
      {!openMenuMobileView ? (
        <div className={`${styles.main_menu}`}>
          <div className={`${styles.nav_wrapper}`}>
            <MainMenuList />
          </div>
          {selectedItems && Object.keys(selectedItems).length !== 0 ? (
            <div className={`${styles.mega_menu_three} ${displayClass}`}>
              <MegaMenu />
            </div>
          ) : (
            ''
          )}
        </div>
      ) : (
        ''
      )}

      {openMenuMobileView ? (
        <>
          <div
            style={{ minHeight: `${window.innerHeight}px` }}
            className={`${displayClassMobile} ${
              stickyClass && stickyClass !== '' ? styles.mobile_menu__sticky : ''
            } ${styles.mobile_main_menu} ${styles.mobile_main_menu} ${
              currentLevel === 1 ? styles.upper_shadow : ''
            }`}
          >
            <MegaMenuMobileView />
          </div>
          {mobileView ? (
            <div
              style={{ minHeight: `${window.innerHeight}px` }}
              onClick={() => {
                setMobileView(false);
              }}
              className={`${styles.overlay} ${currentLevel === 1 ? styles.upper_shadow : ''}`}
            ></div>
          ) : (
            ''
          )}
        </>
      ) : (
        ''
      )}
    </MenuProvider>
  );
};

export default MainMenu;
