export const CONTENT_25 = 'CD_CONTENT__25';
export const CONTENT_33 = 'CD_CONTENT__33';
export const CONTENT_34 = 'CD_CONTENT__34';
export const CONTENT_50 = 'CD_CONTENT__50';
export const CONTENT_66 = 'CD_CONTENT__66';
export const CONTENT_75 = 'CD_CONTENT__75';
export const CONTENT_100 = 'CD_CONTENT__100';

export const CD_25_50_25 = {
  PH_25_50_25_LEFT_25: 'jss-left-25',
  PH_25_50_25_MIDDLE_50: 'jss-middle-50',
  PH_25_50_25_RIGHT_25: 'jss-right-25',
};

export const CD_33_34_33 = {
  PH_33_34_33_LEFT_33: 'jss-left-33',
  PH_33_34_33_MIDDLE_34: 'jss-middle-34',
  PH_33_34_33_RIGHT_33: 'jss-right-33',
};

export const CD_50_50 = {
  PH_50_50_LEFT_50: 'jss-left-50',
  PH_50_50_RIGHT_50: 'jss-right-50',
};

export const CD_66_34 = {
  PH_66_34_LEFT_66: 'jss-content-66',
  PH_66_34_RIGHT_34: 'jss-content-34',
};
export const CD_66_50_50_34 = {
  PH_66_50_50_34_TOP_66: 'jss-top-66',
  PH_66_50_50_34_BOTTOM_LEFT_50: 'jss-bottomleft-50',
  PH_66_50_50_34_BOTTOM_RIGHT_50: 'jss-bottomright-50',
  PH_66_50_50_34_SIDE_RIGHT_34: 'jss-sideright-34',
};

export const CD_75_25 = {
  PH_75_25_LEFT_75: 'jss-leftdata-75',
  PH_75_25_RIGHT_25: 'jss-rightdata-25',
};

export const CD_34_66 = {
  PH_34_66_LEFT_34: 'jss-wf-left-34',
  PH_34_66_RIGHT_66: 'jss-wf-right-66',
};

export const CD_100 = {
  PH_100_CONTENT_100: 'jss-content-100',
};

// color pallete
export const CD_COLOR_PALLETE = [
  {
    key: '{F308C90F-7AAB-4550-AC48-E7FB1E3D9E73}',
    value: '#ffffff',
  },
  {
    key: '{507FDE0F-086B-4BB1-8BC5-8177C7F08DCF}',
    value: '#ffeaef',
  },
  {
    key: '{3D7F6D60-9F4A-4791-AD45-E6A144244E62}',
    value: '#f1f1f1',
  },
  {
    key: '{6380CF26-3909-4CD5-92A7-F3F979F36B2C}',
    value: '#edfde5',
  },
  {
    key: '{B63B7268-C7D1-4BB3-95CE-15AED6FC33FD}',
    value: '#e4f0f4',
  },
];

export const KEY_CONTENT_DIVIDER_LINK_BGCOLOR = 'Background Color';
export const KEY_COMPONENT_WORKFLOW = 'Workflow';
