const IFrame = (): JSX.Element => (
  <div>
    <div>
      <h1 style={{ width: '80%', marginLeft: '2%' }}>Performance link - SAP SF:</h1>
      <a
        style={{ color: 'blue', fontSize: '15px', textDecoration: 'underline', marginLeft: '2%' }}
        href="https://performancemanager5.successfactors.eu/sf/pmreviews/login?company=C0003153479P&loginMethod=SSO%20"
      >
        https://performancemanager5.successfactors.eu/sf/pmreviews/login?company=C0003153479P&loginMethod=SSO%20
      </a>
      <iframe
        style={{ width: '80%', margin: '2%' }}
        src="https://performancemanager5.successfactors.eu/sf/pmreviews/login?company=C0003153479P&loginMethod=SSO%20"
        title="Performance link - SAP SF:"
      ></iframe>
    </div>

    <div>
      <h1 style={{ width: '80%', marginLeft: '2%' }}>Go Learn - Degreed :</h1>
      <a
        style={{ color: 'blue', fontSize: '15px', textDecoration: 'underline', marginLeft: '2%' }}
        href="https://eu.degreed.com/account/login?ReturnUrl=%2fdguserqwegwo4%2fdashboard"
      >
        https://eu.degreed.com/account/login?ReturnUrl=%2fdguserqwegwo4%2fdashboard
      </a>
      <iframe
        style={{ width: '80%', margin: '2%' }}
        src="https://eu.degreed.com/account/login?ReturnUrl=%2fdguserqwegwo4%2fdashboard"
        title="Go Learn - Degreed:"
      ></iframe>
    </div>

    <div>
      <h1 style={{ width: '80%', marginLeft: '2%' }}>Talent Marketplace - Eightfold:</h1>
      <a
        style={{ color: 'blue', fontSize: '15px', textDecoration: 'underline', marginLeft: '2%' }}
        href="https://app.eightfold-eu.ai/login?hl=en&next=http%3A%2f%2fapp.eightfold-eu.ai%2fcareerhub"
      >
        https://app.eightfold-eu.ai/login?hl=en&next=http%3A%2f%2fapp.eightfold-eu.ai%2fcareerhub
      </a>
      <iframe
        style={{ width: '80%', margin: '2%' }}
        src="https://app.eightfold-eu.ai/login?hl=en&next=http%3A%2f%2fapp.eightfold-eu.ai%2fcareerhub"
        title="Talent Marketplace - Eightfold:"
      ></iframe>
    </div>

    <div>
      <h1 style={{ width: '80%', marginLeft: '2%' }}>Job portal Nordics - Teamtailor:</h1>
      <a
        style={{ color: 'blue', fontSize: '15px', textDecoration: 'underline', marginLeft: '2%' }}
        href="https://bayernordic.teamtailor.com/jobs"
      >
        https://bayernordic.teamtailor.com/jobs
      </a>
      <iframe
        style={{ width: '80%', margin: '2%' }}
        src="https://bayernordic.teamtailor.com/jobs"
        title="Job portal Nordics - Teamtailor:"
      ></iframe>
    </div>
  </div>
);

export default IFrame;
