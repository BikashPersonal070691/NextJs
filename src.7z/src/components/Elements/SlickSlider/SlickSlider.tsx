import { useState, useEffect, useRef } from 'react';
import { Placeholder, Text, Link, useSitecoreContext } from '@sitecore-jss/sitecore-jss-nextjs';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import { SlickSliderConfig } from 'src/models/slickSlider';
import styles from './SlickSlider.module.scss';

export default function SlickSlider({
  data,
  headingData,
  numberOfTiles,
  type,
  tilesToShow,
  placeHolderName,
  showButton,
  buttonData,
  parentRef,
  showSideNav,
  showDots,
  showTopNav,
  isSliderThumbnail,
  isImageEnlarge,
  isOverlaySlider,
  overlayCloseEvent,
  isVariableWidth,
  isAdaptiveHeight,
  isDummySlideNeeded,
  isSliderSmall,
}: SlickSliderConfig) {
  const { sitecoreContext } = useSitecoreContext();
  const isExperienceEditor = sitecoreContext && sitecoreContext.pageEditing;
  let slideRef: any = useRef<any>(null);
  let slideRefSmall: any = useRef<any>(null);
  const [isFirstSlideDisabled, setIsFirstSlideDisabled] = useState(true);
  const [isLastSlideDisabled, setIsLastSlideDisabled] = useState(false);
  const [settings, setSettings] = useState<any>('');
  const [nav1, setNav1] = useState<any>(null);
  const [nav2, setNav2] = useState<any>(null);

  useEffect(() => {
    setNav1(slideRef);
    setNav2(slideRefSmall);
  }, []);
  /**
   * @description settings for main slider
   */
  useEffect(() => {
    const sliderSettings: any = {
      arrows: showSideNav && showSideNav,
      draggable: false,
      speed: 500,
      slidesToShow: tilesToShow && tilesToShow,
      slidesToScroll: 1,
      variableWidth: isVariableWidth && isVariableWidth,
      dots: showDots && showDots,
      adaptiveHeight: isAdaptiveHeight && isAdaptiveHeight,
      // swipeToSlide: true,
      nextArrow: <NextArrow className={styles.arrow__next} />,
      prevArrow: <PrevArrow className={styles.arrow__prev} />,
      infinite: false,
      afterChange: (current: any) => {
        if (current === 0) {
          setIsFirstSlideDisabled(true);
        } else {
          setIsFirstSlideDisabled(false);
        }
        const totalSlides =
          tilesToShow > 1
            ? isDummySlideNeeded
              ? numberOfTiles + 1
              : numberOfTiles
            : numberOfTiles;
        if (totalSlides > current + tilesToShow) {
          setIsLastSlideDisabled(false);
        } else {
          setIsLastSlideDisabled(true);
        }
      },
    };

    setSettings(sliderSettings);

    /**
     * @description handle settings whie resizing the window.
     */
    const handleWindowResize = () => {
      setSettings(sliderSettings);
    };
    window.addEventListener('resize', handleWindowResize);
    // cleanup function when component unmounts
    return () => {
      window.removeEventListener('resize', handleWindowResize);
    };
  }, []);

  /**
   * @param prop
   * @description custom next arrow for slider
   * @returns HTMLElement
   */
  const NextArrow = (prop: any) => {
    const { className, onClick } = prop;
    return <div className={className} onClick={onClick} />;
  };
  /**
   * @param prop
   * @description custom previous arrow for slider
   * @returns HTMLElement
   */
  const PrevArrow = (prop: any) => {
    const { className, onClick } = prop;
    return <div className={className} onClick={onClick} />;
  };
  /**
   * @description triggering slick slider previous and next function
   */
  const goPrev = () => {
    slideRef && slideRef.slickPrev();
  };
  const goNext = () => {
    slideRef && slideRef.slickNext();
  };

  return (
    <div className={styles[parentRef]}>
      <div
        className={`${styles.slider__container} ${
          isOverlaySlider && styles.slider__container__overlay
        } ${isOverlaySlider && 'gallery'}`}
      >
        {overlayCloseEvent && (
          <div className={styles.close__wrapper}>
            <div className={styles.close} onClick={overlayCloseEvent}></div>
          </div>
        )}
        <div
          className={`${showButton || showTopNav || headingData ? styles.headline__container : ''}`}
        >
          {/* Heading */}
          <Text
            field={headingData}
            editable={true}
            tag="div"
            className={`${styles.carousel_headline}`}
          />
          {/* top navigation  */}
          {!isExperienceEditor && showTopNav && (
            <div className={`${styles.button_wrapper}`}>
              <button
                className={`${styles.previous} ${isFirstSlideDisabled ? styles.disabled : ''}`}
                onClick={goPrev}
              ></button>
              <button
                className={`${styles.next} ${isLastSlideDisabled ? styles.disabled : ''} `}
                onClick={goNext}
              ></button>
            </div>
          )}
          {/* button */}
          {showButton === true &&
            buttonData &&
            buttonData.url &&
            buttonData.url.value &&
            buttonData.url.value.href &&
            buttonData.text &&
            buttonData.text.value && (
              <div className={styles.button_top__container}>
                {isExperienceEditor ? (
                  <Link field={buttonData && buttonData.url}>
                    <Text
                      className={styles.slider_button}
                      tag="div"
                      field={buttonData && buttonData.text}
                      editable={true}
                    />
                  </Link>
                ) : (
                  <Link field={buttonData && buttonData.url}>
                    <Text
                      className={styles.slider_button}
                      tag="div"
                      field={buttonData && buttonData.text}
                      editable={true}
                    />
                  </Link>
                )}
              </div>
            )}
        </div>
        {isExperienceEditor && isExperienceEditor ? (
          // in experience editor slick slider inline editing is not working so inside experience editor items are wrapped inside flex container and will display as individual items with inline editing
          <Placeholder
            name={placeHolderName}
            rendering={data.rendering}
            data-slider={true}
            data-type={type && type}
            render={(components) => (
              <div className={styles.exp_editor_specific__items}>{components}</div>
            )}
          />
        ) : (
          <>
            <Placeholder
              name={placeHolderName}
              rendering={data.rendering}
              data-slider={true}
              data-type={type && type}
              data-isImageEnlarge={isImageEnlarge}
              data-isOverlaySlider={isOverlaySlider}
              data-isSliderSmall={isSliderSmall}
              render={(components) => (
                <Slider
                  asNavFor={isOverlaySlider && nav2}
                  ref={(slider) => (slideRef = slider)}
                  {...settings}
                >
                  {components}
                  {isDummySlideNeeded && <div></div>}
                </Slider>
              )}
            />
            {/* This slider will only work when "isSliderThumbnail" prop is true. Mailny this slider is shown in image gallery */}
            {isSliderThumbnail && (
              <div className={styles.thumbnail__container}>
                <Placeholder
                  name={placeHolderName}
                  rendering={data.rendering}
                  data-slider={true}
                  data-isSliderThumbnail={isSliderThumbnail}
                  data-type={type && type}
                  data-isImageEnlarge={isImageEnlarge}
                  data-isOverlaySlider={isOverlaySlider}
                  render={(components) => (
                    <Slider
                      asNavFor={isOverlaySlider && nav1}
                      focusOnSelect={true}
                      slidesToShow={2}
                      swipeToSlide={true}
                      adaptiveHeight={false}
                      variableWidth={true}
                      ref={(slider) => (slideRefSmall = slider)}
                      infinite={false}
                      arrows={false}
                    >
                      {components}
                    </Slider>
                  )}
                />
                )
              </div>
            )}
          </>
        )}
        {showButton &&
          showButton === true &&
          buttonData &&
          buttonData.url &&
          buttonData.url.value &&
          buttonData.url.value.href &&
          buttonData.text &&
          buttonData.text.value && (
            <div className={styles.bottom_button__container}>
              <Link field={buttonData && buttonData.url}>
                <Text
                  className={styles.slider_button}
                  tag="div"
                  field={buttonData && buttonData.text}
                  editable={true}
                />
              </Link>
            </div>
          )}
      </div>
    </div>
  );
}
