import { MODAL_TYPE_LOADER } from 'src/constants/general';
import { Modal } from 'components/Elements/Modal/Modal';
import styles from './Loader.module.scss';
export function Loader() {
  return (
    <Modal showModal={true} type={MODAL_TYPE_LOADER}>
      <div className={styles.content_container}>
        <div className={styles.loader_container}></div>
      </div>
    </Modal>
  );
}
