import { useRef, useEffect, useState } from 'react';
import styles from './TeaserGroup.module.scss';
import { Placeholder, Text } from '@sitecore-jss/sitecore-jss-nextjs';
import { getParentClassReference } from 'src/core/utils/utils.helper';
import { CONTENT_100 } from 'src/constants/contentDivider';
import { SLIDE_WIDTH, KEY_SLIDER_TYPE } from '../../constants/general';
import { formatGroupTeaserData } from 'src/helpers/component.helper';
import { KEY_GROUPTEASER_HEADLINE } from 'src/constants/general';
import SlickSlider from 'src/components/Elements/SlickSlider/SlickSlider';

export default function GroupTeaser(props: any) {
  // const { sitecoreContext } = useSitecoreContext();
  // const isExperienceEditor = sitecoreContext && sitecoreContext.pageEditing;
  const teaserData = formatGroupTeaserData(props);
  const teaserSliderContainerRef = useRef<any>('');
  /**
   * @important This code needs to be used in every components inorder to get the content dividers reference
   * @important Also set the reference (ref) and className to the html wrapper as implemented below
   */
  // starts
  const nodeRef = useRef(null);
  const [parentRef, setParentRef] = useState<any>(null);

  useEffect(() => {
    const child: any = nodeRef.current;
    if (child !== null || child !== undefined) {
      setParentRef(getParentClassReference(child));
    } else {
      setParentRef(CONTENT_100);
    }
  }, []);

  const getTilesToShow = () => {
    if (
      teaserSliderContainerRef &&
      teaserSliderContainerRef.current &&
      teaserSliderContainerRef.current.clientWidth
    ) {
      return Math.ceil(
        (teaserSliderContainerRef &&
          teaserSliderContainerRef.current &&
          teaserSliderContainerRef.current.clientWidth) / SLIDE_WIDTH
      );
    } else {
      return 1;
    }
  };

  return (
    <div ref={nodeRef} className={styles[parentRef]}>
      <div ref={teaserSliderContainerRef} className={`${styles.group_teaser_items__container}`}>
        {teaserData && teaserData.sliderview ? (
          <SlickSlider
            data={props}
            headingData={teaserData && teaserData[KEY_GROUPTEASER_HEADLINE]}
            numberOfTiles={teaserData && teaserData.numberOfTiles}
            type={KEY_SLIDER_TYPE.GROUP_TEASER}
            tilesToShow={getTilesToShow()}
            placeHolderName="teaser-groupTeaser"
            showTopNav={true}
            isVariableWidth={true}
            isAdaptiveHeight={false}
          />
        ) : teaserData && teaserData.horizontalView ? (
          <>
            <div className={styles.teaser_headline_container}>
              <Text
                field={teaserData && teaserData[KEY_GROUPTEASER_HEADLINE]}
                editable={true}
                tag="div"
                className={styles.teaser_heading}
              />
            </div>
            <div className={styles.items__horizontal}>
              <Placeholder
                name="teaser-groupTeaser"
                data-slider={true}
                rendering={props.rendering}
              />
            </div>
          </>
        ) : (
          <>
            <div className={styles.teaser_headline_container}>
              <Text
                field={teaserData && teaserData[KEY_GROUPTEASER_HEADLINE]}
                editable={true}
                tag="div"
                className={styles.teaser_heading}
              />
            </div>
            <div className={styles.items__horizontal}>
              <Placeholder
                name="teaser-groupTeaser"
                data-slider={false}
                rendering={props.rendering}
              />
            </div>
          </>
        )}
      </div>
    </div>
  );
}
