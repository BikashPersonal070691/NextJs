import { TextInputConfig } from '../../../models/textInput';
export function TextInput({
  placeHolder,
  className,
  id,
  value,
  name,
  onChange,
  onKeyPress,
}: TextInputConfig) {
  return (
    <>
      <input
        type="text"
        autoComplete="off"
        className={className}
        id={id}
        placeholder={placeHolder}
        value={value}
        name={name}
        onChange={onChange}
        onKeyPress={onKeyPress}
      />
    </>
  );
}
