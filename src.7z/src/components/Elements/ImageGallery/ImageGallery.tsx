import { useEffect, useRef, useState, useCallback } from 'react';
// import { Placeholder, useSitecoreContext, RichText } from '@sitecore-jss/sitecore-jss-nextjs';
import { RichText, Text } from '@sitecore-jss/sitecore-jss-nextjs';
import SlickSlider from 'src/components/Elements/SlickSlider/SlickSlider';
import { formatImageGalleryData } from 'src/helpers/component.helper';
import { KEY_SLIDER_TYPE, KEY_IG_MAIN_TEXT, KEY_GALLERY_CAPTION } from 'src/constants/general';
import { getParentClassReference } from 'src/core/utils/utils.helper';
import { CONTENT_100 } from 'src/constants/contentDivider';
import { Modal } from 'components/Elements/Modal/Modal';
import { GalleryProvider } from 'src/contexts/GalleryContext';
import styles from './ImageGallery.module.scss';

export default function ImageGallery(props: any) {
  // const { sitecoreContext } = useSitecoreContext();
  // const isExperienceEditor = sitecoreContext && sitecoreContext.pageEditing;
  /**
   * @important This code needs to be used in every components inorder to get the content dividers reference
   * @important Also set the reference (ref) and className to the html wrapper as implemented below
   */
  // starts
  const nodeRef = useRef(null);
  const [parentRef, setParentRef] = useState<any>(null);
  const [showModal, setShowModal] = useState<any>(false);
  useEffect(() => {
    const child: any = nodeRef.current;
    if (child !== null || child !== undefined) {
      setParentRef(getParentClassReference(child));
    } else {
      setParentRef(CONTENT_100);
    }
  }, []);
  const formattedData: any = formatImageGalleryData(props);
  const hideOverlay = useCallback(() => {
    setShowModal(false);
  }, [showModal]);

  return (
    <GalleryProvider value={{ setShowModal }}>
      <div ref={nodeRef} className={styles[parentRef]}>
        <div className={styles.img_gallery__container}>
          <div className={styles.img_gallery_inner__container}>
            <div className={styles.img_gallery_inner__image} id="gallery_small">
              <SlickSlider
                isSliderSmall={true}
                data={props}
                numberOfTiles={formattedData && formattedData.numberOfImages}
                type={KEY_SLIDER_TYPE.IMAGEGALLERY}
                tilesToShow={1}
                showSideNav={true}
                showDots={true}
                placeHolderName="image-gallery"
                isImageEnlarge={true}
                isAdaptiveHeight={true}
                isVariableWidth={false}
              />
              <div className={styles.img_small__caption}>
                <Text field={formattedData && formattedData[KEY_GALLERY_CAPTION]} />
              </div>
            </div>
            <div className={styles.img_gallery_inner__content}>
              <RichText field={formattedData && formattedData[KEY_IG_MAIN_TEXT]} />
            </div>
          </div>
          <Modal showModal={showModal}>
            <div style={{ display: 'block', width: '100%' }}>
              <SlickSlider
                data={props}
                numberOfTiles={formattedData && formattedData.numberOfImages}
                type={KEY_SLIDER_TYPE.IMAGEGALLERY}
                tilesToShow={1}
                showSideNav={true}
                showDots={false}
                placeHolderName="image-gallery"
                isSliderThumbnail={true}
                isOverlaySlider={true}
                isImageEnlarge={false}
                overlayCloseEvent={() => hideOverlay()}
                isVariableWidth={false}
                isAdaptiveHeight={true}
              />
            </div>
          </Modal>
        </div>
      </div>
    </GalleryProvider>
  );
}
