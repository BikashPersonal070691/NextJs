import { useEffect, useState } from 'react';
import styles from './CalendarSection.module.scss';
import CalendarTask from 'components/CalendarTask/CalendarTask';

export default function TaskRow() {
  const [calendarSectionData] = useState<any>([
    {
      startMonth: 2,
      length: 1,
      name: 'text',
      buttonlink: '',
      bgColor: '#66b51226',
    },
  ]);
  useEffect(() => {}, []);

  return (
    <div className={styles.calendar_row_wrapper}>
      <div className={styles.calendar_row_title}>
        <div className={styles.title_image}>
          <div className={styles.calendar_row_image_talent} />
        </div>
        <div className={styles.title_text}>Talent Development & Performance</div>
      </div>
      <div className={styles.calendar_row_container}>
        {calendarSectionData &&
          calendarSectionData.length > 0 &&
          calendarSectionData.map(() => {
            return <CalendarTask />;
          })}
      </div>
    </div>
  );
}
