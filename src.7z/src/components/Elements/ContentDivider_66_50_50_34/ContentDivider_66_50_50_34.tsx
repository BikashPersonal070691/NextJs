import { useRef, useEffect, useState } from 'react';
import { Field } from '@sitecore-jss/sitecore-jss-nextjs';
import { ComponentProps } from 'lib/component-props';
import { StyleguideSpecimenFields } from 'lib/component-props/styleguide';
import { Placeholder } from '@sitecore-jss/sitecore-jss-nextjs';
import { CONTENT_34, CONTENT_66, CD_66_50_50_34 } from 'src/constants/contentDivider';
import { formatContentDividerData } from 'src/helpers/contentDivider.helper';
import styles from './ContentDivider_66_50_50_34.module.scss';

type TwoColumnContainerProps = ComponentProps &
  StyleguideSpecimenFields & {
    fields: {
      heading: Field<string>;
    };
  };

const ContentDivider_66_50_50_34 = (props: TwoColumnContainerProps): JSX.Element => {
  const [isParentIdExists, setIsParentIdExists] = useState<boolean>(false);
  const currentElement: any = useRef(null);
  const contentDividerBg = formatContentDividerData(props);
  /**
   * @description to check if parent node has id . If parent has id it this current content divider is a nested content divider.
   */
  useEffect(() => {
    currentElement &&
    currentElement.current &&
    currentElement.current.parentNode &&
    currentElement.current.parentNode.id &&
    currentElement.current.parentNode.id !== undefined &&
    currentElement.current.parentNode.id !== ''
      ? setIsParentIdExists(true)
      : setIsParentIdExists(false);
  }, []);

  return (
    <section
      className={`${styles.divider_66_50_50_34__container} ${
        !isParentIdExists ? styles.divider_66_50_50_34_container__bg : ''
      }`}
      ref={currentElement}
      style={{
        backgroundColor:
          contentDividerBg && contentDividerBg.bgColor && contentDividerBg.bgColor !== ''
            ? contentDividerBg.bgColor
            : 'white',
      }}
    >
      <div className={styles.divider_66_50_50_34__wrapper}>
        <div className={styles.divider_66_50_50__container} id={CONTENT_66}>
          <div className={`${styles.divider_top_66__wrapper} ${styles.min_height_1}`}>
            <Placeholder name={CD_66_50_50_34.PH_66_50_50_34_TOP_66} rendering={props.rendering} />
          </div>
          <div className={styles.divider_bottom_50_50__wrapper}>
            <div className={`${styles.divider_left_50} ${styles.min_height_1}`}>
              <Placeholder
                name={CD_66_50_50_34.PH_66_50_50_34_BOTTOM_LEFT_50}
                rendering={props.rendering}
              />
            </div>
            <div className={`${styles.divider_right_50} ${styles.min_height_1}`}>
              <Placeholder
                name={CD_66_50_50_34.PH_66_50_50_34_BOTTOM_RIGHT_50}
                rendering={props.rendering}
              />
            </div>
          </div>
        </div>

        <div className={`${styles.divider_34__container} ${styles.min_height_1}`} id={CONTENT_34}>
          <Placeholder
            name={CD_66_50_50_34.PH_66_50_50_34_SIDE_RIGHT_34}
            rendering={props.rendering}
          />
        </div>
      </div>
    </section>
  );
};

export default ContentDivider_66_50_50_34;
