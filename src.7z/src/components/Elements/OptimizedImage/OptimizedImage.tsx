import { Image } from '@sitecore-jss/sitecore-jss-nextjs';
import { getPathFromUrl, getCurrentWindowWidth } from 'src/core/utils/utils.helper';

export function OptimizedImage(props: any) {
  const { imageData, scaleData, isBgColorAvailable, customClass, isNormalMode } = props;

  const getScaleData = (param: any, type: any) => {
    let data: any = scaleData.find((o: any) => o.mWidth === param);
    if (data && Object.keys(data).length !== 0) {
      if (type === 'width') {
        return data && data.width;
      } else if (type === 'height') {
        return data && data.height;
      } else {
        return null;
      }
    } else {
      return null;
    }
  };

  const getImageUrl = (url: string, imgWidth: any, imgHeight: any, backgroundColor: any) => {
    const finalUrl = getPathFromUrl(url);

    if (finalUrl !== '') {
      return `${finalUrl}${imgWidth || imgHeight ? '?' : ''}${
        imgWidth ? 'w=' + imgWidth + '&' : ''
      }${imgHeight ? 'h=' + imgHeight + '&' : ''}${backgroundColor ? 'bc=fff' : ''}`;
    } else {
      return '';
    }
  };

  const getScaleDataWidth = () => {
    const currWidth: any = getCurrentWindowWidth();
    if (currWidth && currWidth <= 767) {
      return 767;
    } else if (currWidth && currWidth > 767 && currWidth <= 1019) {
      return 1019;
    } else if (currWidth && currWidth > 1019) {
      return 1020;
    } else {
      return 1020;
    }
  };
  return (
    <>
      {!isNormalMode ? (
        <picture>
          <source
            media="(max-width: 767px)"
            srcSet={getImageUrl(
              imageData && imageData.value && imageData.value.src,
              getScaleData(767, 'width'),
              getScaleData(767, 'height'),
              isBgColorAvailable
            )}
          />
          <source
            media="(max-width: 1019px)"
            srcSet={getImageUrl(
              imageData && imageData.value && imageData.value.src,
              getScaleData(1019, 'width'),
              getScaleData(1019, 'height'),
              isBgColorAvailable
            )}
          />
          <source
            media="(min-width: 1020px)"
            srcSet={getImageUrl(
              imageData && imageData.value && imageData.value.src,
              getScaleData(1020, 'width'),
              getScaleData(1020, 'height'),
              isBgColorAvailable
            )}
          />
          <Image field={imageData} editable={true} className={customClass} />
        </picture>
      ) : (
        <img
          src={getImageUrl(
            imageData && imageData.value && imageData.value.src,
            getScaleData(getScaleDataWidth(), 'width'),
            getScaleData(getScaleDataWidth(), 'height'),
            isBgColorAvailable
          )}
        />
      )}
    </>
  );
}
