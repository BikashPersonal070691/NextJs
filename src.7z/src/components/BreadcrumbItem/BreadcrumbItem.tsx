import styles from './BreadcrumbItem.module.scss';

export default function BreadCrumbItem(props: any) {
  const { text, url, isLast, width } = props;
  return (
    <li className={styles.breadc_item} style={{ width: width == 0 ? 'auto' : width }}>
      {
        <a className={isLast ? styles.breadc_link : styles.breadc_link_middle} href={url}>
          {' '}
          {text}{' '}
        </a>
      }
    </li>
  );
}
