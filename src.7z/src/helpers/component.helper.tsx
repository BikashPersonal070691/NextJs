// import { COLOR_CODES } from 'src/constants/workFlow';
import {
  KEY_LINKBOX_LINK_DESCRIPTION,
  KEY_LINKBOX_LINK_TEXT,
  KEY_LINKBOX_LINK_URL,
  KEY_VIDEOBOX_HEADING,
  KEY_VIDEOBOX_DESCRIPTION,
  KEY_VIDEOBOX_TYPE,
  KEY_VIDEOBOX_CAPTION,
  KEY_VIDEOBOX_SRC,
  KEY_VIDEOBOX_URL,
  KEY_VIDEO_THUMBNAIL,
  KEY_VIDEOBOX_TARGET,
  KEY_LINKBOX_LINK_KEY,
  // KEY_IMAGE_BASE_URL,
  KEY_VIDEOBOX_ISHIGHLIGHT,
  KEY_VIDEOBOX_ISDURATION,
  KEY_VIDEOBOX_TIME,
  KEY_LINKBOX_LINK_BGCOLOR,
  KEY_LINKBOX_LINK_HEADING,
  KEY_LINKBOX_LINK_HEADING_DESCRIPTION,
  KEY_VIDEOBOX_INTERNAL,
  KEY_VIDEOBOX_EXTERNAL,
  KEY_TEXBOX_IMGCAPTION_ENLARGED,
  KEY_TEXBOX_FLOAT_RIGHT,
  KEY_TEXBOX_HEADLINE,
  KEY_TEXBOX_IMGCAPTION,
  KEY_TEXBOX_SUBHEADLINE,
  KEY_TEXBOX_TEXT,
  KEY_TEXBOX_ABSTRACT_TEXT,
  KEY_TEXBOX_ENLARGE_IMAGE_ONLOAD,
  KEY_TEXBOX_ENLARGED_IMAGE,
  KEY_TEXBOX_IMAGE,
  KEY_TEXTBOX_ANCHOR,
  COLOR_PALLETE,
  WIDE_IMAGE_CAPTION,
  WIDE_IMAGE_HEADLINE,
  WIDE_IMAGE_SRC,
  TEASER_COLOR_PALLETE,
  KEY_TEASER_BG_COLOR,
  KEY_TEASER_TEASER_CAPTION,
  KEY_TEASER_HEADLINE,
  KEY_TEASER_IMAGE,
  KEY_TEASER_MAIN_LNK,
  KEY_TEASER_TEXT,
  KEY_TEASER_ALIGN_VERTICAL,
  KEY_TEASER_IS_HIGHLIGHTED,
  KEY_TEASER_SHOW_SUB_LINKS,
  KEY_TEASER_SHOW_TEXT,
  KEY_TEASER_SUB_LINKS,
  KEY_GROUPTEASER_HEADLINE,
  KEY_GROUPTEASER_HORIZONTAL_VIEW,
  KEY_GROUPTEASER_SLIDER_VIEW,
  // KEY_GROUPTEASER_TEASERDATA,
  ACCORDION_OPEN,
  ACCORDION_ITEMS,
  ACCORDION_ITEM_TITLE,
  TAB_ITEM_TITLE,
  ACCORDION_ITEM_OPEN_DEFAULT,
  DEFAULT_COLOR_FOR_TIMELINE,
  DEFAULT_DATE_VALUE,
  KEY_QUOTE_BG_COLOR,
  KEY_QUOTE_SIGNATURE,
  KEY_QUOTE_AUTHOR_IMG,
  KEY_QUOTE_AUTHOR_NAME,
  KEY_QUOTE_JOB_DESC,
  KEY_QUOTE_VALUE,
  COLOR_PALLETE_QUOTE,
  KEY_FEEDBACK_QUESTION,
  KEY_FEEDBACK_QUESTION_MAIN,
  KEY_FEEDBACK_HEADING,
  KEY_COOKIE_PRIVACY_LINK,
  KEY_ANCHOR_DATA,
  KEY_ANCHOR_DATA_TAG,
  KEY_ANCHOR_HEADING,
  KEY_IG_THUMBNAIL,
  KEY_IG_IMAGE_CAPTION,
  KEY_IG_IMAGE,
  KEY_IG_MAIN_TEXT,
  KEY_VIDEO_GALLERY_HEADLINE,
  KEY_GALLERY_CAPTION,
  KEY_KTC_IMAGE,
  KEY_KTC_HEADLINE,
  KEY_KTC_CAPTION,
  KEY_KTC_IS_HIGHLIGHTED,
  KEY_KTC_HORIZONTAL,
  KEY_KTC_API_ENDPOINT,
  KEY_API_FIELD,
  KEY_KTC_HIDE_EYE_BUTTON,
  KEY_KTC_API_NAME,
  KEY_KTC_IMAGES,
  KEY_VIDEOBOX_MEDIA,
} from '../constants/general';
import {
  findColorPallete,
  getMonthName,
  isFutureEvent,
  richTextFix
  // stripTags,
} from 'src/core/utils/utils.helper';
/**
 * @description formatting layout api response for linkbox component
 * @param data {object}
 * @returns {object}
 */

const formatLinkBoxData = (data: any) => {
  const fieldData = data && data.fields;
  const paramsData = data && data.params;
  const listingData: any = {
    Title: fieldData && fieldData.Title,
    [KEY_LINKBOX_LINK_HEADING]: fieldData && fieldData[KEY_LINKBOX_LINK_HEADING],
    [KEY_LINKBOX_LINK_HEADING_DESCRIPTION]:
      fieldData && fieldData[KEY_LINKBOX_LINK_HEADING_DESCRIPTION],
    bgColor:
      paramsData &&
      paramsData[KEY_LINKBOX_LINK_BGCOLOR] &&
      paramsData[KEY_LINKBOX_LINK_BGCOLOR] !== ''
        ? findColorPallete(COLOR_PALLETE, paramsData[KEY_LINKBOX_LINK_BGCOLOR])
        : '',
    listData:
      fieldData &&
      fieldData[KEY_LINKBOX_LINK_KEY] &&
      Object.keys(fieldData[KEY_LINKBOX_LINK_KEY]).length !== 0 &&
      Object.keys(fieldData[KEY_LINKBOX_LINK_KEY]).map((item: any) => {
        const itemFieldsData = fieldData[KEY_LINKBOX_LINK_KEY][item].fields;
        return {
          [KEY_LINKBOX_LINK_TEXT]: itemFieldsData && itemFieldsData[KEY_LINKBOX_LINK_TEXT],
          [KEY_LINKBOX_LINK_DESCRIPTION]:
            itemFieldsData && itemFieldsData[KEY_LINKBOX_LINK_DESCRIPTION],
          [KEY_LINKBOX_LINK_URL]: itemFieldsData && itemFieldsData[KEY_LINKBOX_LINK_URL],
          linkTarget:
            itemFieldsData &&
            itemFieldsData[KEY_LINKBOX_LINK_URL] &&
            itemFieldsData[KEY_LINKBOX_LINK_URL].value &&
            itemFieldsData[KEY_LINKBOX_LINK_URL].value.target && 
            itemFieldsData[KEY_LINKBOX_LINK_URL].value.target == "_blank"
              ? true
              : false,
        };
      }),
  };
  return listingData;
};
/**
 * @description formatting layout api response for videobox component
 * @param data {object}
 * @returns {object}
 */
const formatVideoBoxData = (data: any) => {
  const fieldData = data && data.fields;
  const paramsData = data && data.params;
  const videoUrlData =
    fieldData && fieldData[KEY_VIDEOBOX_URL] && fieldData[KEY_VIDEOBOX_URL].value;
  const listingData: any = {
    [KEY_VIDEOBOX_HEADING]:
      fieldData && fieldData[KEY_VIDEOBOX_HEADING] && fieldData[KEY_VIDEOBOX_HEADING],
    [KEY_VIDEOBOX_DESCRIPTION]:
      fieldData && fieldData[KEY_VIDEOBOX_DESCRIPTION] && fieldData[KEY_VIDEOBOX_DESCRIPTION],
    videoType: videoUrlData && videoUrlData[KEY_VIDEOBOX_TYPE],
    [KEY_VIDEOBOX_CAPTION]: fieldData && fieldData[KEY_VIDEOBOX_CAPTION],
    videoSrc:
      videoUrlData &&
      videoUrlData[KEY_VIDEOBOX_SRC] &&
      videoUrlData[KEY_VIDEOBOX_TYPE] === KEY_VIDEOBOX_INTERNAL
        ? videoUrlData[KEY_VIDEOBOX_SRC]
        : videoUrlData &&
          videoUrlData[KEY_VIDEOBOX_SRC] &&
          videoUrlData[KEY_VIDEOBOX_TYPE] === KEY_VIDEOBOX_EXTERNAL
        ? videoUrlData[KEY_VIDEOBOX_SRC]
        : videoUrlData &&
          videoUrlData[KEY_VIDEOBOX_SRC] && videoUrlData[KEY_VIDEOBOX_TYPE] === KEY_VIDEOBOX_MEDIA?videoUrlData[KEY_VIDEOBOX_SRC]:'',

    // videoThumbnail:
    //   fieldData &&
    //   fieldData[KEY_VIDEO_THUMBNAIL] &&
    //   fieldData[KEY_VIDEO_THUMBNAIL].value &&
    //   fieldData[KEY_VIDEO_THUMBNAIL].value.src
    //     ? KEY_IMAGE_BASE_URL + fieldData[KEY_VIDEO_THUMBNAIL].value.src
    //     : // ? 'http://localhost:8080/Capture.png'
    //       // fieldData[KEY_VIDEO_THUMBNAIL].value.src // only for demo
    //       '',
    [KEY_VIDEO_THUMBNAIL]:
      fieldData && fieldData[KEY_VIDEO_THUMBNAIL] ? fieldData[KEY_VIDEO_THUMBNAIL] : '',
    // [KEY_VIDEO_THUMBNAIL]: {
    //   value: {
    //     src: 'http://localhost:8080/Capture.jpg',
    //   },
    // },
    videoThumbnailAlt:
      fieldData &&
      fieldData[KEY_VIDEO_THUMBNAIL] &&
      fieldData[KEY_VIDEO_THUMBNAIL].value &&
      fieldData[KEY_VIDEO_THUMBNAIL].value.alt
        ? fieldData[KEY_VIDEO_THUMBNAIL].value.alt
        : '',
    videoTarget: videoUrlData && videoUrlData[KEY_VIDEOBOX_TARGET],
    videoHighlight: paramsData && paramsData[KEY_VIDEOBOX_ISHIGHLIGHT],
    videoDuration:
      paramsData && paramsData[KEY_VIDEOBOX_ISDURATION]
        ? fieldData && fieldData[KEY_VIDEOBOX_TIME] && fieldData[KEY_VIDEOBOX_TIME].value
        : '',
    videoAnchor: fieldData && fieldData.Anchor && fieldData.Anchor.value,
  };
  return listingData;
};

const formatTextBoxData = (data: any) => {
  const fieldData = data && data;



  const listingData: any = {
    [KEY_TEXBOX_IMGCAPTION_ENLARGED]: {
      value:
        fieldData &&
        fieldData[KEY_TEXBOX_IMGCAPTION_ENLARGED] &&
        fieldData[KEY_TEXBOX_IMGCAPTION_ENLARGED],
    },
    floatRight:
      fieldData && fieldData[KEY_TEXBOX_FLOAT_RIGHT] && fieldData[KEY_TEXBOX_FLOAT_RIGHT].value,
    [KEY_TEXBOX_HEADLINE]: {
      value: fieldData && fieldData[KEY_TEXBOX_HEADLINE] && fieldData[KEY_TEXBOX_HEADLINE],
    },
    [KEY_TEXBOX_IMGCAPTION]: {
      value: fieldData && fieldData[KEY_TEXBOX_IMGCAPTION] && fieldData[KEY_TEXBOX_IMGCAPTION],
    },
    [KEY_TEXBOX_SUBHEADLINE]: {
      value: fieldData && fieldData[KEY_TEXBOX_SUBHEADLINE] && fieldData[KEY_TEXBOX_SUBHEADLINE],
    },
    [KEY_TEXBOX_TEXT]: {
      value: fieldData && fieldData[KEY_TEXBOX_TEXT] && richTextFix(fieldData[KEY_TEXBOX_TEXT]),
    },
    [KEY_TEXBOX_ABSTRACT_TEXT]: {
      value:
        fieldData && fieldData[KEY_TEXBOX_ABSTRACT_TEXT] && fieldData[KEY_TEXBOX_ABSTRACT_TEXT],
    },
    [KEY_TEXBOX_ENLARGE_IMAGE_ONLOAD]:
      fieldData &&
      fieldData[KEY_TEXBOX_ENLARGE_IMAGE_ONLOAD] &&
      fieldData[KEY_TEXBOX_ENLARGE_IMAGE_ONLOAD].value,
    [KEY_TEXBOX_ENLARGED_IMAGE]: {
      value:
        fieldData && fieldData[KEY_TEXBOX_ENLARGED_IMAGE] && fieldData[KEY_TEXBOX_ENLARGED_IMAGE],
    },
    [KEY_TEXBOX_IMAGE]: fieldData && fieldData[KEY_TEXBOX_IMAGE] && fieldData[KEY_TEXBOX_IMAGE],
    [KEY_TEXTBOX_ANCHOR]:
      fieldData && fieldData[KEY_TEXTBOX_ANCHOR] && fieldData[KEY_TEXTBOX_ANCHOR].value,
  };
  return listingData;
};

const formatTeaserData = (data: any, isExperienceEditor: any) => {
  const fieldData = data.fields;
  const paramsData = data.params;

  const listingData: any = {
    [KEY_TEASER_HEADLINE]: {
      value: fieldData && fieldData[KEY_TEASER_HEADLINE] && fieldData[KEY_LINKBOX_LINK_HEADING],
    },
    [KEY_TEASER_TEASER_CAPTION]:
      fieldData && fieldData[KEY_TEASER_TEASER_CAPTION] && fieldData[KEY_TEASER_TEASER_CAPTION],

    bgColor:
      fieldData && fieldData[KEY_TEASER_BG_COLOR] && fieldData[KEY_TEASER_BG_COLOR].name !== ''
        ? findColorPallete(TEASER_COLOR_PALLETE, fieldData[KEY_TEASER_BG_COLOR].name)
        : '',
    [KEY_TEASER_IMAGE]: fieldData && fieldData[KEY_TEASER_IMAGE] && fieldData[KEY_TEASER_IMAGE],
    // [KEY_TEASER_IMAGE]: {
    //   value: {
    //     src: 'http://localhost:8080/Capture.jpg',
    //     alt: '',
    //   },
    // },
    [KEY_TEASER_MAIN_LNK]: fieldData && fieldData[KEY_TEASER_MAIN_LNK],
    [KEY_TEASER_TEXT]: {
      value: fieldData && fieldData[KEY_TEASER_TEXT] && richTextFix(fieldData[KEY_TEASER_TEXT]),
    },
    alignVertical:
      paramsData &&
      paramsData[KEY_TEASER_ALIGN_VERTICAL] &&
      paramsData[KEY_TEASER_ALIGN_VERTICAL] == '1'
        ? true
        : false,
    isHighlighted: paramsData && paramsData[KEY_TEASER_IS_HIGHLIGHTED] ? true : false,

    showSubLinks: paramsData && paramsData[KEY_TEASER_SHOW_SUB_LINKS] ? true : false,
    showText: (paramsData && paramsData[KEY_TEASER_SHOW_TEXT]) == 1 ? true : false,
    [KEY_TEASER_SUB_LINKS]:
      fieldData && fieldData[KEY_TEASER_SUB_LINKS] && fieldData[KEY_TEASER_SUB_LINKS],

    teaserAnchor: fieldData && fieldData.Anchor && fieldData.Anchor.value,
    isContentAvailable: isExperienceEditor
      ? true
      : (fieldData &&
          fieldData[KEY_TEASER_HEADLINE] &&
          fieldData[KEY_LINKBOX_LINK_HEADING].value &&
          fieldData[KEY_LINKBOX_LINK_HEADING].value !== '') ||
        (fieldData &&
          fieldData[KEY_TEASER_TEXT] &&
          fieldData[KEY_TEASER_TEXT].value &&
          fieldData[KEY_TEASER_TEXT].value !== '') ||
        (fieldData &&
          fieldData[KEY_TEASER_SUB_LINKS] &&
          fieldData[KEY_TEASER_SUB_LINKS].value &&
          fieldData[KEY_TEASER_SUB_LINKS].value !== '')
      ? true
      : false,
  };

  return listingData;
};

const formatGroupTeaserData = (data: any) => {
  const fieldData = data && data.fields;
  const placeholderData = data && data.rendering && data.rendering.placeholders;
  const listingData: any = {
    [KEY_GROUPTEASER_HEADLINE]:
      fieldData && fieldData[KEY_GROUPTEASER_HEADLINE] && fieldData[KEY_GROUPTEASER_HEADLINE],
    sliderview:
      fieldData &&
      fieldData[KEY_GROUPTEASER_SLIDER_VIEW] &&
      fieldData[KEY_GROUPTEASER_SLIDER_VIEW].value,
    horizontalView:
      fieldData &&
      fieldData[KEY_GROUPTEASER_HORIZONTAL_VIEW] &&
      fieldData[KEY_GROUPTEASER_HORIZONTAL_VIEW].value,
    numberOfTiles:
      placeholderData &&
      placeholderData['teaser-groupTeaser'] &&
      placeholderData['teaser-groupTeaser'].length,
  };

  return listingData;
};

/**
 * @description formatting layout api response for wide image component
 * @param data {Object}
 * @returns {Object}
 */

const formatWideImageData = (data: any) => {
  const fieldData = data && data.fields;

  const listingData: any = {
    imageSrc: fieldData && fieldData[WIDE_IMAGE_SRC],
    caption: fieldData && fieldData[WIDE_IMAGE_CAPTION],
    headline: fieldData && fieldData[WIDE_IMAGE_HEADLINE],
  };
  return listingData;
};

/**
 * @description formatting layout api response for work flow timeline component
 * @param data {object}
 * @returns {object}
 */
const formatWorkFlowTimelineData = (fieldData: any) => {
  // const fieldData = data && data.fields;

  const listingData: any = {
    heading: {
      value: fieldData && fieldData.Headline && fieldData.Headline.value,
    },
    subHeading: {
      value: fieldData && fieldData.SubHeading && fieldData.SubHeading.value,
    },
    listData:
      fieldData &&
      fieldData.Events &&
      fieldData.Events.map((item: any) => {
        return {
          eventName: {
            value:
              item.fields && item.fields.Name && item.fields.Name.value
                ? item.fields.Name.value
                : '',
          },
          isTaskCompleted:
            item.fields && item.fields.IsTaskCompleted && item.fields.IsTaskCompleted.value
              ? item.fields.IsTaskCompleted.value
              : true,
          isWorkFlowItem:
            item.fields && item.fields.IsWorkFlowItem && item.fields.IsWorkFlowItem.value
              ? item.fields.IsWorkFlowItem.value
              : false,
          startMonthName: {
            value:
              item.fields &&
              item.fields['Start Date'] &&
              item.fields['Start Date'].value &&
              item.fields['Start Date'].value !== DEFAULT_DATE_VALUE
                ? getMonthName(item.fields['Start Date'].value)
                : '',
          },
          endMonthName: {
            value:
              item.fields &&
              item.fields['End Date'] &&
              item.fields['End Date'].value &&
              item.fields['End Date'].value !== DEFAULT_DATE_VALUE
                ? getMonthName(item.fields['End Date'].value)
                : '',
          },
          labelText: {
            value: item && item.fields && item.fields.Label ? item.fields.Label.value : '',
          },
          labelColor:
            item && item.fields && item.fields.LabelColour && item.fields.LabelColour.value
              ? item.fields.LabelColour.value
              : DEFAULT_COLOR_FOR_TIMELINE,
          eventType:
            item.fields && item.fields['Start Date'] && item.fields['End Date']
              ? isFutureEvent(item.fields['Start Date'].value, item.fields['End Date'].value)
              : true,
          placeholderName:
            item && item.fields && item.fields.PlaceholderName && item.fields.PlaceholderName.value
              ? item.fields.PlaceholderName.value
              : '',
        };
      }),
  };
  return listingData;
};

const formatWorkFlowList = (arr: any) => {
  for (let i = 0; i < arr.length; i++) {
    if (arr[i].isWorkFlowItem === true) {
      for (let j = i; j < arr.length; j++) {
        if (arr[j] && arr[j].isWorkFlowItem === false) {
          arr[i].isLine = true;
          break;
        } else {
          arr[i].isLine = false;
        }
      }
    } else {
      for (let j = i + 1; j < arr.length; j++) {
        if (arr[j] && arr[j].isWorkFlowItem === false) {
          arr[i].isLine = true;
          break;
        } else {
          arr[i].isLine = false;
        }
      }
    }
  }
  return arr;
};

/**
 * @description formatting layout api response for accordion component
 * @param data {object}
 * @returns {object}
 */
const formatAccordionData = (data: any) => {
  const fieldData = data && data.fields;

  const listingData: any = {
    openAccordion: fieldData && fieldData[ACCORDION_OPEN] && fieldData[ACCORDION_OPEN].value,
    accordionItems:
      fieldData &&
      fieldData[ACCORDION_ITEMS] &&
      fieldData[ACCORDION_ITEMS].map((item: any) => {
        const itemFieldsData = item && item.fields;
        return {
          [ACCORDION_ITEM_TITLE]: itemFieldsData && itemFieldsData[ACCORDION_ITEM_TITLE],
          [TAB_ITEM_TITLE]: itemFieldsData && itemFieldsData[TAB_ITEM_TITLE],
          itemOpenDefault:
            itemFieldsData &&
            itemFieldsData[ACCORDION_ITEM_OPEN_DEFAULT] &&
            itemFieldsData[ACCORDION_ITEM_OPEN_DEFAULT].value,
          accordionAnchor: itemFieldsData && itemFieldsData.Anchor && itemFieldsData.Anchor.value,
          placeholderName:
            itemFieldsData &&
            itemFieldsData.PlaceholderName &&
            itemFieldsData.PlaceholderName.value,
        };
      }),
  };
  return listingData;
};
/**
 *
 * @param @description format layout api response for quote component
 * @param data {Object}
 * @returns {Object}
 */
const formatQuoteData = (data: any) => {
  const fieldData = data && data.fields;
  const paramsData = data && data.params;
  const listingData: any = {
    [KEY_QUOTE_BG_COLOR]: findColorPallete(COLOR_PALLETE_QUOTE, paramsData[KEY_QUOTE_BG_COLOR]),
    [KEY_QUOTE_SIGNATURE]:
      paramsData && paramsData[KEY_QUOTE_SIGNATURE] && paramsData[KEY_QUOTE_SIGNATURE] !== undefined
        ? 1
        : 0,
    [KEY_QUOTE_AUTHOR_IMG]:
      fieldData && fieldData[KEY_QUOTE_AUTHOR_IMG] && fieldData[KEY_QUOTE_AUTHOR_IMG],
    // [KEY_QUOTE_AUTHOR_IMG]: {
    //   value: {
    //     src: 'http://localhost:8080/Capture.jpg',
    //     alt: '',
    //   },
    // },
    [KEY_QUOTE_AUTHOR_NAME]:
      fieldData && fieldData[KEY_QUOTE_AUTHOR_NAME] && fieldData[KEY_QUOTE_AUTHOR_NAME],
    [KEY_QUOTE_JOB_DESC]:
      fieldData && fieldData[KEY_QUOTE_JOB_DESC] && fieldData[KEY_QUOTE_JOB_DESC],
    [KEY_QUOTE_VALUE]: fieldData && fieldData[KEY_QUOTE_VALUE] && fieldData[KEY_QUOTE_VALUE],
  };
  return listingData;
};
/**
 *
 * @param @description format layout api response for feedback component
 * @param data {Object}
 * @returns {Object}
 */
const formatFeedbackData = (data: any) => {
  const fieldData = data && data.fields;
  // const paramsData = data && data.params;
  const listingData: any = {
    [KEY_FEEDBACK_HEADING]: fieldData && fieldData[KEY_FEEDBACK_HEADING],
    feedbackItems:
      fieldData &&
      fieldData[KEY_FEEDBACK_QUESTION_MAIN] &&
      fieldData[KEY_FEEDBACK_QUESTION_MAIN].map((item: any) => {
        const itemFieldsData = item && item.fields;
        return {
          [KEY_FEEDBACK_QUESTION]:
            itemFieldsData &&
            itemFieldsData[KEY_FEEDBACK_QUESTION] &&
            itemFieldsData[KEY_FEEDBACK_QUESTION],
          id: item && item.id,
        };
      }),
  };
  return listingData;
};

/**
 *
 * @param @description format layout api response for cookie banner component
 * @param data {Object}
 * @returns {Object}
 */
const formatCookieBannerData = (data: any) => {
  const fieldData = data && data.fields;
  const listingData: any = {
    privacyLink:
      fieldData &&
      fieldData[KEY_COOKIE_PRIVACY_LINK] &&
      fieldData[KEY_COOKIE_PRIVACY_LINK].value &&
      fieldData[KEY_COOKIE_PRIVACY_LINK].value.href,
  };
  return listingData;
};

const formatAnchorTagData = (data: any) => {
  const anchorData = data && data.fields && data.fields[KEY_ANCHOR_DATA];
  const listingData: any = {
    [KEY_ANCHOR_HEADING]: data && data.fields && data.fields[KEY_ANCHOR_HEADING],
    data:
      anchorData &&
      Object.keys(anchorData).map((item: any) => {
        const itemFieldsData = anchorData[item];
        return {
          linkText:
            itemFieldsData &&
            itemFieldsData.fields &&
            itemFieldsData.fields.Text &&
            itemFieldsData.fields.Text.value,
          linkHref:
            itemFieldsData &&
            itemFieldsData.fields &&
            itemFieldsData.fields[KEY_ANCHOR_DATA_TAG] &&
            itemFieldsData.fields[KEY_ANCHOR_DATA_TAG].value,
        };
      }),
  };
  return listingData;
};
const formatBreadCrumbItemsData = (data: any) => {
  const innerItemsArr: any = [data && data.FirstBC, data && data.SecondBC];
  if (data && data.ListData && data.ListData.length !== 0) {
    data.ListData.map((item: any) => {
      innerItemsArr.push(item.Text.trim());
    });
  }
  if (data && data.LastBC) {
    innerItemsArr.push(data.LastBC.trim());
  }
  return innerItemsArr;
};
const formatClusterNavData = (data: any, breadCrumbs: any) => {
  const formattedData = data.map((item: any) => {
    let testData = { ...item };
    for (let i = 0; i < breadCrumbs.length; i++) {
      if (testData.NavigationTitle == breadCrumbs[i]) {
        testData = { ...testData, isSelected: true };
        break;
      }
    }
    return testData;
  });
  return formattedData;
};

/** @description function for format image gallery data */
const formatImageGalleryData = (data: any) => {
  const fieldData = data && data.fields;
  const placeholderData = data && data.rendering && data.rendering.placeholders;
  const formattedData: any = {
    [KEY_IG_MAIN_TEXT]: fieldData && fieldData[KEY_IG_MAIN_TEXT],
    numberOfImages:
      placeholderData &&
      placeholderData['image-gallery'] &&
      placeholderData['image-gallery'].length &&
      placeholderData['image-gallery'].length !== 0
        ? placeholderData['image-gallery'].length
        : 0,
    [KEY_GALLERY_CAPTION]: fieldData && fieldData[KEY_GALLERY_CAPTION],
  };
  return formattedData;
};

/** @description function for format image gallery items data */
const formatImageGalleryItemsData = (data: any) => {
  const fieldData = data && data.fields;

  const formattedData: any = {
    [KEY_IG_THUMBNAIL]: fieldData && fieldData[KEY_IG_THUMBNAIL],
    // [KEY_IG_THUMBNAIL]: {
    //   value: {
    //     src: 'http://localhost:8080/Capture.jpg',
    //     alt: '',
    //   },
    // },
    [KEY_IG_IMAGE_CAPTION]: fieldData && fieldData[KEY_IG_IMAGE_CAPTION],
    [KEY_IG_IMAGE]: fieldData && fieldData[KEY_IG_IMAGE],
  };
  return formattedData;
};

/**
 * @description function for format video gallery
 */
const formatVideoGalleryData = (data: any) => {
  const fieldData = data && data.fields;
  const placeholderData = data && data.rendering && data.rendering.placeholders;
  const formattedData: any = {
    [KEY_VIDEO_GALLERY_HEADLINE]: fieldData && fieldData[KEY_VIDEO_GALLERY_HEADLINE],
    numberOfItems:
      placeholderData &&
      placeholderData['video-gallery'] &&
      placeholderData['video-gallery'].length &&
      placeholderData['video-gallery'].length !== 0
        ? placeholderData['video-gallery'].length
        : 0,
  };
  return formattedData;
};

const formatKeyTaskCardData = (data: any) => {
  const fieldData = data.fields;
  // const paramsData = data.params;
let imgData = [ {"ImageSrc": "/-/media/bag-intra/ws_bayernet/contributorystatement/default.svg",
  "ImageKeyword": "default"
},
{
  "ImageSrc": "/-/media/bag-intra/ws_bayernet/contributorystatement/nodata.svg",
  "ImageKeyword": "error"
},
{
  "ImageSrc": "/-/media/bag-intra/ws_bayernet/contributorystatement/exceptional_contribution.svg",
  "ImageKeyword": "exceptionalcontribution"
},
{
  "ImageSrc": "/-/media/bag-intra/ws_bayernet/contributorystatement/lacking_contribution.svg",
  "ImageKeyword": "lackingcontribution"
},
{
  "ImageSrc": "/-/media/bag-intra/ws_bayernet/contributorystatement/strong_contribution.svg",
  "ImageKeyword": "strongcontribution"
},
{
  "ImageSrc": "/-/media/bag-intra/ws_bayernet/contributorystatement/varied_contribution.svg",
  "ImageKeyword": "variedcontribution"
}]
  const listingData: any = {
    [KEY_KTC_HEADLINE]: {
      value: fieldData && fieldData[KEY_KTC_HEADLINE] && fieldData[KEY_KTC_HEADLINE],
    },
    [KEY_KTC_IMAGE]: fieldData && fieldData[KEY_KTC_IMAGE] && fieldData[KEY_KTC_IMAGE],
    // [KEY_KTC_IMAGE]: {
    //   value: {
    //     src: 'http://localhost:8080/Capture.jpg',
    //     alt: '',
    //   },
    // },
    [KEY_KTC_CAPTION]: fieldData && fieldData[KEY_KTC_CAPTION] && fieldData[KEY_KTC_CAPTION],
    alignHorizontal:
      fieldData &&
      fieldData[KEY_KTC_HORIZONTAL] &&
      fieldData[KEY_KTC_HORIZONTAL] &&
      fieldData[KEY_KTC_HORIZONTAL].value
        ? true
        : false,
    // alignHorizontal: true,
    isHighlighted:
      fieldData && fieldData[KEY_KTC_IS_HIGHLIGHTED] && fieldData[KEY_KTC_IS_HIGHLIGHTED].value
        ? true
        : false,
    apiEndpoint:
      fieldData &&
      fieldData[KEY_KTC_API_ENDPOINT] &&
      fieldData[KEY_KTC_API_ENDPOINT][0] &&
      fieldData[KEY_KTC_API_ENDPOINT][0].fields &&
      fieldData[KEY_KTC_API_ENDPOINT][0].fields[KEY_KTC_API_NAME] &&
      fieldData[KEY_KTC_API_ENDPOINT][0].fields[KEY_KTC_API_NAME].value
        ? fieldData[KEY_KTC_API_ENDPOINT][0].fields[KEY_KTC_API_NAME].value
        : '',
    apiField:
      fieldData &&
      fieldData[KEY_API_FIELD] &&
      fieldData[KEY_API_FIELD] &&
      fieldData[KEY_API_FIELD].value
        ? fieldData[KEY_API_FIELD].value
        : '',
    hideEye: fieldData && fieldData[KEY_KTC_HIDE_EYE_BUTTON] && fieldData[KEY_KTC_HIDE_EYE_BUTTON].value,   
    [KEY_KTC_IMAGES]: fieldData && fieldData[KEY_KTC_IMAGES] && fieldData[KEY_KTC_IMAGES]? fieldData[KEY_KTC_IMAGES] : imgData
  };

  return listingData;
};

export {
  formatLinkBoxData,
  formatVideoBoxData,
  formatTextBoxData,
  formatWideImageData,
  formatTeaserData,
  formatWorkFlowTimelineData,
  formatAccordionData,
  formatGroupTeaserData,
  formatQuoteData,
  formatFeedbackData,
  formatCookieBannerData,
  formatAnchorTagData,
  formatBreadCrumbItemsData,
  formatClusterNavData,
  formatImageGalleryData,
  formatImageGalleryItemsData,
  formatVideoGalleryData,
  formatKeyTaskCardData,
  formatWorkFlowList,
};
