
export const apiEndpoints = {
  authenticate: {
    url: 'LogIn/ValidateUser',
    isMock: false,
  },
  autoSuggestBayernet: {
    url: 'ContentSearch/AutoSuggestion',
    // url: 'searchSection',
    isMock: false,
  },
  autoSuggestTools: {
    url: 'ContentSearch/QuickLinksAutoSuggestion',
    // url: 'searchSection',
    isMock: false,
  },
  saveFavorite: {
    url: 'favorites/savefavorite',
    isMock: false,
  },
  getFooterContents: {
    url: 'HRFooter/Footerdata',
    isMock: false,
  },
  getContributionStatement: {
    url: 'API/GetApiData',
    isMock: false,
  },
  getBreadcrumbData: {
    url: 'Breadcrumb/HRPagesBreadcrumb',
    isMock: false,
    // url:'breadCrumbData',
    // isMock:true
  },
  getClusterNavData: {
    url: 'menu/GetGlobalPinkNavHeadless',
    isMock: false,
    // url:'getClusterMenu',
    // isMock:true
  },
  getClusterMobileNavData: {
    url: 'menu/GetMobileGlobalPinkNavHeadless',
    isMock: false,
    // url:'getClusterMenuMobile',
    // isMock:true
  },
  getSecondLevelClusterNavData: {
    url: 'menu/getsubmenu',
    isMock: false,
    //  url:'getThirdLevel',
    //  isMock:true
  },
  getMainMenus: {
    url: 'menu/HRMenuItems',
    isMock: false,
  },
  getUtilityMenus: {
    url: 'News/GetUtilityMenu',
    isMock: false,
  },
  getChildMenus: {
    url: 'menu/getsubmenu',
    isMock: false,
  },
  getUserSettingsData: {
    url: 'UserProfile/GetUserSettingsData',
    isMock: false,
    // url: 'getUserSettings',
    // isMock: true
  },
  getDivisionData: {
    url: 'UserProfile/GetFunction',
    isMock: false,
    // url: 'getDivisionInfo',
    // isMock: true
  },
  getCountryData: {
    url: 'UserProfile/GetLanguageAndLocation',
    isMock: false,
    // url: 'getCountryInfo',
    // isMock: true
  },
  getChannelTopicData: {
    url: 'UserProfile/GetChannelsAndTags',
    isMock: false,
    // url: 'getChannelTopicInfo',
    // isMock: true
  },
  getProfileInfo: {
    url: 'UserProfile/GetUserProfileSection',
    isMock: false,
  },
  saveProfileInfo: {
    url: 'UserProfile/Save',
    isMock: false,
  },
  saveProfileImage: {
    url: 'UserProfile/UploadProfileImage',
    isMock: false,
  },
  saveCookieData: {
    url: 'UserProfile/SetCookieConsent',
    isMock: false,
  },
  getUserRole: {
    url: 'HRGateway/IsLeader',
    isMock: false,
  },
  getlanguageList: {
    url: 'https://cd.ci.bayernet.int.bayer.com/en/My_HR/api/getLanguageList', // 'https://translate.int.bayer.com/api/translate/v2/languages', //
    isMock: true,
  },
  gtmResult: {
    url: 'gtm/gtmresult',
    isMock: false,
  },
  getNotifications:{
    url:'Notification/HeaderNotification',
    isMock:false
  }
};
