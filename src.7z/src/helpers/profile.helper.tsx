const formatSelectOption = (data: any) => {
  let options = null;
  if (data && Array.isArray(data) && data.length > 0) {
    options = data.map((item) => ({ value: item.Id, label: item.Text }));
  }
  return options;
};
const formatMultiSelectOption = (data: any) => {
  let options = null;
  if (data && Array.isArray(data) && data.length > 0) {
    options = data.map((item) => ({ value: item.Id, label: item.Text, path: item.Path }));
  }
  return options;
};
const formatValue = (data: any, options: any) => {
  let userValue = null;
  if (Array.isArray(options) && options.length > 0) {
    for (let i = 0; i < options.length; i++) {
      if (options[i].Id === data) {
        userValue = options[i];
        break;
      }
    }
  }

  if (userValue === null) {
    return null;
  } else {
    const val = {
      value: userValue.Id,
      label: userValue.Text,
    };
    return val;
  }
};
const formatData = (data: any) => {
  const formattedData = {
    tab1:
      data && data.ProfilePopupDetails && data.ProfilePopupDetails.ProfileText
        ? data.ProfilePopupDetails.ProfileText
        : '',
    tab2:
      data && data.ProfilePopupDetails && data.ProfilePopupDetails.ChannelText
        ? data.ProfilePopupDetails.ChannelText
        : '',
    tab3:
      data && data.ProfilePopupDetails && data.ProfilePopupDetails.TopicsText
        ? data.ProfilePopupDetails.TopicsText
        : '',
    tab4:
      data && data.ProfilePopupDetails && data.ProfilePopupDetails.NewsletterText
        ? data.ProfilePopupDetails.NewsletterText
        : '',
    welcomeText:
      data && data.ProfilePopupDetails && data.ProfilePopupDetails.ProfileWelcomeText
        ? data.ProfilePopupDetails.ProfileWelcomeText
        : null,
    ProfileImageURL:
      data && data.UserProfile && data.UserProfile.ProfileImageURL
        ? { value: { src: data.UserProfile.ProfileImageURL, alt: 'UserImg' } }
        : null,
    DivisionData: {
      options: data && data.lstDivision ? formatSelectOption(data.lstDivision) : null,
      value:
        data && data.UserProfile && data.UserProfile.DivisionId && data.lstDivision
          ? formatValue(data.UserProfile.DivisionId, data.lstDivision)
          : null,
    },
    FunctionData: {
      options: data && data.lstFunction ? formatSelectOption(data.lstFunction) : null,
      value:
        data && data.UserProfile && data.UserProfile.FunctionId && data.lstFunction
          ? formatValue(data.UserProfile.FunctionId, data.lstFunction)
          : null,
    },
    LanguageData: {
      options: data && data.lstLanguage ? formatSelectOption(data.lstLanguage) : null,
      value:
        data && data.UserProfile && data.UserProfile.LanguageId && data.lstLanguage
          ? formatValue(data.UserProfile.LanguageId, data.lstLanguage)
          : null,
    },
    CountryData: {
      options: data && data.lstCountry ? formatSelectOption(data.lstCountry) : null,
      value:
        data && data.UserProfile && data.UserProfile.CountryId && data.lstCountry
          ? formatValue(data.UserProfile.CountryId, data.lstCountry)
          : null,
    },
    LocationData: {
      options: data && data.lstLocation ? formatSelectOption(data.lstLocation) : null,
      value:
        data.UserProfile.LocationId === '00000000-0000-0000-0000-000000000000'
          ? data && data.UserProfile && data.UserProfile.CountryId && data.lstCountry
            ? formatValue(data.UserProfile.CountryId, data.lstCountry)
            : null
          : data && data.UserProfile && data.UserProfile.LocationId && data.lstLocation
          ? formatValue(data.UserProfile.LocationId, data.lstLocation)
          : null,
    },
    channelText:
      data && data.ProfilePopupDetails && data.ProfilePopupDetails.ChannelWelcomeText
        ? data.ProfilePopupDetails.ChannelWelcomeText
        : null,
    isProfileDataEmpty:
      data &&
      data.UserProfile &&
      data.UserProfile.DivisionId &&
      data.UserProfile.DivisionId !== '00000000-0000-0000-0000-000000000000' &&
      data.UserProfile.LanguageId &&
      data.UserProfile.LanguageId !== '00000000-0000-0000-0000-000000000000' &&
      data.UserProfile.CountryId &&
      data.UserProfile.CountryId !== '00000000-0000-0000-0000-000000000000' &&
      data.UserProfile.LocationId &&
      data.UserProfile.LocationId !== '00000000-0000-0000-0000-000000000000'
        ? false
        : true,
    ChannelSelectedMsg:
      data && data.ProfilePopupDetails && data.ProfilePopupDetails.ChannelSelectedMsg
        ? data.ProfilePopupDetails.ChannelSelectedMsg
        : null,
    ChannelMaxMsg:
      data && data.ProfilePopupDetails && data.ProfilePopupDetails.MaxChannelErrorMsg
        ? data.ProfilePopupDetails.MaxChannelErrorMsg
        : null,
    noChannelFoundMsg:
      data && data.ProfilePopupDetails && data.ProfilePopupDetails.ChannelNoResultFoundErrorMsg
        ? data.ProfilePopupDetails.ChannelNoResultFoundErrorMsg
        : null,
    TopicText:
      data && data.ProfilePopupDetails && data.ProfilePopupDetails.TopicsWelcomeText
        ? data.ProfilePopupDetails.TopicsWelcomeText
        : null,
    TagsSelectedMsg:
      data && data.ProfilePopupDetails && data.ProfilePopupDetails.TagsSelectedMsg
        ? data.ProfilePopupDetails.TagsSelectedMsg
        : null,
    MaxTagsErrorMsg:
      data && data.ProfilePopupDetails && data.ProfilePopupDetails.MaxTagsErrorMsg
        ? data.ProfilePopupDetails.MaxTagsErrorMsg
        : null,
    SubscribeToNewsLetter:
      data && data.UserProfile && data.UserProfile.SubscribeToNewsLetter
        ? data.UserProfile.SubscribeToNewsLetter
        : false,
    NewsletterWelcomeText:
      data && data.ProfilePopupDetails && data.ProfilePopupDetails.NewsletterWelcomeText
        ? data.ProfilePopupDetails.NewsletterWelcomeText
        : '',
    NewsletterTitle:
      data && data.ProfilePopupDetails && data.ProfilePopupDetails.NewsletterTitle
        ? data.ProfilePopupDetails.NewsletterTitle
        : '',
    NewsletterSuscribeText:
      data && data.ProfilePopupDetails && data.ProfilePopupDetails.NewsletterSuscribeText
        ? data.ProfilePopupDetails.NewsletterSuscribeText
        : '',
  };
  return formattedData;
};
const formatMultiSelectValue = (data: any, options: any) => {
  const formattedValue = data.map((item: any) => {
    let newData = null;
    for (let i = 0; i < options.length; i++) {
      if (options[i].Id === item) {
        newData = {
          value: options[i].Id,
          label: options[i].Text,
          path: options[i].Path,
        };
        break;
      }
    }
    return newData;
  });
  return formattedValue;
};

const formatAdditionalData = (data: any) => {
  let formattedData = {
    channelData: {
      options:
        data && data.AdditionalChannels ? formatMultiSelectOption(data.AdditionalChannels) : null,
      value:
        data && data.SelectedChannels && data.AdditionalChannels
          ? formatMultiSelectValue(data.SelectedChannels, data.AdditionalChannels)
          : null,
      deactivateSelection:
        data.SelectedChannels &&
        Array.isArray(data.SelectedChannels) &&
        data.SelectedChannels.length > 4
          ? true
          : false,
    },
    topicData: {
      options: data && data.Tags ? formatMultiSelectOption(data.Tags) : null,
      value:
        data && data.SelectedTags && data.SelectedTags
          ? formatMultiSelectValue(data.SelectedTags, data.Tags)
          : null,
      deactivateSelection:
        data.SelectedTags && Array.isArray(data.SelectedTags) && data.SelectedTags.length > 9
          ? true
          : false,
    },
  };
  return formattedData;
};
const formatMultiselectToString = (data: any) => {
  let stringArray = [];
  if (data && Array.isArray(data) && data.length > 0) {
    stringArray = data.map((item) => item.value);
  }
  return stringArray;
};
const formatSettings = (profileData: any, additionalData: any) => {
  const formattedData = {
    AdditionalChannels:
      additionalData && additionalData.channelData && additionalData.channelData.value
        ? formatMultiselectToString(additionalData.channelData.value)
        : [],
    AdditionalTags:
      additionalData && additionalData.topicData && additionalData.topicData.value
        ? formatMultiselectToString(additionalData.topicData.value)
        : [],
    CountryCode:
      profileData &&
      profileData.CountryData &&
      profileData.CountryData.value &&
      profileData.CountryData.value.value
        ? profileData.CountryData.value.value
        : '',
    Division:
      profileData &&
      profileData.DivisionData &&
      profileData.DivisionData.value &&
      profileData.DivisionData.value.value
        ? profileData.DivisionData.value.value
        : '',
    Function:
      profileData &&
      profileData.FunctionData &&
      profileData.FunctionData.value &&
      profileData.FunctionData.value.value
        ? profileData.FunctionData.value.value
        : '',
    LanguageCode:
      profileData &&
      profileData.LanguageData &&
      profileData.LanguageData.value &&
      profileData.LanguageData.value.value
        ? profileData.LanguageData.value.value
        : '',
    Location:
      profileData &&
      profileData.LocationData &&
      profileData.LocationData.value &&
      profileData.LocationData.value.value
        ? profileData.LocationData.value.value
        : '',
    RemindUserSettings: 0,
    SubscribeToNewsLetter:
      profileData && profileData.SubscribeToNewsLetter ? profileData.SubscribeToNewsLetter : false,
  };
  return formattedData;
};
export { formatData, formatSelectOption, formatAdditionalData, formatSettings };
