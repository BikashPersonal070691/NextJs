import { useRef, useEffect, useState } from 'react';
import styles from './Teaser.module.scss';
import { formatTeaserData } from 'src/helpers/component.helper';
// import { Image } from '@sitecore-jss/sitecore-jss-nextjs';
import {
  Image,
  Text,
  Field,
  RichText,
  Link,
  useSitecoreContext,
} from '@sitecore-jss/sitecore-jss-nextjs';
// import { Field } from '@sitecore-jss/sitecore-jss-nextjs';
import { getParentClassReference, getParentAttributeReference } from 'src/core/utils/utils.helper';
// import { getParentAttributeReference } from 'src/core/utils/utils.helper';
import { CONTENT_100 } from 'src/constants/contentDivider';
// import MultiSelectDropdown from 'components/Elements/MultiselectDropdown/MultiSelectDropdown';
import { ComponentProps } from 'lib/component-props';
import { StyleguideSpecimenFields } from 'lib/component-props/styleguide';
import {
  KEY_TEASER_LINK_ITEM,
  KEY_TEASER_TEASER_CAPTION,
  KEY_TEASER_HEADLINE,
  KEY_TEASER_IMAGE,
  KEY_TEASER_TEXT,
  KEY_TEASER_SUB_LINKS,
  KEY_TEASER_MAIN_LNK,
  IFRAME_BUTTON_TYPE
} from '../../constants/general';
import { IframeButton } from 'components/Elements/IframeButton/IframeButton';

//import CalendarSection from 'components/CalendarSection/CalendarSection';

type TeaserComponentProps = ComponentProps &
  StyleguideSpecimenFields & {
    fields: {
      [KEY_TEASER_TEASER_CAPTION]: Field<string>;
      [KEY_TEASER_HEADLINE]: Field<string>;
      [KEY_TEASER_SUB_LINKS]: Field<string>;
      [KEY_TEASER_TEXT]: Field<string>;
      [KEY_TEASER_IMAGE]: Field<string>;
      [KEY_TEASER_MAIN_LNK]: Field<string>;
    };
    groupView: Field<any>;
    sliderview: Field<any>;
    'data-slider': any;
    'data-type': any;
  };

export default function Teaser(props: TeaserComponentProps) {
  const { sitecoreContext } = useSitecoreContext();
  const isExperienceEditor = sitecoreContext && sitecoreContext.pageEditing;
  // const isExperienceEditor = true;
  const teaserData = formatTeaserData(props, isExperienceEditor);
  const fields: any = props.fields;
  /**
   * @important This code needs to be used in every components inorder to get the content dividers reference
   * @important Also set the reference (ref) and className to the html wrapper as implemented below
   */
  // starts
  const nodeRef = useRef(null);
  const [parentRef, setParentRef] = useState<any>(null);
  const isSlider: boolean = props && props['data-slider'];
  const [parentAttr, setParentAttr] = useState<any>(null);

  useEffect(() => {
    const child: any = nodeRef.current;

    if (child !== null || child !== undefined) {
      setParentRef(getParentClassReference(child));
      setParentAttr(getParentAttributeReference(child, 'data-id'));
    } else {
      setParentRef(CONTENT_100);
    }
  }, []);
  
  return (
    <div
      ref={nodeRef}
      className={`${parentRef && styles[parentRef]}`}
      id={teaserData && teaserData.teaserAnchor}
    >
      <div
        className={`${
          isSlider && isSlider == true ? styles.teaser_slider__container : styles.teaser__container
        } ${
          teaserData && !teaserData.alignVertical
            ? styles.teaser__container__horizontal
            : styles.teaser__container__vertical
        } ${teaserData && teaserData.isHighlighted ? styles.teaser__container__highlight : ''} 
          ${isExperienceEditor && !isSlider ? styles.teaser__container__spaced : ''}
          ${parentAttr && styles[parentAttr]}`}
        style={{
          backgroundColor:
            teaserData && teaserData.bgColor && teaserData.bgColor !== ''
              ? teaserData.bgColor
              : 'white',
        }}
      >
        {teaserData &&
          teaserData[KEY_TEASER_IMAGE] &&
          teaserData &&
          teaserData[KEY_TEASER_IMAGE].value &&
          Object.keys(teaserData[KEY_TEASER_IMAGE].value).length !== 0 && (
            <Link
              field={
                teaserData &&
                teaserData[KEY_TEASER_MAIN_LNK] &&
                teaserData[KEY_TEASER_MAIN_LNK] &&
                teaserData[KEY_TEASER_MAIN_LNK].value &&
                teaserData[KEY_TEASER_MAIN_LNK].value.href &&
                teaserData[KEY_TEASER_MAIN_LNK].value.href !== ''
                  ? teaserData[KEY_TEASER_MAIN_LNK]
                  : { value: { href: 'javascript:void(0)' } }
              }
              showLinkTextWithChildrenPresent={false}
              target={
                teaserData &&
                teaserData[KEY_TEASER_MAIN_LNK] &&
                teaserData[KEY_TEASER_MAIN_LNK].value &&
                teaserData[KEY_TEASER_MAIN_LNK].value.target
                  ? '_blank'
                  : ''
              }
              editable={false}
              style={{
                cursor:
                  teaserData &&
                  teaserData[KEY_TEASER_MAIN_LNK] &&
                  teaserData[KEY_TEASER_MAIN_LNK].value &&
                  teaserData[KEY_TEASER_MAIN_LNK].value.href !== ''
                    ? 'pointer'
                    : 'default',
              }}
            >
              <div
                className={`${styles.teaser_image__container} ${
                  isExperienceEditor ? styles.teaser_image__container__exp_editor_img : ''
                } ${
                  teaserData &&
                  teaserData[KEY_TEASER_TEASER_CAPTION] &&
                  teaserData[KEY_TEASER_TEASER_CAPTION].value !== ''
                    ? styles.teaser_image__container__conditional_bg
                    : ''
                } ${
                  teaserData && !teaserData.alignVertical
                    ? styles.teaser_image__container__horizontal
                    : ''
                }`}
                style={
                  teaserData && !teaserData.alignVertical && !teaserData.isContentAvailable
                    ? { margin: 'unset' }
                    : { padding: 'unset' }
                }
              >
                <Image
                  field={teaserData && teaserData[KEY_TEASER_IMAGE]}
                  editable={true}
                  className={`${styles.teaser__image} ${
                    teaserData && !teaserData.alignVertical ? '' : styles.teaser__image__vertical
                  } 
                  `}
                />

                <Text
                  field={teaserData && teaserData[KEY_TEASER_TEASER_CAPTION]}
                  editable={true}
                  tag="div"
                  className={styles.teaser_image__caption}
                />
              </div>
            </Link>
          )}

        {teaserData && teaserData.isContentAvailable && (
          <div
            className={`${styles.teaser_content__container} ${
              teaserData && !teaserData.alignVertical
                ? styles.teaser_content__container__horizontal
                : ''
            }`}
          >
            <Link
              field={
                teaserData && teaserData[KEY_TEASER_MAIN_LNK] && teaserData[KEY_TEASER_MAIN_LNK]
              }
              showLinkTextWithChildrenPresent={false}
              target={
                teaserData &&
                teaserData[KEY_TEASER_MAIN_LNK] &&
                teaserData[KEY_TEASER_MAIN_LNK].value &&
                teaserData[KEY_TEASER_MAIN_LNK].value.target
                  ? '_blank'
                  : ''
              }
              editable={true}
              style={{
                cursor:
                  teaserData &&
                  teaserData[KEY_TEASER_MAIN_LNK] &&
                  teaserData[KEY_TEASER_MAIN_LNK].value &&
                  teaserData[KEY_TEASER_MAIN_LNK].value.href !== ''
                    ? 'pointer'
                    : 'default',
              }}
            >
              <Text
                field={
                  teaserData &&
                  teaserData[KEY_TEASER_HEADLINE] &&
                  teaserData[KEY_TEASER_HEADLINE].value
                }
                editable={true}
                className={`${styles.teaser__headline} ${
                  teaserData && teaserData.isHighlighted ? styles.teaser__headline__highlight : ''
                }`}
                tag="h2"
              />
            </Link>
            {teaserData && teaserData.showText && (
              <RichText
                field={
                  teaserData && teaserData[KEY_TEASER_TEXT] && teaserData[KEY_TEASER_TEXT].value
                }
                editable={true}
                className={styles.teaser__description}
              />
            )}
            {teaserData && teaserData.showSubLinks ? (
              <div className={styles.teaser__links}>
                {teaserData &&
                  teaserData[KEY_TEASER_SUB_LINKS] &&
                  teaserData[KEY_TEASER_SUB_LINKS].map((item: any, index: any) => {
                    return (
                      <Link
                        key={index}
                        field={item && item.fields && item.fields[KEY_TEASER_LINK_ITEM]}
                        showLinkTextWithChildrenPresent={false}
                        target={
                          item && item.flields && item.fields[KEY_TEASER_LINK_ITEM].value.target
                            ? '_blank'
                            : ''
                        }
                        editable={true}
                        className={styles.teaser__link}
                      ></Link>
                    );
                  })}
              </div>
            ) : (
              ''
            )}
            {/* {fields &&
            fields[KEY_IFRAME] &&
            fields[KEY_IFRAME].fields &&
            fields[KEY_IFRAME].fields.IframeSource &&
            fields[KEY_IFRAME].fields.IframeSource.value &&
            fields[KEY_IFRAME_BUTTON_TEXT] &&
            fields[KEY_IFRAME_BUTTON_TEXT].value ? (
              <div className={styles.teaser__iframe}>
                <IframeButton data={fields} type={IFRAME_BUTTON_TYPE.HR_TASK} />
              </div>
            ) : (
              ''
            )} */}

          <div className={styles.teaser__iframe}>
                <IframeButton data={fields} type={IFRAME_BUTTON_TYPE.HR_TASK} />
              </div>
          </div>
        )}
      </div>
    </div>
  );
}
