import { AxiosResponse } from 'axios';
import {
  AxiosDataFetcher,
  RestLayoutService,
  //   LayoutServiceData
} from '@sitecore-jss/sitecore-jss-nextjs';
import { KEY_ENVIRONMENTS } from 'src/constants/general';
import config from 'temp/config';
import { checkEnvExistsinUrl } from 'src/core/utils/utils.helper';

// define your custom data fetcher
function dataFetcher(url: string, data?: unknown): Promise<AxiosResponse<any>> {
  // const current_url = window.location.href;
  let isFound: any = checkEnvExistsinUrl(KEY_ENVIRONMENTS.ENV_CD);

  return new AxiosDataFetcher({
    withCredentials: isFound ? true : false,
  }).fetch(url, data);
}

export const layoutService = new RestLayoutService({
  apiHost: config.sitecoreApiHost,
  apiKey: config.sitecoreApiKey,
  siteName: config.jssAppName,
  tracking: true, // if you wish to disable tracking
  // provide your custom data fetcher to the service instance
  //   dataFetcher
  dataFetcherResolver: () => dataFetcher,
});
