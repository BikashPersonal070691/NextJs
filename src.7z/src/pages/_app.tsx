import type { AppProps } from 'next/app';
import { I18nProvider } from 'next-localization';
import { SitecorePageProps } from 'lib/page-props';
// import { SessionProvider } from 'next-auth/react';
import { Provider } from 'react-redux';
import store from 'src/redux/store';
import 'assets/app.scss';

function App({ Component, pageProps: { ...pageProps } }: AppProps<SitecorePageProps>): JSX.Element {
  const { dictionary, ...rest } = pageProps;

  return (
    <Provider store={store}>
      {/* <SessionProvider session={session}> */}
      {/* // Use the next-localization (w/ rosetta) library to provide our translation dictionary to the
      app. // Note Next.js does not (currently) provide anything for translation, only i18n routing.
      // If your app is not multilingual, next-localization and references to it can be removed. */}
      <I18nProvider lngDict={dictionary} locale={pageProps.locale}>
        <Component {...rest} />
      </I18nProvider>
      {/* </SessionProvider> */}
    </Provider>
  );
}

export default App;
