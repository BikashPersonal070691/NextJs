import { useRef, useState, useEffect } from 'react';
import styles from './TilesContainerSR.module.scss';
import { Text, Link, useSitecoreContext } from '@sitecore-jss/sitecore-jss-nextjs';
import { formatSRTilesData } from 'src/helpers/SRTiles.helper';
import { SR_TILE_HEADLINE, SR_TILE_LINK_TEXT, SR_TILE_LINK_URL } from 'src/constants/general';
import { Field } from '@sitecore-jss/sitecore-jss-nextjs';
import { ComponentProps } from 'lib/component-props';
import { StyleguideSpecimenFields } from 'lib/component-props/styleguide';
import { Placeholder } from '@sitecore-jss/sitecore-jss-nextjs';

type SRTileComponentProps = ComponentProps &
  StyleguideSpecimenFields & {
    fields: {
      [SR_TILE_HEADLINE]: Field<string>;
      [SR_TILE_LINK_TEXT]: Field<string>;
      [SR_TILE_LINK_URL]: Field<string>;
    };
  };
export default function TilesContainerSR(props: SRTileComponentProps) {
  const [isFirstSlideDisabled, setisFirstSlideDisabled] = useState<any>(true);
  const [isLastSlideDisabled, setisLastSlideDisabled] = useState<any>(false);
  const [showTopButton, setShowTopButton] = useState(true);
  const [showDesktopView, setShowDesktopView] = useState(true);
  const containerRef = useRef<any>(null);
  const teaserSliderRef = useRef<any>(null);
  const refinedTilesData: any = formatSRTilesData(props);
  const { sitecoreContext } = useSitecoreContext();
  const isExperienceEditor = sitecoreContext && sitecoreContext.pageEditing;
  useEffect(() => {
    if (
      containerRef &&
      containerRef.current &&
      containerRef.current.clientWidth &&
      containerRef.current.clientWidth < 810
    ) {
      setShowTopButton(false);
    }
    if (
      containerRef &&
      containerRef.current &&
      containerRef.current.clientWidth &&
      containerRef.current.clientWidth < 605
    ) {
      setShowDesktopView(false);
    }
  }, []);

  const goPrev = () => {
    teaserSliderRef && teaserSliderRef.current && (teaserSliderRef.current.scrollLeft -= 205);
    setisLastSlideDisabled(false);
    teaserSliderRef.current.scrollLeft < 205
      ? setisFirstSlideDisabled(true)
      : setisFirstSlideDisabled(false);
    if (teaserSliderRef.current.scrollLeft < 205) {
      teaserSliderRef.current.scrollLeft = 0;
    }
  };

  const goNext = () => {
    teaserSliderRef && teaserSliderRef.current && (teaserSliderRef.current.scrollLeft += 205);
    setisFirstSlideDisabled(false);
    teaserSliderRef.current.scrollLeft <
    teaserSliderRef.current.scrollWidth - teaserSliderRef.current.clientWidth
      ? setisLastSlideDisabled(false)
      : setisLastSlideDisabled(true);
    // teaserSliderRef.current.scrollLeft > teaserSliderRef.current.scrollWidth - 205
    //   ? ''
    //   : (teaserSliderRef.current.scrollLeft = teaserSliderRef.current.clientWidth);
  };

  // const navigationHandler = (link: any, isExternal: boolean) => {
  //   if (isExternal) {
  //     window.open(link, '_blank');
  //   } else {
  //     window.open(link, '_self');
  //   }
  // };
  return (
    <div className={styles.tiles_container}>
      <div className={styles.tiles_wrapper} ref={containerRef}>
        <div
          className={`${styles.headline_container} ${
            showTopButton ? styles.desktop_margin : styles.tab_margin
          } ${!showDesktopView && styles.mobile_margin}`}
        >
          <div className={styles.left_container}>
            {!isExperienceEditor ? (
              refinedTilesData &&
              refinedTilesData[SR_TILE_HEADLINE] &&
              refinedTilesData[SR_TILE_HEADLINE].value && (
                <Text
                  field={refinedTilesData[SR_TILE_HEADLINE]}
                  editable={true}
                  className={styles.carousel_headline}
                  tag="div"
                />
              )
            ) : (
              <Text
                field={refinedTilesData[SR_TILE_HEADLINE]}
                editable={true}
                className={styles.carousel_headline}
                tag="div"
              />
            )}
          </div>

          <div
            className={`${styles.right_container} ${
              typeof showTopButton === 'boolean' && showTopButton === false
                ? styles.hide_button
                : undefined
            }`}
          >
            {refinedTilesData &&
              refinedTilesData.showButton &&
              refinedTilesData[SR_TILE_LINK_URL] &&
              refinedTilesData[SR_TILE_LINK_URL].value &&
              refinedTilesData[SR_TILE_LINK_TEXT] &&
              refinedTilesData[SR_TILE_LINK_TEXT].value && (
                <Link
                  field={refinedTilesData[SR_TILE_LINK_URL].value}
                  target={refinedTilesData.isExternalLink ? '_blank' : ''}
                  editable={true}
                >
                  <Text
                    tag="div"
                    className={styles.right_button}
                    field={refinedTilesData[SR_TILE_LINK_TEXT].value}
                    editable={true}
                  />
                </Link>
              )}
          </div>
        </div>
        {showDesktopView ? (
          <div className={styles.tiles_content_wrapper}>
            <Placeholder name="tile-tileContainer" rendering={props.rendering} />
          </div>
        ) : (
          <>
            <div className={`${styles.button_wrapper} `}>
              <button
                className={`${styles.previous}  ${isFirstSlideDisabled ? styles.disabled : ''}`}
                onClick={goPrev}
              ></button>
              <button
                className={`${styles.next} ${isLastSlideDisabled ? styles.disabled : ''}`}
                onClick={goNext}
              ></button>
            </div>
            <div ref={teaserSliderRef} className={styles.slider_container}>
              <Placeholder name="tile-tileContainer" rendering={props.rendering} />
            </div>
          </>
        )}
        <div className={`${styles.sec_button_wrapper} ${showTopButton ? styles.hide_wrapper : ''}`}>
          {refinedTilesData &&
            refinedTilesData.showButton &&
            refinedTilesData[SR_TILE_LINK_URL] &&
            refinedTilesData[SR_TILE_LINK_URL].value &&
            refinedTilesData[SR_TILE_LINK_TEXT] &&
            refinedTilesData[SR_TILE_LINK_TEXT].value && (
              <Link
                field={refinedTilesData[SR_TILE_LINK_URL].value}
                target={refinedTilesData.isExternalLink ? '_blank' : ''}
                editable={true}
              >
                <Text
                  tag="div"
                  className={styles.sec_button}
                  field={refinedTilesData[SR_TILE_LINK_TEXT].value}
                  editable={true}
                />
              </Link>
            )}
        </div>
      </div>
    </div>
  );
}
