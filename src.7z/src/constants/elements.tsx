// textarea
export const TEXTAREA_NORMAL = 'normal';
export const TEXTAREA_CUSTOM = 'custom';
