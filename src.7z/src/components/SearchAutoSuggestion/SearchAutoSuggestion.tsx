import { SearchAutoSuggestionListItem } from '../SearchAutoSuggestionListItem/SearchAutoSuggestionListItem';
import styles from './SearchAutoSuggestion.module.scss';

export function SearchAutoSuggestion(props: any) {
  const { listData, innerRef } = props;
  return (
    <div ref={innerRef} className={`${styles.search_autocomplete__container}`}>
      {listData && Object.keys(listData).length !== 0 ? (
        <SearchAutoSuggestionListItem
          icon={listData && listData.icon}
          link={listData && listData.link}
          groupName={listData && listData.groupName}
          isBookmarked={listData && listData.isBookmarked}
          type={listData && listData.type}
          displayName={listData && listData.displayName}
          paramName={listData && listData.paramName}
        />
      ) : (
        ''
      )}
    </div>
  );
}
