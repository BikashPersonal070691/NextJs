import React, { useEffect, useRef } from 'react';
export function useInterval(callback, delay) {
  const savedCallback = useRef();

  useEffect(() => {
    savedCallback.current = callback;
  }, [callback]);

  useEffect(() => {
    function tick() {
      savedCallback.current();
    }
    if (delay !== null) {
      let id = setInterval(tick, 20);
      return () => clearInterval(id);
    }
  }, [delay]);
}
