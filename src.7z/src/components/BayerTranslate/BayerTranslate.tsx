import { KEY_BAYER_TRANSLATE_BY, KEY_BAYER_TRANSLATE_DISPLAY } from 'src/constants/dictonary';
import styles from './BayerTranslate.module.scss';
import { useRouter } from 'next/router';
import { useLanguageTranslate } from 'src/hooks/useLanguageTranslate';
import { BAYER_TRANSLATE_LABEL, BAYER_TRANSLATE_MAIN_PAGE } from 'src/constants/general';

const BayerTranslate = () => {
  const { translatedKey } = useLanguageTranslate();
  const router = useRouter();
  const handleClick = () => {
    router.reload();
  };

  return (
    <div className={styles.bayertranslate_disclaimer}>
      <span className={styles.bayertranslate_heading}>
      {translatedKey(KEY_BAYER_TRANSLATE_BY)}{' '}
        <a
          className={styles.page_link}
          target="_blank"
          href={BAYER_TRANSLATE_MAIN_PAGE}
        >
          {BAYER_TRANSLATE_LABEL}
        </a>
        <a className={styles.page_link} href="#" onClick={handleClick}>
        {translatedKey(KEY_BAYER_TRANSLATE_DISPLAY)}
        </a>
      </span>
    </div>
  );
};

export default BayerTranslate;
