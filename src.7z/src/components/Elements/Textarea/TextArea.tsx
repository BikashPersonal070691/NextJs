import { useRef, useEffect } from 'react';
import { TextAreaConfig } from '../../../models/textArea';
import { TEXTAREA_NORMAL } from 'src/constants/elements';
export function TextArea({
  placeHolder,
  className,
  id,
  value,
  name,
  onChange,
  onKeyPress,
  type,
  autoFocus,
  maxLength,
  onKeyDown,
}: TextAreaConfig) {
  const textAreaRef = useRef<any>(null);
  useEffect(() => {
    if (textAreaRef !== null && autoFocus === true) {
      textAreaRef.current.focus();
    }
  }, []);
  const handleGetCharacterCount = () => {
    // get contenteditable div character count
    if (textAreaRef && textAreaRef.current && textAreaRef.current?.innerText !== '') {
      onKeyDown(textAreaRef.current?.innerText);
    }
  };

  const checkCharacterCount = (maxLen: any, e: any) => {
    let contentLength =
      textAreaRef &&
      textAreaRef.current &&
      textAreaRef.current?.innerText.trim() &&
      textAreaRef.current?.innerText.length;
    if (e.which != 8 && contentLength >= maxLen) {
      e.preventDefault();
    }
  };

  const handleSlicePastedText = (e: any, maxLen: any) => {
    let contentLength =
      textAreaRef &&
      textAreaRef.current &&
      textAreaRef.current?.innerText.trim() &&
      textAreaRef.current?.innerText.length;
    if (contentLength >= maxLen) {
      e.preventDefault();
    }
  };

  return (
    <>
      {type && type === TEXTAREA_NORMAL ? (
        <textarea
          autoComplete="off"
          className={className}
          id={id}
          placeholder={placeHolder}
          value={value}
          name={name}
          onChange={onChange}
          onKeyPress={onKeyPress}
          ref={textAreaRef}
          maxLength={maxLength}
        />
      ) : (
        <div
          contentEditable
          id={id}
          className={className}
          data-placeholder={placeHolder}
          onChange={(e) => {
            onChange;
            handleGetCharacterCount();
            checkCharacterCount(maxLength, e);
          }}
          onKeyPress={(e) => {
            onKeyPress;
            handleGetCharacterCount();
            checkCharacterCount(maxLength, e);
          }}
          onKeyDown={(e) => {
            e.stopPropagation();
            handleGetCharacterCount();
            checkCharacterCount(maxLength, e);
          }}
          onKeyUp={(e) => {
            handleGetCharacterCount();
            checkCharacterCount(maxLength, e);
          }}
          onPaste={(e) => {
            handleSlicePastedText(e, maxLength);

            handleGetCharacterCount();
            checkCharacterCount(maxLength, e);
          }}
          // role='textarea'
          ref={textAreaRef}
        ></div>
      )}
    </>
  );
}
