import { useEffect, useRef, useState } from 'react';
import { LinkBoxDataConfig } from 'src/models/linkBox';
import { formatLinkBoxData } from 'src/helpers/component.helper';
import { getParentClassReference, getParentAttributeReference } from 'src/core/utils/utils.helper';
import styles from './Linkbox.module.scss';
import { Text, Link, RichText, Field, useSitecoreContext } from '@sitecore-jss/sitecore-jss-nextjs';
import { CONTENT_100 } from 'src/constants/contentDivider';
import { ComponentProps } from 'lib/component-props';
import { StyleguideSpecimenFields } from 'lib/component-props/styleguide';
import {
  KEY_LINKBOX_LINK_DESCRIPTION,
  KEY_LINKBOX_LINK_TEXT,
  KEY_LINKBOX_LINK_URL,
  KEY_LINKBOX_LINK_TARGET_BLANK,
  KEY_LINKBOX_LINK_HEADING_DESCRIPTION,
  KEY_LINKBOX_LINK_HEADING,
} from 'src/constants/general';

type LinkBoxComponentProps = ComponentProps &
  StyleguideSpecimenFields & {
    fields: {
      Title: Field<string>;
      [KEY_LINKBOX_LINK_DESCRIPTION]: Field<string>;
      [KEY_LINKBOX_LINK_TEXT]: Field<string>;
      [KEY_LINKBOX_LINK_URL]: Field<string>;
      [KEY_LINKBOX_LINK_TARGET_BLANK]: Field<string>;
      [KEY_LINKBOX_LINK_HEADING_DESCRIPTION]: Field<string>;
      [KEY_LINKBOX_LINK_HEADING]: Field<string>;
    };
  };

export default function Linkbox(props: LinkBoxComponentProps) {
  const linkData = formatLinkBoxData(props);
  const { sitecoreContext } = useSitecoreContext();
  const isExperienceEditor = sitecoreContext && sitecoreContext.pageEditing;
  const [parentAttr, setParentAttr] = useState<any>(null);

  /**
   * @important This code needs to be used in every components inorder to get the content dividers reference
   * @important Also set the reference (ref) and className to the html wrapper as implemented below
   */
  // starts
  const nodeRef = useRef(null);
  const [parentRef, setParentRef] = useState<any>(null);
  useEffect(() => {
    const child: any = nodeRef.current;
    if (child !== null || child !== undefined) {
      setParentRef(getParentClassReference(child));
      setParentAttr(getParentAttributeReference(child, 'data-id'));
    } else {
      setParentRef(CONTENT_100);
    }
  }, []);
  //ends

  return (
    <div ref={nodeRef} className={styles[parentRef]}>
      <div
        className={`${styles.linkBox__container} ${parentAttr && styles[parentAttr]}`}
        style={{
          backgroundColor:
            linkData && linkData.bgColor && linkData.bgColor !== '' ? linkData.bgColor : 'white',
        }}
      >
        {!isExperienceEditor ? (
          linkData && linkData.Title && linkData.Title.value && linkData.Title.value !== '' ? (
            <div className={styles.linkBox_heading__container}>
              <div className={styles.linkBox__heading}>
                <Text tag="p" field={linkData.Title} />
              </div>
            </div>
          ) : (
            ''
          )
        ) : (
          <div className={styles.linkBox_heading__container}>
            <div className={styles.linkBox__heading}>
              <Text tag="p" field={linkData.Title} />
            </div>
          </div>
        )}

        <div className={styles.linkbox_data__container}>
          <div className={styles.linkbox_data_common_heading_description__wrapper}>
            {!isExperienceEditor &&
            linkData &&
            linkData[KEY_LINKBOX_LINK_HEADING] &&
            linkData[KEY_LINKBOX_LINK_HEADING].value !== '' ? (
              <div
                className={styles.linkbox_data_common__heading}
                // style={{ marginTop: isExperienceEditor ? '9%' : '0%' }}
              >
                <RichText field={linkData[KEY_LINKBOX_LINK_HEADING]} editable={true} tag="h4" />
              </div>
            ) : isExperienceEditor ? (
              <div className={styles.linkbox_data_common__heading}>
                <RichText field={linkData[KEY_LINKBOX_LINK_HEADING]} editable={true} tag="h4" />
              </div>
            ) : (
              ''
            )}
            {!isExperienceEditor &&
            linkData &&
            linkData[KEY_LINKBOX_LINK_HEADING_DESCRIPTION] &&
            linkData[KEY_LINKBOX_LINK_HEADING_DESCRIPTION].value !== '' ? (
              <div className={styles.linkbox_data_common_heading__description}>
                <RichText
                  field={linkData[KEY_LINKBOX_LINK_HEADING_DESCRIPTION]}
                  editable={true}
                  tag="h4"
                />
              </div>
            ) : isExperienceEditor ? (
              <div className={styles.linkbox_data_common_heading__description}>
                <RichText
                  field={linkData[KEY_LINKBOX_LINK_HEADING_DESCRIPTION]}
                  editable={true}
                  tag="h4"
                />
              </div>
            ) : (
              ''
            )}
          </div>
          {linkData &&
          linkData.listData &&
          Array.isArray(linkData.listData) &&
          linkData.listData.length !== 0
            ? linkData.listData.map((lData: LinkBoxDataConfig, index: any) => {
                return (
                  <div className={styles.linkbox_data__wrapper} key={index}>
                    {!isExperienceEditor ? (
                      lData[KEY_LINKBOX_LINK_URL] &&
                      lData[KEY_LINKBOX_LINK_URL].value &&
                      lData[KEY_LINKBOX_LINK_URL].value != '#' &&
                      lData[KEY_LINKBOX_LINK_URL].value.href.length > 0 ? (
                        <Link
                          field={lData[KEY_LINKBOX_LINK_URL]}
                          showLinkTextWithChildrenPresent={false}
                          target={lData.linkTarget ? '_blank' : ''}
                          editable={true}
                        >
                          <Text
                            tag="div"
                            className={styles.linkBox_data__heading}
                            field={lData && lData[KEY_LINKBOX_LINK_TEXT]}
                            editable={true}
                          />

                          {lData &&
                          lData[KEY_LINKBOX_LINK_DESCRIPTION] &&
                          lData[KEY_LINKBOX_LINK_DESCRIPTION].value &&
                          lData[KEY_LINKBOX_LINK_DESCRIPTION].value !== '' ? (
                            <Text
                              tag="div"
                              className={styles.linkBox_data__sub_heading}
                              field={lData && lData[KEY_LINKBOX_LINK_DESCRIPTION]}
                              editable={true}
                            />
                          ) : (
                            ''
                          )}
                        </Link>
                      ) : (
                        ''
                      )
                    ) : (
                      <Link
                        field={lData[KEY_LINKBOX_LINK_URL]}
                        showLinkTextWithChildrenPresent={false}
                        target={lData.linkTarget ? '_blank' : ''}
                        editable={true}
                      >
                        <Text
                          tag="div"
                          className={styles.linkBox_data__heading}
                          field={lData && lData[KEY_LINKBOX_LINK_TEXT]}
                          editable={true}
                        />

                        {
                          <Text
                            tag="div"
                            className={styles.linkBox_data__sub_heading}
                            field={lData && lData[KEY_LINKBOX_LINK_DESCRIPTION]}
                            editable={true}
                          />
                        }
                      </Link>
                    )}
                  </div>
                );
              })
            : ''}
        </div>
      </div>
    </div>
  );
}
