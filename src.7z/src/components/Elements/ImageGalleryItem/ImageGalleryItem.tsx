import { useContext } from 'react';
import { Image, Text, useSitecoreContext } from '@sitecore-jss/sitecore-jss-nextjs';
import { formatImageGalleryItemsData } from 'src/helpers/component.helper';
import { KEY_IG_THUMBNAIL, KEY_IG_IMAGE_CAPTION } from 'src/constants/general';
import { GalleryContext } from 'src/contexts/GalleryContext';
import { OptimizedImage } from 'src/components/Elements/OptimizedImage/OptimizedImage';
import styles from './ImageGalleryItem.module.scss';

export default function ImageGalleryItem(props: any) {
  const { sitecoreContext } = useSitecoreContext();
  const isExperienceEditor = sitecoreContext && sitecoreContext.pageEditing;
  const isSliderThumbnail: any = props && props['data-isSliderThumbnail'];
  const isImageEnlarge: any = props && props['data-isImageEnlarge'];
  const isOverlaySlider: any = props && props['data-isOverlaySlider'];
  const isSliderSmall: any = props && props['data-isSliderSmall'];
  const formattedData: any = formatImageGalleryItemsData(props);
  const { setShowModal } = useContext(GalleryContext);
  const handleEnlargeClick = () => {
    setShowModal(true);
  };
  return (
    <div className={styles.img_main__container}>
      <div
        className={`${styles.img__container} ${
          isOverlaySlider && !isSliderThumbnail && styles.img__container__overlay
        } ${isOverlaySlider && isSliderThumbnail && styles.img__container__overlay__thumbnail}
        `}
      >
        {isImageEnlarge && <div className={styles.img__enlarge} onClick={handleEnlargeClick}></div>}
        {isOverlaySlider && isSliderThumbnail ? (
          <OptimizedImage
            imageData={formattedData && formattedData[KEY_IG_THUMBNAIL]}
            scaleData={[
              { mWidth: 767, width: 120, height: null },
              { mWidth: 1019, width: 120, height: null },
              { mWidth: 1020, width: 120, height: null },
            ]}
            customClass={styles.thumbnail}
          />
        ) : isOverlaySlider ? (
          // <Image
          //   classname={styles.img_item}
          //   field={formattedData && formattedData[KEY_IG_THUMBNAIL]}
          // />
          <OptimizedImage
            imageData={formattedData && formattedData[KEY_IG_THUMBNAIL]}
            scaleData={[
              { mWidth: 767, width: 820, height: 547 },
              { mWidth: 1019, width: 820, height: 547 },
              { mWidth: 1020, width: 820, height: 547 },
            ]}
            customClass={`${isOverlaySlider ? styles.img_custom_width : ''}`}
            isNormalMode={true}
            isBgColorAvailable={true}
          />
        ) : (
          <Image
            className={styles.img_item}
            field={formattedData && formattedData[KEY_IG_THUMBNAIL]}
          />
        )}
      </div>
      {!isSliderThumbnail && !isSliderSmall ? (
        <div
          className={`${styles.img__caption} ${
            !isExperienceEditor &&
            formattedData &&
            formattedData[KEY_IG_IMAGE_CAPTION] &&
            !formattedData[KEY_IG_IMAGE_CAPTION].value
              ? styles.img__caption__bg_transparent
              : ''
          }`}
        >
          <Text field={formattedData && formattedData[KEY_IG_IMAGE_CAPTION]} />
        </div>
      ) : (
        ''
      )}
    </div>
  );
}
