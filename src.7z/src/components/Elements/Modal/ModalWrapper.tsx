import React, { Fragment } from 'react';

export default function ModalWrapper(props: any) {
  return <Fragment>{props.children}</Fragment>;
}
