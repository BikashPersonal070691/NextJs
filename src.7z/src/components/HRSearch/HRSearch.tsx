import { useEffect, useState,useRef } from 'react';
import { Search } from '../Search/Search';
import {
  KEY_HEADER_HEIGHT_DESKTOP,
  KEY_HEADER_HEIGHT_TABLET,
  KEY_HEADER_HEIGHT_MOBILE,
  KEY_BREAKPOINT_MEDIUM_LARGE,
  KEY_BREAKPOINT_MEDIUM,
} from '../../constants/general';
import { HeaderProvider } from 'src/contexts/HeaderContext';
import styles from './HRSearch.module.scss';
import { Image } from '@sitecore-jss/sitecore-jss-nextjs';
import MainMenu from 'components/MainMenus/MainMenu';
import UtilityBox from 'components/UtilityBox/UtilityBox';
import { getNotifications} from 'src/services/menu.service';
import { onRedirect } from 'src/core/utils/utils.helper';
// import HeaderProfile from 'components/HeaderProfile/HeaderProfile';

export default function HRSearch(props: any) {
  const { fields } = props;
  const [stickyClass, setStickyClass] = useState('');
  const [mobileView, setMobileView] = useState(false);
  const [notificationData, setNotificationData] = useState<any>({});
  const [notificationPopupOpen, setNotificationPopupOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState<boolean>(false); // search icon & search box open close state
  const [searchInputDisplayValue, setSearchInputDisplayValue] = useState<any>(null); // for input box display
  const [mainMenuOpen, setMainMenuOpen] = useState<boolean>(false);
  const [initialLoad, setInitialLoad] = useState<boolean>(true);
  const [burgerIconShow, setBurgerIconShow] = useState<boolean>(true);
    const popupRef = useRef(null);
//   let mockData = {
//     "MorgoItems": [],
//     "MargoLabel": "Margo",
//     "MargoItem": "{400BA8CC-2D14-4E95-9DD5-9468FCBFCE87}",
//     "TopicsNotification": [
//         {
//             "ItemId": "4df2657b-567c-46e4-80a5-eb90db68b54b",
//             "TopicHeadline": "Updates on Ukraine",
//             "IsNew": true,
//             "PageLink": "",
//             "IsExternal": false
//         },
//         {
//             "ItemId": "c3b34cdd-3628-4b55-9875-1ba5f550cd34",
//             "TopicHeadline": "Annual Report2",
//             "IsNew": true,
//             "PageLink": "https://www.bayer.com/en/investors/integrated-annual-reports",
//             "IsExternal": true
//         }
//     ],
//     "TopicLabel": "TOPICS",
//     "AnnouncementNotification": {
//         "SearchResult": [
//             {
//                 "Headline": "Jessica Christiansen",
//                 "IsNewAnnouncement": true,
//                 "ItemID": "2e4696e7-d866-4855-a591-d1c6bcb45d5f",
//                 "PageLink": "/en/global/shared/corporate-announcements-folder/corporate-folder/2025/03/19/corporate-announcement-2",
//                 "IsExternal": false
//             },
//             {
//                 "Headline": "Phil Smits, Henrik Wulff",
//                 "IsNewAnnouncement": true,
//                 "ItemID": "efe6be74-4cec-45f1-903c-776e32df6d09",
//                 "PageLink": "/en/global/shared/corporate-announcements-folder/corporate-announcements-test/test-announcement",
//                 "IsExternal": false
//             },
//             {
//               "Headline": "Phil Smits, Henrik Wulff",
//               "IsNewAnnouncement": true,
//               "ItemID": "efe6be74-4cec-45f1-903c-776e32df6d09",
//               "PageLink": "/en/global/shared/corporate-announcements-folder/corporate-announcements-test/test-announcement",
//               "IsExternal": false
//           },
//           {
//             "Headline": "Phil Smits, Henrik Wulff",
//             "IsNewAnnouncement": true,
//             "ItemID": "efe6be74-4cec-45f1-903c-776e32df6d09",
//             "PageLink": "/en/global/shared/corporate-announcements-folder/corporate-announcements-test/test-announcement",
//             "IsExternal": false
//         }

//         ],
//         "TotalRecords": 10,
//         "AnnouncementLabel": "PERSONNEL ANNOUNCEMENTS"
//     },
//     "HeaderNotification": true,
//     "NotificationEmptyText": "You currently have no notifications"
// };
  useEffect(() => {
    // sticky navbar event listener
    window.addEventListener('scroll', stickNavbar);
    return () => window.removeEventListener('scroll', stickNavbar);
  }, [mainMenuOpen]);

  useEffect(() => {
    if (window.innerWidth < KEY_BREAKPOINT_MEDIUM_LARGE) {
      if (searchOpen) {
        document.body.style.overflow = 'hidden';
      } else {
        document.body.style.overflow = 'visible';
      }
    }
  }, [searchOpen]);

  /**
   * @description handling header sticky function
   */
  var lastScrollTop = 0;
  const stickNavbar = () => {
    if (!mainMenuOpen) {
      if (
        window !== undefined &&
        window.innerHeight + window.scrollY < document.body.scrollHeight
      ) {
        let windowHeight = window.scrollY;
        let headerHeight =
          window.innerWidth > KEY_BREAKPOINT_MEDIUM_LARGE
            ? KEY_HEADER_HEIGHT_DESKTOP
            : window.innerWidth > KEY_BREAKPOINT_MEDIUM
            ? KEY_HEADER_HEIGHT_TABLET
            : KEY_HEADER_HEIGHT_MOBILE;

        var st = window.pageYOffset || document.documentElement.scrollTop;
        if (st < lastScrollTop) {
          // scroll top

          // need to uncomment if tab & mob sticky design not want animation
          // windowHeight > headerHeight && window.innerWidth > KEY_BREAKPOINT_MEDIUM_LARGE
          //   ? setStickyClass(`${styles.header_sticky} ${styles.header_sticky_animation}`)
          //   : windowHeight > headerHeight && window.innerWidth < KEY_BREAKPOINT_MEDIUM_LARGE
          //   ? setStickyClass(styles.header_sticky)
          //   : setStickyClass('');

          windowHeight > headerHeight
            ? setStickyClass(
                `${styles.header_sticky} ${styles.header_sticky_animation_slide_top__bottom}`
              )
            : setStickyClass('');
          setBurgerIconShow(true);
        } else {
          //scroll bottom
          windowHeight > headerHeight
            ? (setStickyClass(
                `${styles.header_sticky} ${styles.header_sticky_animation_slide_bottom__top}`
              ),
              setTimeout(() => {
                setBurgerIconShow(false);
              }, 200))
            : (setStickyClass(''), setBurgerIconShow(true));
        }
        lastScrollTop = st <= 0 ? 0 : st; // For Mobile or negative scrolling
      }
    } else {
      setStickyClass('');
    }
  };

  const handleRedirection = () => {
    window.location.href =
      process.env && process.env.IMAGE_BASE_URL ? process.env.IMAGE_BASE_URL : '';
  };
  const CloseNotification = (e:any)=>{

    //Handling clicks once popup is open
    e.target.closest(".notification_wrapper") ?  e.target.closest(".close_container") ? setNotificationPopupOpen(false):  "": setNotificationPopupOpen(false);
    document.removeEventListener("click",CloseNotification);
  }
    const handleNotificationClick = (e:any) =>{
      e.stopPropagation();
      document.addEventListener("click",CloseNotification);
      setNotificationPopupOpen(!notificationPopupOpen);
  
  
    }
    const checksTargetPage = (path:any) => {
      const splitPath = path?.split('/')?.filter((item:any) => item);
      const isHomePage = splitPath?.length == 1;
      const isNewHomePage = (splitPath[1] || '').toLowerCase() === 'newHomePage'.toLowerCase();
      return isHomePage || isNewHomePage;
    };
  
    const redirectToSection = (sectionClass:any) => {
      // const section = document.querySelector(`.${sectionClass}`);
      const isTargetPage = checksTargetPage(window.location.pathname);
      if (isTargetPage) {
        const section = document.getElementsByClassName(sectionClass);
        if (section && section.length > 0) {
          section[0].scrollIntoView({
            behavior: 'smooth',
          });
        }
      } else {
        const getRedirection = window?.location?.host == 'cd.ci.bayernet.int.bayer.com' ? '/newHomePage' : '/';
        // const sessionKey = 'notification-routing-section';
        // sessionStorage.setItem(sessionKey, sectionClass);
        window.location.href = `${getRedirection}`;
      }
    };
  
    const handleEllipsisClick = (sectionClass:any) => {
      redirectToSection(sectionClass);
    };

    

    const onClickItemLink = (itemUrl:any, isNewTab:any, sectionclassName:any) => {
      if (itemUrl) {
        return onRedirect(itemUrl, isNewTab, true);
      }
      return redirectToSection(sectionclassName);
    };

    const onPressEnter = (e:any, actionType:any,  urlLink:any, isExternal:any, elementId:any) =>{
      if(e.key==="Enter"){
        if(actionType==="notification"){
          handleNotificationClick(e);
        } else if(actionType==="closeIcon"){
          setNotificationPopupOpen(false);
        } else if(actionType==="itemClick"){
          onClickItemLink(urlLink, isExternal, elementId);
        } else if(actionType==="ellipsisClick"){
          handleEllipsisClick(elementId)
        }
      }
    }

    
  useEffect(() => {
    

    getNotifications().then((data:any)=>{
      if(data && data.data){
        setNotificationData(data.data)
      }
    })

  }, []);

  return (
    <>
      <HeaderProvider
        value={{
          searchOpen,
          setSearchOpen,
          searchInputDisplayValue,
          setSearchInputDisplayValue,
          stickyClass,
          fields,
          mobileView,
          setMobileView,
          setMainMenuOpen,
          initialLoad,
        }}
      >
        <div className={`${styles.header_wrapper} ${stickyClass}`}>
          <div className={`${styles.header_inner__wrapper}`}>
            <div className={styles.burger_menu_wrapper}>
              {/* {!mobileView ? ( */}
              <div
                className={`${styles.img_burger_menu} ${mobileView ? styles.showCross : undefined}`}
                onClick={() => {
                  setMobileView(!mobileView ? true : false);
                  setInitialLoad(false);
                }}
              >
                {burgerIconShow && burgerIconShow ? (
                  <>
                    <div className={styles.top}></div>
                    <div className={styles.middle}></div>
                    <div className={styles.bottom}></div>
                  </>
                ) : (
                  ''
                )}
              </div>
              {/* ) : ( */}
              {/* <div
                  className={styles.burger_container}
                  onClick={() => {
                    setMobileView(mobileView ? false : true);
                  }}
                >
                  <span className={styles.top}></span>
                  <span className={styles.middle}></span>
                  <span className={styles.bottom}></span>
                </div> */}
              {/* )} */}
            </div>

            <div className={styles.logo_wrapper}>
              <div className={styles.bayer_logo_wrapper} onClick={handleRedirection}>
                <Image field={fields.Logo} editable={true} className={styles.img_bayer_logo} />
              </div>
              <div className={styles.bayerNet_logo_wrapper}>
                <div className={styles.utility_wrapper}>
                  <div className={styles.inner_logo_wrapper}>
                    <div onClick={handleRedirection} className={styles.img_bayerNet_logo} />
                  </div>

                  <UtilityBox />

                  {/* <HeaderProfile /> */}
                </div>

                <div className={styles.main_navigation_wrapper}>
                  <MainMenu mobileView={mobileView} />
                </div>
              </div>
            </div>

            <div className={styles.userinteractions_wrapper}>
            
            <div className= {`notification_wrapper ${styles.notification_wrapper}`}  >
                    <i className={`bell-icon ${styles.bell_icon} ${notificationPopupOpen? styles.opened:""}`} tabIndex={0}  aria-label="notification icon" onClick={handleNotificationClick}>
        <svg width="25" height="26" viewBox="0 0 25 26" fill="none">
            <path d="M12.39 2.946a7.435 7.435 0 0 0-7.434 7.434v4.444l-.876.876a1.24 1.24 0 0 0 .876 2.115h14.87a1.24 1.24 0 0 0 .876-2.115l-.877-.876V10.38a7.435 7.435 0 0 0-7.434-7.434zM12.39 22.772a3.717 3.717 0 0 1-3.717-3.718h7.435a3.717 3.717 0 0 1-3.717 3.718z" fill="#145375"/>
        </svg>
        </i>

        {notificationPopupOpen ? (
        <div ref={popupRef} className= {`notification_wrapper ${styles.mobile_notif_overlay}`} >
          {notificationData &&
          ((notificationData?.MorgoItems && notificationData?.MorgoItems?.length > 0) ||
            (notificationData?.TopicsNotification && notificationData?.TopicsNotification?.length > 0) ||
            (notificationData?.AnnouncementNotification?.SearchResult &&
              notificationData?.AnnouncementNotification?.SearchResult?.length > 0)) ? (
            <div>
              <div className={styles.close_container}>
                <div className={styles.notification_close}  onClick={() => setNotificationPopupOpen(false)} tabIndex={0} onKeyDown={(e)=>onPressEnter(e, 'closeIcon',null,null,null)}/>{' '}
              </div>

              {notificationData.MorgoItems && notificationData.MorgoItems.length > 0 && (
                <ul className={` ${styles.notification_content_area }  ${styles.border_sep }`} >
                  <div className= {styles.content_area_sep}>
                    <div className={styles.category_head}>
                      <svg
                        className={styles.icon}
                        width='16'
                        height='16'
                        viewBox='0 0 16 16'
                        xmlns='http://www.w3.org/2000/svg'
                        style={{ marginTop: '1px' }}
                      >
                        <path d='M2 8.553a.75.75 0 0 1 .75-.75h8.787L8.25 4.862a.75.75 0 1 1 1-1.118L14 7.994a.75.75 0 0 1 0 1.118l-4.75 4.25a.75.75 0 0 1-1-1.118l3.287-2.941H2.75a.75.75 0 0 1-.75-.75z' />
                      </svg>
                      <span className={styles.notification_category} onClick={() => handleEllipsisClick('homepage-margo-feed-importer')}
                        tabIndex={0}
                        aria-label={notificationData?.MargoLabel?.toLowerCase()}
                        onKeyDown={(e)=>onPressEnter(e, 'ellipsisClick', null, null, 'homepage-margo-feed-importer')}
                      >
                        {notificationData?.MargoLabel?.toLowerCase()}
                      </span>

                      {/* {hasNewItem(notificationData.MorgoItems) && (
                        <div>
                          <i className='bubble'></i>
                        </div>
                      )} */}
                    </div>
                    {notificationData.MorgoItems.map(
                      (item:any, index:any) =>
                        index < 3 && (
                          <li
                            key={index}
                            className={styles.notification_content}
                            onClick={() => onClickItemLink(item.MargoUrl, item.IsExternal, 'homepage-margo-feed-importer')}
                            tabIndex={0}
                            aria-label={item.MargoHeadline}
                            onKeyDown={(e)=>onPressEnter(e, 'itemClick', item.MargoUrl, item.IsExternal, 'homepage-margo-feed-importer')}
                          >
                            {item.MargoHeadline}
                          </li>
                        ),
                    )}
                    {notificationData.MorgoItems.length > 3 && (
                      <div className={styles.more_ellipsis}>
                        <span
                          className= {` ${styles.more_dot_icon}  ${styles.pointer_cursor }`}
                          onClick={() => handleEllipsisClick('homepage-margo-feed-importer')}
                          tabIndex={0}
                          aria-label='Ellipsis icon'
                          onKeyDown={(e)=>onPressEnter(e, 'ellipsisClick', null, null, 'homepage-margo-feed-importer')}
                        >
                          ...
                        </span>
                      </div>
                    )}
                  </div>
                </ul>
              )}

              {notificationData.TopicsNotification && notificationData.TopicsNotification.length > 0 && (
                <ul className={` ${styles.notification_content_area}  ${styles.border_sep }`}>
                  <div className={styles.content_area_sep}>
                    <div className={styles.category_head}>
                      <svg
                        className={styles.icon}
                        width='16'
                        height='16'
                        viewBox='0 0 16 16'
                        xmlns='http://www.w3.org/2000/svg'
                        style={{ marginTop: '1px' }}
                      >
                        <path d='M2 8.553a.75.75 0 0 1 .75-.75h8.787L8.25 4.862a.75.75 0 1 1 1-1.118L14 7.994a.75.75 0 0 1 0 1.118l-4.75 4.25a.75.75 0 0 1-1-1.118l3.287-2.941H2.75a.75.75 0 0 1-.75-.75z' />
                      </svg>
                      <span className={styles.notification_category} onClick={() => handleEllipsisClick('homepage-topics')}
                        tabIndex={0}
                        aria-label={notificationData?.TopicLabel?.toLowerCase()}
                        onKeyDown={(e)=>onPressEnter(e, 'ellipsisClick', null, null, 'homepage-topics')}  
                      >
                        {notificationData?.TopicLabel?.toLowerCase()}
                      </span>

                      {/* {hasNewItem(notificationData.TopicsNotification) && (
                        <div>
                          <i class='bubble'></i>
                        </div>
                      )} */}
                    </div>
                    {notificationData.TopicsNotification.map(
                      (topic:any, index:any) =>
                        index < 3 && (
                          <li
                            key={index}
                            className={styles.notification_content}
                            onClick={() => onClickItemLink(topic.PageLink, topic.IsExternal, 'homepage-topics')}
                            tabIndex={0}
                            aria-label={topic.TopicHeadline}
                            onKeyDown={(e)=>onPressEnter(e, 'itemClick', topic.PageLink, topic.IsExternal, "homepage-topics")}
                          >
                            {topic.TopicHeadline}
                          </li>
                        ),
                    )}
                    {notificationData.TopicsNotification.length > 3 && (
                      <div className={styles.more_ellipsis}>
                        <span className={` ${styles.more_dot_icon}  ${styles.pointer_cursor}`} onClick={() => handleEllipsisClick('homepage-topics')}
                        tabIndex={0}
                        aria-label="ellipsis icon"
                        onKeyDown={(e)=>onPressEnter(e, 'ellipsisClick', null, null, 'homepage-topics')}
                        >
                          ...
                        </span>
                      </div>
                    )}
                  </div>
                </ul>
              )}

              {notificationData.AnnouncementNotification.SearchResult &&
                notificationData.AnnouncementNotification.SearchResult.length > 0 && (
                  <ul className={styles.notification_content_area}>
                    <div className={styles.content_area_sep}>
                      <div className={styles.category_head}>
                        <svg
                          className={styles.icon}
                          width='16'
                          height='16'
                          viewBox='0 0 16 16'
                          xmlns='http://www.w3.org/2000/svg'
                          style={{ marginTop: '1px' }}
                        >
                          <path d='M2 8.553a.75.75 0 0 1 .75-.75h8.787L8.25 4.862a.75.75 0 1 1 1-1.118L14 7.994a.75.75 0 0 1 0 1.118l-4.75 4.25a.75.75 0 0 1-1-1.118l3.287-2.941H2.75a.75.75 0 0 1-.75-.75z' />
                        </svg>
                        <span className={styles.notification_category} onClick={() => handleEllipsisClick('homepage-announcements')}
                          tabIndex={0}
                          aria-label={notificationData?.AnnouncementNotification?.AnnouncementLabel?.toLowerCase()}
                          onKeyDown={(e)=>onPressEnter(e, 'ellipsisClick', null, null, 'homepage-announcements')}
                        >
                          {notificationData?.AnnouncementNotification?.AnnouncementLabel?.toLowerCase()}
                        </span>

                        {/* {hasNewItem(notificationData.AnnouncementNotification.SearchResult) && (
                          <div>
                            <i class='bubble'></i>
                          </div>
                        )} */}
                      </div>
                      {notificationData.AnnouncementNotification.SearchResult.map(
                        (announcement:any, index:any) =>
                          index < 3 && (
                            <li
                              key={index}
                              className={styles.notification_content}
                              onClick={() =>
                                onClickItemLink(announcement.PageLink, announcement.IsExternal, 'homepage-announcements')
                              }
                              tabIndex={0}
                              aria-label={announcement.Headline}
                              onKeyDown={(e)=>onPressEnter(e, 'itemClick', announcement.PageLink, announcement.IsExternal, "homepage-topics")}
                            >
                              {announcement.Headline}
                            </li>
                          ),
                      )}
                      {notificationData.AnnouncementNotification.SearchResult.length > 3 && (
                        <div className={styles.more_ellipsis}>
                          <span
                            className={` ${styles.more_dot_icon}  ${styles.pointer_cursor}`} 
                            onClick={() => handleEllipsisClick('homepage-announcements')}
                            tabIndex={0}
                            aria-label="ellipsis icon"
                            onKeyDown={(e)=>onPressEnter(e, 'ellipsisClick', null, null, 'homepage-announcements')}
                          >
                            ...
                          </span>
                        </div>
                      )}
                    </div>
                  </ul>
                )}

              {/* ))} */}
            </div>
          ) : (
            <div className={styles.no_notify_container}>
              <div>
                <div className={styles.notification_close}  tabIndex={0}  onClick={() => setNotificationPopupOpen(false)} onKeyDown={(e)=>onPressEnter(e, 'closeIcon',null,null,null)}/>
              </div>
              {(notificationData?.MorgoItems?.length === 0 || !notificationData.MorgoItems) &&
              (notificationData?.TopicsNotification?.length === 0 || !notificationData?.TopicsNotification) &&
              (notificationData?.AnnouncementNotification?.SearchResult?.length === 0 ||
                !notificationData?.AnnouncementNotification?.SearchResult) ? (
                <>
                  <div className={styles.no_notification_icon}  />
                  <p className={styles.notification_empty_text}>{notificationData.NotificationEmptyText}</p>
                </>
              ) : (
               ''
              )}
            </div>
          )}
        </div>
      ) : (
        ''
      )}
                </div>

              <Search />
            </div>
          </div>
        </div>
      </HeaderProvider>
      {/* <BreadCrumb /> */}
    </>
  );
}
