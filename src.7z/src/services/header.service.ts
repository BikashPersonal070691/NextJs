import { BAYER_TRANSLATE_API_ENDPOINT } from 'src/constants/general';
import { apiEndpoints } from 'src/core/api/apiEndpoints';
import { externalPostApi, httpRequest } from 'src/core/api/httpRequest';

const getAutoSuggestionsBayernet = (payload: any) => {
  return httpRequest(apiEndpoints.autoSuggestBayernet, 'post', payload);
};

const getAutoSuggestionTools = (payload: any) => {
  return httpRequest(apiEndpoints.autoSuggestTools, 'post', payload);
};

const saveBookmark = (payload: any) => {
  return httpRequest(apiEndpoints.saveFavorite, 'post', payload);
};

const getlanguageList = (payload: any) => {
  return externalPostApi(`${BAYER_TRANSLATE_API_ENDPOINT}v2/languages`, payload);
};

export { getAutoSuggestionsBayernet, getAutoSuggestionTools, saveBookmark, getlanguageList };


