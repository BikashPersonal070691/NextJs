export const APP_NAME = 'HR Gateway';
export const KEY_COOKIE_NAME = 'bag.intra.ws.bayernet#lang'; //'.AspNet.Cookies';
// export const KEY_AUTHENTICATION_APP_URL = 'https://cd.ci.bayernet.int.bayer.com/en?';
export const KEY_GRAPH_API_ENDPOINT = 'https://graph.microsoft.com/v1.0';
//environments
export const KEY_BASE_URL = 'bayernet.int.bayer.com';
export const KEY_ENVIRONMENTS: any = {
  ENV_LOCAL: ['localhost:8080'],
  ENV_CD: [
    `cd.ci.${KEY_BASE_URL}`,
    `cd.uat1.${KEY_BASE_URL}`,
    `cd.qa.${KEY_BASE_URL}`,
    `cd.trprod.${KEY_BASE_URL}`,
    `${KEY_BASE_URL}`,
  ],
  ENV_CM: [
    `cm.ci.${KEY_BASE_URL}`,
    `cm.uat1.${KEY_BASE_URL}`,
    `cm.qa.${KEY_BASE_URL}`,
    `cm.trprod.${KEY_BASE_URL}`,
    `cm.${KEY_BASE_URL}`,
  ],
  ENV_NODE: [
    `bn-ci-sc103-node-01.azurewebsites.net`,
    `bn-uat-sc103-node-01.azurewebsites.net`,
    `bn-qa-sc103-node-01.azurewebsites.net`,
    'bn-trp-sc103-node-01.azurewebsites.net',
    'bn-prod-sc103-node-01.azurewebsites.net',
  ],
};
//languages
export const KEY_LANGUAGES = [
  'en',
  'de-DE',
  'es-ES',
  'zh-CN',
  'ko-KR',
  'pl-PL',
  'ja-JP',
  'fr-FR',
  'pt-PT',
  'ru-RU',
  'it-IT',
  'nl-NL',
  'fi-FI',
  'tr-TR',
  'el-GR',
];
//breakpoints
export const KEY_BREAKPOINT_XXX_LARGE = 1440;
export const KEY_BREAKPOINT_XX_LARGE = 1281;
export const KEY_BREAKPOINT_X_LARGE = 1280;
export const KEY_BREAKPOINT_LARGE = 1199;
export const KEY_BREAKPOINT_MEDIUM_LARGE = 1019;
export const KEY_BREAKPOINT_MEDIUM: any = 767;
export const KEY_BREAKPOINT_SMALL = 679;
export const KEY_BREAKPOINT_SMALL_CALENDAR = 480;
//image link
export const KEY_IMAGE_BASE_URL = process.env.IMAGE_BASE_URL
  ? process.env.IMAGE_BASE_URL
  : 'https://cd.ci.bayernet.int.bayer.com';
export const KEY_IS_PREVIEW = 'preview';
export const KEY_IS_EDIT = 'edit';
export const KEY_QA_ENV = 'https://cd.qa.bayernet.int.bayer.com';

//Header
// export const KEY_HEADER_HEIGHT_DESKTOP = 140;
export const KEY_HEADER_HEIGHT_DESKTOP = 72;
export const KEY_HEADER_HEIGHT_TABLET = 75;
export const KEY_HEADER_HEIGHT_MOBILE = 54;

// Search
export const KEY_SEARCH_SECTION_TOOLS_RESOURCES = 'Tools Resources';
export const KEY_SEARCH_SECTION_BAYERNET = 'Bayernet';
export const KEY_SEARCH_SECTION_PEOPLE_FINDER = 'People Finder';
export const KEY_SEARCH_SECTION_SEARCH_CENTER = 'Search Center';
export const KEY_SEARCH_LINK_ICON = 'link';
export const KEY_SEARCH_TAG_ICON = 'tag';
export const KEY_SEARCH_REDIRECT_BAYERNET = '?bayernetsearchterm={1}&isTag={2}';
export const KEY_SEARCH_REDIRECT_PEOPLE_FINDER = '{1}';
export const KEY_SEARCH_REDIRECT_SEARCH_CENTER = '{1}';
export const KEY_SEARCH_REDIRECT_TOOLS = '?quicklinksearchterm={1}';

//LinkBox
export const KEY_LINKBOX_LINK_DESCRIPTION = 'Link Description';
export const KEY_LINKBOX_LINK_TEXT = 'Link Text';
export const KEY_LINKBOX_LINK_URL = 'Link URL';
export const KEY_LINKBOX_LINK_KEY = 'Select Links only for HR Headless pages';
export const KEY_LINKBOX_LINK_TARGET_BLANK = 'external';
export const KEY_LINKBOX_LINK_BGCOLOR = 'Background Color';
export const KEY_LINKBOX_LINK_HEADING = 'Headline';
export const KEY_LINKBOX_LINK_HEADING_DESCRIPTION = 'Description';

//VideoBox
export const KEY_VIDEOBOX_HEADING = 'Headline';
export const KEY_VIDEOBOX_DESCRIPTION = 'Text';
export const KEY_VIDEOBOX_TYPE = 'linktype';
export const KEY_VIDEOBOX_CAPTION = 'Video Caption';
export const KEY_VIDEOBOX_SRC = 'href';
export const KEY_VIDEOBOX_URL = 'Video URL';
export const KEY_VIDEOBOX_TIME = 'Video Time';
export const KEY_VIDEOBOX_EXTERNAL = 'external';
export const KEY_VIDEOBOX_MEDIA = 'media';
export const KEY_VIDEOBOX_INTERNAL = 'internal';
export const KEY_VIDEO_THUMBNAIL = 'Video Thumbnail';
export const KEY_VIDEOBOX_TARGET = 'target';
export const KEY_VIDEOBOX_TARGET_BLANK = '_blank';
export const KEY_VIDEOBOX_ISHIGHLIGHT = 'Is Highlighted';
export const KEY_VIDEOBOX_ISDURATION = 'Show Duration';

export const KEY_IMPRINT_LINK = 'https://cd.uat1.bayernet.int.bayer.com/en/imprint';
export const KEY_PRIVACY_LINK = 'https://cd.uat1.bayernet.int.bayer.com/en/privacy-page';

// TextBox

export const KEY_TEXBOX_IMGCAPTION_ENLARGED = 'Enlarged Image Caption';
export const KEY_TEXBOX_FLOAT_RIGHT = 'Float Right';
export const KEY_TEXBOX_HEADLINE = 'Headline';
export const KEY_TEXBOX_IMAGE = 'Image';
export const KEY_TEXBOX_IMGCAPTION = 'Image Caption';
export const KEY_TEXBOX_SUBHEADLINE = 'Sub Headline';
export const KEY_TEXBOX_TEXT = 'Text';
export const KEY_TEXBOX_ABSTRACT_TEXT = 'Abstract Text';
export const KEY_TEXBOX_ENLARGE_IMAGE_ONLOAD = 'Enlarge Image On Load';
export const KEY_TEXBOX_ENLARGED_IMAGE = 'Enlarged Image';
export const KEY_TEXTBOX_ANCHOR = 'Anchor';

export const CLASS_NAME_PREFIX = 'menu';
export const APP_NAME_BAYER = 'bayer';
export const NUMBER_OF_LEVELS = 5;
export const HOME_PAGE = 'https://bayernet.int.bayer.com/en/';

//TEASER
export const KEY_TEASER_BG_COLOR = 'Background Color';
export const KEY_TEASER_TEASER_CAPTION = 'Caption';
export const KEY_TEASER_HEADLINE = 'Headline';
export const KEY_TEASER_IMAGE = 'Image';
export const KEY_TEASER_MAIN_LNK = 'Main Link';
export const KEY_TEASER_TEXT = 'Text';
export const KEY_TEASER_ALIGN_VERTICAL = 'Align Vertical';
export const KEY_TEASER_IS_HIGHLIGHTED = 'Is Highlighted';
export const KEY_TEASER_SHOW_SUB_LINKS = 'Show Sub Links';
export const KEY_TEASER_SHOW_TEXT = 'Show Text';
export const KEY_TEASER_SUB_LINKS = 'Select sublinks for headless';
export const KEY_TEASER_LINK_ITEM = 'Link Item';

//GROUP TEASER
export const KEY_GROUPTEASER_SLIDER_VIEW = 'Slide Teaser';
export const KEY_GROUPTEASER_HEADLINE = 'Headline';
export const KEY_GROUPTEASER_HORIZONTAL_VIEW = 'Horizontal Placing';
export const KEY_GROUPTEASER_TEASERDATA = 'Select teaser required';

//Tiles Component
export const SLIDE_WIDTH = 289; // Slide width plus right margin
//SRTiles Component
export const KEY_SRTILE_HEADLINE = 'headline';
export const KEY_SRTILE_IMAGE = 'image';
export const KEY_SRTILE_HOVER_IMAGE = 'mouseoverImage';

// color pallete
export const COLOR_PALLETE = [
  {
    key: '{5660D089-A7DD-40C3-94E8-530FEFE7BBE4}',
    value: '#ffffff',
  },
  {
    key: '{5EE9CA73-CECF-40D8-A889-87540E988071}',
    value: '#FFEAF0',
  },
  {
    key: '{B119F4D4-A90A-4641-8176-1B295E9F593D}',
    value: '#f2f8fa',
  },
  {
    key: '{8A1AD264-DF2D-4FBB-B7B4-1A1FC2689CEA}',
    value: '#F3FFE6',
  },
  {
    key: '{25A059AB-F3AB-4F3D-A382-8E30E71709F8}',
    value: '#e4f0f4',
  },
];

// color pallete
export const TEASER_COLOR_PALLETE = [
  {
    key: 'Light Blue',
    value: '#e4f0f4',
  },
  {
    key: 'Light Green',
    value: '#edfde5',
  },
  {
    key: 'Light Grey',
    value: '#f2f8fa',
  },
  {
    key: 'Light Red',
    value: '#ffeaef',
  },
  {
    key: 'White',
    value: '#fff',
  },
];
// Contact
export const KEY_TEAMS_STATUS_AVAILABLE = 'Available';
export const KEY_TEAMS_STATUS_AWAY = 'Away';
export const KEY_TEAMS_STATUS_BLOCKED = 'Blocked';
export const KEY_TEAMS_STATUS_BUSY = 'Busy';
export const KEY_TEAMS_STATUS_DO_NOT_DISTURB = 'DoNotDisturb';
export const KEY_TEAMS_STATUS_INVISIBLE = 'Invisible';
export const KEY_TEAMS_STATUS_OFFLINE = 'Offline';
export const KEY_TEAMS_STATUS_BRB = 'BeRightBack';
export const KEY_TEAMS_API_ERROR_INVALID_TOKEN = 'InvalidAuthenticationToken';

//Wideimage
export const WIDE_IMAGE_CAPTION = 'Caption';
export const WIDE_IMAGE_HEADLINE = 'Headline';
export const WIDE_IMAGE_SRC = 'Image';

//modal dialog
export const MODAL_TYPE_VIDEO = 'video';
export const MODAL_TYPE_TEXT = 'text';
export const MODAL_TYPE_LOADER = 'loader';
export const MODAL_TYPE_CALENDER = 'calender';
export const MODAL_TYPE_IFRAME = 'iframe';

export const KEY_PAST_EVENT = 'PAST';
export const KEY_PARESENT_EVENT = 'PRESENT';
export const KEY_FUTURE_EVENT = 'FUTURE';

export const KEY_DEFAULT_LINKS = 'DefaultLinks';

export const KEY_PAGE_HEADLINE = 'Page Headline';
export const KEY_PAGE_ABSTRACT = 'Page Abstract';
//SR Tiles
export const SR_TILE_HEADLINE = 'heading';
export const SR_TILE_LINK_TEXT = 'buttonText';
export const SR_TILE_LINK_URL = 'buttonLink';
//accordion
export const ACCORDION_OPEN = 'Accordion Open';
export const ACCORDION_ITEMS = 'items';
export const ACCORDION_ITEM_TITLE = 'Title';
export const TAB_ITEM_TITLE = 'Tab Title';
export const ACCORDION_ITEM_OPEN_DEFAULT = 'Accordion Open Default';
export const ACCORDION_PLACEHOLDER = 'AccordionPlaceholder';
export const DEFAULT_COLOR_FOR_TIMELINE = '#00bcff';
export const MY_HR_MENU_TEMPLETE_ID = '036f2d50-f8d6-4641-bf98-1ea03319d540';
export const COLOR_SELECTED_MAIN_MENU = '#0091c8';
export const COLOR_NON_SELECT_MAIN_MENU = '#10384f';
export const URL_MY_HR = 'My_HR';
export const DEFAULT_DATE_VALUE = '0001-01-01T00:00:00Z';
export const PAGE_UNDER_CONSTRUCTION = 'page-under-construction';
export const THROUGHOUT_THE_YEAR = {
  value: 'Throughout the Year',
};
export const MONTH_NAME_JAN = 'Jan';
export const MONTH_NAME_DEC = 'Dec';

//cluster menu
export const OVERLAY_INITIAL_WIDTH = 790;
export const OVERLAY_EXTENDED_WIDTH = 1042;

//quote component
export const KEY_QUOTE_BG_COLOR = 'Background Color';
export const KEY_QUOTE_SIGNATURE = 'Signature Visible';
export const KEY_QUOTE_AUTHOR_IMG = 'Author Image';
export const KEY_QUOTE_AUTHOR_NAME = 'Author name';
export const KEY_QUOTE_JOB_DESC = 'Job Description';
export const KEY_QUOTE_VALUE = 'Quote';
export const COLOR_PALLETE_QUOTE = [
  {
    key: '{D997F58A-7164-4FF2-86F8-9637E5974128}',
    value: '#71536d',
  },
  {
    key: '{F63DECEB-7C7C-4CEC-AFF3-3E3BD9D8F76B}',
    value: '#269fd0',
  },
  {
    key: '{5C222227-C387-4B0D-92B9-1333C7693804}',
    value: '#e4f0f4',
  },
];
// Feedback
export const KEY_FEEDBACK_WORD_COUNT = 1000;
export const KEY_FEEDBACK_QUESTION_MAIN = 'Feedback Questions';
export const KEY_FEEDBACK_QUESTION = 'Question';
export const KEY_FEEDBACK_HEADING = 'Headline';
//cookie
export const KEY_COOKIE_PRIVACY_LINK = 'Privacy Link';

export const KEY_HR_CALENDAR_TABS = [
  { id: 1, label: 'Employee' },
  { id: 2, label: 'People Leader' },
];
export const KEY_DEEP_LINK_EMPLOYEE = 'employee';
export const KEY_DEEP_LINK_LEADER = 'leader';
export const KEY_MONTH_NAMES = [
  { id: 1, name: 'jan' },
  { id: 2, name: 'feb' },
  { id: 3, name: 'mar' },
  { id: 4, name: 'apr' },
  { id: 5, name: 'may' },
  { id: 6, name: 'jun' },
  { id: 7, name: 'jul' },
  { id: 8, name: 'aug' },
  { id: 9, name: 'sep' },
  { id: 10, name: 'oct' },
  { id: 11, name: 'nov' },
  { id: 12, name: 'dec' },
];

export const KEY_CALENDAR_TASKS = 'HR Tasks';
export const KEY_CALENDAR_PDF = 'PDF Folder';
export const KEY_CALENDAR_LINKS = 'HR LinkBox';
export const KEY_CALENDAR_BANNER = 'Banner Folder';
export const KEY_CALENDAR_DUE = 'Deadline of Task';

export const KEY_ROLE_EMPLOYEE = 'Employee';
export const KEY_ROLE_PEOPLE_LEADER = 'PeopleLeader';
export const KEY_ROLE_EMP_AND_PEOPLE_LEADER = 'EmpAndPeopleLeader';

//anchortag
export const KEY_ANCHOR_DATA = 'Select Tags';
export const KEY_ANCHOR_DATA_TAG = 'Anchor';
export const KEY_ANCHOR_HEADING = 'Headline';

// Azure AD
export const KEY_AZURE_AD_URL = 'CurrentPageUrl';
export const KEY_AZURE_AD_CODE = 'AuthorizationCode';

//Tiles
export const TILE_HEADLINE = 'Headline';
export const TILE_LINK_TEXT = 'Button text';
export const TILE_LINK_URL = 'Button link';
export const TILE_IMAGE = 'Image';
export const TILE_DESCRIPTION = 'Description';
export const TILE_TEXT = 'Text';
export const TILE_LINK = 'Link';
export const TILE_IMAGE_HOVER = 'Mouseover image';
export const TILE_SHOW_MOUSE_HOVER = 'Show Mouseover effect';

export const CALENDAR_LINK_TEXT = 'Link Text';
export const CALENDAR_LINK_URL = 'Link URL';

export const COLOR_SELECTED_MAIN_MENU_SMALL_SCREEN = '#0091df';
export const COLOR_NON_SELECT_MAIN_MENU_SMALL_SCREEN = '#737373';

export const KEY_HR_TASK_LAYOUT_SERVICE_RESPONSE = 'HR Task';
export const KEY_MAIN_CONTENT_TRANSLATION_ID = '__main_section';
export const KEY_POPUP_TRANSLATION_ID = '__popup_container';

export const CODE_CHALLENGE_METHOD = 'S256';
export const CODE_CHALLENGE = 'MtiuruIoWiXcYl0RARn1mZeAb-vnrRB5zUXSPCy_fLQ';
export const CODE_VERIFIER =
  'lffWDlOWRfD-1y5xGPDnQnC.DoWjhYHbPYvb_CmWkCXBuFMcm2NjNVOPmduasK.nogPDZ-SZ6rQLUZnNa7CSxbqYaE.x8SsOa-A4gLdgg-lZWqVYqgvqvd5S9T1lWqNu';

export const BAYER_TRANSLATE_API_ENDPOINT = 'https://translate.int.bayer.com/api/translate/';
export const BAYER_TRANSLATE_KEY = 'bayernet-widget';
export const BAYER_TRANSLATE_MAIN_PAGE = 'https://translate.int.bayer.com/translation';
export const BAYER_TRANSLATE_LABEL = 'BayerTranslate';

export const GRAPH_API_SCOPE = 'openid profile email';
export const GRAPH_API_GRANT_TYPE = 'authorization_code';
export const GRAPH_API_ENDPOINT = `https://login.microsoftonline.com/${process.env.AZURE_AD_TENANT_ID}/oauth2/v2.0/token`;
export const GRAPH_API_ACCESS_TOKEN_KEY = 'Azure_Access_Token';

// export const ROI5_WIDGET_SCRIPT = 'https://cdn.roi5.747385846639.cloud.bayer.com/portletce/0.7.139/portlet.js';
export const ROI5_WIDGET_SCRIPT =
  'https://cdn.roi5.747385846639.cloud.bayer.com/portletce/0.8.15-alpha.roi5-3121-auth-r.2/portlet.js';
export const ROI5_WIDGET_KEY_ITEM = 'Widget Item';
export const ROI5_WIDGET_KEY_SCRIPT = 'Widget Script';

export const KEY_URL_STRING_REMOVAL = 'global-headless-portal/home/';
export const KEY_SELECTED_LANGUAGE = 'SelectedLanguage';
export const KEY_PAGE_LANGUAGE = 'PageLanguage';
export const KEY_DEFAULT_SELECTED_LANGUAGE = 'DefaultSelectedLanguage';
export const KEY_LANGUAGE_CODE_EN = 'en';
export const KEY_COOKIE_CURRENT_LANGUAGE = 'global-headless-portal#lang';
export const KEY_COOKIE_CURRENT_LANGUAGE1 = 'bag.intra.ws.bayernet#lang';
export const KEY_COOKIE_CURRENT_LANGUAGE2 = 'shell#lang';
export const KEY_COOKIE_PAGE_MODE = 'global-headless-portal#sc_mode';
export const KEY_COOKIE_PAGE_MODE2 = 'bag.intra.ws.bayernet#sc_mode';

export const IFRAME_BUTTON_TYPE = {
  HR_TASK: 'hr_task',
  KEY_TASK: 'key_task',
  HR_ALL_TASK:'hr_all_task'
};

export const KEY_SLIDER_TYPE: any = {
  GROUP_TEASER: { key: 'group-teaser', value: true, headlineField: 'Headline' },
  TILES: { key: 'tiles', value: true, headlineField: 'Headline' },
  IMAGEGALLERY: { key: 'image-gallery', value: true, headlineField: '' },
  VIDEOGALLERY: { key: 'video-gallery', value: true, headlineField: 'Gallery Headline' },
};

//image gallery
export const KEY_IG_THUMBNAIL = 'Thumbnail';
export const KEY_IG_IMAGE_CAPTION = 'Image Caption';
export const KEY_IG_IMAGE = 'Image';
export const KEY_IG_MAIN_TEXT = 'Text';
export const KEY_GALLERY_CAPTION = 'Gallery Caption';

//video gallery
export const KEY_VIDEO_GALLERY_HEADLINE = 'Gallery Headline';

// Iframe
export const KEY_IFRAME_BUTTON_TEXT = 'IFrameButtonText';
export const KEY_IFRAME = 'Iframe';

// KeyTask
export const KEY_KEYTASK_TIME_SPAN = 'Timespan Info';
export const KEY_KEYTASK_LINK_TEXT1 = 'Link Text1';
export const KEY_KEYTASK_LINK_URL1 = 'Link Url1';
export const KEY_KEYTASK_LINK_TEXT2 = 'Link Text2';
export const KEY_KEYTASK_LINK_URL2 = 'Link Url2';
export const KEY_KEYTASK_LINK_TEXT3 = 'Link Text3';
export const KEY_KEYTASK_LINK_URL3 = 'Link Url3';
export const KEY_KEYTASK_LINK_TEXT4 = 'Link Text4';
export const KEY_KEYTASK_LINK_URL4 = 'Link Url4';
export const KEY_KEYTASK_CTA_LINK = 'CTA link';

//Keytask card
export const KEY_KTC_IMAGE = 'IconImage';
export const KEY_KTC_HEADLINE = 'Heading';
export const KEY_KTC_CAPTION = 'TextArea';
export const KEY_KTC_HORIZONTAL = 'HorizontalView';
export const KEY_KTC_IS_HIGHLIGHTED = 'IsHeadlineHighlighted';
export const KEY_KTC_API_ENDPOINT = 'ApiEndPoint';
export const KEY_API_FIELD = 'ApiField';
export const KEY_KTC_HIDE_EYE_BUTTON = 'HideEyeButton';
export const KEY_KTC_API_NAME = 'APIName';
export const KEY_KTC_IMAGES = 'images';
export const KEY_KTC_ERROR = 'No Data';

