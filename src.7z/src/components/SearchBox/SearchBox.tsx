import { useState, useEffect, useRef, useContext } from 'react';
import { TextInput } from '../Elements/Input/Input';
import { Button } from 'components/Elements/Button/Button';
import { Radio } from 'components/Elements/Radio/Radio';
import { SearchAutoSuggestion } from 'components/SearchAutoSuggestion/SearchAutoSuggestion';
import {
  formatAutoSuggestionList,
  getSearchRadioConfig,
  searchUrlBuilder,
} from 'src/helpers/search.helper';
import {
  KEY_SEARCH_SECTION_TOOLS_RESOURCES,
  KEY_SEARCH_SECTION_BAYERNET,
  KEY_SEARCH_SECTION_PEOPLE_FINDER,
  KEY_SEARCH_SECTION_SEARCH_CENTER,
  KEY_SEARCH_REDIRECT_BAYERNET,
  KEY_SEARCH_REDIRECT_TOOLS,
  KEY_SEARCH_REDIRECT_PEOPLE_FINDER,
  KEY_SEARCH_REDIRECT_SEARCH_CENTER,
  KEY_SEARCH_TAG_ICON,
} from 'src/constants/general';
import { getAutoSuggestionsBayernet, getAutoSuggestionTools } from 'src/services/header.service';
import useOnClickOutside from 'src/hooks/useOnClickOutside';
import { HeaderContext } from 'src/contexts/HeaderContext';
import styles from './SearchBox.module.scss';
import { useLanguageTranslate } from 'src/hooks/useLanguageTranslate';
import { KEY_SEARCH_SEARCH_BUTTON, KEY_SEARCH_SEARCH_PLACEHOLDER } from 'src/constants/dictonary';

export function SearchBox(props: any) {
  const { closeHandler } = props;
  const { searchInputDisplayValue, stickyClass, setSearchInputDisplayValue, fields, searchOpen } =
    useContext(HeaderContext);
  const sectionConfig = getSearchRadioConfig(); // for fetching radiobutton configuration
  const [selectedSectionValue, setSelectedSectionValue] = useState<string>(sectionConfig[0].value); // for radio button value
  const [searchInputValue, setSearchInputValue] = useState<any>(null); // for input box value
  const [headerSticky, setHeaderSticky] = useState<any>(''); // for sticky class
  const [autoSuggestionList, setAutoSuggestionList] = useState<any>(null); // for auto suggestion list
  const ref = useRef();
  const { translatedKey } = useLanguageTranslate();
  /** for header sticky */
  useEffect(() => {
    if (stickyClass !== '') {
      setHeaderSticky(styles.header_search__sticky);
    } else {
      setHeaderSticky('');
    }
  }, [stickyClass]);

  /** debounce function for search input */
  useEffect(() => {
    const delayDebounceFn = setTimeout(() => {
      handleSearchSuggestion(searchInputValue);
    }, 500);

    return () => clearTimeout(delayDebounceFn);
  }, [searchInputValue, selectedSectionValue]);

  /** update search value to display value in input field */
  useEffect(() => {
    if (searchInputDisplayValue !== '') {
      setSearchInputValue(searchInputDisplayValue);
    }
  }, [searchInputDisplayValue]);

  useEffect(() => {
    if (searchOpen) {
      // setSearchInputValue('');
      // setSearchInputDisplayValue('');
      console.info('closed');
    }
  }, [searchOpen]);

  /** for closing autopopulate dropdown on outside click */
  useOnClickOutside(ref, () => setAutoSuggestionList(null));

  /**
   * @description handling auto suggestion api calling
   * @param inputVal
   */
  const handleSearchSuggestion = (inputVal: any) => {
    if (
      selectedSectionValue &&
      selectedSectionValue !== '' &&
      selectedSectionValue === KEY_SEARCH_SECTION_BAYERNET &&
      inputVal &&
      inputVal !== '' &&
      inputVal.length > 1
    ) {
      const requestObj = {
        IsGlobal: true,
        IsTag: false,
        keyword: inputVal,
        IsHomePage: true,
      };
      getAutoSuggestionsBayernet(requestObj).then((data: any) => {
        if (data && data.data) {
          const formattedData = formatAutoSuggestionList(
            data.data, // for mock json only otherwise data.data
            KEY_SEARCH_SECTION_BAYERNET,
            fields[KEY_SEARCH_SECTION_BAYERNET].value + KEY_SEARCH_REDIRECT_BAYERNET,
            inputVal,
            styles
          );
          setAutoSuggestionList(formattedData && formattedData.data);
        } else {
          setAutoSuggestionList(null);
        }
      });
    } else if (
      selectedSectionValue &&
      selectedSectionValue !== '' &&
      selectedSectionValue === KEY_SEARCH_SECTION_TOOLS_RESOURCES &&
      inputVal &&
      inputVal !== '' &&
      inputVal.length > 1
    ) {
      const requestObj = {
        keyword: inputVal,
      };
      getAutoSuggestionTools(requestObj).then((data: any) => {
        if (data && data.data) {
          const formattedData = formatAutoSuggestionList(
            data.data, // for mock json only otherwise data.data
            KEY_SEARCH_SECTION_TOOLS_RESOURCES,
            '',
            inputVal,
            styles
          );
          setAutoSuggestionList(formattedData && formattedData.data);
        } else {
          setAutoSuggestionList(null);
        }
      });
    } else {
      setAutoSuggestionList(null);
    }
  };

  /**
   * @description for handling radiobutton change
   */
  const handleSectionChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSelectedSectionValue(event.target.value);
  };

  /**
   * @description for handling input field change
   */
  const handleSearchInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSearchInputValue(event.target.value);
    setSearchInputDisplayValue(event.target.value);
  };

  /**
   * @description for handling search button click
   */
  const handleSearchAction = () => {
    if (searchInputValue && searchInputValue !== '') {
      if (selectedSectionValue === KEY_SEARCH_SECTION_TOOLS_RESOURCES) {
        window.location.href = searchUrlBuilder(
          fields[KEY_SEARCH_SECTION_TOOLS_RESOURCES].value + KEY_SEARCH_REDIRECT_TOOLS,
          searchInputValue,
          KEY_SEARCH_SECTION_TOOLS_RESOURCES
        );
      } else if (selectedSectionValue === KEY_SEARCH_SECTION_BAYERNET) {
        window.location.href = searchUrlBuilder(
          fields[KEY_SEARCH_SECTION_BAYERNET].value + KEY_SEARCH_REDIRECT_BAYERNET,
          searchInputValue,
          KEY_SEARCH_SECTION_BAYERNET
        );
      } else if (selectedSectionValue === KEY_SEARCH_SECTION_PEOPLE_FINDER) {
        window.open(
          searchUrlBuilder(
            fields[KEY_SEARCH_SECTION_PEOPLE_FINDER].value + KEY_SEARCH_REDIRECT_PEOPLE_FINDER,
            searchInputValue,
            KEY_SEARCH_SECTION_PEOPLE_FINDER
          ),
          '_blank'
        );
      } else if (selectedSectionValue === KEY_SEARCH_SECTION_SEARCH_CENTER) {
        window.open(
          searchUrlBuilder(
            fields[KEY_SEARCH_SECTION_SEARCH_CENTER].value + KEY_SEARCH_REDIRECT_SEARCH_CENTER,
            searchInputValue,
            KEY_SEARCH_SECTION_SEARCH_CENTER
          ),
          '_blank'
        );
      }
    }
  };

  return (
    <div className={`${styles.search_box_outer__container} ${headerSticky}`}>
      <div className={styles.search_box__container}>
        <div className={`${styles.container} ${styles.search_box__wrapper}`}>
          <div className={styles.search_box__box}>
            <div className={styles.search_box_row__one}>
              {sectionConfig &&
                sectionConfig.map((item: any, index: any) => {
                  return (
                    <div className={styles.search_box_row_one_radio__box} key={`${item.id}`}>
                      <Radio
                        key={`${index + item.id}`}
                        className={styles.search_box_row_one__radio}
                        id={item.id}
                        value={item.value}
                        label={item.label}
                        name={item.name}
                        onChange={handleSectionChange}
                        isDefault={item.isDefault}
                      />
                    </div>
                  );
                })}
            </div>
            <div className={styles.search_box_row__two}>
              <div className={styles.search_box_row_two_input__box}>
                <div>
                  <div className={styles.search_box_row_two_input__wrapper}>
                    <TextInput
                      className={styles.search_box_row_two__input}
                      // placeHolder="What are you looking for?"
                      placeHolder={translatedKey(KEY_SEARCH_SEARCH_PLACEHOLDER)}
                      name="search_box"
                      id="search_box"
                      onChange={handleSearchInputChange}
                      value={searchInputDisplayValue}
                      onKeyPress={(e: any) => {
                        if (e.key == 'Enter') {
                          handleSearchAction();
                        }
                      }}
                    />
                    <div className={styles.search_box_row_two_btn_box__mobile}>
                      <Button
                        class={styles.search_box_row_two_btn__mobile}
                        onClick={handleSearchAction}
                      >
                        <span>{translatedKey(KEY_SEARCH_SEARCH_BUTTON)}</span>
                      </Button>
                    </div>
                  </div>

                  {autoSuggestionList &&
                    Array.isArray(autoSuggestionList) &&
                    autoSuggestionList.length !== 0 && (
                      <div className={styles.search_box_row_two__autosuggestion}>
                        <div className={styles.search_box_row_two_autosuggestion__wrapper}>
                          {autoSuggestionList.map((item: any, index: number) => {
                            return (
                              <div key={index}>
                                <span
                                  className={
                                    item &&
                                    item.type === KEY_SEARCH_SECTION_BAYERNET &&
                                    item.icon === KEY_SEARCH_TAG_ICON
                                      ? styles.autosuggestion__divider
                                      : ''
                                  }
                                ></span>
                                <SearchAutoSuggestion innerRef={ref} listData={item} key={index} />
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}
                </div>
              </div>
              <div className={styles.search_box_row_two_btn__box}>
                <Button class={styles.search_box_row_two__btn} onClick={handleSearchAction}>
                  <span>{translatedKey(KEY_SEARCH_SEARCH_BUTTON)}</span>
                </Button>
              </div>
            </div>
          </div>
          {closeHandler}
        </div>
      </div>
    </div>
  );
}
