import React, { useState, useEffect, useRef } from 'react';
import { formatWorkFlowList, formatWorkFlowTimelineData } from 'src/helpers/component.helper';
import styles from './WorkFlowItem.module.scss';
import { Text, Field } from '@sitecore-jss/sitecore-jss-nextjs';
import {
  DEFAULT_COLOR_FOR_TIMELINE,
  KEY_FUTURE_EVENT,
  KEY_PARESENT_EVENT,
  KEY_PAST_EVENT,
  MONTH_NAME_DEC,
  MONTH_NAME_JAN,
  THROUGHOUT_THE_YEAR,
} from 'src/constants/general';
import { Placeholder } from '@sitecore-jss/sitecore-jss-nextjs';
import { getParentClassReference } from 'src/core/utils/utils.helper';
import { CONTENT_100 } from 'src/constants/contentDivider';
import { KEY_COMPONENT_WORKFLOW } from 'src/constants/contentDivider';
import { ComponentProps } from 'lib/component-props';
import { StyleguideSpecimenFields } from 'lib/component-props/styleguide';

type WorkFlowItemProps = ComponentProps &
  StyleguideSpecimenFields & {
    fields: {
      Headline: Field<string>;
      SubHeading: Field<string>;
    };
  };

const WorkFlowItem = (props: WorkFlowItemProps) => {
  const { fields } = props;
  const workFlowData = formatWorkFlowTimelineData(fields);
  const listData = formatWorkFlowList(workFlowData.listData);
  const [activeEvent, setActiveEvent] = useState<any>({});
  /**
   * @important This code needs to be used in every components inorder to get the content dividers reference
   * @important Also set the reference (ref) and className to the html wrapper as implemented below
   */
  // starts
  const nodeRef = useRef(null);
  const [parentRef, setParentRef] = useState<any>(null);
  useEffect(() => {
    const child: any = nodeRef.current;
    if (child !== null || child !== undefined) {
      setParentRef(getParentClassReference(child));
    } else {
      setParentRef(CONTENT_100);
    }
  }, [parentRef]);
  //ends
  const handleActiveEvent = (item: any) => {
    if (
      activeEvent &&
      activeEvent.eventName &&
      activeEvent.eventName.value === item.eventName.value
    ) {
      setActiveEvent({});
    } else {
      setActiveEvent(item);
    }
  };

  const getStatus = (event: any) => {
    return event.isWorkFlowItem === false ? (
      event.eventType && event.eventType === KEY_PAST_EVENT ? (
        <div className={`${styles.cd_timeline_green}`}>
          <div className={styles.arrow} />
        </div>
      ) : event.eventType === KEY_PARESENT_EVENT ? (
        <div className={`${styles.cd_timeline_blue}`}>
          <div className={styles.dot}></div>
        </div>
      ) : (
        <div className={`${styles.cd_timeline_grey}`}>
          <img />
        </div>
      )
    ) : (
      ''
    );
  };

  const getClass = (index: any, arr: any, event: any) => {
    if (index + 1 === arr.length || !event.isLine) {
      return styles.cd_timeline_wrapper_white;
    } else if (event.eventType === KEY_FUTURE_EVENT) {
      // return styles.cd_timeline_wrapper_white;
      return styles.cd_timeline_wrapper_grey;
    } else if (event.eventType && event.eventType === KEY_PAST_EVENT) {
      return styles.cd_timeline_wrapper;
    } else if (event.eventType && event.eventType === KEY_PARESENT_EVENT) {
      return styles.cd_timeline_wrapper_grey;
    } else {
      return styles.cd_timeline_wrapper;
    }
  };
  const addActiveClass =(e:any, eventType:string)=>{
   
    if (eventType!==KEY_FUTURE_EVENT && e.target && e.target.closest('.accordion-details')){
      let detailsElm = e.target.closest('.accordion-details');
      let accordionElm = detailsElm.querySelector('.accordion');
      if( accordionElm && accordionElm.classList.contains('open-default')){
        accordionElm.classList.remove('open-default');
       return
      }

      
      accordionElm && accordionElm.classList.contains('active') ? detailsElm.querySelector('.accordion').classList.remove('active'): detailsElm.querySelector('.accordion').classList.add('active');

    }
  
  }

  return (
    <div ref={nodeRef} className={styles[parentRef]}>
      <div className={styles.work_flow_wrapper}>
        <Text
          field={fields && fields.Headline}
          editable={true}
          tag="div"
          className={styles.headline}
        />
        <Text
          field={fields && fields.SubHeading}
          editable={true}
          tag="div"
          className={styles.sub_heading}
        />
        <div className={`${styles.cd_container}`}>
          {workFlowData.listData && Array.isArray(workFlowData.listData)
            ? workFlowData.listData.map((event: any, index: any) => (
                // <div className={getClass(index, workFlowData.listData, event)} key={index}>
                <div className={getClass(index, listData, event)} key={index}>
                  <div className={styles.cd_timeline_block}>
                    {getStatus(event)}
                    <div className={styles.cd_timeline_content} onClick={(divEvent)=>addActiveClass(divEvent, event.eventType)}>
                      <details className= {`${"accordion-details"}`
                    } >
                        
                       
                        <summary className={`accordion ${activeEvent.eventName &&
                                activeEvent.eventName.value === event.eventName.value ? 'active':''}`}>
                          <div className={styles.summary__wrapper} style={{cursor:'pointer'}}>
                            {event.eventType !== KEY_FUTURE_EVENT ? (
                              <h2
                                onClick={() => {
                                  handleActiveEvent(event);
                                }}
                                style={{ cursor: 'pointer' }}
                                className= {`accordion-heading-text  ${styles.full_width_title}`}
                                // className={`${event.labelText && event.labelText.value !== '' ? styles.short_title : (event.startMonthName && event.startMonthName.value === MONTH_NAME_JAN && event.endMonthName && event.endMonthName.value === MONTH_NAME_DEC) ? styles.thorought_the_year : styles.full_width_title}`}
                              >
                                {activeEvent.eventName &&
                                activeEvent.eventName.value === event.eventName.value ? (
                                  <div className={styles.wf_opened_arrow}></div>
                                ) : (
                                  <div className={styles.wf_closed_arrow}></div>
                                )}
                                <Text field={event.eventName} editable={true} />
                              </h2>
                            ) : (
                              <h2
                                
                                style={{cursor:'pointer'}}
                                className={styles.full_width_title}
                              >
                                {activeEvent.eventName &&
                                activeEvent.eventName.value === event.eventName.value ? (
                                  <div className={styles.wf_opened_arrow}></div>
                                ) : (
                                  <div className={styles.wf_closed_arrow}></div>
                                )}
                                <Text field={event.eventName} editable={true} />
                              </h2>
                            )}

                            <div
                              className={
                                event.startMonthName &&
                                event.startMonthName.value === MONTH_NAME_JAN &&
                                event.endMonthName &&
                                event.endMonthName.value === MONTH_NAME_DEC
                                  ? `${styles.feeds_wrapper} ${styles.feeds_wrapper_margin}`
                                  : styles.feeds_wrapper
                              }
                            >
                              {(event.startMonthName && event.startMonthName.value !== '') ||
                              (event.endMonthName && event.endMonthName.value !== '') ? (
                                <div
                                  className={`${styles.feeds} ${styles.center_align}  ${styles.margin_left_auto}`}
                                >
                                  <div className={styles.feeds_text}>
                                    <div className={styles.calendar}></div>
<div className={styles.calendar_date}>
{event.startMonthName &&
                                    event.startMonthName.value === MONTH_NAME_JAN &&
                                    event.endMonthName &&
                                    event.endMonthName.value === MONTH_NAME_DEC ? (
                                      <Text field={THROUGHOUT_THE_YEAR} editable={true} />
                                    ) : (
                                      <>
                                        <Text field={event.startMonthName} editable={true} />
                                        {event.startMonthName &&
                                        event.startMonthName.value &&
                                        event.endMonthName &&
                                        event.endMonthName.value &&
                                        event.startMonthName.value != event.endMonthName.value ? (
                                          <>
                                            {' '}
                                            - <Text field={event.endMonthName} editable={true} />
                                          </>
                                        ) : (
                                          ''
                                        )}
                                      </>
                                    )}
</div>
                                    
                                  </div>
                                </div>
                              ) : (
                                ''
                              )}

                              {event.labelText && event.labelText.value !== '' ? (
                                <div
                                  className={`${styles.feeds} ${styles.center_align} ${
                                    event.startMonthName && event.startMonthName.value === ''
                                      ? styles.margin_left_auto
                                      : ''
                                  }`}
                                >
                                  <div className={styles.feeds_text}>
                                    <>
                                      <div
                                        className={styles.color_dot}
                                        style={{
                                          backgroundColor:
                                            event && event.labelColor
                                              ? event.labelColor
                                              : DEFAULT_COLOR_FOR_TIMELINE,
                                        }}
                                      ></div>
                                      <span
                                        style={{
                                          lineHeight:
                                            event &&
                                            event.labelText &&
                                            event.labelText.value &&
                                            event.labelText.value.length > 24
                                              ? 'normal'
                                              : '2',
                                        }}
                                      >
                                        <Text field={event.labelText} editable={true} />
                                      </span>
                                    </>
                                  </div>
                                </div>
                              ) : (
                                ''
                              )}
                            </div>
                          </div>
                        </summary>
                        <div className={styles.placeholder_wrapper}>
                          <div id={KEY_COMPONENT_WORKFLOW} className={styles.workflow__inner}>
                            <Placeholder
                              name={event.placeholderName}
                              rendering={props.rendering}
                            />
                          </div>
                        </div>
                      </details>
                    </div>
                  </div>
                </div>
              ))
            : null}
        </div>
      </div>
    </div>
  );
};

export default WorkFlowItem;
