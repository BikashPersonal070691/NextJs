import { useState } from 'react';
import CalendarTaskXL from 'components/CalendarTaskXL/CalendarTaskXL';
import styles from './CalendarTaskContainerXL.module.scss';

export default function CalendarTaskContainerXL(props: any) {
  const { tasks, order } = props;
  const [rowHeight, setRowHeight] = useState(50);
  const [isHeightUpdated, setIsHeightUpdated] = useState(false);
  let childHeightArray: any = [];
  const handleLoad = (childHeight: any) => {
    childHeightArray.push(childHeight);
    if (
      tasks &&
      tasks.length > 0 &&
      childHeightArray.length > 0 &&
      tasks.length === childHeightArray.length
    ) {
      setRowHeight(Math.max(...childHeightArray));
      setIsHeightUpdated(true);
    }
  };

  return (
    <div
      className={styles.calendar_row_container}
      style={{
        height: rowHeight,
      }}
    >
      {tasks &&
        tasks.length > 0 &&
        tasks.map((item: any, index: any) => {
          return (
            <>
              <CalendarTaskXL
                {...item}
                key={index}
                order={order ? order : 0}
                handleLoad={handleLoad}
                commonHeight={rowHeight}
                takeHeight={isHeightUpdated}
              />
            </>
          );
        })}
    </div>
  );
}
