import { configureStore } from '@reduxjs/toolkit';
import profileReducer from './reducers/profileSlice';
import isPreviewModeReducer from './reducers/isPreviewModeSlice';
import languageDataReducer from './reducers/languageSlice';
import commonReducer from './reducers/commonSlice';

export default configureStore({
  reducer: {
    profile: profileReducer,
    expEditorProps: isPreviewModeReducer,
    language: languageDataReducer,
    common: commonReducer,
  },
});
