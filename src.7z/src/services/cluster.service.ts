import { apiEndpoints } from 'src/core/api/apiEndpoints';
import { httpRequest, httpRequestWithCancel } from 'src/core/api/httpRequest';

const getClusterData = () => {
  const url = apiEndpoints.getClusterNavData;
  return httpRequest(url, 'get');
};
const getClusterDataMobile = () => {
  const url = apiEndpoints.getClusterMobileNavData;
  return httpRequest(url, 'get');
};
const getSecondLevelClusterData = (rootId: any, templateId: any) => {
  const url = {
    url: `${apiEndpoints.getSecondLevelClusterNavData.url}/?rootid=${rootId}&level=2&template=${templateId}`,
    isMock: apiEndpoints.getSecondLevelClusterNavData.isMock,
  };
  // const url=apiEndpoints.getSecondLevelClusterNavData;
  return httpRequestWithCancel(url, 'get');
};

export { getClusterData, getSecondLevelClusterData, getClusterDataMobile };
