import { useEffect, useRef, useState } from 'react';
import { getParentClassReference } from 'src/core/utils/utils.helper';
import { CONTENT_100 } from 'src/constants/contentDivider';
import { formatQuoteData } from 'src/helpers/component.helper';
import {
  Image,
  Text,
  RichText,
  Field,
  useSitecoreContext,
} from '@sitecore-jss/sitecore-jss-nextjs';
import { ComponentProps } from 'lib/component-props';
import { StyleguideSpecimenFields } from 'lib/component-props/styleguide';
import {
  KEY_QUOTE_SIGNATURE,
  KEY_QUOTE_AUTHOR_IMG,
  KEY_QUOTE_AUTHOR_NAME,
  KEY_QUOTE_JOB_DESC,
  KEY_QUOTE_VALUE,
  KEY_QUOTE_BG_COLOR,
} from 'src/constants/general';
import { getParentAttributeReference } from 'src/core/utils/utils.helper';
import styles from './Quote.module.scss';

type QuoteComponentProps = ComponentProps &
  StyleguideSpecimenFields & {
    fields: {
      [KEY_QUOTE_AUTHOR_NAME]: Field<string>;
      [KEY_QUOTE_AUTHOR_IMG]: Field<string>;
      [KEY_QUOTE_JOB_DESC]: Field<string>;
      [KEY_QUOTE_VALUE]: Field<string>;
      [KEY_QUOTE_BG_COLOR]: Field<string>;
    };
  };

const Quote = (props: QuoteComponentProps) => {
  const quoteData = formatQuoteData(props);
  const { sitecoreContext } = useSitecoreContext();
  const isExperienceEditor = sitecoreContext && sitecoreContext.pageEditing;
  /**
   * @important This code needs to be used in every components inorder to get the content dividers reference
   * @important Also set the reference (ref) and className to the html wrapper as implemented below
   */
  // starts
  const nodeRef = useRef(null);
  const [parentRef, setParentRef] = useState<any>(null);
  const [dividerBg, setDividerBg] = useState<any>('white');
  useEffect(() => {
    const child: any = nodeRef.current;
    if (child !== null || child !== undefined) {
      setParentRef(getParentClassReference(child));
      setDividerBg(getParentAttributeReference(child, 'data-cd-bg'));
    } else {
      setParentRef(CONTENT_100);
    }
  }, []);
  //ends
  return (
    <div ref={nodeRef} className={styles[parentRef]}>
      <div
        className={`${
          quoteData && quoteData[KEY_QUOTE_BG_COLOR] === '#e4f0f4' ? styles.color__blue : ''
        } ${styles.quote__container}`}
        style={{
          backgroundColor:
            quoteData && quoteData[KEY_QUOTE_BG_COLOR] && quoteData[KEY_QUOTE_BG_COLOR] !== ''
              ? quoteData[KEY_QUOTE_BG_COLOR]
              : 'white',
        }}
      >
        <div
          className={`${styles.quote_image__wrapper} ${
            isExperienceEditor && styles.quote_image__wrapper__quote__exp__image_wrapper
          }`}
        >
          <Image
            className={!isExperienceEditor && styles.quote_image_wrapper__inner}
            field={quoteData && quoteData[KEY_QUOTE_AUTHOR_IMG]}
            editable={true}
          />
        </div>
        <div className={styles.quote_content_wrapper}>
          <div className={styles.quote_content__heading}>
            <Text
              tag="h3"
              className={styles.quote_content_heading__inner}
              field={quoteData && quoteData[KEY_QUOTE_AUTHOR_NAME]}
            />
            {quoteData && quoteData[KEY_QUOTE_SIGNATURE] == 1 ? (
              <RichText tag="p" field={quoteData && quoteData[KEY_QUOTE_JOB_DESC]} />
            ) : (
              ''
            )}
          </div>

          <RichText
            tag="div"
            className={styles.quote_content__description}
            field={quoteData && quoteData[KEY_QUOTE_VALUE]}
          />
        </div>
        <div
          className={styles.box_bottom__corner}
          style={{
            borderTopColor:
              quoteData && quoteData[KEY_QUOTE_BG_COLOR] && quoteData[KEY_QUOTE_BG_COLOR] !== ''
                ? quoteData[KEY_QUOTE_BG_COLOR]
                : 'white',
            borderLeftColor: dividerBg && dividerBg !== '' ? dividerBg : 'white',
          }}
        ></div>
      </div>
    </div>
  );
};

export default Quote;
