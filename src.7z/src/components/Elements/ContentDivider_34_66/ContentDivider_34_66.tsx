import { useRef, useEffect, useState } from 'react';
import { Field } from '@sitecore-jss/sitecore-jss-nextjs';
import { ComponentProps } from 'lib/component-props';
import { StyleguideSpecimenFields } from 'lib/component-props/styleguide';
import { Placeholder } from '@sitecore-jss/sitecore-jss-nextjs';
import { CONTENT_34, CONTENT_66, CD_34_66 } from 'src/constants/contentDivider';
import { formatContentDividerData } from 'src/helpers/contentDivider.helper';
import styles from './ContentDivider_34_66.module.scss';

type TwoColumnContainerProps = ComponentProps &
  StyleguideSpecimenFields & {
    fields: {
      heading: Field<string>;
    };
  };

const ContentDivider_34_66 = (props: TwoColumnContainerProps): JSX.Element => {
  const [isParentIdExists, setIsParentIdExists] = useState<boolean>(false);
  const currentElement: any = useRef(null);
  const contentDividerBg = formatContentDividerData(props);
  /**
   * @description to check if parent node has id . If parent has id it this current content divider is a nested content divider.
   */
  useEffect(() => {
    currentElement &&
    currentElement.current &&
    currentElement.current.parentNode &&
    currentElement.current.parentNode.id &&
    currentElement.current.parentNode.id !== undefined &&
    currentElement.current.parentNode.id !== ''
      ? setIsParentIdExists(true)
      : setIsParentIdExists(false);
  }, []);

  return (
    <section
      className={`${styles.divider_34_66__container} ${
        !isParentIdExists ? styles.divider_34_66_container__bg : ''
      }`}
      ref={currentElement}
      style={{
        backgroundColor:
          contentDividerBg && contentDividerBg.bgColor && contentDividerBg.bgColor !== ''
            ? contentDividerBg.bgColor
            : 'white',
      }}
    >
      <div className={styles.divider_34_66__wrapper}>
        <div
          className={styles.divider_34__container}
          id={CONTENT_34}
          data-nested={isParentIdExists}
          data-cd-bg={
            contentDividerBg && contentDividerBg.bgColor && contentDividerBg.bgColor !== ''
              ? contentDividerBg.bgColor
              : 'white'
          }
        >
          <Placeholder name={CD_34_66.PH_34_66_LEFT_34} rendering={props.rendering} />
        </div>
        <div
          className={styles.divider_66__container}
          id={CONTENT_66}
          data-nested={isParentIdExists}
          data-cd-bg={
            contentDividerBg && contentDividerBg.bgColor && contentDividerBg.bgColor !== ''
              ? contentDividerBg.bgColor
              : 'white'
          }
        >
          <Placeholder name={CD_34_66.PH_34_66_RIGHT_66} rendering={props.rendering} />
        </div>
      </div>
    </section>
  );
};

export default ContentDivider_34_66;
