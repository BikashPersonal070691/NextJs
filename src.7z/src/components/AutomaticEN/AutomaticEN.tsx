import { useContext, useEffect, useState } from 'react';
import { useLanguageTranslate } from 'src/hooks/useLanguageTranslate';
import styles from './AutomaticEN.module.scss';
import { Text } from '@sitecore-jss/sitecore-jss-nextjs';
import { KEY_AUTOMATIC_EN } from 'src/constants/dictonary';
import { CommonContext } from 'src/contexts/CommonContext';
import { getCookie, redirectWithLanguage, setToLocalStorage } from 'src/core/utils/utils.helper';
import { KEY_COOKIE_CURRENT_LANGUAGE, KEY_DEFAULT_SELECTED_LANGUAGE } from 'src/constants/general';

const AutomaticEN = (): JSX.Element => {
  const { translatedKey } = useLanguageTranslate();
  const { formattedLanguageData } = useContext(CommonContext);
  const [isOpen, setisOpen] = useState<any>(false);
  const handleLanguageBoxOpen = () => {
    setisOpen(!isOpen);
  };


  //console.log("translatedKey",translatedKey,"formattedLanguageData",formattedLanguageData)
  useEffect(() => {
    setTimeout(function () {
      let language: any = getCookie(KEY_COOKIE_CURRENT_LANGUAGE);
      //console.log("language",language);
      for (var i = 0; i < formattedLanguageData.length; i++) {
        if (
          formattedLanguageData[i].LanguageCode !== language &&
          formattedLanguageData[i].LanguageCode !== 'en'
        ) {
          setToLocalStorage(
            KEY_DEFAULT_SELECTED_LANGUAGE,
            JSON.stringify(formattedLanguageData[i])
          );
          redirectWithLanguage(formattedLanguageData[i].LanguageCode);
          break;
        }
      }
    }, 6000);
  });

  const handleRedirection = (data: any) => {
    setToLocalStorage(KEY_DEFAULT_SELECTED_LANGUAGE, JSON.stringify(data));
    redirectWithLanguage(data.LanguageCode);
  };

  //console.log("after","translatedKey",translatedKey,"formattedLanguageData",formattedLanguageData)
  return (
    <div className={styles.content_wrapper}>
      <div className={styles.no_lang_version}>
        <div className={styles.no_lang_img}></div>
        <Text
          tag="h1"
          className={styles.no_lang_content}
          field={{ value: translatedKey(KEY_AUTOMATIC_EN) }}
        />
        <div className={styles.no_lang_dropdown} onClick={() => handleLanguageBoxOpen()}>
          <div className={styles.language_dropdown_text}>EN</div>
          <div
            className={`${styles.language_dropdown_arrow} ${
              isOpen && isOpen ? styles.language_dropdown_arrow__open : ''
            }`}
          ></div>
          {isOpen && isOpen ? (
            <div className={styles.language_box}>
              <ul>
                {formattedLanguageData &&
                  formattedLanguageData.length > 0 &&
                  formattedLanguageData.map((data: any) => {
                    return (
                      <li key={data && data.LanguageName}>
                        <a onClick={() => handleRedirection(data)}>{`${data && data.LanguageName} ${
                          data && data.Text && `(${data.Text})`
                        }`}</a>
                      </li>
                    );
                  })}
              </ul>
            </div>
          ) : (
            ''
          )}
        </div>
      </div>
    </div>
  );
};
export default AutomaticEN;
