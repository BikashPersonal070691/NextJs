import { useEffect, useState, useContext,useRef } from 'react';
import styles from './UtilityBox.module.scss';
import { getNotifications, getUtilityMenus} from 'src/services/menu.service';
//import { getNotifications } from 'src/services/header.service';
import HeaderProfile from 'components/HeaderProfile/HeaderProfile';
import { HeaderContext } from 'src/contexts/HeaderContext';
import { KEY_BREAKPOINT_MEDIUM_LARGE } from 'src/constants/general';
import { onRedirect } from 'src/core/utils/utils.helper';


export default function UtilityBox() {
  const [menuData, setMenuData] = useState<any>({});
  const [notificationData, setNotificationData] = useState<any>({});
  const [notificationPopupOpen, setNotificationPopupOpen] = useState(false);
  const { stickyClass } = useContext(HeaderContext);
  const [openMenuMobileView, setOpenMenuMobileView] = useState(false);
  const popupRef = useRef(null);

  const [windowWidth, setWindowWidth] = useState<any>();

//   let mockData = {
//     "MorgoItems": [],
//     "MargoLabel": "Margo",
//     "MargoItem": "{400BA8CC-2D14-4E95-9DD5-9468FCBFCE87}",
//     "TopicsNotification": [
//         {
//             "ItemId": "4df2657b-567c-46e4-80a5-eb90db68b54b",
//             "TopicHeadline": "Updates on Ukraine",
//             "IsNew": true,
//             "PageLink": "",
//             "IsExternal": false
//         },
//         {
//             "ItemId": "c3b34cdd-3628-4b55-9875-1ba5f550cd34",
//             "TopicHeadline": "Annual Report2",
//             "IsNew": true,
//             "PageLink": "https://www.bayer.com/en/investors/integrated-annual-reports",
//             "IsExternal": true
//         }
//     ],
//     "TopicLabel": "TOPICS",
//     "AnnouncementNotification": {
//         "SearchResult": [
//             {
//                 "Headline": "Jessica Christiansen",
//                 "IsNewAnnouncement": true,
//                 "ItemID": "2e4696e7-d866-4855-a591-d1c6bcb45d5f",
//                 "PageLink": "/en/global/shared/corporate-announcements-folder/corporate-folder/2025/03/19/corporate-announcement-2",
//                 "IsExternal": false
//             },
//             {
//                 "Headline": "Phil Smits, Henrik Wulff",
//                 "IsNewAnnouncement": true,
//                 "ItemID": "efe6be74-4cec-45f1-903c-776e32df6d09",
//                 "PageLink": "/en/global/shared/corporate-announcements-folder/corporate-announcements-test/test-announcement",
//                 "IsExternal": false
//             },
//             {
//               "Headline": "Phil Smits, Henrik Wulff",
//               "IsNewAnnouncement": true,
//               "ItemID": "efe6be74-4cec-45f1-903c-776e32df6d09",
//               "PageLink": "/en/global/shared/corporate-announcements-folder/corporate-announcements-test/test-announcement",
//               "IsExternal": false
//           },
//           {
//             "Headline": "Phil Smits, Henrik Wulff",
//             "IsNewAnnouncement": true,
//             "ItemID": "efe6be74-4cec-45f1-903c-776e32df6d09",
//             "PageLink": "/en/global/shared/corporate-announcements-folder/corporate-announcements-test/test-announcement",
//             "IsExternal": false
//         }
//         ],
//         "TotalRecords": 10,
//         "AnnouncementLabel": "PERSONNEL ANNOUNCEMENTS"
//     },
//     "HeaderNotification": true,
//     "NotificationEmptyText": "You currently have no notifications"
// };
const CloseNotification = (e:any)=>{

  //Handling clicks once popup is open
  e.target.closest(".notification_wrapper") ?  e.target.closest(".close_container") ? setNotificationPopupOpen(false):  "": setNotificationPopupOpen(false);
  document.removeEventListener("click",CloseNotification);
}
  const handleNotificationClick = (e:any) =>{
    e.stopPropagation();
    document.addEventListener("click",CloseNotification);
    setNotificationPopupOpen(!notificationPopupOpen);


  }
 
  useEffect(() => {
    getUtilityMenus().then((data: any) => {
      if (data && data.data) {
        setMenuData(data.data);
      }
    });

    getNotifications().then((data:any)=>{
      if(data && data.data){
        setNotificationData(data.data)
      } 
    })

  }, []);
  useEffect(() => {
    let width = window.innerWidth;
    setWindowWidth(width);
    // Resize Event
    window.addEventListener('resize', function () {
      if (window.innerWidth != width) {
        width = window.innerWidth;
      }
    });
  }, []);

  useEffect(() => {
    if (windowWidth && windowWidth < KEY_BREAKPOINT_MEDIUM_LARGE) {
      setOpenMenuMobileView(true);
    } else {
      setOpenMenuMobileView(false);
    }
  }, [windowWidth]);


  const onClickItemLink = (itemUrl:any, isNewTab:any, sectionclassName:any) => {
    if (itemUrl) {
      return onRedirect(itemUrl, isNewTab, true);
    }
    return redirectToSection(sectionclassName);
  };

  const onPressEnter = (e:any, actionType:any,  urlLink:any, isExternal:any, elementId:any) =>{
    if(e.key==="Enter"){
      if(actionType==="notification"){
        handleNotificationClick(e);
      } else if(actionType==="closeIcon"){
        setNotificationPopupOpen(false);
      } else if(actionType==="itemClick"){
        onClickItemLink(urlLink, isExternal, elementId);
      } else if(actionType==="ellipsisClick"){
        handleEllipsisClick(elementId)
      }
    }
  }

  const checksTargetPage = (path:any) => {
    const splitPath = path?.split('/')?.filter((item:any) => item);
    const isHomePage = splitPath?.length == 1;
    const isNewHomePage = (splitPath[1] || '').toLowerCase() === 'newHomePage'.toLowerCase();
    return isHomePage || isNewHomePage;
  };

  const redirectToSection = (sectionClass:any) => {
    // const section = document.querySelector(`.${sectionClass}`);
    const isTargetPage = checksTargetPage(window.location.pathname);
    if (isTargetPage) {
      const section = document.getElementsByClassName(sectionClass);
      if (section && section.length > 0) {
        section[0].scrollIntoView({
          behavior: 'smooth',
        });
      }
    } else {
      const getRedirection = window?.location?.host == 'cd.ci.bayernet.int.bayer.com' ? '/newHomePage' : '/';
      // const sessionKey = 'notification-routing-section';
      // sessionStorage.setItem(sessionKey, sectionClass);
      window.location.href = `${getRedirection}`;
    }
  };

  const handleEllipsisClick = (sectionClass:any) => {
    redirectToSection(sectionClass);
  };


  return (
    <>
      {!openMenuMobileView ? (
        <div className={styles.utility_container}>
          {stickyClass !== '' ? (
            ''
          ) : (
            <div className={styles.utility_menus}>
              {menuData && Array.isArray(menuData)
                ? menuData.map((menuItem, index) => (
                  <span key={index} className={styles.utility_item}>
                    <a
                      href={menuItem.NavigationLink}
                      target={menuItem.IsExternal ? '_blank' : '_self'}
                    >
                      {menuItem.Name}
                    </a>
                  </span>
                ))
                : null}
                <div className={`notification_wrapper ${styles.notification_wrapper}`} >
                    <i className={`bell-icon ${styles.bell_icon}`} tabIndex={0}  aria-label="notification icon" onClick={handleNotificationClick}>
        <svg width="25" height="26" viewBox="0 0 25 26" fill="none">
            <path d="M12.39 2.946a7.435 7.435 0 0 0-7.434 7.434v4.444l-.876.876a1.24 1.24 0 0 0 .876 2.115h14.87a1.24 1.24 0 0 0 .876-2.115l-.877-.876V10.38a7.435 7.435 0 0 0-7.434-7.434zM12.39 22.772a3.717 3.717 0 0 1-3.717-3.718h7.435a3.717 3.717 0 0 1-3.717 3.718z" fill="#145375"/>
        </svg>
        </i>

        {notificationPopupOpen ? (
        <div ref={popupRef} className= {`notification_wrapper ${!openMenuMobileView ? styles.notification_overlay : styles.mobile_notif_overlay}`} >
          {notificationData &&
          ((notificationData?.MorgoItems && notificationData?.MorgoItems?.length > 0) ||
            (notificationData?.TopicsNotification && notificationData?.TopicsNotification?.length > 0) ||
            (notificationData?.AnnouncementNotification?.SearchResult &&
              notificationData?.AnnouncementNotification?.SearchResult?.length > 0)) ? (
            <div>
              <div className={styles.close_container}>
                <div className={styles.notification_close}  onClick={() => setNotificationPopupOpen(false)} tabIndex={0} onKeyDown={(e)=>onPressEnter(e, 'closeIcon',null,null,null)}/>{' '}
              </div>

              {notificationData.MorgoItems && notificationData.MorgoItems.length > 0 && (
                <ul className={` ${styles.notification_content_area }  ${styles.border_sep }`} >
                  <div className= {styles.content_area_sep}>
                    <div className={styles.category_head}>
                      <svg
                        className={styles.icon}
                        width='16'
                        height='16'
                        viewBox='0 0 16 16'
                        xmlns='http://www.w3.org/2000/svg'
                        style={{ marginTop: '1px' }}
                      >
                        <path d='M2 8.553a.75.75 0 0 1 .75-.75h8.787L8.25 4.862a.75.75 0 1 1 1-1.118L14 7.994a.75.75 0 0 1 0 1.118l-4.75 4.25a.75.75 0 0 1-1-1.118l3.287-2.941H2.75a.75.75 0 0 1-.75-.75z' />
                      </svg>
                      <span className={styles.notification_category} onClick={() => handleEllipsisClick('homepage-margo-feed-importer')}
                        tabIndex={0}
                        aria-label={notificationData?.MargoLabel?.toLowerCase()}
                        onKeyDown={(e)=>onPressEnter(e, 'ellipsisClick', null, null, 'homepage-margo-feed-importer')}
                      >
                        {notificationData?.MargoLabel?.toLowerCase()}
                      </span>

                      {/* {hasNewItem(notificationData.MorgoItems) && (
                        <div>
                          <i className='bubble'></i>
                        </div>
                      )} */}
                    </div>
                    {notificationData.MorgoItems.map(
                      (item:any, index:any) =>
                        index < 3 && (
                          <li
                            key={index}
                            className={styles.notification_content}
                            onClick={() => onClickItemLink(item.MargoUrl, item.IsExternal, 'homepage-margo-feed-importer')}
                            tabIndex={0}
                            aria-label={item.MargoHeadline}
                            onKeyDown={(e)=>onPressEnter(e, 'itemClick', item.MargoUrl, item.IsExternal, 'homepage-margo-feed-importer')}
                          >
                            {item.MargoHeadline}
                          </li>
                        ),
                    )}
                    {notificationData.MorgoItems.length > 3 && (
                      <div className={styles.more_ellipsis}>
                        <span
                          className= {` ${styles.more_dot_icon}  ${styles.pointer_cursor }`}
                          onClick={() => handleEllipsisClick('homepage-margo-feed-importer')}
                          tabIndex={0}
                          aria-label='Ellipsis icon'
                          onKeyDown={(e)=>onPressEnter(e, 'ellipsisClick', null, null, 'homepage-margo-feed-importer')}
                        >
                          ...
                        </span>
                      </div>
                    )}
                  </div>
                </ul>
              )}

              {notificationData.TopicsNotification && notificationData.TopicsNotification.length > 0 && (
                <ul className={` ${styles.notification_content_area}  ${styles.border_sep }`}>
                  <div className={styles.content_area_sep}>
                    <div className={styles.category_head}>
                      <svg
                        className={styles.icon}
                        width='16'
                        height='16'
                        viewBox='0 0 16 16'
                        xmlns='http://www.w3.org/2000/svg'
                        style={{ marginTop: '1px' }}
                      >
                        <path d='M2 8.553a.75.75 0 0 1 .75-.75h8.787L8.25 4.862a.75.75 0 1 1 1-1.118L14 7.994a.75.75 0 0 1 0 1.118l-4.75 4.25a.75.75 0 0 1-1-1.118l3.287-2.941H2.75a.75.75 0 0 1-.75-.75z' />
                      </svg>
                      <span className={styles.notification_category} onClick={() => handleEllipsisClick('homepage-topics')}
                        tabIndex={0}
                        aria-label={notificationData?.TopicLabel?.toLowerCase()}
                        onKeyDown={(e)=>onPressEnter(e, 'ellipsisClick', null, null, 'homepage-topics')}  
                      >
                        {notificationData?.TopicLabel?.toLowerCase()}
                      </span>

                      {/* {hasNewItem(notificationData.TopicsNotification) && (
                        <div>
                          <i class='bubble'></i>
                        </div>
                      )} */}
                    </div>
                    {notificationData.TopicsNotification.map(
                      (topic:any, index:any) =>
                        index < 3 && (
                          <li
                            key={index}
                            className={styles.notification_content}
                            onClick={() => onClickItemLink(topic.PageLink, topic.IsExternal, 'homepage-topics')}
                            tabIndex={0}
                            aria-label={topic.TopicHeadline}
                            onKeyDown={(e)=>onPressEnter(e, 'itemClick', topic.PageLink, topic.IsExternal, "homepage-topics")}
                          >
                            {topic.TopicHeadline}
                          </li>
                        ),
                    )}
                    {notificationData.TopicsNotification.length > 3 && (
                      <div className={styles.more_ellipsis}>
                        <span className={` ${styles.more_dot_icon}  ${styles.pointer_cursor}`} onClick={() => handleEllipsisClick('homepage-topics')}
                        tabIndex={0}
                        aria-label="ellipsis icon"
                        onKeyDown={(e)=>onPressEnter(e, 'ellipsisClick', null, null, 'homepage-topics')}
                        >
                          ...
                        </span>
                      </div>
                    )}
                  </div>
                </ul>
              )}

              {notificationData.AnnouncementNotification.SearchResult &&
                notificationData.AnnouncementNotification.SearchResult.length > 0 && (
                  <ul className={styles.notification_content_area}>
                    <div className={styles.content_area_sep}>
                      <div className={styles.category_head}>
                        <svg
                          className={styles.icon}
                          width='16'
                          height='16'
                          viewBox='0 0 16 16'
                          xmlns='http://www.w3.org/2000/svg'
                          style={{ marginTop: '1px' }}
                        >
                          <path d='M2 8.553a.75.75 0 0 1 .75-.75h8.787L8.25 4.862a.75.75 0 1 1 1-1.118L14 7.994a.75.75 0 0 1 0 1.118l-4.75 4.25a.75.75 0 0 1-1-1.118l3.287-2.941H2.75a.75.75 0 0 1-.75-.75z' />
                        </svg>
                        <span className={styles.notification_category} onClick={() => handleEllipsisClick('homepage-announcements')}
                          tabIndex={0}
                          aria-label={notificationData?.AnnouncementNotification?.AnnouncementLabel?.toLowerCase()}
                          onKeyDown={(e)=>onPressEnter(e, 'ellipsisClick', null, null, 'homepage-announcements')}
                        >
                          {notificationData?.AnnouncementNotification?.AnnouncementLabel?.toLowerCase()}
                        </span>

                        {/* {hasNewItem(notificationData.AnnouncementNotification.SearchResult) && (
                          <div>
                            <i class='bubble'></i>
                          </div>
                        )} */}
                      </div>
                      {notificationData.AnnouncementNotification.SearchResult.map(
                        (announcement:any, index:any) =>
                          index < 3 && (
                            <li
                              key={index}
                              className={styles.notification_content}
                              onClick={() =>
                                onClickItemLink(announcement.PageLink, announcement.IsExternal, 'homepage-announcements')
                              }
                              tabIndex={0}
                              aria-label={announcement.Headline}
                              onKeyDown={(e)=>onPressEnter(e, 'itemClick', announcement.PageLink, announcement.IsExternal, "homepage-topics")}
                            >
                              {announcement.Headline}
                            </li>
                          ),
                      )}
                      {notificationData.AnnouncementNotification.SearchResult.length > 3 && (
                        <div className={styles.more_ellipsis}>
                          <span
                            className={` ${styles.more_dot_icon}  ${styles.pointer_cursor}`} 
                            onClick={() => handleEllipsisClick('homepage-announcements')}
                            tabIndex={0}
                            aria-label="ellipsis icon"
                            onKeyDown={(e)=>onPressEnter(e, 'ellipsisClick', null, null, 'homepage-announcements')}
                          >
                            ...
                          </span>
                        </div>
                      )}
                    </div>
                  </ul>
                )}

              {/* ))} */}
            </div>
          ) : (
            <div className={styles.no_notify_container}>
              <div>
                <div className={styles.notification_close}  tabIndex={0} onClick={() => setNotificationPopupOpen(false)} onKeyDown={(e)=>onPressEnter(e, 'closeIcon',null,null,null)}/>
              </div>
              {(notificationData?.MorgoItems?.length === 0 || !notificationData.MorgoItems) &&
              (notificationData?.TopicsNotification?.length === 0 || !notificationData?.TopicsNotification) &&
              (notificationData?.AnnouncementNotification?.SearchResult?.length === 0 ||
                !notificationData?.AnnouncementNotification?.SearchResult) ? (
                <>
                  <div className={styles.no_notification_icon}  />
                  <p className={styles.notification_empty_text}>{notificationData.NotificationEmptyText}</p>
                </>
              ) : (
               ''
              )}
            </div>
          )}
        </div>
      ) : (
        ''
      )}
                </div>
              

            </div>
          )}

          {/* <div className={styles.side_line}></div> */}
          <HeaderProfile />
        </div>
      ) : (
        ''
      )}
    </>
  );
}
