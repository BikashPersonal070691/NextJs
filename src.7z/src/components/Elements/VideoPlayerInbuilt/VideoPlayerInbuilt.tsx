import { useState } from 'react';
import { ImageCustom } from 'src/components/Elements/ImageCustom/ImageCustom';
import styles from './VideoPlayerInbuilt.module.scss';

export function VideoPlayerInbuilt(props: any) {
  const { videoSrc, videoThumbnail } = props;
  // const [showVideo, setShowVideo] = useState<boolean>(false);
  const [showVideo, setShowVideo] = useState<boolean>(true);
  const handleThumbnailClick = () => {
    setShowVideo(true);
  };

  return (
    <div className={styles.videoInbuiltPlayer__container}>
      {showVideo ? (
        <video controls>
          <source src={videoSrc && videoSrc} />
        </video>
      ) : (
        <ImageCustom src={videoThumbnail} fromVideo={true} imgEvent={handleThumbnailClick} />
      )}
    </div>
  );
}
