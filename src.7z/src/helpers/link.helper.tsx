// import { KEY_PAGE_LANGUAGE } from "src/constants/general";
import { KEY_URL_STRING_REMOVAL } from 'src/constants/general';
// import { getFromLocalStorage } from "src/core/utils/utils.helper";

const formatLink = (link: any) => {
  // const isAbsoluteURL = link.startsWith('https://');
  // if (isAbsoluteURL === true) {
  //   const firstStepLink = link.replace('https://', '');
  // const ifDomainPresent = firstStepLink.includes('bayernet.int.bayer.com');
  // if (ifDomainPresent) {
  //   const secondStepLink = firstStepLink.substring(firstStepLink.indexOf('/') + 1);
  //   const firstSectionString = secondStepLink.substring(0, secondStepLink.indexOf('/'));
  //   const lastSectionString = secondStepLink.substring(secondStepLink.indexOf('/') + 1);
  //   const navLink = '/' + firstSectionString + '/My_HR/' + lastSectionString;
  //   return navLink;
  // } else {
  //   return link;
  // }
  // } else {
  //   return link;
  // }

  // let url = "/de-de/my_hr/global-headless-portal/home/global/home/my_hr/ask-hr";

  //console.log('Link--' + link);
  const en = '/en/';
  if (!link.includes(en)) {
    link = link.replace(KEY_URL_STRING_REMOVAL, '');
  }
  // let currentLang = getFromLocalStorage(KEY_PAGE_LANGUAGE);
  // let formattedURL: any = link;
  // console.log('Formatted link 1--'+link)
  // formattedURL = formattedURL.toString().split('/');
  // if (formattedURL && formattedURL[1]) {
  //     formattedURL[1] = currentLang;
  //     formattedURL = formattedURL.join('/');
  // }
  // console.log('Formatted link 2--'+formattedURL)
  // return formattedURL;
  return link;
};
export { formatLink };
