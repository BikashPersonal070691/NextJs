import { useContext } from 'react';
import { Placeholder } from '@sitecore-jss/sitecore-jss-nextjs';
import { formatAccordionData } from 'src/helpers/component.helper';
// import { ACCORDION_PLACEHOLDER } from 'src/constants/general';
// import { isExperienceEditorActive } from '@sitecore-jss/sitecore-jss';
import { Text } from '@sitecore-jss/sitecore-jss-nextjs';
import { ACCORDION_ITEM_TITLE, TAB_ITEM_TITLE } from 'src/constants/general';
import { CommonContext } from 'src/contexts/CommonContext';
import styles from './Collapse.module.scss';

export function Collapse(props: any) {
  const { listData, id } = props;
  const { anchor } = useContext(CommonContext);
  const accordionData = formatAccordionData(listData);

  const addActiveClass =(e:any)=>{
   
    if ( e.target && e.target.closest('.accordion-details')){
      let detailsElm = e.target.closest('.accordion-details');
      let accordionElm = detailsElm.querySelector('.accordion');
      if( accordionElm && accordionElm.classList.contains('open-default')){
        accordionElm.classList.remove('open-default');
       return
      }

      
      accordionElm && accordionElm.classList.contains('active') ? detailsElm.querySelector('.accordion').classList.remove('active'): detailsElm.querySelector('.accordion').classList.add('active');

    }
  
  }

  

  return (
    <div className={styles[id]}>
      <div
        className={`${"accordion-wrapper"}  ${accordionData && accordionData.accordionItems && accordionData.accordionItems.length !== 0
          ? styles.collapse__container
          : ''}
          
            `
        }
        onClick={addActiveClass}
      >
        {accordionData && accordionData.accordionItems && accordionData.accordionItems.length !== 0
          ? accordionData.accordionItems.map((lItem: any, index: any) => {
              // const incrementalIndex = index + 1; // for dynamic placeholder name

              return (
                <div key={index} >
                  <details
                    className= {`${"accordion-details"}  ${styles.collapse}`
                    } 
                    open={
                      (index === 0 && accordionData && accordionData.openAccordion == true) ||
                      anchor === lItem.accordionAnchor ||
                      lItem.itemOpenDefault === true
                        ? true
                        : false
                    }
                    id={lItem && lItem.accordionAnchor}
                    
                  >
                    <summary className= {`${"accordion"} ${styles.collapse__heading}
                     ${( accordionData && accordionData.openAccordion == true) ||
                      lItem.itemOpenDefault === true
                        ? 'open-default'
                        : '' } `}>
                      {lItem && lItem[TAB_ITEM_TITLE] && (
                        <Text field={lItem[TAB_ITEM_TITLE]} tag="span" className={`${"accordion-heading-text"} `
                      } editable={true} />
                      )}
                      {lItem && lItem[ACCORDION_ITEM_TITLE] && (
                        <Text field={lItem[ACCORDION_ITEM_TITLE]} tag="span" className={`${"accordion-heading-text"} `
                      }  editable={true} />
                      )}
                    </summary>
                  </details>

                  <div
                    className={styles.collapseItemWrapper}
                    id={id}
                    key={lItem && lItem.itemTitle + index}
                  >
                    <div className={styles.collapseItemInnerWrapper} data-id="accordion">
                      <Placeholder
                        // name={ACCORDION_PLACEHOLDER + incrementalIndex}
                        name={lItem.placeholderName}
                        rendering={listData.rendering}
                      />
                    </div>
                  </div>
                </div>
              );
            })
          : ''}
      </div>
    </div>
  );
}
