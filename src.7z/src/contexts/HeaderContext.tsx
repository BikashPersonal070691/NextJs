import { createContext } from 'react';
export const HeaderContext = createContext<any>(null);

const HeaderProvider = HeaderContext.Provider;
const HeaderConsumer = HeaderContext.Consumer;
export { HeaderProvider, HeaderConsumer };
