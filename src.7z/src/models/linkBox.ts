import {
  KEY_LINKBOX_LINK_DESCRIPTION,
  KEY_LINKBOX_LINK_TEXT,
  KEY_LINKBOX_LINK_URL,
} from 'src/constants/general';
export interface LinkBoxConfig {
  heading?: string;
  bgColor?: string;
  linkData: any;
}

export interface LinkBoxDataConfig {
  [KEY_LINKBOX_LINK_TEXT]: any;
  [KEY_LINKBOX_LINK_DESCRIPTION]: any;
  [KEY_LINKBOX_LINK_URL]: any;
  linkTarget: string;
}
