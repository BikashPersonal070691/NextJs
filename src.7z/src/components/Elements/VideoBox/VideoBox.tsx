import { KEY_VIDEOBOX_EXTERNAL } from 'src/constants/general';
import { VideoPlayerInbuilt } from '../VideoPlayerInbuilt/VideoPlayerInbuilt';
import styles from './VideoBox.module.scss';

export function VideoBox(props: any) {
  const { linkType, linkSrc, thumbnail } = props;
  
  return (
    <div className={styles.videoBox__container}>
      <div className={styles.videoBox_inner__wrapper}>
        {linkType && linkType !== '' && linkType === KEY_VIDEOBOX_EXTERNAL ? (
          <iframe
            src={linkSrc && linkSrc}
            className={styles.videoBox__iframe}
            allowFullScreen
          ></iframe>
        ) : (
          <VideoPlayerInbuilt videoSrc={linkSrc} videoThumbnail={thumbnail} />
        )}
      </div>
      {/* {caption && caption !== '' ? (
        <div className={styles.videoBox_caption__wrapper}>
          <span>{caption}</span>
        </div>
      ) : null} */}
    </div>
  );
}
