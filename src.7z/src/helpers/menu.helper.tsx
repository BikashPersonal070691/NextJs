import { useRouter } from 'next/router';

const formatCurrentUrl = () => {
  const router = useRouter();
  // const currentUrl = window.location.href;
  // remove this line for production
  // const currentUrl = window.location.href.split(/[?#]/)[0];
  const currentUrl = router.pathname.split(/[?#]/)[0];
  return currentUrl;
};
export { formatCurrentUrl };
