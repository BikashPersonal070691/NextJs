import {
  KEY_DEFAULT_LINKS,
  KEY_FUTURE_EVENT,
  KEY_MONTH_NAMES,
  KEY_PARESENT_EVENT,
  KEY_PAST_EVENT,
  KEY_ENVIRONMENTS,
  KEY_LANGUAGES,
  // KEY_AZURE_AD_URL,
  CODE_CHALLENGE_METHOD,
  CODE_CHALLENGE,
  GRAPH_API_ENDPOINT,
  CODE_VERIFIER,
  GRAPH_API_SCOPE,
  GRAPH_API_GRANT_TYPE,
  KEY_AZURE_AD_URL,
  KEY_IS_PREVIEW,
  KEY_IS_EDIT,
  DEFAULT_DATE_VALUE
} from 'src/constants/general';
import { CONTENT_100 } from 'src/constants/contentDivider';
import { createEvent } from 'ics';
import FileSaver from 'file-saver';
import { formatLink } from 'src/helpers/link.helper';

let appStorage: any = '';
let cacheStorage: any = '';
if (typeof window !== 'undefined') {
  appStorage = sessionStorage;

  cacheStorage = localStorage;
}

/**
 * Get a value from browser storage
 * @param key
 * @returns string | null
 */
const getFromStorage = (key: string) => {
  return key && appStorage.getItem(key) ? appStorage.getItem(key) : null;
};

/**
 * Set a value to browser storage using a specified key
 * @param key
 * @param value
 */
const setToStorage = (key: string, value = '') => {
  if (key) {
    appStorage.setItem(key, value);
  }
};

/**
 * Get a value from browser storage
 * @param key
 * @returns string | null
 */
const getFromLocalStorage = (key: string) => {
  return key && cacheStorage.getItem(key) ? cacheStorage.getItem(key) : null;
};

/**
 * Set a value to browser storage using a specified key
 * @param key
 * @param value
 */
const setToLocalStorage = (key: string, value = '') => {
  if (key) {
    cacheStorage.setItem(key, value);
  }
};

/**
 * Remove a specific value or clear the entire browser storage
 * @param key
 */
const removeFromStorage = (key = '') => {
  if (key) {
    appStorage.removeItem(key);
  } else {
    appStorage.clear();
  }
};

/**
 * Remove a specific value or clear the entire browser storage
 * @param key
 */
const removeFromLocalStorage = (key = '') => {
  if (key) {
    cacheStorage.removeItem(key);
  } else {
    cacheStorage.clear();
  }
};

/**
 * check array only has null values
 * @param array
 */
function isNull(inputArray: any) {
  if (inputArray.length) {
    var currentElement = inputArray[0];
    for (var i = 1, len = inputArray.length; i < len && currentElement === null; i += 1) {
      currentElement = currentElement || inputArray[i];
    }
    if (currentElement !== null) {
      return false;
    }
  }
  return true;
}
/**
 * find color pallete from values added in constant in general.ts file
 * @param string
 */
function findColorPallete(colorPallete: any, key: any) {
  let color = colorPallete.find((o: any) => o.key === key);
  return color && Object.keys(color).length !== 0 ? color.value : '';
}

/**
 * get closest id of a div element
 * @param html element
 */
function getParentClassReference(element: HTMLElement) {
  const closest = element && element.parentElement;
  // debugger;
  if (closest !== null) {
    const elemId = closest && closest.id;
    if (elemId && elemId !== undefined) {
      return elemId;
    } else return CONTENT_100;
  } else return CONTENT_100;
}

/**
 * get closest id of a div element
 * @param html element
 */
function getParentAttributeReference(element: HTMLElement, attrName: any) {
  const closest = element && element.parentElement;
  if (closest !== null) {
    return closest.getAttribute(attrName);
  } else {
    return false;
  }
}

/**
 * get month name
 * @param html element
 */
function getMonthName(obj: any) {
  const date = new Date(obj);
  // date.setDate(date.getDate() - 1); // substract 1 day

  date.setDate(date.getDate());
  let name = '';
  const monthNames = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
  ];

  const month = monthNames[date.getMonth()];
  if (month) {
    name = month.slice(0, 3);
  }
  return name;
}

function getCurrentQuarterName() {
  const today = new Date();
  const quarter = Math.floor(today.getMonth() / 3);
  return quarter;
}

/**
 * Check if an event is a future event
 * @param html element
 */
function isFutureEvent(start: any, end: any) {
  const startDate: any = Date.parse(start);
  const endDate = Date.parse(end);
  const date = Date.now();

  let isFutureEvent = KEY_FUTURE_EVENT;
  if (start === DEFAULT_DATE_VALUE || end === DEFAULT_DATE_VALUE) {
    isFutureEvent = KEY_PARESENT_EVENT;
  } else if (date < startDate) {
    isFutureEvent = KEY_FUTURE_EVENT;
  } else if (date >= startDate && date <= endDate) {
    isFutureEvent = KEY_PARESENT_EVENT;
  } else if (date > endDate) {
    isFutureEvent = KEY_PAST_EVENT;
  }
  return isFutureEvent;
}

const correctURLrouting = (data: any) => {
  if (data.URL.startsWith('https://https')) {
    data.URL = data.URL.replace('https://https/en', '/en/My_HR');
  }
  data.URL = formatLink(data.URL);
};
/**
 * @description to remove query parameter from a url string
 */
const getPathFromUrl = (url: any) => {
  return url && url.split('?')[0];
};

const getCookie = (name: any) => {
  const value: any = `; ${document.cookie}`;
  const parts: any = value.split(`; ${name}=`);
  if (parts.length === 2) return parts.pop().split(';').shift();
};

const setCookie = (cName : any, cValue : any) => {
  const expires = "expires=Session";
  document.cookie = cName + "=" + cValue + "; " + expires + "; path=/;" ;
}

/* Function for grouping HR Calendar Events by their type.
 *  Created On : 7 Oct 2023
 *  Created By : Waseem
 *  Module : HR Calender
 */

// const groupCalendarEvents = (events: any) => {
//   if(events && events !== '') {
//     let groupingViaCommonProperty = Object.values(
//       events.reduce((acc: any, current: any) => {
//         const calendarSection : any = current.fields.CalenderSection && current.fields.CalenderSection.fields && current.fields.CalenderSection.fields.SortingOrder && current.fields.CalenderSection.fields.SortingOrder.value;
//         if (calendarSection) {
//           acc[calendarSection] = acc[calendarSection] ?? [];
//           acc[calendarSection].push(current);
//           return acc;
//         } else {
//           acc[''] = acc[''] ?? [];
//           acc[''].push(current);
//           return acc;
//         }
//       }, {})
//     );
//     return groupingViaCommonProperty;
//   } else {
//     return [];
//   }

// };

const groupCalendarEvents = (events: any) => {
  if (events && events !== '') {
    let groupingViaCommonProperty = Object.values(
      events.reduce((acc: any, current: any) => {
        const calendarSectionWithSorting: any =
          current.fields.CalenderSection &&
          current.fields.CalenderSection.fields &&
          current.fields.CalenderSection.fields.SortingOrder &&
          current.fields.CalenderSection.fields.SortingOrder.value;
        const calendarSectionWithoutSorting: any =
          current.fields.CalenderSection && current.fields.CalenderSection.name;

        if (calendarSectionWithSorting) {
          if (typeof acc[calendarSectionWithSorting] === undefined) {
            acc[calendarSectionWithoutSorting] = acc[calendarSectionWithoutSorting] ?? [];
            acc[calendarSectionWithoutSorting].push(current);
          } else {
            acc[calendarSectionWithSorting] = acc[calendarSectionWithSorting] ?? [];
            acc[calendarSectionWithSorting].push(current);
          }
          return acc;
        } else if (calendarSectionWithoutSorting) {
          acc[calendarSectionWithoutSorting] = acc[calendarSectionWithoutSorting] ?? [];
          acc[calendarSectionWithoutSorting].push(current);
          return acc;
        } else {
          acc[''] = acc[''] ?? [];
          acc[''].push(current);
          return acc;
        }
      }, {})
    );
    return groupingViaCommonProperty;
  } else {
    return [];
  }
};

// const groupCalendarEvents = (events: any) => {
//   console.log(JSON.stringify(events))
//   if (events && events !== '') {
//     let groupingViaCommonProperty = Object.values(
//       events.reduce((acc: any, current: any) => {
//         const calendarSection : any = current.fields.CalenderSection;

//         if(calendarSection) {
//           const calendarSectionWithSorting: any = calendarSection.fields && calendarSection.fields.SortingOrder && calendarSection.fields.SortingOrder.value;
//           const calendarSectionWithoutSorting: any = calendarSection && calendarSection.name;

//           if (calendarSectionWithSorting) {
//             if (typeof acc[calendarSectionWithSorting] === undefined) {
//               acc[calendarSectionWithoutSorting] = acc[calendarSectionWithoutSorting] ?? [];
//               acc[calendarSectionWithoutSorting].push(current);
//             } else {
//               acc[calendarSectionWithSorting] = acc[calendarSectionWithSorting] ?? [];
//               acc[calendarSectionWithSorting].push(current);
//             }
//             return acc;
//           } else if (calendarSectionWithoutSorting) {
//             acc[calendarSectionWithoutSorting] = acc[calendarSectionWithoutSorting] ?? [];
//             acc[calendarSectionWithoutSorting].push(current);
//             return acc;
//           } else {
//             acc[''] = acc[''] ?? [];
//             acc[''].push(current);
//             return acc;
//           }
//         }
//       }, {})
//     );
//     return groupingViaCommonProperty;
//   } else {
//     return [];
//   }
// };



/* Function for getting start month and length of task
 *  Created On : 7 Oct 2023
 *  Created By : Waseem
 *  Module : HR Calender
 * Edit: 21 Oct 2024 Ibrahim - Addded 1 Hr to start date to fix edge cases - WorkItem 181748
 */
const getTaskDuration = (task: any) => {

  let duration=0;
  let startDate =task && task.fields && task.fields['Start Date'] && new Date(task.fields['Start Date'].value);
    let endDate =task && task.fields && task.fields['End Date'] && new Date(task.fields['End Date'].value);

    // fix edits for edge cases

    startDate.setHours(startDate.getHours() + 17);
    endDate.setHours(endDate.getHours() -17 );

    if(startDate.getMonth() == 0 &&  startDate.getDate()<1){
      startDate.setDate(startDate.getDate() + 1);
    }
    if(endDate.getMonth() == 11 && endDate.getDate()>30){
      endDate.setDate(endDate.getDate()-1);
    }
    
   //

  const startMonth = startDate.getUTCMonth() + 1;
  const endMonth = endDate.getUTCMonth() + 1;
  const yearOfTaskStart = startDate.getYear() + 1900;
  const yearOfTaskEnd = endDate.getYear() + 1900;
  if(yearOfTaskEnd > yearOfTaskStart){
    duration = (yearOfTaskEnd - yearOfTaskStart) * 12 + endMonth - startMonth + 1
  }else{
    duration = endMonth - startMonth + 1
  }
  //console.log( task && task.fields && task.fields['Name'] && task.fields['Name'].value,startDate,endDate,endDate.getMonth(),endDate.getDate()>30, startMonth,endMonth, duration)

  const currentYear = new Date().getFullYear();
  const startYrCheck = yearOfTaskStart === currentYear;
  const endYrCheck = yearOfTaskEnd === currentYear;


  const data = {
    startMonth: startMonth,
    duration: duration,
    endMonth: endMonth,
    endMonthName: getMonthNameById(endMonth),
    startMonthName: getMonthNameById(startMonth),
    startDay: getDateSuffix(startDate.getUTCDate()),
    endDay: getDateSuffix(endDate.getUTCDate()),
    isRelevantData: startYrCheck && endYrCheck,
  };
  return data;

  // const time = new Date(date);
  // const formattedTime = [time.getUTCFullYear(), (time.getUTCMonth()+1), time.getUTCDate(), time.getUTCHours(), time.getUTCMinutes()];
};

/* Function for getting name by passing month id in month name array
 *  Created On : 18 Oct 2023
 *  Created By : Waseem
 *  Module : HR Calender
 */
const getMonthNameById = (monthId: any) => {
  let currentMonth: any = KEY_MONTH_NAMES.filter(function (item) {
    return item.id === monthId;
  });
  currentMonth = currentMonth[0].name;
  return currentMonth;
};

/* Function for formatting task list data to add duration and start month with each task
 *  Created On : 7 Oct 2023
 *  Created By : Waseem
 *  Module : HR Calender
 */
const getTaskDetails = (taskList: any) => {
  const listingData: any =
    Array.isArray(taskList) &&
    taskList.map((item: any) => ({
      ...item,
      ...getTaskDuration(item),
      duration: getTaskDuration(item),
    }));
  const currentYearData = listingData.filter((data: any) => data.isRelevantData === true); //filter items if the start year or end year is not the current
  return isNull(currentYearData) ? [] : currentYearData.flat();
};

/* Function for grouping events by checkin type to display items in multiple rows in calendar in same category
 *  Created On : 7 Oct 2023
 *  Created By : Waseem
 *  Module : HR Calender
 */
const groupByTaskType = (taskList: any) => {
  const result = taskList.reduce(function (r: any, a: any) {
    r[a.fields.TaskType && a.fields.TaskType && a.fields.TaskType.name && a.fields.TaskType.name] =
      r[
        a.fields.TaskType && a.fields.TaskType && a.fields.TaskType.name && a.fields.TaskType.name
      ] || [];
    r[
      a.fields.TaskType && a.fields.TaskType && a.fields.TaskType.name && a.fields.TaskType.name
    ].push(a);
    return r;
  }, Object.create(null));
  return result;
};

/* Function for setting hash string url for deep linkings
 *  Created On : 16 Oct 2023
 *  Created By : Waseem
 *  Module : HR Calender
 */
const setHashString = (id: any) => {
  let hash = window.location.hash.substring(1);
  if (hash.includes('/')) {
    hash = hash.substring(0, hash.indexOf('/'));
  }
  const finalHash = `${hash}/${id}`;
  window.location.hash = finalHash;
};

/* Function for getting hash string url for deep linkings
 *  Created On : 16 Oct 2023
 *  Created By : Waseem
 *  Module : HR Calender
 */
const getHashString = () => {
  const url: any = window.location.hash.substring(1);

  if (url.includes('/')) {
    const hash: any = url.split('/');
    const obj = {
      category: hash[0],
      month: hash[1] ? hash[1] : '',
      popupId: hash[2] ? hash[2] : '',
    };
    return obj;
  } else {
    const obj = {
      category: url,
      month: '',
    };
    return obj;
  }
};
/* Function for getting list of all tasks of a month
 *  Created On : 17 Oct 2023
 *  Created By : Waseem
 *  Module : HR Calender
 */

const getSelectedMonthTaskList = (list: any, month: any) => {
  const selectedMonth: any = KEY_MONTH_NAMES.filter(function (item) {
    return item.name === month;
  });
  const id = selectedMonth && selectedMonth[0] && selectedMonth[0].id;
  const arr: any = [];
  list.map((item: any) => {
    const obj = getTaskDuration(item);
    if (id >= obj.startMonth && id <= obj.endMonth) {
      arr.push({ ...item, ...obj });
    }
  });
  return arr;
};

/* Function for getting list all links month wise
 *  Created On : 2 Nov 23
 *  Created By : Waseem
 *  Module : HR Calender
 */

const getSelectedMonthLinks = (list: any, month: any) => {
  const selectedMonthLinks: any = list.filter(function (item: any) {
    return item.name.toLowerCase() === month || item.name === KEY_DEFAULT_LINKS;
  });
  return selectedMonthLinks;
};

/* Function for retruniging date in th, st format
 *  Created On : 18 Oct 2023
 *  Created By : Waseem
 *  Module : HR Calender
 */
const getDateSuffix = (date: any) => {
  switch (date) {
    case 1:
    case 21:
    case 31:
      return `${date}st`;
    case 2:
    case 22:
      return `${date}nd`;
    case 3:
    case 23:
      return `${date}rd`;
    default:
      return `${date}th`;
  }
};

/* Function creating calendar file
 *  Created On : 25 Oct 2023
 *  Created By : Waseem
 *  Module : HR Calender
 */
const createIcsFile = (event: any, name: any) => {
  createEvent(event, (error: any, value: any) => {
    if (!error) {
      // const blob = new Blob([value], { type: "text/plain;charset=utf-8" });
      // const blob = new Blob([value], { type: 'X-ALT-DESC:FMTTYPE=text/html' });
      const blob = new Blob([value], { type: 'text/calendar' });

      FileSaver.saveAs(blob, name);
    }
  });
};

/* Function formatting date for MS appointment
 *  Created On : 25 Oct 2023
 *  Created By : Waseem
 *  Module : HR Calender
 */
const formatDateICS = (date: any) => {
  // const time = new Date(date);

  const date2 = new Date(date);
  const time = new Date(date2.setHours(date2.getHours() + 1));
  const formattedTime = [
    time.getUTCFullYear(),
    time.getUTCMonth() + 1,
    time.getUTCDate(),
    time.getUTCHours(),
    time.getUTCMinutes(),
  ];
  return formattedTime;
};

/* Function for formatting html content
 *  Created On : 12 Nov 2023
 *  Created By : Waseem
 *  Module : HR Calender
 */
// const formatHtmlContent = (content : any) => {

// };

/**
 * @description function to check the current environment is localhost or not
 */
const checkIsLocalhost = () => {
  let currentUrl = typeof window !== 'undefined' ? window.location.href : '';
  return currentUrl.indexOf(KEY_ENVIRONMENTS.ENV_LOCAL) > -1 ? true : false;
};

/**
 * @description function to check the if language code exists in the url
 */
const checkIsLanguageExistsInUrl = () => {
  return KEY_LANGUAGES.some((language) => {
    let languageCode = language.toLowerCase();
    return window.location.href
      .toLowerCase()
      .split('/')
      .filter((e) => e.trim().length)
      .indexOf(languageCode) > -1
      ? true
      : false;
  });
};

/**
 * @description function to check the if current url exists in the environment array
 */

const checkEnvExistsinUrl = (envArray: any) => {
  let currentUrl = typeof window !== 'undefined' ? window.location.href : '';
  return envArray.some((env: any) => {
    if (
      currentUrl
        .split('/')
        .filter((e) => e.trim().length)
        .indexOf(env) > -1
    ) {
      return true;
    } else {
      return false;
    }
  });
};

/**
 * @description function to check if the site is opened in preview mode
 */
const checkIsPreviewOrEditorMode = (param: any) => {
  let currentUrlQueryString = typeof window !== 'undefined' ? window.location.search : '';
  if (currentUrlQueryString !== '') {
    const urlParams = new URLSearchParams(currentUrlQueryString);
    if (urlParams && urlParams.has('sc_mode')) {
      const mode: any = urlParams.getAll('sc_mode').toString();
      return mode && mode === param ? true : false;
    } else {
      return false;
    }
  } else {
    return false;
  }
};

/**
 * @description function to strip tags from text
 */
const stripTags = (data: any) => {
  const regexForStripHTML = /(<([^>]+)>)/gi;
  const stripContent = data && data !== '' ? data.replaceAll(regexForStripHTML, '') : '';
  return stripContent;
};

/**
 * @description function to generating MS Graph api code
 */
const getCode = () => {
  const tenant = process.env.AZURE_AD_TENANT_ID;
  const clientId = String(process.env.NEXT_PUBLIC_AZURE_AD_CLIENT_ID);
  const redirect_uri = process.env.NEXTAUTH_URL;

  const current_url = window.location.href;
  // const combinedEnv: any[] = [...KEY_ENVIRONMENTS.ENV_CM, ...KEY_ENVIRONMENTS.ENV_NODE];
  const combinedEnv: any[] = [...KEY_ENVIRONMENTS.ENV_NODE];
  const isFound: boolean = checkEnvExistsinUrl(combinedEnv);
  const isPreviewMode: any = checkIsPreviewOrEditorMode(KEY_IS_PREVIEW);
  const isExperienceEditor: any = checkIsPreviewOrEditorMode(KEY_IS_EDIT);
  if (!isFound && !isPreviewMode && !isExperienceEditor) {
    setToStorage(KEY_AZURE_AD_URL, current_url);
    const path = `https://login.microsoftonline.com/${tenant}/oauth2/authorize?code_challenge_method=${CODE_CHALLENGE_METHOD}&code_challenge=${CODE_CHALLENGE}&client_id=${clientId}&response_type=code&redirect_uri=${redirect_uri}/&response_mode=query&state=${current_url}`;
    window.location.replace(path);
  }
  return null;
};

/**
 * @description function to get text of all nodes in htlm dom for text translation
 */
const getPageContentForTranslation = (id: any) => {
  let result: any = [];
  // const root = document.body;
  // let node: any = root.childNodes[0];
  const root: any = document.getElementsByClassName(id)[0];
  let node: any = root.childNodes[0];
  while (node != null) {
    if (node.nodeType == 3) {
      result.push(node.nodeValue);
    }
    if (node.hasChildNodes()) {
      node = node.firstChild;
    } else {
      while (node.nextSibling == null && node != root) {
        node = node.parentNode;
      }
      node = node.nextSibling;
    }
  }

  result = result.join('<BR>');

  return result;
};

/**
 * @description function to get text of all nodes in htlm dom for text translation
 */
const setTranslatedText = (textArr: any, id: any) => {
  // const root = document.body;
  // let node: any = root.childNodes[0];
  // let node: any = document.getElementById(id);
  const root: any = document.getElementsByClassName(id)[0];
  let node: any = root.childNodes[0];
  let x = 0;
  while (node != null) {
    if (node.nodeType == 3) {
      node.nodeValue = textArr && textArr[x];
      x++;
    }
    if (node.hasChildNodes()) {
      node = node.firstChild;
    } else {
      while (node.nextSibling == null && node != root) {
        node = node.parentNode;
      }
      node = node.nextSibling;
    }
  }
};

/**
 * Function to get access token from Graph API Azure AD
 * @param code
 * @returns
 */
const getGraphApiToken = (code: any) => {
  const redirect_uri = process.env.NEXTAUTH_URL;
  const clientId = String(process.env.NEXT_PUBLIC_AZURE_AD_CLIENT_ID);

  const payload: any = {
    client_id: clientId,
    scope: GRAPH_API_SCOPE,
    code: code,
    redirect_uri: `${redirect_uri}/`,
    grant_type: GRAPH_API_GRANT_TYPE,
    code_verifier: CODE_VERIFIER,
  };
  const dataObj: any = Object.keys(payload)
    .map((key) => `${key}=${encodeURIComponent(payload[key])}`)
    .join('&');
  return new Promise(function (resolve) {
    let xhr = new XMLHttpRequest();
    xhr.open('POST', GRAPH_API_ENDPOINT, true);
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
    xhr.setRequestHeader('Access-Control-Allow-Origin', '*');

    xhr.onload = function () {
      // if (this.status >= 200 && this.status < 300) {
      //   resolve(xhr.response);
      // } else {
      // }

      resolve({
        status: this.status,
        statusText: xhr.statusText,
        response: xhr.response,
      });
    };
    xhr.send(dataObj);
    xhr.onerror = function () {
      resolve({
        status: this.status,
        statusText: xhr.statusText,
        response: '',
      });
    };
  });
};

/**
 * Function to get current window width
 * @param code
 * @returns String
 */
const getCurrentWindowWidth = () => {
  return typeof window !== 'undefined' && window && window.innerWidth;
};

/**
 * Check if language exixts in the array if not fallback to english (en)
 * @param language
 */
const checkIfLanguageExistsInArray = (language: any) => {
  if (language !== '') {
    return KEY_LANGUAGES.map((v) => v.toLowerCase()).indexOf(language.toLowerCase()) !== -1
      ? language
      : 'en';
  } else {
    return 'en';
  }
};

const toTimeStamp = (strDate: any) => {
  var datum = Date.parse(strDate);
  return datum / 1000;
};

const redirectWithLanguage = (languageCode: any) => {
  const isPreviewMode: any = checkIsPreviewOrEditorMode(KEY_IS_PREVIEW);
  const isExperienceEditor: any = checkIsPreviewOrEditorMode(KEY_IS_EDIT);
  if (!isExperienceEditor && !isPreviewMode) {
    const currentUrl = window.location;
    let formattedURL: any = currentUrl.toString().split('/');
    if (formattedURL && formattedURL[3]) {
      if (formattedURL[3] === languageCode) {
        window.location.reload();
      } else {
        formattedURL[3] = languageCode;
        formattedURL = formattedURL.join('/');
        //console.log('FormattedURL---' + formattedURL);
        window.location.href = formattedURL;
      }
    } else {
      window.location.reload();
    }
  } else {
    window.location.reload();
  }
};

const countryPersonalizedQuickLinks = (CountryCode: any, linkList: any) => {
  const filteredLinks: any = [];
  for (let i = 0; i < linkList.length; i++) {
    const link: any = linkList[i];
    const enableFor: any = link && link.fields && link.fields.EnableFor;
    if (enableFor) {
      for (let j = 0; j < enableFor.length; j++) {
        const country: any =
          enableFor &&
          enableFor[j] &&
          enableFor[j].fields &&
          enableFor[j].fields['Country Name'] &&
          enableFor[j].fields['Country Name'].value;
        if (country === CountryCode) {
          filteredLinks.push(link);
        }
      }
    }
  }
  return filteredLinks;
};

const countryPersonalizedCalendarSections = (CountryCode: any, linkList: any) => {
  const filteredLinks: any = [];
  for (let i = 0; i < linkList.length; i++) {
    const link: any = linkList[i];
    const enableFor: any =
      link &&
      link.fields &&
      link.fields.CalenderSection &&
      link.fields.CalenderSection.fields &&
      link.fields.CalenderSection.fields.EnableFor;
    if (enableFor) {
      for (let j = 0; j < enableFor.length; j++) {
        const country: any =
          enableFor &&
          enableFor[j] &&
          enableFor[j].fields &&
          enableFor[j].fields['Country Name'] &&
          enableFor[j].fields['Country Name'].value;
        if (country === CountryCode) {
          //console.log('*********************** Country matching *****************');
          filteredLinks.push(link);
        }
      }
    }
  }
  return filteredLinks;
};

const formatLayoutLanguageData = (layoutData: any) => {
  const finalData =
    layoutData &&
    layoutData.fields &&
    layoutData.fields.languages &&
    layoutData.fields.languages.LanguagesList;

  if (finalData && finalData.length > 0) {
    return finalData;
  } else {
    return null;
  }
};

const getQueryParamsFromUrl = (name: string) => {
  const params = new URLSearchParams(window.location.search);
  const response = params.get(name);
  return response ?? '';
};


/* Function for adding margin class to hyphens in bayersans font
 *  Created On : 27 Aug 2024
 *  Created By : Ibrahim
 *  Module : for all date strins in headless with bayersans font
 */

const hyphenFontFix = (date:string) => {
  if(!date){
    return undefined;
}

const newDate = date.split("-").map((val, ndx)=>{
    if(ndx!==date.split("-").length-1){
        return `${val}<span class='bayersans_hyphen'>-</span>`
    }
    return val;
}).join("");
return newDate.trim();
}


let richTextFix = (text:any)=>{
  let textToRemove = "/sitecore/content/bag-intra/ws_bayernet/";
  if (text.value.search('href')>0){
    return {...text,value:text.value.replaceAll(textToRemove,'/')};
  }else{
    return text;
  }
}

let onRedirect = (reDirectTo:any, isNewTab:any, isWhitLang:any) => {
  if (!reDirectTo) {
    return false;
  }
  if (reDirectTo.includes('http://') || reDirectTo.includes('https://')) {
    return window.open(reDirectTo, isNewTab ? '_blank' : '_self');
  }
  const currPath = window.location.pathname.split('/');
  if (isWhitLang) {
    return window.open(`${window.location.origin}${reDirectTo}`, isNewTab ? '_blank' : '_self');
  }
  let path = '';
  if (currPath.length > 1) {
    path = `${currPath[0] !== '' ? currPath[0] : currPath[1]}${reDirectTo}`;
  } else {
    path = reDirectTo;
  }
  return window.open(`${window.location.origin}/${path}`, isNewTab ? '_blank' : '_self');
};






export {
  
  getFromStorage,
  setToStorage,
  getCookie,
  removeFromStorage,
  setToLocalStorage,
  getFromLocalStorage,
  removeFromLocalStorage,
  isNull,
  findColorPallete,
  getParentClassReference,
  getMonthName,
  isFutureEvent,
  correctURLrouting,
  getPathFromUrl,
  getCurrentQuarterName,
  getParentAttributeReference,
  groupCalendarEvents,
  getTaskDuration,
  getTaskDetails,
  groupByTaskType,
  setHashString,
  getHashString,
  getSelectedMonthTaskList,
  getMonthNameById,
  getDateSuffix,
  createIcsFile,
  formatDateICS,
  getSelectedMonthLinks,
  checkIsLocalhost,
  checkIsLanguageExistsInUrl,
  checkEnvExistsinUrl,
  checkIsPreviewOrEditorMode,
  stripTags,
  getCode,
  getPageContentForTranslation,
  getGraphApiToken,
  setTranslatedText,
  getCurrentWindowWidth,
  checkIfLanguageExistsInArray,
  toTimeStamp,
  redirectWithLanguage,
  countryPersonalizedQuickLinks,
  countryPersonalizedCalendarSections,
  formatLayoutLanguageData,
  getQueryParamsFromUrl,
  setCookie,
  hyphenFontFix,
  richTextFix,
  onRedirect
};
