import { useRef, useEffect, useState } from 'react';
import { ComponentProps } from 'lib/component-props';
import { StyleguideSpecimenFields } from 'lib/component-props/styleguide';
import { Placeholder, Field } from '@sitecore-jss/sitecore-jss-nextjs';
import { CONTENT_25, CONTENT_75, CD_75_25 } from 'src/constants/contentDivider';
import { formatContentDividerData } from 'src/helpers/contentDivider.helper';
import styles from './ContentDivider_75_25.module.scss';

type TwoColumnContainerProps = ComponentProps &
  StyleguideSpecimenFields & {
    fields: {
      heading: Field<string>;
    };
  };

const ContentDivider_75_25 = (props: TwoColumnContainerProps): JSX.Element => {
  const [isParentIdExists, setIsParentIdExists] = useState<boolean>(false);
  const currentElement: any = useRef(null);
  const contentDividerBg = formatContentDividerData(props);
  /**
   * @description to check if parent node has id . If parent has id it this current content divider is a nested content divider.
   */
  useEffect(() => {
    currentElement &&
    currentElement.current &&
    currentElement.current.parentNode &&
    currentElement.current.parentNode.id &&
    currentElement.current.parentNode.id !== undefined &&
    currentElement.current.parentNode.id !== ''
      ? setIsParentIdExists(true)
      : setIsParentIdExists(false);
  }, []);

  return (
    <section
      className={`${styles.divider_75_25__container} ${
        !isParentIdExists ? styles.divider_75_25_container__bg : ''
      }`}
      ref={currentElement}
      style={{
        backgroundColor:
          contentDividerBg && contentDividerBg.bgColor && contentDividerBg.bgColor !== ''
            ? contentDividerBg.bgColor
            : 'white',
      }}
    >
      <div className={styles.divider_75_25_wrapper}>
        <div
          className={styles.divider_left_75_container}
          id={CONTENT_75}
          data-nested={isParentIdExists}
          data-cd-bg={
            contentDividerBg && contentDividerBg.bgColor && contentDividerBg.bgColor !== ''
              ? contentDividerBg.bgColor
              : 'white'
          }
        >
          <Placeholder name={CD_75_25.PH_75_25_LEFT_75} rendering={props.rendering} />
        </div>
        <div
          className={styles.divider_right_25_container}
          id={CONTENT_25}
          data-nested={isParentIdExists}
          data-cd-bg={
            contentDividerBg && contentDividerBg.bgColor && contentDividerBg.bgColor !== ''
              ? contentDividerBg.bgColor
              : 'white'
          }
        >
          <Placeholder name={CD_75_25.PH_75_25_RIGHT_25} rendering={props.rendering} />
        </div>
      </div>
    </section>
  );
};
export default ContentDivider_75_25;
