// import { Image } from '../Image/Image';
import { useState } from 'react';
import { formatTileItemData } from 'src/helpers/tiles.helper';
import { RichText, Text, Link, Image, useSitecoreContext } from '@sitecore-jss/sitecore-jss-nextjs';
import {
  TILE_IMAGE,
  TILE_DESCRIPTION,
  TILE_TEXT,
  TILE_LINK,
  TILE_IMAGE_HOVER,
  TILE_SHOW_MOUSE_HOVER,
} from 'src/constants/general';
import styles from './TileItem.module.scss';

export default function TileItem(props: any) {
  const { sitecoreContext } = useSitecoreContext();
  const isExperienceEditor = sitecoreContext && sitecoreContext.pageEditing;
  const refinedTileItemData: any = formatTileItemData(props && props.fields);
  const [tileHoverImage, setTileHoverImage] = useState<boolean>(false);
  const hoverHandler = (param: boolean) => {
    if (param === true) {
      setTileHoverImage(true);
    } else if (param === false) {
      setTileHoverImage(false);
    } else {
      setTileHoverImage(false);
    }
  };

  return (
    <div
      className={`${styles.tile_container}`}
      onMouseEnter={() => hoverHandler(true)}
      onMouseLeave={() => hoverHandler(false)}
      onTouchMove={() => hoverHandler(true)}
      onTouchEnd={() => hoverHandler(false)}
    >
      <Link
        field={refinedTileItemData && refinedTileItemData[TILE_LINK]}
        showLinkTextWithChildrenPresent={false}
        editable={true}
        target="_blank"
      >
        <div>
          {!isExperienceEditor ? (
            refinedTileItemData[TILE_IMAGE] &&
            refinedTileItemData[TILE_IMAGE].value &&
            Object.keys(refinedTileItemData[TILE_IMAGE].value).length !== 0 ? (
              refinedTileItemData &&
              refinedTileItemData[TILE_IMAGE_HOVER] &&
              refinedTileItemData[TILE_IMAGE_HOVER].value &&
              Object.keys(refinedTileItemData[TILE_IMAGE_HOVER].value).length !== 0 &&
              refinedTileItemData[TILE_SHOW_MOUSE_HOVER] ? (
                <div className={styles.img_container}>
                  <Image
                    field={refinedTileItemData && refinedTileItemData[TILE_IMAGE_HOVER]}
                    editable={true}
                    className={
                      refinedTileItemData &&
                      refinedTileItemData[TILE_SHOW_MOUSE_HOVER] &&
                      tileHoverImage
                        ? styles.show__img
                        : styles.hide__img
                    }
                  />
                  <Image
                    field={refinedTileItemData && refinedTileItemData[TILE_IMAGE]}
                    editable={true}
                    className={
                      refinedTileItemData &&
                      refinedTileItemData[TILE_SHOW_MOUSE_HOVER] &&
                      !tileHoverImage
                        ? styles.show__img
                        : styles.hide__img
                    }
                  />
                </div>
              ) : (
                <div className={styles.img_container}>
                  <Image
                    field={refinedTileItemData && refinedTileItemData[TILE_IMAGE]}
                    editable={true}
                  />
                </div>
              )
            ) : (
              ''
            )
          ) : (
            <div className={styles.img_container}>
              <Image
                field={refinedTileItemData && refinedTileItemData[TILE_IMAGE]}
                editable={true}
              />
            </div>
          )}

          <div className={styles.text_container}>
            <Text
              tag="div"
              className={styles.headline_container}
              field={refinedTileItemData && refinedTileItemData[TILE_DESCRIPTION]}
            />

            <RichText
              tag="div"
              className={styles.description_container}
              field={refinedTileItemData && refinedTileItemData[TILE_TEXT]}
            />
          </div>
        </div>
      </Link>
    </div>
  );
}
