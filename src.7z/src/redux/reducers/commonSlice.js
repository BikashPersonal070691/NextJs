import { createSlice } from '@reduxjs/toolkit';
import { getGtmDataLayer } from 'src/services/userSettings.service';

const commonSlice = createSlice({
  name: 'common',
  initialState: {
    breadcrumbData: [],
    isAuthorized: false,
    gtmDataLayer: null,
  },
  reducers: {
    SET_BREADCRUMB_DATA: (state, action) => {
      state.breadcrumbData = action.payload;
    },
    SET_IS_AUTHORIZED: (state, action) => {
      state.isAuthorized = action.payload;
    },
    setGtmDataLayer: (state, action) =>{
      state.gtmDataLayer = action.payload;
    }
  },
});

export const { SET_BREADCRUMB_DATA, SET_IS_AUTHORIZED, setGtmDataLayer } = commonSlice.actions;

export const getDataLayer = () => async(dispatch)=>{
  try {
    const dataLayer = await getGtmDataLayer()
    if(dataLayer.data){
      dispatch(setGtmDataLayer(dataLayer?.data))
    }
  } catch (error) {
    console.error('fetchProfileData - Slice ~ error:', error);
  }
}

export default commonSlice.reducer;
