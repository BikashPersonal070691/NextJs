import {
  BAYER_TRANSLATE_KEY,
  BAYER_TRANSLATE_MAIN_PAGE,
  KEY_COOKIE_CURRENT_LANGUAGE1,
  KEY_DEFAULT_SELECTED_LANGUAGE,
  KEY_LANGUAGE_CODE_EN,
  KEY_MAIN_CONTENT_TRANSLATION_ID,
  KEY_PAGE_LANGUAGE,
  KEY_SELECTED_LANGUAGE,
  KEY_URL_STRING_REMOVAL,
} from 'src/constants/general';
import styles from './Languages.module.scss';
import { useState, useEffect } from 'react';
import {
  getFromLocalStorage,
  getPageContentForTranslation,
  setCookie,
  setToLocalStorage,
  setToStorage,
  setTranslatedText,
} from 'src/core/utils/utils.helper';
import { getlanguageList } from 'src/services/header.service';
import { bayerTranslateApi } from 'src/services/userSettings.service';
import { Loader } from 'components/Elements/Loader/Loader';
import { SET_IS_LANGAUGE_SELECTED } from 'src/redux/reducers/languageSlice';
import { useDispatch } from 'react-redux';
import { KEY_BAYER_TRANSLATE_TEXT, KEY_BAYER_TRANSLATE_TO } from 'src/constants/dictonary';
import { useLanguageTranslate } from 'src/hooks/useLanguageTranslate';

export default function Languages(props: any) {
  const { translatedKey } = useLanguageTranslate();
  const { fields } = props;
  const dispatch = useDispatch<any>();
  const [isOpen, setisOpen] = useState<any>(false);
  const [showDropdown, setshowDropdown] = useState<any>(false);
  const [seed, setSeed] = useState(1);
  const [pageTextArr, setPageTextArr] = useState('');
  const [showLoader, setShowLoader] = useState(false);
  const [responseText, setResponseText] = useState('');
  const [defaultSelectedLang, setDefaultSelectedLang] = useState<any>('');
  const [languageList, setLanguageList] = useState<any>([]);
  const [filteredLanguageList, setFilteredLanguageList] = useState<any>([]);
  const [selectedLanguage, setSelectedLanguage] = useState<any>('');
  const [defaultLanguages, setDefaultLanguages] = useState<any>([]);

  useEffect(() => {
    const payload = {
      key: BAYER_TRANSLATE_KEY,
      target: KEY_LANGUAGE_CODE_EN,
    };
    getlanguageList(payload).then((data: any) => {
      if (data && data.data) {
        setFilteredLanguageList(data && data.data && data.data.languages);
        setLanguageList(data && data.data && data.data.languages);
      }
    });

    const langList =
      fields && fields.languages && fields.languages.LanguagesList
        ? fields.languages.LanguagesList
        : [];
    setDefaultLanguages(langList);

    let currentUrl = window.location;
    let formattedURL: any = currentUrl.toString().split('/');
    if (formattedURL && formattedURL[3]) {
      let text = formattedURL[3].toString().split('-');
    

      //fix for preview mode
    if( currentUrl.toString().indexOf("lang=") && currentUrl.toString().indexOf("mode=preview")>1){
      currentUrl.toString().split('lang=')[1] ?  text = [currentUrl.toString().split('lang=')[1].slice(0,2).toUpperCase(),currentUrl.toString().split('lang=')[1].slice(0,2).toUpperCase()]:"";
    }
    const isLanguageDefault = langList.some(
      (lang: any) => lang.LanguageCode.toLowerCase() === formattedURL[3].toString().toLowerCase()
    );
    if(!isLanguageDefault && currentUrl.toString().indexOf("lang=")===-1){
      setDefaultSelectedLang({ Text: 'EN', LanguageCode: 'en' });
    }else{
      if (text && text[1]) {
        //Fix for JA and KO
        if(text[0] && (text[0]=="ja"|| text[0]=="JA" )){
          setDefaultSelectedLang({ Text: "JP", LanguageCode: formattedURL[3]  });
        }else if(text[0] && (text[0]=="ko"|| text[0]=="KO" ) ){
          setDefaultSelectedLang({ Text: "KR", LanguageCode: formattedURL[3] });
        }else {
          setDefaultSelectedLang({ Text: text && text[0], LanguageCode: formattedURL[3] });
        }
      } else {
         //Fix for JA and KO
         if (text && (text == 'ja' || text == 'JA')) {
           setDefaultSelectedLang({ Text: 'JP', LanguageCode: text });
         } else if (text && (text == 'ko' || text == 'KO')) {
           setDefaultSelectedLang({ Text: 'KR', LanguageCode: text });
         } else {
           setDefaultSelectedLang({ Text: text, LanguageCode: text });
         }
      }
    }
    } else {
      let pageLanguage = getFromLocalStorage(KEY_PAGE_LANGUAGE);

      if (pageLanguage) {
        const isLanguageDefault = langList.some(
          (lang: any) => lang.LanguageCode.toLowerCase() === pageLanguage.toString().toLowerCase()
        );
        if (!isLanguageDefault) {
          setDefaultSelectedLang({ Text: 'EN', LanguageCode: 'en' });
        } else {
          pageLanguage = pageLanguage.toString().split('-');
          if (pageLanguage && pageLanguage[1]) {
            //Fix for JA and KO
            if (pageLanguage[0] && (pageLanguage[0] == 'ja' || pageLanguage[0] == 'JA')) {
              setDefaultSelectedLang({ Text: 'JP', LanguageCode: pageLanguage[1] });
            } else if (pageLanguage[0] && (pageLanguage[0] == 'ko' || pageLanguage[0] == 'KO')) {
              setDefaultSelectedLang({ Text: 'KR', LanguageCode: pageLanguage[1] });
            } else {
              setDefaultSelectedLang({ Text: pageLanguage[0], LanguageCode: pageLanguage[1] });
            }
          } else {
            //Fix for JA and KO
            if (pageLanguage[0] && (pageLanguage[0] == 'ja' || pageLanguage[0] == 'JA')) {
              setDefaultSelectedLang({ Text: 'JP', LanguageCode: pageLanguage[0] });
            } else if (pageLanguage[0] && (pageLanguage[0] == 'ko' || pageLanguage[0] == 'KO')) {
              setDefaultSelectedLang({ Text: 'KR', LanguageCode: pageLanguage[0] });
            } else {
              setDefaultSelectedLang({ Text: pageLanguage[0], LanguageCode: pageLanguage[0] });
            }
          }
        }
      } else {
        setDefaultSelectedLang({ Text: 'EN', LanguageCode: 'en' });
      }
    }
  }, []);

  const handleShowdropdown = () => {
    setisOpen(!isOpen);
    document.body.addEventListener('click', handleHidedropdown);
  };

  const handlelanguagedropdownclick = (e: any) => {
    e.stopPropagation();
    let dropdownElm = e.target.closest('.translate_language_dropdown');
    if (!dropdownElm) {
      handleShowdropdown();
    }
  };
  const handlelanguageInputDropdownclick = () => {
    setshowDropdown(!showDropdown);
    scrollToSelected();
  };

  const handleHidedropdown = (e: any) => {
    if (!e.target.closest('.translate_language_dropdown')) {
      setisOpen(false);
      setshowDropdown(false);
      document.body.removeEventListener('click', handleHidedropdown);
    }
  };

  const handleSearch = (e: any) => {
    let input = e.target.value;
    setSelectedLanguage(input);
    let searchedLanguages = languageList.filter((langItem: any) => {
      if (
        langItem &&
        langItem.name &&
        langItem.name.toLowerCase().startsWith(input.toLowerCase())
      ) {
        return langItem;
      }
    });

    setFilteredLanguageList(searchedLanguages);
  };

  const translateText = (item: any) => {
    setSelectedLanguage(item && item.name);
    setShowLoader(true);
    let textArr: any = getPageContentForTranslation(KEY_MAIN_CONTENT_TRANSLATION_ID);

    let finalText: any = pageTextArr;
    if (pageTextArr == '' || textArr !== responseText) {
      setPageTextArr(textArr);
      finalText = textArr;
    }

    const payload = {
      key: BAYER_TRANSLATE_KEY,
      target: item.code,
      q: finalText,
    };

    bayerTranslateApi(payload).then((data: any) => {
      if (data && data.data) {
        setResponseText(
          data.data.translations &&
            data.data.translations[0] &&
            data.data.translations[0].translatedText
        );
        const translatedText =
          data.data.translations &&
          data.data.translations[0] &&
          data.data.translations[0].translatedText &&
          data.data.translations[0].translatedText.split('<BR>');
        setTranslatedText(translatedText, KEY_MAIN_CONTENT_TRANSLATION_ID);
        setSeed(Math.random());
        handleShowdropdown();
        setToStorage(KEY_SELECTED_LANGUAGE, item.code);
        setShowLoader(false);
        dispatch(SET_IS_LANGAUGE_SELECTED(true));
      }
    });
  };

  const handleDefaultLanguageClick = (item: any) => {
    if (item) {
      setCookie(KEY_COOKIE_CURRENT_LANGUAGE1, item.LanguageCode);
      setToLocalStorage(KEY_DEFAULT_SELECTED_LANGUAGE, JSON.stringify(item));
    }
    return true;
  };

  const scrollToSelected = () => {
    if (selectedLanguage && selectedLanguage != '') {
      const list: any = document.getElementById('translate_ul');
      const targetLi: any = document.getElementById(selectedLanguage);

      list.scrollTop = targetLi.offsetTop - 50;
    }
    return true;
  };

  const addHoverClass = (e:any) =>{
    e.target.classList.add("hover");
  }

  const removeHoverClass = (e:any) =>{
    e.target.classList.remove("hover");
  }

  
  return (
    <div
      className={styles.language_dropdown_wrappper}
      onClick={handlelanguagedropdownclick}
      key={seed}
    >
      <span className={styles.language_dropdown_text}>
        {defaultSelectedLang && defaultSelectedLang.Text}
      </span>
      <span
        className={`
        ${styles.language_dropdown_arrow} 
        ${isOpen && isOpen ? styles.arrow_up : styles.arrow_down}`}
      ></span>

      <ul
        id="translate_ul"
        className={`translate_language_dropdown ${styles.languages_container} ${
          isOpen && isOpen ? styles.languages_container_show : styles.languages_container_hidden
        }`}
      >
        {defaultLanguages.map((languageItem: any) => {
          return (
            <li
              className={styles.language_item}
              id={languageItem.LanguageCode}
              key={languageItem.LanguageCode}
              onClick={() => handleDefaultLanguageClick(languageItem)}
              style={{
                color:
                  defaultSelectedLang &&
                  defaultSelectedLang.LanguageCode &&
                  defaultSelectedLang.LanguageCode.toString() ===
                    languageItem.LanguageCode.toLowerCase()
                    ? '#d70d5a'
                    : '#0f384f',
              }}
            >
              <a
                href={languageItem.URL ? languageItem.URL.replace(KEY_URL_STRING_REMOVAL, '') : '#'}
              >
                {languageItem.LanguageName} ({languageItem.Text})
              </a>
            </li>
          );
        })}

        <div className={styles.languages_wrapper}>
          <p className={styles.languages_text}>
            {' '}
            {translatedKey(KEY_BAYER_TRANSLATE_TEXT)}{' '}
            <a
              className={styles.languages_transalte_link}
              href={BAYER_TRANSLATE_MAIN_PAGE}
              target="_blank"
            >
              Bayer Translate
            </a>{' '}
            {translatedKey(KEY_BAYER_TRANSLATE_TO)}  :
          </p>

          <input
            className={styles.language_selector_dropdown}
            placeholder="Select Target Language"
            onClick={handlelanguageInputDropdownclick}
            onChange={handleSearch}
            value={selectedLanguage}
          ></input>
          <ul
            className={`dropdown-menu
                ${styles.languages_items_container}
                ${
                  showDropdown && showDropdown
                    ? styles.languages_items_container_shown
                    : styles.languages_items_hidden
                }`}
          >
            {filteredLanguageList && Array.isArray(filteredLanguageList)
              ? filteredLanguageList.map((languageItem: any) => {
                  return (
                    <li
                      className={`${styles.languages_item}`}
                      id={languageItem && languageItem.name}
                      key={languageItem && languageItem.code}
                      data-value={languageItem.code && languageItem.code}
                      onClick={() => translateText(languageItem)}
                      onMouseEnter={addHoverClass}
                      onMouseLeave={removeHoverClass}
                    >
                      <a>{languageItem.name && languageItem.name} </a>
                    </li>
                  );
                })
              : ''}
          </ul>
        </div>
        {showLoader ? <Loader /> : ''}
      </ul>
    </div>
  );
}
