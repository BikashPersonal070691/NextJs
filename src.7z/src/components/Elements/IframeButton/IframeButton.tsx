/*Button Component */
import { useState } from 'react';
import styles from './IframeButton.module.scss';
import IframeOverLay from 'components/Iframeoverlay/IframeOverlay';
import { IFRAME_BUTTON_TYPE, KEY_IFRAME, KEY_IFRAME_BUTTON_TEXT } from 'src/constants/general';

export function IframeButton(props: any) {
  const { data, type,group } = props;
  const [openIframe, setOpenIframe] = useState(false);

  const launchIframe = () => {
   if(type === IFRAME_BUTTON_TYPE.HR_ALL_TASK){
    return;
   }else{
    setOpenIframe(true);
   }
    
  };

  const closeIframe = () => {
    setOpenIframe(false);
  };

  const getClass = () => {
    if (type === IFRAME_BUTTON_TYPE.HR_TASK) {
      return styles.iframe_launch_hr_task;
    } else if (type === IFRAME_BUTTON_TYPE.KEY_TASK) {
      return styles.iframe_launch_key_task;
    } else if(type === IFRAME_BUTTON_TYPE.HR_ALL_TASK){
       if(group =="group_one"){
        return (`iframe_hr_all ${styles.iframe_launch_hr_task_all_group_one}`);
       }else if(group=="group_two") {
        return (`iframe_hr_all ${styles.iframe_launch_hr_task_all_group_two}`);
       }else if(group=="group_three") {
        return (`iframe_hr_all ${styles.iframe_launch_hr_task_all_group_three}`);
       }else{
        return (`iframe_hr_all ${styles.iframe_launch_hr_task_all}`);
       }
    }else {
      return styles.iframe_launch_hr_task;
    }
  };

  return (

    data &&
      data[KEY_IFRAME] &&
      data[KEY_IFRAME][0] && data[KEY_IFRAME][0].fields &&
      data[KEY_IFRAME][0].fields.IframeSource &&
      data[KEY_IFRAME][0].fields.IframeSource.value &&
      data[KEY_IFRAME_BUTTON_TEXT] &&
      data[KEY_IFRAME_BUTTON_TEXT].value ? (
        <div className={styles.iframe_launch_button_wrapper}>
      <a onClick={launchIframe} className={getClass()}>
        {data[KEY_IFRAME_BUTTON_TEXT] && data[KEY_IFRAME_BUTTON_TEXT].value}
      </a>
      {openIframe ? <IframeOverLay closeIframe={closeIframe} iframe={data[KEY_IFRAME] && data[KEY_IFRAME][0]} /> : ''}
    </div>
      ) : (
        <></>
      )


    
  );
}
