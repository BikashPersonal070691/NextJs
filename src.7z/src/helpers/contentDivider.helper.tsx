import { CD_COLOR_PALLETE, KEY_CONTENT_DIVIDER_LINK_BGCOLOR } from '../constants/contentDivider';

import { findColorPallete } from 'src/core/utils/utils.helper';
/**
 * format contentdivider data
 * @param data
 * @returns
 */
const formatContentDividerData = (data: any) => {
  const paramsData = data && data.params;
  const listingData: any = {
    bgColor:
      paramsData &&
      paramsData[KEY_CONTENT_DIVIDER_LINK_BGCOLOR] &&
      paramsData[KEY_CONTENT_DIVIDER_LINK_BGCOLOR] !== ''
        ? findColorPallete(CD_COLOR_PALLETE, paramsData[KEY_CONTENT_DIVIDER_LINK_BGCOLOR])
        : '',
  };
  return listingData;
};

export { formatContentDividerData };
