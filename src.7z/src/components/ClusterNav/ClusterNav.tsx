import { useState, useEffect } from 'react';
import { KEY_BREAKPOINT_MEDIUM_LARGE } from '../../constants/general';
import ClusterNavMobile from 'components/ClusterNavMobile/ClusterNavMobile';
import ClusterNavigationDesktop from 'components/ClusterNavDesktop/ClusterNavDesktop';

export default function ClusterNav() {
  const [showMobileView, setShowMobileView] = useState<any>(false);
  const [windowWidth, setWindowWidth] = useState<any>();

  const handleResize = () => {
    if (window.innerWidth != windowWidth) {
      setWindowWidth(window.innerWidth);
    }
  };

  useEffect(() => {
    let width = window.innerWidth;
    setWindowWidth(width);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    if (windowWidth && windowWidth > KEY_BREAKPOINT_MEDIUM_LARGE) {
      setShowMobileView(false);
    }
    if (windowWidth && windowWidth <= KEY_BREAKPOINT_MEDIUM_LARGE) {
      setShowMobileView(true);
    }
  }, [windowWidth]);

  return (
    <>
      {showMobileView && <ClusterNavMobile />}
      {typeof showMobileView === 'boolean' && showMobileView === false && (
        <ClusterNavigationDesktop />
      )}
    </>
  );
}
