import { useState, useEffect } from 'react';
import { Text, RichText, useSitecoreContext } from '@sitecore-jss/sitecore-jss-nextjs';
import { Button } from 'components/Elements/Button/Button';
import { useLanguageTranslate } from 'src/hooks/useLanguageTranslate';
import {
  KEY_COOKIE_HEADING,
  KEY_COOKIE_DESCRIPTION,
  KEY_COOKIE_ACCEPT,
  KEY_COOKIE_REJECT,
  KEY_COOKIE_SETTINGS,
} from 'src/constants/dictonary';
import { KEY_ENVIRONMENTS } from 'src/constants/general';
import { setCookieConsent } from 'src/services/footer.service';
import { formatCookieBannerData } from 'src/helpers/component.helper';
import { useSelector } from 'react-redux';
import { checkEnvExistsinUrl } from 'src/core/utils/utils.helper';
import styles from './CookieBanner.module.scss';

const CookieBanner = (props: any) => {
  const { translatedKey } = useLanguageTranslate();
  const formattedData = formatCookieBannerData(props);
  const [showBanner, setShowBanner] = useState<boolean>(false);
  const { isPreviewMode } = useSelector((state: any) => state.expEditorProps);
  const { sitecoreContext } = useSitecoreContext();
  const isExperienceEditor = sitecoreContext && sitecoreContext.pageEditing;

  // check the environment is localhost
  const isEnvLocalHost: any = checkEnvExistsinUrl(KEY_ENVIRONMENTS.ENV_LOCAL);

  // show and hide banner
  useEffect(() => {
    if (props && props.fields && props.fields.ShowConsent) {
      setShowBanner(true);
    } else {
      setShowBanner(false);
    }
  }, []);

  const handleCookieConsent = (status: boolean) => {
    setCookieConsent(status)
      .then((data: any) => {
        if (data && data.status && data.status === 200) {
          setShowBanner(false);
        } else {
          setShowBanner(true);
        }
      })
      .catch((err: any) => {
        setShowBanner(true);
        console.error('handleCookieConsent ~ err:', err);
      });
  };

  const handlePrivacyRedirection = () => {
    if (formattedData && formattedData.privacyLink !== '') {
      window.location.href = formattedData.privacyLink;
    }
  };
  return (
    <>
      {!isExperienceEditor && !isPreviewMode && showBanner && !isEnvLocalHost && (
        <div className={styles.cookie_banner_container}>
          <div className={styles.container}>
            <div className={styles.content__wrapper}>
              <div className={styles.content__heading}>
                <Text tag="h5" field={{ value: translatedKey(KEY_COOKIE_HEADING) }} />
              </div>
              <div className={styles.content__text}>
                <RichText
                  tag="p"
                  field={{
                    value: translatedKey(KEY_COOKIE_DESCRIPTION),
                  }}
                />
              </div>
            </div>
            <div className={styles.actions__wrapper}>
              <div className={styles.actions_wrapper__inner}>
                <Button class={styles.action} onClick={() => handlePrivacyRedirection()}>
                  {translatedKey(KEY_COOKIE_SETTINGS)}
                </Button>
                <Button class={styles.action} onClick={() => handleCookieConsent(false)}>
                  {translatedKey(KEY_COOKIE_REJECT)}
                </Button>
                <Button class={styles.action} onClick={() => handleCookieConsent(true)}>
                  {translatedKey(KEY_COOKIE_ACCEPT)}
                </Button>
              </div>
            </div>
          </div>
          <div className={styles.close__button} onClick={() => handleCookieConsent(false)}></div>
        </div>
      )}
    </>
  );
};

export default CookieBanner;
