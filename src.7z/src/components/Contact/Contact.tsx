import React, { useEffect, useState, useRef } from 'react';
import styles from './Contact.module.scss';
import { getCode, getFromStorage, getParentClassReference } from 'src/core/utils/utils.helper';
import { CONTENT_100 } from 'src/constants/contentDivider';
import {
  KEY_AZURE_AD_CODE,
  KEY_TEAMS_API_ERROR_INVALID_TOKEN,
  KEY_TEAMS_STATUS_AVAILABLE,
  KEY_TEAMS_STATUS_AWAY,
  KEY_TEAMS_STATUS_BLOCKED,
  KEY_TEAMS_STATUS_BRB,
  KEY_TEAMS_STATUS_BUSY,
  KEY_TEAMS_STATUS_DO_NOT_DISTURB,
  KEY_TEAMS_STATUS_INVISIBLE,
  KEY_TEAMS_STATUS_OFFLINE,
} from 'src/constants/general';
import { getUserId, getUserStatus } from 'src/services/contact.service';

// type ContactComponentProps = StyleguideComponentProps & {
//   fields: {
//     useR_ID: Field<string>;
//     lasT_NAME: Field<string>;
//     firsT_NAME: Field<string>;
//     namE_PREFIX: Field<string>;
//     leadinG_SUBGROUP: Field<string>;
//     companY_CODE: Field<string>;
//     companY_NAME: Field<string>;
//     location: Field<string>;
//     countrY_CODE: Field<string>;
//     maiL_ADDRESS: Field<string>;
//     iS_SUPERVISOR: Field<string>;
//     orgleveL2: Field<string>;
//     iT_STATUS: Field<string>;
//     purposE_OF_USAGE: Field<string>;
//     phone: Field<string>;
//     title: Field<string>;
//     byhrPortalRole: Field<string>;
//   };
// };

export default function Contact(props: any) {
  const { fields } = props;
  const nodeRef = useRef(null);
  const [parentRef, setParentRef] = useState<any>(null);
  // const [isNested, setIsNested] = useState<any>(false);
  const [contactData, setContactData] = useState<any>({});
  const [userAvailabilityStatus, setUserAvailabilityStatus] = useState<any>(
    KEY_TEAMS_STATUS_AVAILABLE
  );

  const [baseURL, setBaseURL] = useState<any>(process.env.SITECORE_API_URL);

  useEffect(() => {
    if (fields && fields[0]) {
      setContactData(fields[0]);
    }

    if (window && window !== undefined) {
      // const currentUrl : any = window.location.href;
      // const cm_url: any = process.env.CM_APP_URL;
      // const baseLink = currentUrl.includes(cm_url) ? `${cm_url}/api/` : process.env.SITECORE_API_URL;
      const baseLink = process.env.SITECORE_API_URL;
      setBaseURL(baseLink);
    }
  }, [fields]);

  useEffect(() => {
    const child: any = nodeRef.current;
    if (child !== null || child !== undefined) {
      setParentRef(getParentClassReference(child));
      // setIsNested(getParentAttributeReference(child, 'data-nested'));
      // return isNested; //remove this
    } else {
      setParentRef(CONTENT_100);
    }

    /**
     * Added for generating code from contact component for ms teams
     */
    const authorization_code = getFromStorage(KEY_AZURE_AD_CODE);
    if (authorization_code === null || authorization_code === '') {
      getCode();
    }
  }, []);

  useEffect(() => {
    (async () => {
      if (contactData && contactData.maiL_ADDRESS) {
        const userIdApiResponse: any = await getUserId(contactData.maiL_ADDRESS);
        if (userIdApiResponse && userIdApiResponse.id) {
          const userStatusApiResponse: any = await getUserStatus(userIdApiResponse.id);
          setUserAvailabilityStatus(userStatusApiResponse && userStatusApiResponse.availability);
        } else if (
          userIdApiResponse &&
          userIdApiResponse.error &&
          userIdApiResponse.error.code &&
          userIdApiResponse.error.code === KEY_TEAMS_API_ERROR_INVALID_TOKEN
        ) {
          getCode();
        }
      }
    })();
  }, [contactData]);

  const getClass = () => {
    if (userAvailabilityStatus === KEY_TEAMS_STATUS_AVAILABLE) {
      return styles.contact_icon_available;
    } else if (
      userAvailabilityStatus === KEY_TEAMS_STATUS_AWAY ||
      userAvailabilityStatus === KEY_TEAMS_STATUS_BRB
    ) {
      return styles.contact_icon_away;
    } else if (userAvailabilityStatus === KEY_TEAMS_STATUS_BLOCKED) {
      return styles.contact_icon_blocked;
    } else if (userAvailabilityStatus === KEY_TEAMS_STATUS_BUSY) {
      return styles.contact_icon_busy;
    } else if (userAvailabilityStatus === KEY_TEAMS_STATUS_DO_NOT_DISTURB) {
      return styles.contact_icon_dnd;
    } else if (userAvailabilityStatus === KEY_TEAMS_STATUS_INVISIBLE) {
      return styles.contact_icon_invisible;
    } else if (userAvailabilityStatus === KEY_TEAMS_STATUS_OFFLINE) {
      return styles.contact_icon_offline;
    }
    return styles.contact_icon_available;
  };

  return (
    <div ref={nodeRef} className={styles[parentRef]}>
      <div className={styles.contact_card_wrapper}>
        <div className={styles.image_container}>
          <a href={`im:sip:${contactData.maiL_ADDRESS ? contactData.maiL_ADDRESS : ''}`}>
            <img
              className={styles.contact_image}
              src={
                contactData && contactData.useR_ID
                  ? `${baseURL}userprofile/getprofileimage?cwid=${contactData.useR_ID}`
                  : ''
              }
              alt="Image"
            />
            <i className={`${styles.contact_status} ${getClass()}`}></i>
          </a>
        </div>
        <div className={styles.data_container}>
          <div className={styles.name_container}>
            {contactData.maiL_ADDRESS && contactData.maiL_ADDRESS != '' ? (
              <a href={`mailto:${contactData.maiL_ADDRESS ? contactData.maiL_ADDRESS : ''}`}>
                {contactData && contactData.namE_PREFIX} {contactData && contactData.firsT_NAME}{' '}
                {contactData && contactData.lasT_NAME}
                <i className={styles.icon_mail}></i>
              </a>
            ) : (
              ''
            )}
          </div>
          <div className={styles.description_container}>{contactData && contactData.title} </div>
          <div className={styles.contact_container}>
            {' '}
            {contactData.phone && contactData.phone != '' ? (
              <a href={`Tel:${contactData.phone ? contactData.phone : ''}`}>
                <i className={styles.icon_phone}></i> {contactData && contactData.phone}
              </a>
            ) : (
              ''
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
