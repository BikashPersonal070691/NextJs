import { useContext } from 'react';
import { formatAnchorTagData } from 'src/helpers/component.helper';
import { Field, useSitecoreContext } from '@sitecore-jss/sitecore-jss-nextjs';
import styles from './AnchorTag.module.scss';
import { CommonContext } from 'src/contexts/CommonContext';
import { KEY_ANCHOR_HEADING } from 'src/constants/general';
import { ComponentProps } from 'lib/component-props';
import { StyleguideSpecimenFields } from 'lib/component-props/styleguide';

type AnchorTagComponentProps = ComponentProps &
  StyleguideSpecimenFields & {
    fields: {
      [KEY_ANCHOR_HEADING]: Field<string>;
    };
  };

const AnchorTag = (props: AnchorTagComponentProps) => {
  const { setAnchor } = useContext(CommonContext);
  const formattedAnchorData = formatAnchorTagData(props);
  const { sitecoreContext } = useSitecoreContext();
  const isExperienceEditor = sitecoreContext && sitecoreContext.pageEditing;

  return (
    <div className={styles.anchor__container}>
      {isExperienceEditor && (
        // <Text tag="h1" field={formattedAnchorData && formattedAnchorData[KEY_ANCHOR_HEADING]} />
        <h2>Anchor tag (This will not be displayed in frontend)</h2>
      )}
      {formattedAnchorData &&
        formattedAnchorData.data &&
        formattedAnchorData.data.map((item: any, index: any) => {
          return (
            <a
              onClick={() => setAnchor(item.linkHref)}
              href={`#${item.linkHref}`}
              key={index + item.linkHref}
            >
              {item && item.linkText}
            </a>
          );
        })}
    </div>
  );
};

export default AnchorTag;
