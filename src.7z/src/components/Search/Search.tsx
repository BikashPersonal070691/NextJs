import { useContext } from 'react';
import { SearchBox } from 'components/SearchBox/SearchBox';
import { SearchClose } from 'components/SearchClose/SearchClose';
import { HeaderContext } from 'src/contexts/HeaderContext';
import styles from './Search.module.scss';

export function Search() {
  const { searchOpen, setSearchOpen } = useContext(HeaderContext);
  const searchBoxAction = () => {
    setSearchOpen((prevState: any) => !prevState);
  };
  return (
    <>
      <div className={styles.search__container}>
        <div className={styles.search_icon__box} onClick={searchBoxAction}>
          <span
            className={!searchOpen ? styles.search_icon__search : styles.search_icon__close}
          ></span>
        </div>
      </div>
      {searchOpen ? (
        <div className={styles.search_input__box}>
          <SearchBox closeHandler={<SearchClose closeAction={searchBoxAction} />} />
        </div>
      ) : (
        ''
      )}
    </>
  );
}
