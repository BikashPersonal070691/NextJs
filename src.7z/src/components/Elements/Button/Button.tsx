/*Button Component */
import styles from './Button.module.scss';
export function Button(props: any) {
  return (
    <>
      <button
        onClick={props.onClick ? props.onClick : null}
        className={`${props.class ? props.class : ''} ${styles.btn_default}`}
        disabled={props.disabled || false}
      >
        {props.children}
      </button>
    </>
  );
}
