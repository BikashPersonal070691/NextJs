import { useLanguageTranslate } from 'src/hooks/useLanguageTranslate';
import {
  KEY_SEARCH_LINK_ICON,
  KEY_SEARCH_TAG_ICON,
  KEY_SEARCH_SECTION_TOOLS_RESOURCES,
  KEY_SEARCH_SECTION_BAYERNET,
  KEY_SEARCH_SECTION_PEOPLE_FINDER,
  KEY_SEARCH_SECTION_SEARCH_CENTER,
} from '../constants/general';
import { isNull } from 'src/core/utils/utils.helper';
import {
  KEY_SEARCH_PEOPLE_FINDER,
  KEY_SEARCH_SEARCH_CENTER,
  KEY_SEARCH_TOOLS,
} from 'src/constants/dictonary';
/**
 * Modify clear request API response into a specific format
 * @param data
 * @param type
 * @param url
 * @param searchKeyword
 * @returns
 */
const formatAutoSuggestionList = (
  data: any,
  type: string,
  url: any,
  searchKeyword: any,
  styles: any
) => {
  const listingData: any = {
    //     message: data && data.message ? data.message : '',
    //     status: data && data.status ? data.status : false,
    data:
      type && type === KEY_SEARCH_SECTION_BAYERNET
        ? formatAutoSuggestionBayerNetList(data, type, url, searchKeyword, styles)
        : type && type === KEY_SEARCH_SECTION_TOOLS_RESOURCES
        ? formatAutoSuggestionToolsList(data, type, searchKeyword, styles)
        : '',
  };
  return listingData;
};

/**
 * replace default strings with user defined strings
 * @param url
 * @param isTag
 * @param searchItem
 * @returns url
 */
const searchUrlBuilderAutosuggestion = (url: any, isTag: boolean, searchItem: any) => {
  if (url !== '') {
    let sUrl = isTag
      ? url.replace(/\{1}/, searchItem).replace(/\{2}/, true)
      : url.replace(/\{1}/, searchItem).replace(/\{2}/, false);
    return sUrl;
  }
};

/**
 * replace default strings with user defined strings
 * @param url
 * @param isTag
 * @param searchItem
 * @returns url
 */
const searchUrlBuilder = (url: any, searchItem: any, type: any) => {
  if (url !== '' && type === KEY_SEARCH_SECTION_BAYERNET) {
    let sUrl = url.replace(/\{1}/, searchItem).replace(/\{2}/, false);
    return sUrl;
  } else if (url !== '' && type === KEY_SEARCH_SECTION_TOOLS_RESOURCES) {
    let sUrl = url.replace(/\{1}/, searchItem);
    return sUrl;
  } else if (url !== '' && type === KEY_SEARCH_SECTION_PEOPLE_FINDER) {
    let sUrl = url.replace(/\{1}/, searchItem);
    return sUrl;
  } else if (url !== '' && type === KEY_SEARCH_SECTION_SEARCH_CENTER) {
    let sUrl = url.replace(/\{1}/, searchItem);
    return sUrl;
  } else {
    return url;
  }
};

/**
 * format bayernet auto suggestion api data
 * @param data
 * @param type
 * @param url
 * @param searchKeyword
 * @returns
 */
const formatAutoSuggestionBayerNetList = (
  data: any,
  type: string,
  url: any,
  searchKeyword: any,
  styles: any
) => {
  const listingData: any =
    data &&
    Object.keys(data).length !== 0 &&
    Object.keys(data).map(
      (item: any) =>
        data[item] &&
        data[item] !== null &&
        data[item].map((sItem: any) => ({
          icon: item === 'Tags' ? KEY_SEARCH_TAG_ICON : '',
          link: searchUrlBuilderAutosuggestion(url, item === 'Tags' ? true : false, sItem),
          groupName: '',
          isBookmarked: false,
          type: type,
          displayName: getHighlightedText(sItem, searchKeyword, styles),
          paramName: sItem,
        }))
    );

  return isNull(listingData) ? [] : listingData.flat();
};

/**
 * format bayernet auto suggestion api data
 * @param data
 * @param type
 * @param searchKeyword
 * @returns
 */
const formatAutoSuggestionToolsList = (
  data: any,
  type: string,
  searchKeyword: any,
  styles: any
) => {
  const listingData: any =
    data &&
    Object.keys(data).length !== 0 &&
    data.searchResult &&
    Array.isArray(data.searchResult) &&
    data.searchResult.map((item: any) => ({
      icon: KEY_SEARCH_LINK_ICON,
      link: item && item.Link,
      groupName: item && item.ToolGroupName,
      isBookmarked: item && item.IsFavorite,
      type: type,
      displayName: getHighlightedText(item && item.ToolName, searchKeyword, styles),
      paramName: item && item.ToolName,
    }));
  return isNull(listingData) ? [] : listingData.flat();
};

/**
 * highlight search keyword in autosuggestion list
 * @param text
 * @param highlight
 * @returns html
 */

const getHighlightedText = (text: any, highlight: any, styles: any) => {
  // Split on highlight term and include term into parts, ignore case
  const parts = text.split(new RegExp(`(${highlight})`, 'gi'));
  return (
    <span className={styles.search__highlight}>
      {parts.map((part: any, i: number) => (
        <span
          key={i}
          className={
            part.toLowerCase() === highlight.toLowerCase() ? styles.search_word__highlight : ''
          }
        >
          {part}
        </span>
      ))}
    </span>
  );
};

/**
 * config for search section radiobuttons
 * @returns json
 */
const getSearchRadioConfig = () => {
  const { translatedKey } = useLanguageTranslate();
  return [
    {
      id: KEY_SEARCH_SECTION_BAYERNET,
      value: KEY_SEARCH_SECTION_BAYERNET,
      label: KEY_SEARCH_SECTION_BAYERNET,
      name: 'section',
      isDefault: true,
    },
    {
      id: KEY_SEARCH_SECTION_PEOPLE_FINDER,
      value: KEY_SEARCH_SECTION_PEOPLE_FINDER,
      label: translatedKey(KEY_SEARCH_PEOPLE_FINDER), // 'Personensuche',
      name: 'section',
      isDefault: false,
    },
    {
      id: KEY_SEARCH_SECTION_TOOLS_RESOURCES,
      value: KEY_SEARCH_SECTION_TOOLS_RESOURCES,
      label: translatedKey(KEY_SEARCH_TOOLS),
      name: 'section',
      isDefault: false,
    },
    {
      id: KEY_SEARCH_SECTION_SEARCH_CENTER,
      value: KEY_SEARCH_SECTION_SEARCH_CENTER,
      label: translatedKey(KEY_SEARCH_SEARCH_CENTER),
      name: 'section',
      isDefault: false,
    },
  ];
};

export { formatAutoSuggestionList, getHighlightedText, getSearchRadioConfig, searchUrlBuilder };
