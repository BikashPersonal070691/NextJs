import { useRef, useState, useEffect } from 'react';
import 'overlayscrollbars/styles/overlayscrollbars.css';
//import { OverlayScrollbarsComponent } from 'overlayscrollbars-react';

import styles from './Dropdown.module.scss';
import { useLanguageTranslate } from 'src/hooks/useLanguageTranslate';
import { KEY_PROFILE_SELECT, KEY_PROFILE_NOT_FOUND } from 'src/constants/dictonary';

export default function Dropdown(props: any) {
  const { translatedKey } = useLanguageTranslate();
  const [headline, setHeadline] = useState<any>('');
  const [label, setLabel] = useState<any>('');
  const [options, setOptions] = useState<any>();
  const [filteredOptions, setFilteredOptions] = useState<any>();
  const [showOptions, setShowOptions] = useState<any>(false);
  const [placeholder, setPlaceholder] = useState(translatedKey(KEY_PROFILE_SELECT));
  const refShowOptions = useRef<any>();
  const getDataLoaded = () => {
    if (props && props.userSelection && props.userSelection.options) {
      setOptions(props.userSelection.options);
      setFilteredOptions(props.userSelection.options);
    }
    if (props && props.subHeadline) {
      setHeadline(props.subHeadline);
    }
    if (
      props &&
      props.userSelection &&
      props.userSelection.value &&
      props.userSelection.value.label
    ) {
      setLabel(props.userSelection.value.label);
    }
  };
  useEffect(() => {
    getDataLoaded();
  }, []);
  useEffect(() => {
    getDataLoaded();
  }, [props]);
  const toggleOptions = () => {
    setShowOptions(!showOptions);
  };
  const handleOptionSelection = (event: any) => {
    // setValue(event.target.dataset.value);
    setLabel(event.target.dataset.label);
    if (props && props.onChange) {
      props.onChange(event.target.dataset.value, event.target.dataset.label, options);
    }
    setShowOptions(false);
  };
  useEffect(() => {
    const checkIfClickedOutside = (e: any) => {
      // If the target pop is open and the clicked target is not within the pop up,
      // then close the target pop
      if (refShowOptions.current && !refShowOptions.current.contains(e.target)) {
        setShowOptions(false);
      }
    };
    document.addEventListener('mousedown', checkIfClickedOutside);
    return () => {
      // Cleanup the event listener
      document.removeEventListener('mousedown', checkIfClickedOutside);
    };
  }, [showOptions]);
  const handleChange = (event: any) => {
    if (event.target.value) {
      const userInput = event.target.value;
      setLabel(userInput);
      if (options && Array.isArray(options) && options.length > 0) {
        const result = options.filter((option: any) => {
          const newLabel = option.label.toLowerCase();
          const newInput = event.target.value.toLowerCase();
          return newLabel.includes(newInput);
        });
        setFilteredOptions(result);
      }
    } else {
      setPlaceholder('');
      setLabel('');
      if (props && props.userSelection && props.userSelection.options) {
        setFilteredOptions(props.userSelection.options);
      }
    }
  };
  return (
    <div className={styles.custom_select_container} onClick={toggleOptions}>
      <span className={styles.select_label}>{headline}</span>
      <ul className={styles.custom_select}>
        <li className={styles.dropdown}>
          <ul className={`${styles.dropdown_menu} ${styles.inactive}`}>
            <li className={styles.item_wrapper}>
              <span
                className={`${styles.selected_item} ${
                  props && props.showError ? styles.error : undefined
                }`}
              >
                <input
                  className={styles.predictInput}
                  type="text"
                  placeholder={placeholder}
                  value={label}
                  onChange={handleChange}
                />
              </span>
              <i className={`${styles.select_arrow} ${styles.icon_small_down_arrow}`}></i>
            </li>
          </ul>
        </li>

        {showOptions && filteredOptions && filteredOptions.length > 0 && (
          <ul className={styles.menu_wrapper} ref={refShowOptions}>
            {filteredOptions.map((optionItem: any, index: number) => {
              return (
                <li
                  className={styles.menu}
                  data-value={optionItem.value}
                  data-label={optionItem.label}
                  key={index}
                  onClick={handleOptionSelection}
                >
                  {optionItem.label}
                </li>
              );
            })}
          </ul>
        )}
        {showOptions && filteredOptions && filteredOptions.length === 0 && (
          <div className={styles.menu_wrapper} ref={refShowOptions}>
            <div className={styles.not_found}>{translatedKey(KEY_PROFILE_NOT_FOUND)}</div>
          </div>
        )}
      </ul>
    </div>
  );
}
