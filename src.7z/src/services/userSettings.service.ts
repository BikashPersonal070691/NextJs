import { BAYER_TRANSLATE_API_ENDPOINT } from 'src/constants/general';
import { apiEndpoints } from 'src/core/api/apiEndpoints';
import { externalPostApi, httpRequest } from 'src/core/api/httpRequest';

const getUserData = () => {
  const url = apiEndpoints.getUserSettingsData;
  return httpRequest(url, 'get');
};

const getUserAdditionalData = () => {
  const url = apiEndpoints.getChannelTopicData;
  return httpRequest(url, 'get');
};

const getDivisionData = (id: any) => {
  const url = {
    url: `${apiEndpoints.getDivisionData.url}?DivisionId=${id}`,
    isMock: apiEndpoints.getDivisionData.isMock,
  };
  // const url = apiEndpoints.getDivisionData;
  return httpRequest(url, 'get');
};

const getCountryData = (id: any) => {
  const url = {
    url: `${apiEndpoints.getCountryData.url}?CountryId=${id}`,
    isMock: apiEndpoints.getDivisionData.isMock,
  };
  // const url = apiEndpoints.getCountryData;
  return httpRequest(url, 'get');
};

const saveProfileSettings = (payload: any) => {
  return httpRequest(apiEndpoints.saveProfileInfo, 'post', payload);
};

const saveProfileImage = (payload: any) => {
  return httpRequest(apiEndpoints.saveProfileImage, 'post', payload);
};

/*
 * API for translating page content using Bayer translate
 */
const bayerTranslateApi = (payload: any) => {
  return externalPostApi(`${BAYER_TRANSLATE_API_ENDPOINT}v2`, payload);
};

/** API to get gtm datalayer values
 *
 * @returns
 */
const getGtmDataLayer = () => {
  const url = {
    url: `${apiEndpoints.gtmResult.url}`,
    isMock: apiEndpoints.gtmResult.isMock,
  };
  return httpRequest(url, 'get');
};

export {
  getUserData,
  getDivisionData,
  getCountryData,
  getUserAdditionalData,
  saveProfileSettings,
  saveProfileImage,
  bayerTranslateApi,
  getGtmDataLayer,
};
