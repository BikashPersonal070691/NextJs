// import { useEffect } from 'react';
import {
  MODAL_TYPE_VIDEO,
  MODAL_TYPE_TEXT,
  MODAL_TYPE_LOADER,
  MODAL_TYPE_CALENDER,
} from 'src/constants/general';
import { createPortal } from 'react-dom';
import { useSelector } from 'react-redux';
import styles from './Modal.module.scss';

export function Modal(props: any) {
  const { modalCloseEvent, showModal, type, closeOnClickBackground, showHeader } = props;
  const { isPreviewMode } = useSelector((state: any) => state.expEditorProps);
  
  // useEffect(() => {
  //   if (!showModal) {
  //     document.body.style.overflow = 'visible';
  //   } else {
  //     document.body.style.overflow = 'hidden';
  //   }
  // }, [showModal]);
  return (
    showModal &&
    createPortal(
      <div
        className={`${styles.modal__container} ${
          type && type == MODAL_TYPE_VIDEO
            ? styles.modal_bg__video
            : type == MODAL_TYPE_TEXT
            ? styles.modal_bg__textBox
            : // : type == MODAL_TYPE_CALENDER
            // ? styles.modal_bg__loader
            type == MODAL_TYPE_LOADER || type == MODAL_TYPE_CALENDER
            ? styles.modal_bg__loader
            : styles.modal_bg__black
        } ${showHeader && styles.header_space}`}
      >
        <div
          className={styles.modal__wrapper}
          onClick={closeOnClickBackground ? closeOnClickBackground : undefined}
        >
          {type !== MODAL_TYPE_CALENDER && modalCloseEvent && (
            <div
              className={`${styles.modal_close__wrapper} ${
                isPreviewMode ? styles.modal_close_wrapper_experienceeditor : ''
              }`}
              onClick={(e) => {
                e.stopPropagation();
                modalCloseEvent();
              }}
            >
              <span className={styles.modal__close}></span>
            </div>
          )}
          <div
            className={styles.modal_inner__wrapper}
            onClick={(e: any) => {
              e.stopPropagation();
            }}
          >
            {props.children}
          </div>
        </div>
      </div>,
      document.body
    )
  );
}
