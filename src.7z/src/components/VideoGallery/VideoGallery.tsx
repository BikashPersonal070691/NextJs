import React, { useEffect, useRef, useState, useTransition } from 'react';
import { getParentClassReference } from 'src/core/utils/utils.helper';
import { CONTENT_100, CONTENT_25, CONTENT_33, CONTENT_34 } from 'src/constants/contentDivider';
import {
  KEY_SLIDER_TYPE,
  KEY_VIDEO_GALLERY_HEADLINE,
  KEY_BREAKPOINT_MEDIUM,
} from 'src/constants/general';
import styles from './VideoGallery.module.scss';
import { Placeholder, Text } from '@sitecore-jss/sitecore-jss-nextjs';
import SlickSlider from 'components/Elements/SlickSlider/SlickSlider';
import { formatVideoGalleryData } from 'src/helpers/component.helper';
import { getCurrentWindowWidth } from 'src/core/utils/utils.helper';
const VideoGallery = (props: any) => {
  /**
   * @important This code needs to be used in every components inorder to get the content dividers reference
   * @important Also set the reference (ref) and className to the html wrapper as implemented below
   */
  // starts
  const [parentRef, setParentRef] = useState<any>(null);
  const nodeRef = useRef(null);
  const smallDividers: any = [CONTENT_25, CONTENT_33, CONTENT_34];
  const [isSliderNeeded, setIsSliderNeeded] = useState<any>(false);
  const [isPending, startTransition] = useTransition();
  const containerRef: any = useRef(null);
  useEffect(() => {
    const child: any = nodeRef.current;
    if (child !== null || child !== undefined) {
      setParentRef(getParentClassReference(child));
    } else {
      setParentRef(CONTENT_100);
    }
  }, []);
  //ends
  const refinedData: any = formatVideoGalleryData(props);
  const isMobileDevice: any = getCurrentWindowWidth() <= KEY_BREAKPOINT_MEDIUM ? true : false;
  const getTilesToShow = () => {
    if (containerRef && containerRef.current && containerRef.current.clientWidth) {
      return Math.ceil(
        (containerRef && containerRef.current && containerRef.current.clientWidth) / 290
      );
    } else {
      return 1;
    }
  };
  const getTilesToNav = () => {
    if (containerRef && containerRef.current && containerRef.current.clientWidth) {
      const res: any = Math.floor(
        (containerRef && containerRef.current && containerRef.current.clientWidth) / 290
      );
      return res == 0 ? 1 : res;
    } else {
      return 1;
    }
  };
  useEffect(() => {
    if (parentRef && parentRef !== '') {
      const isSmallDivider = smallDividers.includes(parentRef) ? true : false;
      startTransition(() => {
        if (isMobileDevice && refinedData.numberOfItems > getTilesToNav()) {
          setIsSliderNeeded(true);
        } else if (isSmallDivider && refinedData.numberOfItems > getTilesToNav()) {
          setIsSliderNeeded(true);
        } else if (refinedData.numberOfItems > getTilesToNav()) {
          setIsSliderNeeded(true);
        } else {
          setIsSliderNeeded(false);
        }
      });
    }
  }, [parentRef]);
  return (
    <div className={styles[parentRef]} ref={nodeRef}>
      <div ref={containerRef}>
        {!isPending && isSliderNeeded ? (
          <div className={`${styles.video_gallery__container}`}>
            <SlickSlider
              data={props}
              headingData={refinedData && refinedData[KEY_VIDEO_GALLERY_HEADLINE]}
              numberOfTiles={refinedData && refinedData.numberOfItems}
              type={KEY_SLIDER_TYPE.VIDEOGALLERY}
              tilesToShow={getTilesToShow()}
              placeHolderName="video-gallery"
              parentRef={parentRef}
              showTopNav={true}
              isVariableWidth={true}
              isAdaptiveHeight={false}
              isDummySlideNeeded={true}
            />
          </div>
        ) : !isPending && !isSliderNeeded ? (
          <div className={styles.video_gallery__container__horizontal}>
            <div className={styles.headline__container}>
              <Text
                field={refinedData && refinedData[KEY_VIDEO_GALLERY_HEADLINE]}
                editable={true}
                tag="div"
                className={styles.headline}
              />
            </div>
            <div className={styles.items__container}>
              <Placeholder name="video-gallery" rendering={props.rendering} />
            </div>
          </div>
        ) : (
          ''
        )}
      </div>
    </div>
  );
};

export default VideoGallery;
