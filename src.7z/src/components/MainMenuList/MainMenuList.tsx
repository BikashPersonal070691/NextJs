import React, { useContext, useEffect, useState } from 'react';
import { MenuContext } from 'src/contexts/MenuContext';
import { HeaderContext } from 'src/contexts/HeaderContext';
import styles from './MainMenuList.module.scss';
import {
  COLOR_NON_SELECT_MAIN_MENU,
  COLOR_SELECTED_MAIN_MENU,
  MY_HR_MENU_TEMPLETE_ID,
  URL_MY_HR,
} from 'src/constants/general';
import { useRouter } from 'next/router';

export function MainMenuList() {
  const {
    menuData,
    activeMenu,
    setActiveMenu,
    setFirstLevelItems,
    selectedItems,
    setSecondLevelItems,
    setThirdLevelItems,
    setFourthLevelItems,
    setFifthLevelItems,
    setSixthLevelItems,
  } = useContext(MenuContext);

  const { stickyClass } = useContext(HeaderContext);
  const { asPath, pathname } = useRouter();

  const [mainMenuListData, setMainMenuListData] = useState({});
  useEffect(() => {
    if (menuData) {
      const { MainNavigation } = menuData;
      setMainMenuListData(MainNavigation);
    }
  }, [menuData]);

  const handleActiveMenu = (item: any) => {
    setActiveMenu(item);
    setSecondLevelItems({});
    setThirdLevelItems({});
    setFourthLevelItems({});
    setFifthLevelItems({});
    setSixthLevelItems({});
  };

  return (
    <nav
      className={`${styles.nav_bar} ${styles.mega_menu_three} ${
        stickyClass && stickyClass !== '' ? styles.menu__sticky : ''
      }`}
    >
      <ul>
        {mainMenuListData && Array.isArray(mainMenuListData)
          ? mainMenuListData.map((menuItem, index) => (
              <li
                className={
                  activeMenu &&
                  activeMenu.NavigationTitle === menuItem.NavigationTitle &&
                  selectedItems &&
                  Object.keys(selectedItems).length !== 0
                    ? `${styles.main_menu_item} ${styles.valign_wrapper}  ${styles.menu_active} ${
                        index === 0 ? styles.no_padding_left : ''
                      }`
                    : `${styles.main_menu_item} ${styles.valign_wrapper} ${
                        index === 0 ? styles.no_padding_left : ''
                      }`
                }
                key={index}
              >
                {menuItem.TemplateID === MY_HR_MENU_TEMPLETE_ID ||
                menuItem.HasChildren === false ? (
                  <a
                    className={`${styles.nav_link} ${
                      (menuItem.NavigationTitle &&
                        menuItem.NavigationTitle.toLowerCase() === 'MyHR'.toLowerCase()) ||
                      (menuItem.NavigationTitle &&
                        menuItem.NavigationTitle.toLowerCase() === 'MyIT'.toLowerCase())
                        ? styles.text_case
                        : ''
                    }`}
                    href={menuItem.ExternalURL != '' ? menuItem.ExternalURL : menuItem.URL}
                    style={
                      ((asPath && asPath.toLowerCase().includes(URL_MY_HR.toLowerCase())) ||
                        (pathname && pathname.toLowerCase().includes(URL_MY_HR.toLowerCase()))) &&
                      menuItem.TemplateID === MY_HR_MENU_TEMPLETE_ID
                        ? { color: COLOR_SELECTED_MAIN_MENU }
                        : { color: COLOR_NON_SELECT_MAIN_MENU }
                    }
                  >
                    <span className={`${styles.left} ${styles.menu_text}`}>
                      {menuItem.NavigationTitle}
                    </span>
                  </a>
                ) : (
                  ''
                )}

                {menuItem.HasChildren === true && menuItem.TemplateID !== MY_HR_MENU_TEMPLETE_ID ? (
                  <a
                    className={`${styles.nav_link} ${
                      (menuItem.NavigationTitle &&
                        menuItem.NavigationTitle.toLowerCase() == 'MyHR'.toLowerCase()) ||
                      (menuItem.NavigationTitle &&
                        menuItem.NavigationTitle.toLowerCase() == 'MyIT'.toLowerCase())
                        ? styles.text_case
                        : ''
                    }`}
                    onClick={() => {
                      setFirstLevelItems(menuItem);
                      handleActiveMenu(menuItem);
                    }}
                  >
                    <span className={`${styles.left} ${styles.menu_text}`}>
                      {menuItem.NavigationTitle}
                    </span>
                  </a>
                ) : (
                  ''
                )}
              </li>
            ))
          : null}
      </ul>
    </nav>
  );
}
