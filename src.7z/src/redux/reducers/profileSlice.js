import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { getProfileInfo } from 'src/services/menu.service';

export const fetchProfileData = createAsyncThunk('profileData', async () => {
  try {
    return getProfileInfo().then((data) => {
      if (data && data.data) {
        return data.data;
      } else {
        return null;
      }
    });
  } catch (error) {
    console.error('fetchProfileData - Slice ~ error:', error);
  }
});
const profileSlice = createSlice({
  name: 'profile',
  initialState: {
    userProfileData: null,
  },
  // reducers: {
  //   SET_DATA: (state, action) => {
  //     state.name = action.payload;
  //   }
  // },
  extraReducers: (builder) => {
    builder.addCase(fetchProfileData.pending, (state, action) => {
      state.isLoading = true;
    });
    builder.addCase(fetchProfileData.fulfilled, (state, action) => {
      state.isLoading = false;
      state.userProfileData = action.payload;
    });
    builder.addCase(fetchProfileData.rejected, (state, action) => {
      state.isError = true;
    });
  },
});

// export const { SET_DATA } = profileSlice.actions;
export default profileSlice.reducer;
