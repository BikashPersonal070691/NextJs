import React from 'react';
import { useState, useEffect, useRef } from 'react';
import { Text, useSitecoreContext } from '@sitecore-jss/sitecore-jss-nextjs';
import styles from './MonthlyViewTaskDetails.module.scss';
import {
  createIcsFile,
  formatDateICS,
  getFromStorage,
  getHashString,
  getPageContentForTranslation,
  setTranslatedText,
} from 'src/core/utils/utils.helper';
import {
  BAYER_TRANSLATE_KEY,
  IFRAME_BUTTON_TYPE,
  KEY_KEYTASK_CTA_LINK,
  // KEY_KEYTASK_CTA_LINK,
  KEY_KEYTASK_LINK_TEXT1,
  KEY_KEYTASK_LINK_TEXT2,
  KEY_KEYTASK_LINK_TEXT3,
  KEY_KEYTASK_LINK_TEXT4,
  KEY_KEYTASK_LINK_URL1,
  KEY_KEYTASK_LINK_URL2,
  KEY_KEYTASK_LINK_URL3,
  KEY_KEYTASK_LINK_URL4,
  KEY_KEYTASK_TIME_SPAN,
  KEY_POPUP_TRANSLATION_ID,
  KEY_SELECTED_LANGUAGE,
} from 'src/constants/general';
import { bayerTranslateApi } from 'src/services/userSettings.service';
import { getParentAttributeReference } from 'src/core/utils/utils.helper';
import { Loader } from 'components/Elements/Loader/Loader';
import { IframeButton } from '../IframeButton/IframeButton';

const MonthlyViewTaskDetails = (props: any) => {
  const { taskDetails } = props;
  const { fields } = taskDetails;
  const htmlContent = {
    value:
      fields && fields.Details && fields.Details.value && fields.Details.value.replaceAll('\n', ''),
  };
  const nodeRef = useRef(null);
  const [parentRef, setParentRef] = useState<any>(null);
  const [border, setBorder] = useState({});
  const [maxHeight, setMaxHeight] = useState({});
  const [maxContentHeight, setMaxContentHeight] = useState({});
  const { sitecoreContext } = useSitecoreContext();
  const isExperienceEditor = sitecoreContext && sitecoreContext.pageEditing;
  const [pageTextArr, setPageTextArr] = useState('');
  const [isShow, setIsShow] = useState(false);
  const [showLoader, setShowLoader] = useState(false);

  useEffect(() => {
    const child: any = nodeRef.current;
    if (child !== null || child !== undefined) {
      setParentRef(getParentAttributeReference(child, 'data-modal'));
    } else {
      setParentRef('');
    }
  }, []);

  useEffect(() => {
    const language: any = getFromStorage(KEY_SELECTED_LANGUAGE);
    const hashString: any = getHashString();
    if (
      language !== null &&
      language != '' &&
      language != 'en' &&
      hashString &&
      hashString.popupId
    ) {
      setShowLoader(true);
      let textArr: any = getPageContentForTranslation(KEY_POPUP_TRANSLATION_ID);
      setPageTextArr(textArr);

      const payload = {
        key: BAYER_TRANSLATE_KEY,
        target: language,
        q: pageTextArr ? pageTextArr : textArr,
      };

      bayerTranslateApi(payload).then((data: any) => {
        if (data && data.data) {
          const translatedText =
            data.data.translations &&
            data.data.translations[0] &&
            data.data.translations[0].translatedText &&
            data.data.translations[0].translatedText.split('<BR>');
          setTranslatedText(translatedText, KEY_POPUP_TRANSLATION_ID);
          setIsShow(true);
          setShowLoader(false);
        }
      });
    } else {
      setIsShow(true);
      // setShowLoader(false);
    }
  }, []);

  const save = () => {
    const event: any = {
      start: formatDateICS(fields.SaveInStartDate && fields.SaveInStartDate.value),
      end: formatDateICS(fields.SaveInEndDate && fields.SaveInEndDate.value),
      title: `Employee Calendar Time for ${fields && fields.Name && fields.Name.value} meeting`,
      htmlContent:
        fields && fields.SaveInEmailText && fields.SaveInEmailText.value.replace(/\n/g, ''),
    };
    const name = `Employee Calendar Time for ${
      fields && fields.Name && fields.Name.value
    } meeting.ics`;
    createIcsFile(event, name);
  };

  const schedule = () => {
    const event: any = {
      start: formatDateICS(fields.SendInviteStartDate && fields.SendInviteStartDate.value),
      end: formatDateICS(fields.SendInviteEndDate && fields.SendInviteEndDate.value),
      title: `Invite - Employee Time for ${fields && fields.Name && fields.Name.value} meeting`,
      htmlContent:
        fields && fields.SendInviteEmailText && fields.SendInviteEmailText.value.replace(/\n/g, ''),
    };
    const name = `Invite - Employee Time for ${
      fields && fields.Name && fields.Name.value
    } meeting.ics`;
    createIcsFile(event, name);
  };

  useEffect(() => {
    const hashObj = getHashString();
    if (hashObj && hashObj.month != 'all') {
      setBorder({ border: '1px solid #c5d1d6' });
      setMaxHeight({});
      setMaxContentHeight({ maxHeight: '100%' });
    }

    if (hashObj && hashObj.month == 'all') {
      setBorder({ marginBottom: '0px' });
      setMaxHeight({ maxHeight: 'unset', 'overflow-y': 'auto', marginBottom: '10px' });
      setMaxContentHeight({ maxHeight: '280px' });
    }
  }, [props]);

  const getLink = (title: any, link: any) => {
    return (
      <div className={styles.external_links}>
        <a
          target="_blank"
          title={title}
          href={link ? (link.includes('http') ? link : `http://${link}`) : '#'}
        >
          {title}
        </a>
      </div>
    );
  };

  return (
    <div
      className={`${styles.card_container} ${
        parentRef ? styles.card_max__height : ''
      } ${KEY_POPUP_TRANSLATION_ID}`}
      style={border}
      // id={KEY_POPUP_TRANSLATION_ID}
      ref={nodeRef}
    >
      <div style={{ display: isShow ? 'block' : 'none' }}>
        <h1 className={styles.sub_headline}>{fields.Name && fields.Name.value}</h1>
        <div className={styles.modal_body} style={maxHeight}>
          <div className={styles.goal_month}>
            <span>
              {fields && fields[KEY_KEYTASK_TIME_SPAN] && fields[KEY_KEYTASK_TIME_SPAN].value}
            </span>
          </div>

          <div
            className={`${styles.scheduler_wrapper} ${
              !(fields && fields.SaveInCalenderText && fields.SaveInCalenderText.value) &&
              !(fields && fields.SendInviteText && fields.SendInviteText.value)
                ? styles.scheduler_wrapper_empty
                : ''
            } `}
          >
            {fields && fields.SaveInCalenderText && fields.SaveInCalenderText.value ? (
              <div className={styles.calendar} onClick={save}>
                <div className={styles.calendar_icon}></div>
                <a>{fields && fields.SaveInCalenderText && fields.SaveInCalenderText.value}</a>
              </div>
            ) : (
              ''
            )}
            {fields && fields.SendInviteText && fields.SendInviteText.value ? (
              <div className={`${styles.calendar} ${styles.schedule_link}`} onClick={schedule}>
                <a>{fields && fields.SendInviteText && fields.SendInviteText.value}</a>
                <div className={styles.arrow_right}></div>
              </div>
            ) : (
              ''
            )}
          </div>

          {!isExperienceEditor && (
            <div
              className={styles.checkin_rules}
              dangerouslySetInnerHTML={{
                __html: fields && fields.Details && fields.Details.value,
              }}
            ></div>
          )}

          {isExperienceEditor && (
            <Text
              tag="div"
              field={htmlContent}
              editable={true}
              className={styles.checkin_rules}
              // encode={false}
              style={maxContentHeight}
            ></Text>
          )}

          <div className={styles.link_section}>
            {fields &&
            fields[KEY_KEYTASK_LINK_TEXT1] &&
            fields[KEY_KEYTASK_LINK_TEXT1].value &&
            fields[KEY_KEYTASK_LINK_URL1] &&
            fields[KEY_KEYTASK_LINK_URL1].value
              ? getLink(fields[KEY_KEYTASK_LINK_TEXT1].value, fields[KEY_KEYTASK_LINK_URL1].value)
              : ''}

            {fields &&
            fields[KEY_KEYTASK_LINK_TEXT2] &&
            fields[KEY_KEYTASK_LINK_TEXT2].value &&
            fields[KEY_KEYTASK_LINK_URL2] &&
            fields[KEY_KEYTASK_LINK_URL2].value
              ? getLink(fields[KEY_KEYTASK_LINK_TEXT2].value, fields[KEY_KEYTASK_LINK_URL2].value)
              : ''}

            {fields &&
            fields[KEY_KEYTASK_LINK_TEXT3] &&
            fields[KEY_KEYTASK_LINK_TEXT3].value &&
            fields[KEY_KEYTASK_LINK_URL3] &&
            fields[KEY_KEYTASK_LINK_URL3].value
              ? getLink(fields[KEY_KEYTASK_LINK_TEXT3].value, fields[KEY_KEYTASK_LINK_URL3].value)
              : ''}

            {fields &&
            fields[KEY_KEYTASK_LINK_TEXT4] &&
            fields[KEY_KEYTASK_LINK_TEXT4].value &&
            fields[KEY_KEYTASK_LINK_URL4] &&
            fields[KEY_KEYTASK_LINK_URL4].value
              ? getLink(fields[KEY_KEYTASK_LINK_TEXT4].value, fields[KEY_KEYTASK_LINK_URL4].value)
              : ''}
          </div>

          {fields[KEY_KEYTASK_CTA_LINK] &&
          fields[KEY_KEYTASK_CTA_LINK].value &&
          fields[KEY_KEYTASK_CTA_LINK].value.text &&
          fields[KEY_KEYTASK_CTA_LINK].text != '' ? (
            <div>
              <div className={styles.contribution_button}>
                <a
                  href={
                    fields[KEY_KEYTASK_CTA_LINK].value.href
                      ? fields[KEY_KEYTASK_CTA_LINK].value.href
                      : '#'
                  }
                  target="_blank"
                >
                  {fields[KEY_KEYTASK_CTA_LINK].value.text &&
                    fields[KEY_KEYTASK_CTA_LINK].value.text}
                </a>
              </div>
            </div>
          ) : (
            ''
          )}

          {/* {fields[KEY_IFRAME] &&
          fields[KEY_IFRAME].fields &&
          fields[KEY_IFRAME].fields.IframeSource &&
          fields[KEY_IFRAME].fields.IframeSource.value &&
          fields[KEY_IFRAME_BUTTON_TEXT] &&
          fields[KEY_IFRAME_BUTTON_TEXT].value ? (
            <div>
              <div className={`${styles.float_left}`}>
                <IframeButton data={fields} type={IFRAME_BUTTON_TYPE.HR_TASK} />
              </div>
            </div>
          ) : (
            ''
          )} */}

<div>
              <div className={`${styles.float_right}`}>
                <IframeButton data={fields} type={IFRAME_BUTTON_TYPE.HR_TASK} />
              </div>
            </div>
        </div>
      </div>
      {showLoader ? <Loader /> : ''}
    </div>
  );
};

export default MonthlyViewTaskDetails;
