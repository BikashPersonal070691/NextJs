import MonthlyViewTaskDetails from 'components/Elements/MonthlyViewTaskDetails/MonthlyViewTaskDetails';
import { Modal } from 'components/Elements/Modal/Modal';
import { MODAL_TYPE_CALENDER } from 'src/constants/general';
import styles from './LightBoxOverlay.module.scss';
import { setHashString } from 'src/core/utils/utils.helper';

const LightBoxOverLay = (props: any) => {
  const { isOpen, closeOverlay, taskDetails } = props;

  if (isOpen) {
    document.body.style.overflow = 'hidden';
  }
  const handleCloseIconClick = () => {
    closeOverlay(false);
    document.body.style.overflow = 'scroll';
    setHashString('');
  };

  return (
    <Modal showModal={isOpen} modalCloseEvent={handleCloseIconClick} type={MODAL_TYPE_CALENDER}>
      <div className={styles.lightbox_overlay}>
        <div className={styles.popup_contents} data-modal={true}>
          <div className={styles.icon_popup_close} onClick={handleCloseIconClick}></div>
          <MonthlyViewTaskDetails taskDetails={taskDetails} />
        </div>
      </div>
    </Modal>
  );
};

export default LightBoxOverLay;
