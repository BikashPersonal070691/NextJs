import axios from 'axios';
// import { getSession } from 'next-auth/react';
// import { KEY_CM_APP_URL_CI } from 'src/constants/general';
import 'src/core/api/httpInterceptors';
import { getFromStorage } from '../utils/utils.helper';
import { GRAPH_API_ACCESS_TOKEN_KEY } from 'src/constants/general';

/**
 * Common method through which all API requests are passed
 * @param endPoint
 * @param method
 * @param data
 * @returns
 */
export function httpRequest(endPoint: any, method: string, data?: any) {
  const isMock = endPoint && endPoint.isMock ? endPoint.isMock : false;
  const requestMethod = isMock ? 'get' : method;
  // const cm_url: any = process.env.CM_APP_URL;
  // const currentUrl = window.location.href;

  // choose between mock or api url
  const baseUrl = isMock
    ? process.env.MOCK_API_URL
    : // : currentUrl.includes(cm_url)
      // ? `${cm_url}/api/`
      process.env.SITECORE_API_URL;

  const requestUrl = endPoint && endPoint.url ? baseUrl + endPoint.url : baseUrl;
  switch (requestMethod) {
    case 'get':
      return get(requestUrl);
    case 'post':
      return post(requestUrl, data);
    case 'put':
      return put(requestUrl, data);
    case 'postUrlencoded':
      return postUrlencoded(requestUrl, data);
    default:
      return get(requestUrl);
  }
  // return false;
}
let cancelToken: any;
/**
 * Common method through which all API requests are passed with CancelRequest Option
 * @param endPoint
 * @param method
 * @param cancelToken
 * @param data
 * @returns
 */
export function httpRequestWithCancel(endPoint: any, method: string, data?: any) {
  const isMock = endPoint && endPoint.isMock ? endPoint.isMock : false;
  const requestMethod = isMock ? 'get' : method;
  // const cm_url: any = process.env.CM_APP_URL;
  // const currentUrl = window.location.href;

  if (typeof cancelToken != typeof undefined) {
    cancelToken.cancel('Operation canceled due to new request.');
  }
  cancelToken = axios.CancelToken.source();
  // const baseUrl = isMock ? process.env.MOCK_API_URL : process.env.SITECORE_API_URL;
  const baseUrl = isMock
    ? process.env.MOCK_API_URL
    : // : currentUrl.includes(cm_url)
      // ? `${cm_url}/api/`
      process.env.SITECORE_API_URL;

  const requestUrl = endPoint && endPoint.url ? baseUrl + endPoint.url : baseUrl;
  switch (requestMethod) {
    case 'get':
      return get(requestUrl, cancelToken);
    case 'post':
      return post(requestUrl, data);
    case 'put':
      return put(requestUrl, data);
    case 'postUrlencoded':
      return postUrlencoded(requestUrl, data);
    default:
      return get(requestUrl);
  }
  // return false;
}

function get(url: string, cancelToken?: any) {
  if (cancelToken) {
    return axios.get(url, { cancelToken: cancelToken.token });
  } else {
    return axios.get(url);
  }
}

function post(url: string, data: any) {
  return axios.post(url, data);
}

function postUrlencoded(url: string, data: any) {
  const dataObj = Object.keys(data)
    .map((key) => `${key}=${encodeURIComponent(data[key])}`)
    .join('&');
  return axios.post(url, dataObj);
}

function put(url: string, data: any) {
  return axios.post(url, data);
}

export function getGraphApiData(url: string) {
  const access_token = getFromStorage(GRAPH_API_ACCESS_TOKEN_KEY);
  return new Promise(async function (resolve, reject) {
    const headers = new Headers();
    const bearer = `Bearer ${access_token}`;
    headers.append('Authorization', bearer);

    const options = {
      method: 'GET',
      headers: headers,
    };

    fetch(url, options)
      .then((response) => response.json())
      .then((data) => {
        if (data) {
          resolve(data);
        } else {
          reject();
        }
      });
  });
}

/**
 * For calling third party apis e.g Bayer translate
 * @param url
 * @param payload
 * @returns
 */
export function externalPostApi(url: string, payload: any) {
  return new Promise(async function (resolve, reject) {
    const options = {
      method: 'POST',
      body: JSON.stringify(payload),
    };
    fetch(url, options)
      .then((response) => response.json())
      .then((data) => {
        if (data) {
          resolve(data);
        } else {
          reject();
        }
      });
  });
}

export function getExternalData(url: string, token: any) {
  return new Promise(async function (resolve, reject) {
    const headers = new Headers();
    const bearer = `Bearer ${token}`;
    headers.append('Authorization', bearer);
    headers.append('X-Correlation-ID', '4631b46d-fd8f-4fe2-8c33-694ed410fb4c');

    const options = {
      method: 'GET',
      headers: headers,
    };

    fetch(url, options)
      .then((response) => response.json())
      .then((data) => {
        if (data) {
          resolve(data);
        } else {
          reject();
        }
      });
  });
}
