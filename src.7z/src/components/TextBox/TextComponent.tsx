import { useRef, useEffect, useState } from 'react';
import styles from './TextBox.module.scss';
import { formatTextBoxData } from 'src/helpers/component.helper';
// import { OptimizedImage } from 'src/components/Elements/OptimizedImage/OptimizedImage';
import { Text, Image, Field, useSitecoreContext } from '@sitecore-jss/sitecore-jss-nextjs';
import { getParentClassReference, getParentAttributeReference } from 'src/core/utils/utils.helper';
import { Modal } from 'components/Elements/Modal/Modal';
import TextBoxModal from './TextBoxModal';
import { MODAL_TYPE_TEXT } from 'src/constants/general';
import { CONTENT_100 } from 'src/constants/contentDivider';
import { ComponentProps } from 'lib/component-props';
import { StyleguideSpecimenFields } from 'lib/component-props/styleguide';
import {
  KEY_TEXBOX_IMGCAPTION_ENLARGED,
  KEY_TEXBOX_HEADLINE,
  KEY_TEXBOX_IMGCAPTION,
  KEY_TEXBOX_SUBHEADLINE,
  KEY_TEXBOX_TEXT,
  KEY_TEXBOX_ABSTRACT_TEXT,
  KEY_TEXBOX_ENLARGED_IMAGE,
  KEY_TEXBOX_IMAGE,
  KEY_TEXBOX_ENLARGE_IMAGE_ONLOAD,
  KEY_TEXTBOX_ANCHOR,
} from 'src/constants/general';
// for dummy data
//import tData from './GroupTeaserDummyData'

type TextComponentProps = ComponentProps &
  StyleguideSpecimenFields & {
    fields: {
      [KEY_TEXBOX_HEADLINE]: Field<string>;
      [KEY_TEXBOX_ABSTRACT_TEXT]: Field<string>;
      [KEY_TEXBOX_IMGCAPTION]: Field<string>;
      [KEY_TEXBOX_IMGCAPTION_ENLARGED]: Field<string>;
      [KEY_TEXBOX_SUBHEADLINE]: Field<string>;
      [KEY_TEXBOX_TEXT]: Field<string>;
      [KEY_TEXBOX_ENLARGED_IMAGE]: Field<string>;
      [KEY_TEXBOX_IMAGE]: Field<string>;
    };
  };

export default function TextComponent(props: TextComponentProps) {
  const { fields } = props;
  const textBoxData = formatTextBoxData(fields);
  const [modal, showModal] = useState<boolean>(false);
  const { sitecoreContext } = useSitecoreContext();
  const isExperienceEditor = sitecoreContext && sitecoreContext.pageEditing;

  const modalData = {
    enlargedImgCaption: textBoxData[KEY_TEXBOX_IMGCAPTION_ENLARGED],
    enlargeImgOnLoad: textBoxData[KEY_TEXBOX_ENLARGE_IMAGE_ONLOAD],
    enlargedImg: textBoxData[KEY_TEXBOX_ENLARGED_IMAGE],
    modalOpen: false,
  };

  const htmlContent = {
    value:
      textBoxData &&
      textBoxData[KEY_TEXBOX_TEXT] &&
      textBoxData[KEY_TEXBOX_TEXT].value &&
      textBoxData[KEY_TEXBOX_TEXT].value.value &&
      textBoxData[KEY_TEXBOX_TEXT].value.value.replaceAll('\n', ''),
  };
  /**
   * @important This code needs to be used in every components inorder to get the content dividers reference
   * @important Also set the reference (ref) and className to the html wrapper as implemented below
   */
  // starts
  const nodeRef = useRef<any>(null);
  const [parentRef, setParentRef] = useState<any>(null);
  const [parentAttr, setParentAttr] = useState<any>(null);
  // setParentAttr(getParentAttributeReference(child, 'data-id'));

  useEffect(() => {
    const child: any = nodeRef.current;
    if (child !== null || child !== undefined) {
      setParentRef(getParentClassReference(child));
      setParentAttr(getParentAttributeReference(child, 'data-id'));
    } else {
      setParentRef(CONTENT_100);
    }
    // document &&
    // (document.querySelector('.modal_check') ||
    //   document.documentElement.classList.contains('textmodal_open'))
    //   ? ''
    //   : handleModalOnPageLoad();
  }, []);

  //ends
  //Removed Modal open on page load functionality
  // useEffect(() => {
  //   document &&
  //   (document.querySelector('.modal_check') ||
  //     document.documentElement.classList.contains('textmodal_open'))
  //     ? ''
  //     : handleModalOnPageLoad();
  // }, []);

  // const handleModalOnPageLoad = () => {
  //   let textBoxComponents = document.querySelectorAll('.textbox-check');
  //   let textcomponentDomArray = Array.from(textBoxComponents);
  //   // let modalOpened = false;
  //   if (textcomponentDomArray.length > 0) {
  //     textcomponentDomArray.map((textcomponentDom: any, index: any) => {
  //       if (
  //         textBoxData[KEY_TEXBOX_ENLARGE_IMAGE_ONLOAD] &&
  //         textBoxData[KEY_TEXBOX_ENLARGED_IMAGE].value.value.src &&
  //         textBoxData[KEY_TEXBOX_ENLARGED_IMAGE].value.value.src.length > 0 &&
  //         textcomponentDom.querySelector('.image_check') &&
  //         textcomponentDom.querySelector('.image_check').offsetWidth > 0 &&
  //         document.querySelectorAll('.textbox-check')[index] == nodeRef.current.childNodes[0] &&
  //         nodeRef &&
  //         nodeRef.current &&
  //         nodeRef.current.childNodes.length > 0 &&
  //         !modalOpened
  //       ) {
  //         handleModalOpen();
  //         // modalOpened = true;
  //         setModalOpened(true);
  //         document.documentElement.classList.add('textmodal_open');
  //       }
  //     });
  //   }
  // };

  const handleModalOpen = () => {
    showModal(true);
  };

  /**
   * @description Modal CloseEvent handler
   */

  const handleModalCloseEvent = () => {
    showModal(false);
    document.documentElement.classList.remove('textmodal_open');
  };

  return (
    <div
      ref={nodeRef}
      className={`${styles[parentRef]}`}
      id={textBoxData && textBoxData[KEY_TEXTBOX_ANCHOR]}
    >
      <div className={`${'textbox-check'} ${styles.textbox_component}`}>
        <div className={`${styles.textbox_wrapper} ${parentAttr && styles[parentAttr]}`}>
          <Text
            field={
              textBoxData &&
              textBoxData[KEY_TEXBOX_HEADLINE] &&
              textBoxData[KEY_TEXBOX_HEADLINE].value
            }
            editable={true}
            tag="div"
            className={styles.textbox_headline}
          />
          <Text
            field={
              textBoxData &&
              textBoxData[KEY_TEXBOX_SUBHEADLINE] &&
              textBoxData[KEY_TEXBOX_SUBHEADLINE].value
            }
            editable={true}
            tag="div"
            className={styles.textbox_subheadline}
          />
          <div className={styles.textbox_textcontent}>
            <div
              className={
                textBoxData &&
                textBoxData[KEY_TEXBOX_IMAGE] &&
                textBoxData[KEY_TEXBOX_IMAGE].value &&
                textBoxData[KEY_TEXBOX_IMAGE].value.src &&
                textBoxData[KEY_TEXBOX_IMAGE].value.src.length > 0
                  ? ' '
                  : styles.text_image_hide
              }
            >
              <div
                className={
                  textBoxData && textBoxData.floatRight && textBoxData.floatRight
                    ? styles.textbox_image_wrapper_right
                    : styles.textbox_image_wrapper_left
                }
              >
                <div
                  className={`${styles.image_container} ${
                    isExperienceEditor && isExperienceEditor
                      ? styles.image_container_exp_editor
                      : ''
                  }`}
                >
                  <div className={styles.textbox_image_check + ' image_check'}>
                    <Image
                      field={textBoxData && textBoxData[KEY_TEXBOX_IMAGE]}
                      editable={true}
                      className={styles.textbox_image}
                    />
                  </div>

                  <div
                    className={
                      textBoxData &&
                      textBoxData[KEY_TEXBOX_ENLARGED_IMAGE] &&
                      textBoxData[KEY_TEXBOX_ENLARGED_IMAGE].value &&
                      textBoxData[KEY_TEXBOX_ENLARGED_IMAGE].value.value &&
                      textBoxData[KEY_TEXBOX_ENLARGED_IMAGE].value.value.src &&
                      textBoxData[KEY_TEXBOX_ENLARGED_IMAGE].value.value.src.length > 0
                        ? styles.icon_expand
                        : styles.icon_expand_hide
                    }
                    onClick={handleModalOpen}
                  ></div>
                </div>

                <Text
                  field={
                    textBoxData &&
                    textBoxData[KEY_TEXBOX_IMGCAPTION] &&
                    textBoxData[KEY_TEXBOX_IMGCAPTION].value
                  }
                  editable={true}
                  tag="div"
                  className={styles.textbox_image_text}
                />
              </div>
            </div>

            <div className={styles.textbox_text_wrapper}>
              {isExperienceEditor ? (
                <Text
                  field={
                    textBoxData &&
                    textBoxData[KEY_TEXBOX_ABSTRACT_TEXT] &&
                    textBoxData[KEY_TEXBOX_ABSTRACT_TEXT].value
                  }
                  editable={true}
                  tag="div"
                  className={styles.textbox_abstractText}
                />
              ) : (
                textBoxData &&
                textBoxData[KEY_TEXBOX_ABSTRACT_TEXT] &&
                textBoxData[KEY_TEXBOX_ABSTRACT_TEXT].value &&
                textBoxData[KEY_TEXBOX_ABSTRACT_TEXT].value.value && (
                  <div
                    className={styles.textbox_abstractText}
                    dangerouslySetInnerHTML={{
                      __html:
                        textBoxData &&
                        textBoxData[KEY_TEXBOX_ABSTRACT_TEXT] &&
                        textBoxData[KEY_TEXBOX_ABSTRACT_TEXT].value &&
                        textBoxData[KEY_TEXBOX_ABSTRACT_TEXT].value.value,
                    }}
                  />
                )
              )}

              {isExperienceEditor ? (
                <Text
                  field={textBoxData && textBoxData[KEY_TEXBOX_TEXT].value}
                  editable={true}
                  tag="div"
                  className={styles.textbox_text}
                />
              ) : (
                // <Text
                //   field={htmlContent}
                //   editable={true}
                //   tag="div"
                //   className={styles.textbox_text}
                // />

                <div
                  className={styles.textbox_text}
                  dangerouslySetInnerHTML={{
                    __html: htmlContent && htmlContent.value,
                  }}
                />
              )}

              {/* <div
                className={`${styles.textbox_text} `}
                dangerouslySetInnerHTML={{
                  __html:
                    textBoxData &&
                    textBoxData[KEY_TEXBOX_TEXT] &&
                    textBoxData[KEY_TEXBOX_TEXT].value
                }}
              /> */}
            </div>
          </div>
          <div className={styles.textbox_desciption}></div>
          <Modal showModal={modal} type={MODAL_TYPE_TEXT}>
            <TextBoxModal data={modalData} handleModalClose={handleModalCloseEvent} />
          </Modal>
        </div>
        
      </div>
    </div>
  );
}
