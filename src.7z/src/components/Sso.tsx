// import { signIn, signOut, useSession } from 'next-auth/react';

export default function Sso() {
  // const { data: session } = useSession();

  return (
    <div>
      {/* {!session && (
        <>
          <a
            onClick={(e) => {
              e.preventDefault();
              signIn();
            }}
          >
            Sign in
          </a>
        </>
      )}

      {session && (
        <>
          <span>
            <small>
              Signed in as : <strong>{session.user && session.user.name}</strong>
            </small>
            <br />

            <strong>{session.user && session.user.email}</strong>
          </span>
          <br></br>
          <a
            onClick={(e) => {
              e.preventDefault();
              signOut();
            }}
          >
            Sign out
          </a>
        </>
      )} */}
    </div>
  );
}
