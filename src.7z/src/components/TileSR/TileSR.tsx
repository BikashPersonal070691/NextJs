import { Image, Text, useSitecoreContext } from '@sitecore-jss/sitecore-jss-nextjs';
import { useState } from 'react';
import styles from './TileSR.module.scss';
import { getTiles } from 'src/helpers/SRTiles.helper';
import { Field } from '@sitecore-jss/sitecore-jss-nextjs';
import { ComponentProps } from 'lib/component-props';
import { StyleguideSpecimenFields } from 'lib/component-props/styleguide';
import {
  KEY_SRTILE_HEADLINE,
  KEY_SRTILE_IMAGE,
  KEY_SRTILE_HOVER_IMAGE,
} from '../../constants/general';

type SRTileProps = ComponentProps &
  StyleguideSpecimenFields & {
    fields: {
      [KEY_SRTILE_HEADLINE]: Field<string>;
      [KEY_SRTILE_IMAGE]: Field<string>;
      [KEY_SRTILE_HOVER_IMAGE]: Field<string>;
    };
  };

export default function TileSR(props: SRTileProps) {
  const formattedData = getTiles(props);
  // const {
  //   abstract,
  //   image,
  //   showMouseoverEffect,
  //   mouseoverImage,
  //   isCentered,
  //   isLinkURL,
  //   linkToDownload,
  //   linkURL
  // } = getTiles(props);
  const [showActualImage, setShowActualImage] = useState(true);
  const { sitecoreContext } = useSitecoreContext();
  const isExperienceEditor = sitecoreContext && sitecoreContext.pageEditing;

  const navigationHandler = () => {
    if (formattedData.isLinkURL && formattedData.linkURL !== '') {
      window.open(formattedData.linkURL, '_blank');
    } else if (formattedData.linkToDownload !== '') {
      const pdfUrl = formattedData.linkToDownload.replace('/sitecore/media-library/', '/~/media/');
      const link = document.createElement('a');
      link.href = pdfUrl;
      link.target = '_blank';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };
  // useEffect(() => {
  //   setTileImage(formattedData.image);
  // }, []);
  const hoverHandler = () => {
    if (formattedData.showMouseoverEffect === true) {
      setShowActualImage(false);
    }
  };
  const noHoverHandler = () => {
    setShowActualImage(true);
  };
  return (
    <a
      className={`${styles.tile_container} ${
        formattedData.linkURL !== '' || formattedData.linkToDownload !== '' ? styles.is_link : ''
      }  ${formattedData.showMouseoverEffect === true ? styles.showHover : undefined}`}
      onClick={navigationHandler}
      onMouseEnter={hoverHandler}
      onMouseLeave={noHoverHandler}
      onTouchMove={hoverHandler}
      onTouchEnd={noHoverHandler}
    >
      {isExperienceEditor &&
        formattedData[KEY_SRTILE_IMAGE] &&
        formattedData[KEY_SRTILE_IMAGE].value &&
        formattedData[KEY_SRTILE_IMAGE].value.value &&
        formattedData[KEY_SRTILE_IMAGE].value.value.src && (
          <div className={styles.img_container}>
            <Image field={formattedData[KEY_SRTILE_IMAGE].value} editable={true} />
          </div>
        )}

      {!isExperienceEditor &&
        showActualImage &&
        formattedData[KEY_SRTILE_IMAGE] &&
        formattedData[KEY_SRTILE_IMAGE].value &&
        formattedData[KEY_SRTILE_IMAGE].value.value &&
        formattedData[KEY_SRTILE_IMAGE].value.value.src && (
          <div className={styles.img_container}>
            <Image field={formattedData[KEY_SRTILE_IMAGE].value} editable={true} />
          </div>
        )}
      {!isExperienceEditor &&
        !showActualImage &&
        formattedData[KEY_SRTILE_HOVER_IMAGE] &&
        formattedData[KEY_SRTILE_HOVER_IMAGE].value &&
        formattedData[KEY_SRTILE_HOVER_IMAGE].value.value &&
        formattedData[KEY_SRTILE_HOVER_IMAGE].value.value.src && (
          <div className={styles.img_container}>
            <Image field={formattedData[KEY_SRTILE_HOVER_IMAGE].value} editable={true} />
          </div>
        )}
      {!isExperienceEditor ? (
        formattedData[KEY_SRTILE_HEADLINE] &&
        formattedData[KEY_SRTILE_HEADLINE].value && (
          <div
            className={`${styles.text_container} ${
              formattedData.isCentered ? styles.text_center : undefined
            }`}
          >
            <Text
              field={formattedData[KEY_SRTILE_HEADLINE]}
              editable={true}
              className={styles.headline_container}
            />
          </div>
        )
      ) : (
        <div
          className={`${styles.text_container} ${
            formattedData.isCentered ? styles.text_center : undefined
          }`}
        >
          <Text
            field={formattedData[KEY_SRTILE_HEADLINE]}
            editable={true}
            className={styles.headline_container}
          />
        </div>
      )}
    </a>
  );
}
