import { useRef, useState, useEffect } from 'react';
import styles from './KeyTaskCard.module.scss';
import {
  Text,
  RichText,
  Field,
  useSitecoreContext,
  Image,
} from '@sitecore-jss/sitecore-jss-nextjs';
// import { KEY_KTC_CAPTION, KEY_KTC_HEADLINE, KEY_KTC_IMAGE } from 'src/constants/general';
import {
  KEY_KTC_CAPTION,
  KEY_KTC_HEADLINE,
  KEY_KTC_IMAGE,
  KEY_KTC_IMAGES,
  KEY_KTC_ERROR
} from 'src/constants/general';
import { CONTENT_100 } from 'src/constants/contentDivider';
import { StyleguideSpecimenFields } from 'lib/component-props/styleguide';
import { formatKeyTaskCardData } from 'src/helpers/component.helper';
import { getParentClassReference } from 'src/core/utils/utils.helper';
import { getContributionStatement } from 'src/services/integration.service';
type KeyTaskCardComponentProps = StyleguideSpecimenFields & {
  fields: {
    [KEY_KTC_HEADLINE]: Field<string>;
    [KEY_KTC_IMAGE]: Field<string>;
  };
};

const KeyTaskCard = (props: KeyTaskCardComponentProps) => {
  const { sitecoreContext } = useSitecoreContext();
  const isExperienceEditor = sitecoreContext && sitecoreContext.pageEditing;
  // const isExperienceEditor = true;
  const ktcData = formatKeyTaskCardData(props);

  /**
   * @important This code needs to be used in every components inorder to get the content dividers reference
   * @important Also set the reference (ref) and className to the html wrapper as implemented below
   */
  // starts
  const nodeRef = useRef(null);
  const [parentRef, setParentRef] = useState<any>(null);
  const [hidden, setHidden] = useState<any>(true);
  const [contributionStatement, setContributionStatement] = useState<any>('');
  const [hideEye, setHideEye] = useState(false);
  const [shownImage, setShownImage] = useState<any>(ktcData && ktcData[KEY_KTC_IMAGE]);


  useEffect(() => {
    const child: any = nodeRef.current;

    if (child !== null || child !== undefined) {
      setParentRef(getParentClassReference(child));
    } else {
      setParentRef(CONTENT_100);
    }
    setHideEye(ktcData.hideEye);
    if (ktcData && ktcData.hideEye) {
      const endpoint = ktcData && ktcData.apiEndpoint;
      const apiField = ktcData && ktcData.apiField;
      getContributionStatement(endpoint).then((data: any) => {
        if (data) {
          const contributionStatement =
            data && data.data && data.data.lastYear
              ? data.data.lastYear[apiField]
              : data.data[apiField]
              ? data.data[apiField]
              : '';
          setContributionStatement(contributionStatement);
        }
      });
    }
  }, [props]);

  const setImage = (contributionStatement: any) => {
    let statementText =
      contributionStatement && contributionStatement.toString().replace(/\s+/g, '').toLowerCase();
      statementText && statementText == 'nodata' ? statementText= 'error':"";
    ktcData &&
      ktcData[KEY_KTC_IMAGES] &&
      ktcData[KEY_KTC_IMAGES].map((imageObj: any) => {
        imageObj.ImageKeyword == statementText ? setShownImage(     {value:{src:window.location.href.split(".com")[0]+'.com'+imageObj.ImageSrc,alt:''}}) : '';
      });
  };
  const getStatus = () => {
    const endpoint = ktcData && ktcData.apiEndpoint;
    const apiField = ktcData && ktcData.apiField;


    if (endpoint && endpoint != '' && hidden) {
      getContributionStatement(endpoint).then((data: any) => {
        if (data) {

         
          const contributionStatement =
            data && data.data && data.data.lastYear
              ? data.data.lastYear[apiField] ?  data.data.lastYear[apiField] : KEY_KTC_ERROR
              : data.data[apiField]
              ? data.data[apiField]
              : KEY_KTC_ERROR;

              setContributionStatement(contributionStatement);
              // if( data && data.data && data.data.lastYear
              //   && data.data.lastYear[apiField]){
              //    setImage(contributionStatement);
              //   }else{
              //     setImage(KEY_KTC_ERROR)
              //   }
                setImage(contributionStatement);
                setHidden(!hidden);
        } else {
          setImage("nodata");
          setHidden(!hidden);
          setContributionStatement("No Data");
         
        }
      });
    } else {
      setHidden(true);
  
      setShownImage(ktcData && ktcData[KEY_KTC_IMAGE]);
    }
  };

  return (
    <div
      ref={nodeRef}
      className={`${parentRef && styles[parentRef]}`}
      id={ktcData && ktcData.ktcAnchor}
    >
      <div
        className={`${styles.ktc__container} ${
          ktcData && ktcData.alignHorizontal
            ? styles.ktc__container__horizontal
            : styles.ktc__container__vertical
        } ${ktcData && ktcData.isHighlighted ? styles.ktc__container__highlight : ''} 
          ${isExperienceEditor ? styles.ktc__container__spaced : ''}`}
      >
        {ktcData &&
          ktcData[KEY_KTC_IMAGE] &&
          ktcData &&
          ktcData[KEY_KTC_IMAGE].value &&
          Object.keys(ktcData[KEY_KTC_IMAGE].value).length !== 0 && (
            <div
              className={`${styles.ktc_image__container} ${
                isExperienceEditor ? styles.ktc_image__container__exp_editor_img : ''
              } ${
                ktcData && ktcData.alignHorizontal ? styles.ktc_image__container__horizontal : ''
              }`}
            >
              <Image
                field={shownImage}
                editable={true}
                className={`${styles.ktc__image} ${
                  ktcData && ktcData.alignHorizontal ? '' : styles.ktc__image__vertical
                } 
                  `}
              />
            </div>
          )}

        <div
          className={`${styles.ktc_content__container} ${
            ktcData && ktcData.alignHorizontal ? styles.ktc_content__container__horizontal : ''
          }`}
        >
          <Text
            field={ktcData && ktcData[KEY_KTC_HEADLINE] && ktcData[KEY_KTC_HEADLINE].value}
            editable={true}
            className={`${styles.ktc__headline} ${
              ktcData && ktcData.isHighlighted ? styles.ktc__headline__highlight : ''
            }`}
            tag="h2"
          />

          {ktcData && ktcData[KEY_KTC_CAPTION] && ktcData[KEY_KTC_CAPTION].value !== '' && (
            <div className={styles.ktc_content__caption}>
              <RichText
                field={ktcData && ktcData[KEY_KTC_CAPTION] && ktcData[KEY_KTC_CAPTION]}
                editable={true}
              />
            </div>
          )}

          {!hideEye ? (
            <div className={styles.ktc_content__subheadline}>
              <div
                className={`${
                  hidden
                    ? styles.ktc_subHeadline__section1__hidden
                    : styles.ktc_subHeadline__section1
                }`}
              >
                {hidden ? '*****************' : contributionStatement}
              </div>
              <a
                className={`${
                  hidden
                    ? styles.ktc_subHeadline__section2__hidden
                    : styles.ktc_subHeadline__section2
                }`}
                onClick={() => getStatus()}
              ></a>
            </div>
          ) : (
            <div className={styles.ktc_content__subheadline}>
              <div className={`${styles.ktc_subHeadline__section1}`}>{contributionStatement}</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
export default KeyTaskCard;
