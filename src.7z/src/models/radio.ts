export interface RadioButtonConfig {
  name: string;
  id: string;
  label?: string;
  value?: any;
  onChange?: any;
  className: string;
  isDefault?: any;
}
