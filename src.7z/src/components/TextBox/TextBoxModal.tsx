import styles from './TextBox.module.scss';
import { useEffect, useState } from 'react';
import { Image } from '@sitecore-jss/sitecore-jss-nextjs';
import { Text } from '@sitecore-jss/sitecore-jss-nextjs';

export default function TextBoxModal(props: any) {
  const [modalData, setModalData] = useState<any>(props.data);

  useEffect(() => {
    setModalData(props.data);
  }, []);

  const handleModalClose = () => {
    props.handleModalClose();
  };

  return (
    <>
      {props.data ? (
        <div className={styles.modal_container}>
          <div className={styles.modal_image_container + ' modal_check'}>
            <Image
              field={modalData.enlargedImg.value}
              editable={true}
              className={styles.modal_image}
            />
            <div className={styles.icon_collapse} onClick={handleModalClose}></div>
          </div>
          <Text
            field={modalData.enlargedImgCaption.value}
            editable={true}
            tag="div"
            className={styles.modal_image_text}
          />
        </div>
      ) : (
        ' '
      )}
    </>
  );
}
