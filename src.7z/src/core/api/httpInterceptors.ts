import axios from 'axios';
import { BehaviorSubject } from 'rxjs';
import { loaderSubject } from 'src/helpers/loader.helper';
import { STORAGE_ACCESS_TOKEN } from 'src/constants/storage';
import {
  KEY_ENVIRONMENTS,
  // KEY_IS_EDIT,
  // KEY_IS_PREVIEW,
  // KEY_IS_EDIT, KEY_IS_PREVIEW,
  KEY_QA_ENV,
} from 'src/constants/general';
import {
  getFromStorage,
  checkEnvExistsinUrl,
  // getQueryParamsFromUrl,
  // getFromLocalStorage,
  // removeFromLocalStorage,
} from 'src/core/utils/utils.helper';

export const errorSubject = new BehaviorSubject(null);

const requests: any[] = []; // a global array to keep all active http requests

/**
 * Remove a request from global array once it is completed
 * @param req
 */
const removeRequest = (req: any) => {
  const i = requests.indexOf(req);
  if (i >= 0) {
    requests.splice(i, 1);
  }
  loaderSubject.next(requests.length > 0);
};

// Add a request interceptor
axios.interceptors.request.use(
  function (config) {
    const token = getFromStorage(STORAGE_ACCESS_TOKEN);
    if (config && config.headers) {
      config.headers.Authorization = 'Bearer ' + token;
    }
    requests.push(config); // add request to global request array
    loaderSubject.next(true); // set loader to true
    // Do something before request is sent
    return config;
  },
  function (error) {
    // Do something with request error
    return Promise.reject(error);
  }
);

// Add a response interceptor
axios.interceptors.response.use(
  function (response) {
    if (response) {
      removeRequest(response.config); // remove request from global request array
      // Any status code that lie within the range of 2xx cause this function to trigger
      // Do something with response data
      return response;
    } else {
      return false;
    }
  },
  function (error) {
    removeRequest(error.config); // remove request from global request array
    // Any status codes that falls outside the range of 2xx cause this function to trigger
    // Do something with response error
    const currentUrl = window.location.href;
    if (
      error.response &&
      (error.response.status === 440 ||
        (error.response.status === 500 && currentUrl.includes(KEY_QA_ENV)))
    ) {
      const current_url = window.location.href;
      let redirection_url = `${process.env.SITECORE_API_HOST}/en/imprint?src=HR`;
      // const redirection_url = 'https://cd.uat1.bayernet.int.bayer.com/en/imprint?src=HR';
      // if(redirection_url.includes('uat1')) {
      //   redirection_url = redirection_url.replace('/en?src=HR', '/en/imprint?src=HR');
      // }

      // check the environment is localhost
      const isEnvLocalHost: any = checkEnvExistsinUrl(KEY_ENVIRONMENTS.ENV_LOCAL);
      const isEnvNode: any = checkEnvExistsinUrl(KEY_ENVIRONMENTS.ENV_NODE);

      if (!isEnvLocalHost && !isEnvNode) {
        document.cookie = `redirection_url=${current_url};Path=/`;
        window.location.assign(redirection_url);
      }
    } else {
      errorSubject.next(error);
    }
  }
);
