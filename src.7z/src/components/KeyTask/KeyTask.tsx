import React from 'react';
import styles from './KeyTask.module.scss';
import { Text, Field, RichText, useSitecoreContext } from '@sitecore-jss/sitecore-jss-nextjs';
import { ComponentProps } from 'lib/component-props';
import { StyleguideSpecimenFields } from 'lib/component-props/styleguide';
import { createIcsFile, formatDateICS } from 'src/core/utils/utils.helper';
import {
  DEFAULT_DATE_VALUE,
  IFRAME_BUTTON_TYPE,
  KEY_KEYTASK_CTA_LINK,
  KEY_KEYTASK_LINK_TEXT1,
  KEY_KEYTASK_LINK_TEXT2,
  KEY_KEYTASK_LINK_TEXT3,
  KEY_KEYTASK_LINK_TEXT4,
  KEY_KEYTASK_LINK_URL1,
  KEY_KEYTASK_LINK_URL2,
  KEY_KEYTASK_LINK_URL3,
  KEY_KEYTASK_LINK_URL4,
  KEY_KEYTASK_TIME_SPAN,
} from 'src/constants/general';
import { IframeButton } from 'components/Elements/IframeButton/IframeButton';

type KeyTaskComponentProps = ComponentProps &
  StyleguideSpecimenFields & {
    fields: {
      SaveInCalenderText: Field<string>;
      // When: Field<string>;
      SendInviteText: Field<string>;
      Details: Field<string>;
      SaveInEmailText: Field<string>;
      SaveInStartDate: Field<string>;
      SaveInEndDate: Field<any>;
      SendInviteStartDate: Field<any>;
      SendInviteEndDate: Field<any>;
      SendInviteEmailText: Field<string>;
      IsGrey: Field<boolean>;
      'CTA link': Field<any>;
      // ButtonLink: Field<any>;
      Headline: Field<string>;
      Name: Field<string>;
      SubHeadline: Field<string>;
      'Timespan Info': Field<string>;
      'Link Url1': Field<any>;
      'Link Text1': Field<any>;
      'Link Url2': Field<any>;
      'Link Text2': Field<any>;
      'Link Url3': Field<any>;
      'Link Text3': Field<any>;
      'Link Url4': Field<any>;
      'Link Text4': Field<any>;
      Iframe: Field<any>;
      // Link1: Field<any>;
      // Link2: Field<any>;
      // Link3: Field<any>;
      // Link4: Field<any>;
    };
  };

const KeyTask = (props: KeyTaskComponentProps) => {
  // const {fields} = props;
  const fields: any = props.fields;
  const { sitecoreContext } = useSitecoreContext();
  const isExperienceEditor = sitecoreContext && sitecoreContext.pageEditing;
  // const htmlContent = {
  //   value: fields && fields.TaskDetails && fields.TaskDetails.value && fields.TaskDetails.value.replaceAll('\n', '')
  // }

  const save = () => {
    const event: any = {
      start: formatDateICS(fields.SaveInStartDate && fields.SaveInStartDate.value),
      end: formatDateICS(fields.SaveInEndDate && fields.SaveInEndDate.value),
      title: fields && fields.SubHeadline && fields.SubHeadline.value,
      htmlContent:
        fields && fields.SaveInEmailText && fields.SaveInEmailText.value.replace(/\n/g, ''),
    };
    const name = `Employee Calendar Time for ${
      fields && fields.SubHeadline && fields.SubHeadline.value
    } meeting.ics`;
    createIcsFile(event, name);
  };

  const schedule = () => {
    const event: any = {
      start: formatDateICS(fields.SendInviteStartDate && fields.SendInviteStartDate.value),
      end: formatDateICS(fields.SendInviteEndDate && fields.SendInviteEndDate.value),
      title: fields && fields.SubHeadline && fields.SubHeadline.value,
      htmlContent:
        fields && fields.SendInviteEmailText && fields.SendInviteEmailText.value.replace(/\n/g, ''),
    };
    const name = `Invite - Employee Time for ${
      fields && fields.SubHeadline && fields.SubHeadline.value
    } meeting.ics`;
    createIcsFile(event, name);
  };

  const getLink = (title: any, link: any) => {
    return (
      <div className={styles.external_links}>
        <a
          target="_blank"
          title={title}
          href={link ? (link.includes('http') ? link : `http://${link}`) : '#'}
        >
          {title}
        </a>
      </div>
    );
  };

  return (
    <div
      className={`${styles.card_container} ${
        fields && fields.IsGrey && fields.IsGrey.value === true ? styles.grey_background : ''
      }`}
    >
      {/* <Text
        tag='h1'
        field={fields && fields.Headline}
        editable={true}
        className={styles.main_headline}
      ></Text> */}

      <Text
        tag="h1"
        field={fields && fields.Name}
        editable={true}
        className={styles.main_headline}
      ></Text>

      <Text
        tag="h1"
        field={fields && fields.SubHeadline}
        editable={true}
        className={styles.sub_headline}
      ></Text>

      <div className={styles.goal_month}>
        <Text
          tag="p"
          field={fields && fields[KEY_KEYTASK_TIME_SPAN]}
          editable={true}
          // className={styles.sub_headline}
        ></Text>
      </div>

      <div
        className={styles.scheduler_wrapper}
        style={{
          borderBottom: fields ? '1px solid #c5d1d6' : 'none',
          paddingBottom:
            (fields &&
              fields.SaveInStartDate &&
              fields.SaveInStartDate.value &&
              fields.SaveInStartDate.value !== DEFAULT_DATE_VALUE &&
              fields.SaveInEndDate &&
              fields.SaveInEndDate.value &&
              fields.SaveInEndDate.value !== DEFAULT_DATE_VALUE) ||
            (fields &&
              fields.SendInviteStartDate &&
              fields.SendInviteStartDate.value &&
              fields.SendInviteStartDate.value !== DEFAULT_DATE_VALUE &&
              fields.SendInviteEndDate &&
              fields.SendInviteEndDate.value &&
              fields.SendInviteEndDate.value !== DEFAULT_DATE_VALUE)
              ? '21.5px'
              : '0px',
        }}
      >
        {fields &&
        fields.SaveInStartDate &&
        fields.SaveInStartDate.value &&
        fields.SaveInStartDate.value !== DEFAULT_DATE_VALUE &&
        fields.SaveInEndDate &&
        fields.SaveInEndDate.value &&
        fields.SaveInEndDate.value !== DEFAULT_DATE_VALUE ? (
          <div className={styles.calendar} onClick={save}>
            <div className={styles.calendar_icon}></div>
            <Text
              tag="a"
              field={fields && fields.SaveInCalenderText && fields.SaveInCalenderText}
              editable={true}
            ></Text>
          </div>
        ) : (
          ''
        )}

        {fields &&
        fields.SendInviteStartDate &&
        fields.SendInviteStartDate.value &&
        fields.SendInviteStartDate.value !== DEFAULT_DATE_VALUE &&
        fields.SendInviteEndDate &&
        fields.SendInviteEndDate.value &&
        fields.SendInviteEndDate.value !== DEFAULT_DATE_VALUE ? (
          <div className={styles.calendar} onClick={schedule}>
            <div className={styles.arrow_right}></div>
            <Text
              tag="a"
              field={fields && fields.SendInviteText && fields.SendInviteText}
              editable={true}
            ></Text>
          </div>
        ) : (
          ''
        )}
      </div>

      {isExperienceEditor ? (
        <RichText
          tag="p"
          field={fields && fields.Details}
          editable={true}
          className={styles.checkin_rules}
        ></RichText>
      ) : (
        <div
          className={styles.checkin_rules}
          dangerouslySetInnerHTML={{
            __html: fields && fields.Details && fields.Details.value,
          }}
        ></div>
      )}

      <div className={styles.link_section}>
        {fields &&
        fields[KEY_KEYTASK_LINK_TEXT1] &&
        fields[KEY_KEYTASK_LINK_TEXT1].value &&
        fields[KEY_KEYTASK_LINK_URL1] &&
        fields[KEY_KEYTASK_LINK_URL1].value
          ? getLink(fields[KEY_KEYTASK_LINK_TEXT1].value, fields[KEY_KEYTASK_LINK_URL1].value)
          : ''}

        {fields &&
        fields[KEY_KEYTASK_LINK_TEXT2] &&
        fields[KEY_KEYTASK_LINK_TEXT2].value &&
        fields[KEY_KEYTASK_LINK_URL2] &&
        fields[KEY_KEYTASK_LINK_URL2].value
          ? getLink(fields[KEY_KEYTASK_LINK_TEXT2].value, fields[KEY_KEYTASK_LINK_URL2].value)
          : ''}

        {fields &&
        fields[KEY_KEYTASK_LINK_TEXT3] &&
        fields[KEY_KEYTASK_LINK_TEXT3].value &&
        fields[KEY_KEYTASK_LINK_URL3] &&
        fields[KEY_KEYTASK_LINK_URL3].value
          ? getLink(fields[KEY_KEYTASK_LINK_TEXT3].value, fields[KEY_KEYTASK_LINK_URL3].value)
          : ''}

        {fields &&
        fields[KEY_KEYTASK_LINK_TEXT4] &&
        fields[KEY_KEYTASK_LINK_TEXT4].value &&
        fields[KEY_KEYTASK_LINK_URL4] &&
        fields[KEY_KEYTASK_LINK_URL4].value
          ? getLink(fields[KEY_KEYTASK_LINK_TEXT4].value, fields[KEY_KEYTASK_LINK_URL4].value)
          : ''}
      </div>

      {fields &&
      fields[KEY_KEYTASK_CTA_LINK] &&
      fields[KEY_KEYTASK_CTA_LINK].value &&
      fields[KEY_KEYTASK_CTA_LINK].value.text &&
      fields[KEY_KEYTASK_CTA_LINK].value.text != '' ? (
        <div>
          <div className={styles.contribution_button}>
            <a
              href={
                fields[KEY_KEYTASK_CTA_LINK].value.href
                  ? fields[KEY_KEYTASK_CTA_LINK].value.href
                  : '#'
              }
              target="_blank"
            >
              {fields[KEY_KEYTASK_CTA_LINK].value.text && fields[KEY_KEYTASK_CTA_LINK].value.text}
            </a>
          </div>
        </div>
      ) : (
        ''
      )}

      {/* {fields &&
      fields[KEY_IFRAME] &&
      fields[KEY_IFRAME][0] && fields[KEY_IFRAME][0].fields &&
      fields[KEY_IFRAME][0].fields.IframeSource &&
      fields[KEY_IFRAME][0].fields.IframeSource.value &&
      fields[KEY_IFRAME_BUTTON_TEXT] &&
      fields[KEY_IFRAME_BUTTON_TEXT].value ? (
        <div>
          <div className={`${styles.float_left}`}>
            <IframeButton data={fields} type={IFRAME_BUTTON_TYPE.HR_TASK} />
          </div>
        </div>
      ) : (
        ''
      )} */}

<div className={`${styles.float_right}`}>
            <IframeButton data={fields} type={IFRAME_BUTTON_TYPE.HR_TASK} />
          </div>
    </div>
  );
};

export default KeyTask;
