import { IframeButton } from 'components/Elements/IframeButton/IframeButton';
import styles from './CalendarTaskMobile.module.scss';
import { Text } from '@sitecore-jss/sitecore-jss-nextjs';
import LightBoxOverLay from 'components/LightBoxOverlay/LightBoxOverlay';
import { useState, useRef, useEffect } from 'react';
import { setHashString } from 'src/core/utils/utils.helper';
import { IFRAME_BUTTON_TYPE } from 'src/constants/general';

export default function CalendarTaskMobile(props: any) {
  const { fields, duration, width, order, handleLoad, commonHeight, takeHeight } = props;
  const unitWidth = (width - 16) / 3;
  const rowView = duration && duration.duration && duration.duration > 2 ? true : false;
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<any>(null);
  const handleOpenOverlay = () => {
    setIsOpen(true);
    const hash = `all/${props.id}`;
    setHashString(hash);
  };

  //console.log("fielsHR",fields);
  const closeOverlay = () => {
    setIsOpen(false);
  };
  useEffect(() => {
    if (containerRef && containerRef.current && containerRef.current.clientHeight) {
      handleLoad(containerRef.current.clientHeight);
    }
  }, []);
  const getWidth = (duration: any) => {
    let durationWidth;
    if (duration.startMonth === 1) {
      if (duration.endMonth === 1) {
        durationWidth = unitWidth + 2;
      }
      if (duration.endMonth === 2) {
        durationWidth = 2 * unitWidth + 8 + 2;
      }
      if (duration.endMonth === 3) {
        durationWidth = 3 * unitWidth + 2 * 8;
      }
      if (duration.endMonth === 4) {
        durationWidth = 4 * unitWidth + 2 * 8 + 2;
      }
      if (duration.endMonth === 5) {
        durationWidth = 5 * unitWidth + 3 * 8 + 2;
      }
      if (duration.endMonth === 6) {
        durationWidth = 6 * unitWidth + 4 * 8;
      }
      if (duration.endMonth === 7) {
        durationWidth = 7 * unitWidth + 4 * 8 + 2;
      }
      if (duration.endMonth === 8) {
        durationWidth = 8 * unitWidth + 5 * 8 + 2;
      }
      if (duration.endMonth === 9) {
        durationWidth = 9 * unitWidth + 6 * 8;
      }
      if (duration.endMonth === 10) {
        durationWidth = 10 * unitWidth + 6 * 8 + 2;
      }
      if (duration.endMonth === 11) {
        durationWidth = 11 * unitWidth + 7 * 8 + 2;
      }
      if (duration.endMonth === 12) {
        durationWidth = 4 * width;
      }
    } else if (duration.startMonth === 2) {
      if (duration.endMonth === 2) {
        durationWidth = unitWidth + 4;
      }
      if (duration.endMonth === 3) {
        durationWidth = 2 * unitWidth + 8 + 2;
      }
      if (duration.endMonth === 4) {
        durationWidth = 3 * unitWidth + 8 + 4;
      }
      if (duration.endMonth === 5) {
        durationWidth = 4 * unitWidth + 2 * 8 + 4;
      }
      if (duration.endMonth === 6) {
        durationWidth = 5 * unitWidth + 3 * 8 + 2;
      }
      if (duration.endMonth === 7) {
        durationWidth = 6 * unitWidth + 3 * 8 + 4;
      }
      if (duration.endMonth === 8) {
        durationWidth = 7 * unitWidth + 4 * 8 + 4;
      }
      if (duration.endMonth === 9) {
        durationWidth = 8 * unitWidth + 5 * 8 + 2;
      }
      if (duration.endMonth === 10) {
        durationWidth = 9 * unitWidth + 5 * 8 + 4;
      }
      if (duration.endMonth === 11) {
        durationWidth = 10 * unitWidth + 6 * 8 + 4;
      }
      if (duration.endMonth === 12) {
        durationWidth = 11 * unitWidth + 7 * 8 + 2;
      }
    } else if (duration.startMonth === 3) {
      if (duration.endMonth === 3) {
        durationWidth = unitWidth + 2;
      }
      if (duration.endMonth === 4) {
        durationWidth = 2 * unitWidth + 4;
      }
      if (duration.endMonth === 5) {
        durationWidth = 3 * unitWidth + 8 + 4;
      }
      if (duration.endMonth === 6) {
        durationWidth = 4 * unitWidth + 2 * 8 + 2;
      }
      if (duration.endMonth === 7) {
        durationWidth = 5 * unitWidth + 2 * 8 + 4;
      }
      if (duration.endMonth === 8) {
        durationWidth = 6 * unitWidth + 3 * 8 + 4;
      }
      if (duration.endMonth === 9) {
        durationWidth = 7 * unitWidth + 4 * 8 + 2;
      }
      if (duration.endMonth === 10) {
        durationWidth = 8 * unitWidth + 4 * 8 + 4;
      }
      if (duration.endMonth === 11) {
        durationWidth = 9 * unitWidth + 5 * 8 + 4;
      }
      if (duration.endMonth === 12) {
        durationWidth = 10 * unitWidth + 6 * 8 + 2;
      }
    } else if (duration.startMonth === 4) {
      if (duration.endMonth === 4) {
        durationWidth = unitWidth + 2;
      }
      if (duration.endMonth === 5) {
        durationWidth = 2 * unitWidth + 8 + 2;
      }
      if (duration.endMonth === 6) {
        durationWidth = 3 * unitWidth + 2 * 8;
      }
      if (duration.endMonth === 7) {
        durationWidth = 4 * unitWidth + 2 * 8 + 2;
      }
      if (duration.endMonth === 8) {
        durationWidth = 5 * unitWidth + 3 * 8 + 2;
      }
      if (duration.endMonth === 9) {
        durationWidth = 6 * unitWidth + 4 * 8;
      }
      if (duration.endMonth === 10) {
        durationWidth = 7 * unitWidth + 4 * 8 + 2;
      }
      if (duration.endMonth === 11) {
        durationWidth = 8 * unitWidth + 5 * 8 + 2;
      }
      if (duration.endMonth === 12) {
        durationWidth = 9 * unitWidth + 6 * 8;
      }
    } else if (duration.startMonth === 5) {
      if (duration.endMonth === 5) {
        durationWidth = unitWidth + 4;
      }
      if (duration.endMonth === 6) {
        durationWidth = 2 * unitWidth + 8 + 2;
      }
      if (duration.endMonth === 7) {
        durationWidth = 3 * unitWidth + 8 + 4;
      }
      if (duration.endMonth === 8) {
        durationWidth = 4 * unitWidth + 2 * 8 + 4;
      }
      if (duration.endMonth === 9) {
        durationWidth = 5 * unitWidth + 3 * 8 + 2;
      }
      if (duration.endMonth === 10) {
        durationWidth = 6 * unitWidth + 3 * 8 + 4;
      }
      if (duration.endMonth === 11) {
        durationWidth = 7 * unitWidth + 4 * 8 + 4;
      }
      if (duration.endMonth === 12) {
        durationWidth = 8 * unitWidth + 5 * 8 + 2;
      }
    } else if (duration.startMonth === 6) {
      if (duration.endMonth === 6) {
        durationWidth = unitWidth + 2;
      }
      if (duration.endMonth === 7) {
        durationWidth = 2 * unitWidth + 4;
      }
      if (duration.endMonth === 8) {
        durationWidth = 3 * unitWidth + 8 + 4;
      }
      if (duration.endMonth === 9) {
        durationWidth = 4 * unitWidth + 2 * 8 + 2;
      }
      if (duration.endMonth === 10) {
        durationWidth = 5 * unitWidth + 2 * 8 + 4;
      }
      if (duration.endMonth === 11) {
        durationWidth = 6 * unitWidth + 3 * 8 + 4;
      }
      if (duration.endMonth === 12) {
        durationWidth = 7 * unitWidth + 4 * 8 + 2;
      }
    } else if (duration.startMonth === 7) {
      if (duration.endMonth === 7) {
        durationWidth = unitWidth + 2;
      }
      if (duration.endMonth === 8) {
        durationWidth = 2 * unitWidth + 8 + 2;
      }
      if (duration.endMonth === 9) {
        durationWidth = width;
      }
      if (duration.endMonth === 10) {
        durationWidth = 4 * unitWidth + 2 * 8 + 2;
      }
      if (duration.endMonth === 11) {
        durationWidth = 5 * unitWidth + 3 * 8 + 2;
      }
      if (duration.endMonth === 11) {
        durationWidth = 2 * width;
      }
    } else if (duration.startMonth === 8) {
      if (duration.endMonth === 8) {
        durationWidth = unitWidth + 4;
      }
      if (duration.endMonth === 9) {
        durationWidth = 2 * unitWidth + 8 + 2;
      }
      if (duration.endMonth === 10) {
        durationWidth = 3 * unitWidth + 8 + 4;
      }
      if (duration.endMonth === 11) {
        durationWidth = 4 * unitWidth + 2 * 8 + 4;
      }
      if (duration.endMonth === 12) {
        durationWidth = 5 * unitWidth + 3 * 8 + 2;
      }
    } else if (duration.startMonth === 9) {
      if (duration.endMonth === 9) {
        durationWidth = unitWidth + 2;
      }
      if (duration.endMonth === 10) {
        durationWidth = 2 * unitWidth + 4;
      }
      if (duration.endMonth === 11) {
        durationWidth = 3 * unitWidth + 8 + 4;
      }
      if (duration.endMonth === 12) {
        durationWidth = 4 * unitWidth + 2 * 8 + 2;
      }
    } else if (duration.startMonth === 10) {
      if (duration.endMonth === 10) {
        durationWidth = unitWidth + 2;
      }
      if (duration.endMonth === 11) {
        durationWidth = 2 * unitWidth + 8 + 2;
      }
      if (duration.endMonth === 12) {
        durationWidth = width;
      }
    } else if (duration.startMonth === 11) {
      if (duration.endMonth === 11) {
        durationWidth = unitWidth + 4;
      }
      if (duration.endMonth === 12) {
        durationWidth = 2 * unitWidth + 8 + 2;
      }
    } else {
      durationWidth = unitWidth + 2;
    }
    return durationWidth;
  };
  const getPosition = (duration: any) => {
    let pos;
    if (duration.startMonth === 1) {
      pos = 0;
    } else if (duration.startMonth === 2) {
      pos = unitWidth + 6;
    } else if (duration.startMonth === 3) {
      pos = 2 * unitWidth + 8 + 6;
    } else if (duration.startMonth === 4) {
      pos = width;
    } else if (duration.startMonth === 5) {
      pos = width + unitWidth + 6;
    } else if (duration.startMonth === 6) {
      pos = width + 2 * unitWidth + 8 + 6;
    } else if (duration.startMonth === 7) {
      pos = 2 * width;
    } else if (duration.startMonth === 8) {
      pos = 2 * width + unitWidth + 6;
    } else if (duration.startMonth === 9) {
      pos = 2 * width + 2 * unitWidth + 8 + 6;
    } else if (duration.startMonth === 10) {
      pos = 3 * width;
    } else if (duration.startMonth === 11) {
      pos = 3 * width + unitWidth + 6;
    } else {
      pos = 3 * width + 2 * unitWidth + 8 + 6;
    }
    return pos;
  };
  return (
    <>
      <div
        className={`${styles.task_wrapper} ${
          order === 3 || order === 7
            ? styles.group_three
            : order === 2 || order === 6
            ? styles.group_two
            : order === 1 || order === 5
            ? styles.group_one
            : styles.default
        } ${rowView && styles.row_button}`}
        style={
          takeHeight
            ? {
                width: getWidth(duration),
                height: commonHeight,
                left: getPosition(duration),
              }
            : {
                width: getWidth(duration),
                left: getPosition(duration),
              }
        }
        onClick={handleOpenOverlay}
        ref={containerRef}
      >
        <Text field={fields.Name} editable={true} className={styles.task_text} tag="p" />
        {fields['IsTaskCompleted'] &&
        fields['IsTaskCompleted'].value &&
        fields['IsTaskCompleted'].value === true ? (
          <div className={styles.check_icon} />
        ) : fields['CTA link'] &&
          fields['CTA link'].value &&
          fields['CTA link'].value.text &&
          fields['CTA link'].value.text != '' ? (
          <a
            className={styles.task_link}
            href={fields['CTA link'] && fields['CTA link'].value && fields['CTA link'].value.href}
            target="_blank"
          >
            <button className={styles.task_button}>{fields['CTA link'].value.text}</button>
          </a>
        ) : (
          ''
        )}

{fields['IFrameButtonText'] &&
        fields['IFrameButtonText'].value  && !(fields['IsTaskCompleted'] &&
          fields['IsTaskCompleted'].value &&
          fields['IsTaskCompleted'].value === true)?
         <div>
        <div className={`${styles.float_right}`}>
          <IframeButton data={fields} type={IFRAME_BUTTON_TYPE.HR_ALL_TASK} group={
            order === 3 || order === 7
            ? "group_three"
            : order === 2 || order === 6
            ? 'group_two'
            : order === 1 || order === 5
            ? 'group_one'
            : ''} />
        </div>
      </div> : (
          ''
        )}
      </div>
      {isOpen ? (
        <LightBoxOverLay taskDetails={props} isOpen={isOpen} closeOverlay={closeOverlay} />
      ) : (
        ''
      )}
    </>
  );
}
