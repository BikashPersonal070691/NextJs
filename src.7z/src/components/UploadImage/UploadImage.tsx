import { useRef, useState, ChangeEvent } from 'react';
import { Cropper, CropperRef, CircleStencil } from 'react-advanced-cropper';
import { saveProfileImage } from 'src/services/userSettings.service';
import 'react-advanced-cropper/dist/style.css';
import styles from './UploadImage.module.scss';
import { useLanguageTranslate } from 'src/hooks/useLanguageTranslate';

import {
  KEY_PROFILE_BROWSE,
  KEY_PROFILE_CANCEL,
  KEY_PROFILE_ERROR_MESSAGE_ON_SIZE,
  KEY_PROFILE_FILESIZE_VALIDATION,
  KEY_PROFILE_SELECT_PROFILE_IMAGE,
  KEY_PROFILE_UNABLE_TO_SAVE_VALIDATION,
  KEY_PROFILE_UPLOAD_AND_SAVE,
  KEY_PROFILE_UPLOAD_BY_BROWSING_DESKTOP,
  KEY_PROFILE_UPLOAD_BY_BROWSING_DEVICE,
  KEY_PROFILE_UPLOAD_IMAGE_HEADING,
} from 'src/constants/dictonary';

export default function UploadImage(props: any) {
  const { translatedKey } = useLanguageTranslate();
  const [imgPreview, setImgPreview] = useState<any>();
  const [imgFormat, setImgFormat] = useState<any>();
  const [wrongType, setWrongType] = useState<any>(false);
  const [noImgSelected, setNoImgSelected] = useState<any>(false);
  const [serviceFalied, setServiceFalied] = useState<any>(false);
  const cropperRef = useRef<CropperRef>(null);

  const saveUserImage = (blob: any) => {
    let formData = new FormData();
    formData.append('image', blob);
    formData.append('extension', imgFormat);
    saveProfileImage(formData).then((data: any) => {
      if (data && data.status && data.status === 200) {
        setServiceFalied(false);
        if (cropperRef.current) {
          if (props && props.onUpload) {
            props.onUpload(cropperRef.current.getCanvas()?.toDataURL());
          }
          if (props && props.onCancel) {
            props.onCancel();
          }
        }
      } else {
        setServiceFalied(true);
      }
    });
  };

  const onCrop = () => {
    if (cropperRef.current) {
      cropperRef.current.getCanvas()?.toBlob((blob) => {
        saveUserImage(blob);
      });
    } else {
      setNoImgSelected(true);
    }
  };

  const fileDataURL = (file: any) =>
    new Promise((resolve, reject) => {
      let fr = new FileReader();
      fr.onload = () => resolve(fr.result);
      fr.onerror = reject;
      fr.readAsDataURL(file);
    });

  const showResult = (file: any) => {
    if (file) {
      setNoImgSelected(false);
    }
    if (file && file.size && file.size > 5000000) {
      setWrongType(true);
    } else {
      if (
        file &&
        file.type &&
        (file.type === 'image/png' || file.type === 'image/jpeg' || file.type === 'image/jpg')
      ) {
        setWrongType(false);
        const fileType = file.type;
        const isImage = fileType.startsWith('image/');
        if (isImage === true) {
          const imgFormat = fileType.replace('image/', '');
          setImgFormat(imgFormat);
        }
        fileDataURL(file).then((data) => {
          setImgPreview(data);
        });
      } else {
        setWrongType(true);
      }
    }
  };
  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e && e.target && e.target.files) {
      showResult(e.target.files[0]);
    }
  };
  const buttonClickHandler = () => {
    const imgElement = window.document.getElementById('profileImage');
    if (imgElement !== null) {
      imgElement.click();
    }
  };
  const dragOver = (e: any) => {
    e.preventDefault();
  };
  const dragEnter = (e: any) => {
    e.preventDefault();
  };
  const dragLeave = (e: any) => {
    e.preventDefault();
  };
  const fileDrop = (e: any) => {
    e.preventDefault();
    if (e && e.dataTransfer && e.dataTransfer.files) {
      const files = e.dataTransfer.files;
      showResult(files[0]);
    }
  };
  const cancelUpload = () => {
    if (props && props.onCancel) {
      props.onCancel();
    }
  };
  return (
    <div className={styles.edit_profile}>
      <div className={styles.upload_img_header}>
        <span>{translatedKey(KEY_PROFILE_UPLOAD_IMAGE_HEADING)}</span>
      </div>
      <div className={styles.profile_img_action_area}>
        <div className={styles.drag_area}>
          <div
            onDragOver={dragOver}
            onDragEnter={dragEnter}
            onDragLeave={dragLeave}
            onDrop={fileDrop}
          >
            {imgPreview ? (
              <div className={styles.image_preview_container}>
                <Cropper stencilComponent={CircleStencil} ref={cropperRef} src={imgPreview} />
              </div>
            ) : (
              <div className={styles.image_placeholder_container}>
                {props && props.userImage ? (
                  <img src={props.userImage} alt="previewImage" />
                ) : (
                  <div className={styles.no_preview}></div>
                )}
              </div>
            )}
          </div>
          <div className={styles.upload_text_area}>
            <div className={styles.upload_msg_parent}>
              <div className={styles.upload_msg_header}>
                {translatedKey(KEY_PROFILE_UPLOAD_BY_BROWSING_DESKTOP)}
              </div>
              <div className={styles.upload_msg_mobile_header}>
                {translatedKey(KEY_PROFILE_UPLOAD_BY_BROWSING_DEVICE)}
              </div>
              <div className={styles.upload_msg_info}>
                {translatedKey(KEY_PROFILE_ERROR_MESSAGE_ON_SIZE)}
              </div>
            </div>
            <div className={styles.browse_button_parent}>
              <div className={styles.browse_button} onClick={buttonClickHandler}>
                {translatedKey(KEY_PROFILE_BROWSE)}
              </div>
              <input
                id="profileImage"
                className={styles.profile_image_file}
                name="profileImageFile"
                accept=".png, .jpeg, .jpg"
                type="file"
                onChange={handleFileChange}
              />
            </div>
          </div>
        </div>
      </div>
      <div className={styles.error_parent_container}>
        {wrongType && (
          <div className={styles.profile_img_error}>
            {translatedKey(KEY_PROFILE_FILESIZE_VALIDATION)}
          </div>
        )}
        {noImgSelected && (
          <div className={styles.profile_img_error}>
            {translatedKey(KEY_PROFILE_SELECT_PROFILE_IMAGE)}
          </div>
        )}
        {serviceFalied && (
          <div className={styles.profile_img_error}>
            {translatedKey(KEY_PROFILE_UNABLE_TO_SAVE_VALIDATION)}
          </div>
        )}
      </div>
      <div className={styles.button_parent_container}>
        <div className={styles.cancel_container}>
          <button className={styles.cancel_img_upload} onClick={cancelUpload}>
            {translatedKey(KEY_PROFILE_CANCEL)}
          </button>
        </div>
        <div className={styles.save_image_container}>
          <button className={styles.save_img_upload} onClick={onCrop}>
            {translatedKey(KEY_PROFILE_UPLOAD_AND_SAVE)}
          </button>
        </div>
      </div>
    </div>
  );
}
