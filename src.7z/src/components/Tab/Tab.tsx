import { useState, useRef, useEffect } from 'react';
import { Placeholder, Field, useSitecoreContext } from '@sitecore-jss/sitecore-jss-nextjs';
import { getHashString } from 'src/core/utils/utils.helper';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import { getParentClassReference } from 'src/core/utils/utils.helper';
import { Collapse } from 'components/Elements/Collapse/Collapse';
import { CONTENT_100 } from 'src/constants/contentDivider';
import { ComponentProps } from 'lib/component-props';
import { StyleguideSpecimenFields } from 'lib/component-props/styleguide';
import { TAB_ITEM_TITLE } from 'src/constants/general';
import { formatTabData } from 'src/helpers/tab.helper';
import styles from './Tab.module.scss';

type TabComponentProps = ComponentProps &
  StyleguideSpecimenFields & {
    fields: {
      [TAB_ITEM_TITLE]: Field<string>;
    };
  };

const Tab = (props: TabComponentProps) => {
  const formattedData = formatTabData(props);
  const containerRef = useRef<any>(null);
  const slideRef = useRef<any>(null);
  const tabContainerRef = useRef<any>(null);
  const { sitecoreContext } = useSitecoreContext();
  const isExperienceEditor = sitecoreContext && sitecoreContext.pageEditing;
  // const [isFirstSlideDisabled, setIsFirstSlideDisabled] = useState(true);

  const [settings, setSettings] = useState<any>('');
  const [activeId, setActiveId] = useState(null);
  const [activePlaceholder, setActivePlaceholder] = useState(null);
  const [activeTab, setActiveTab] = useState<any>({});
  const [showTabsContainer, setShowTabsContainer] = useState(true);
  const [showSlider, setShowSlider] = useState(false);
  const [placeholderWidth, setPlaceholderWidth] = useState(0);

  useEffect(() => {
    const hash = getHashString();
    const deepLinkId = hash && hash.category ? hash.category : null;
    const selectedItem = formattedData.selectedTab;
    const defaultId = deepLinkId ? deepLinkId : selectedItem;
    setActiveId(defaultId);
    const selectedDefaultItem =
      defaultId && formattedData.items && formattedData.items.length !== 0
        ? formattedData.items.filter((x: any) => x.id == defaultId)
        : null;
    if (
      selectedDefaultItem &&
      selectedDefaultItem[0] &&
      selectedDefaultItem[0].fields &&
      selectedDefaultItem[0].fields.PlaceholderName &&
      selectedDefaultItem[0].fields.PlaceholderName.value
    ) {
      setActivePlaceholder(selectedDefaultItem[0].fields.PlaceholderName.value);
      setActiveTab(selectedDefaultItem[0]);
    }
    const selectedIndex =
      defaultId && formattedData.items && formattedData.items.length !== 0
        ? formattedData.items.findIndex((x: any) => x.id == defaultId)
        : -1;
    if (
      containerRef &&
      containerRef.current &&
      containerRef.current.clientWidth &&
      tabContainerRef &&
      tabContainerRef.current &&
      tabContainerRef.current.clientWidth
    ) {
      const containerWidth = containerRef.current.clientWidth;
      const tabsWidth = tabContainerRef.current.clientWidth;
      if (tabsWidth > containerWidth) {
        setShowTabsContainer(false);
        setShowSlider(true);
      } else {
        setPlaceholderWidth(tabsWidth);
        console.info(placeholderWidth);
      }
    }
    const initializeTab = () => {
      if (slideRef && slideRef.current) {
        slideRef.current.slickGoTo(selectedIndex, false);
      }
    };

    setSettings({
      arrows: false,
      infinite: true,
      draggable: false,
      speed: 500,
      slidesToScroll: 1,
      variableWidth: true,
      className: 'tab_slider',
      onInit: initializeTab(),
      // afterChange: (current: any) => {
      //   if (current === 0) {
      //     setIsFirstSlideDisabled(true);
      //   } else {
      //     setIsFirstSlideDisabled(false);
      //   }
      // }
    });
    let width = window.innerWidth;
    window.addEventListener('resize', function () {
      if (window.innerWidth != width) {
        setSettings({
          arrows: false,
          infinite: true,
          draggable: false,
          speed: 500,
          slidesToScroll: 1,
          variableWidth: true,
          className: 'tab_slider',
          onInit: initializeTab(),
          // afterChange: (current: any) => {
          //   if (current === 0) {
          //     setIsFirstSlideDisabled(true);
          //   } else {
          //     setIsFirstSlideDisabled(false);
          //   }
          // }
        });
      }
    });
  }, []);

  const goPrev = () => {
    if (slideRef && slideRef.current) {
      slideRef.current.slickPrev();
    }
  };
  const goNext = () => {
    if (slideRef && slideRef.current) {
      slideRef.current.slickNext();
    }
  };
  const handleTabClick = (item: any) => {
    setActiveId(item.id);
    if (item.fields && item.fields.PlaceholderName && item.fields.PlaceholderName.value) {
      setActiveTab(item);
      setActivePlaceholder(item.fields.PlaceholderName.value);
    }
    window.location.hash = item.id;
  };
  /**
   * @important This code needs to be used in every components inorder to get the content dividers reference
   * @important Also set the reference (ref) and className to the html wrapper as implemented below
   */
  // starts
  const nodeRef = useRef(null);
  const [parentRef, setParentRef] = useState<any>(null);
  useEffect(() => {
    const child: any = nodeRef.current;
    if (child !== null || child !== undefined) {
      setParentRef(getParentClassReference(child));
    } else {
      setParentRef(CONTENT_100);
    }
  }, []);
  //ends
  return (
    <>
      {isExperienceEditor && (
        <div ref={nodeRef}>
          <h2>Tab Component (This will not be displayed in frontend)</h2>
          <Collapse listData={props} id={parentRef} isTab={true} />
        </div>
      )}
      {!isExperienceEditor && (
        <div className={styles.tab_component_parent}>
          <div className={styles.tab_wrapper} ref={containerRef}>
            <div
              className={`${styles.tab_tile_container} ${
                showTabsContainer ? styles.show_container : styles.hide_container
              }`}
              ref={tabContainerRef}
            >
              {formattedData.items &&
                formattedData.items.map((item: any, index: any) => {
                  return (
                    <a
                      className={`tabitemwrapper ${styles.tab_item} ${
                        activeId === item.id ? styles.active : undefined
                      }`}
                      key={index}
                      onClick={() => handleTabClick(item)}
                    >
                      {item.fields &&
                        item.fields['Tab Title'] &&
                        item.fields['Tab Title'].value && (
                          <div className={styles.tab_name}>{item.fields['Tab Title'].value}</div>
                        )}
                      {/* <div className={styles.tab_name}>{item.displayName}</div>                         */}
                      <div className={styles.tab_border}></div>
                    </a>
                  );
                })}
            </div>
            <div
              className={`${styles.tab_container} ${
                showSlider ? styles.show_slider : styles.hide_slider
              }`}
            >
              <Slider ref={slideRef} {...settings}>
                {formattedData.items &&
                  formattedData.items.map((item: any, index: any) => {
                    return (
                      <a
                        className={`${styles.tab_item} ${
                          activeId === item.id ? styles.active : undefined
                        }`}
                        key={index}
                        onClick={() => handleTabClick(item)}
                      >
                        {item.fields &&
                          item.fields['Tab Title'] &&
                          item.fields['Tab Title'].value && (
                            <div className={styles.tab_name}>{item.fields['Tab Title'].value}</div>
                          )}
                        {/* <div className={styles.tab_name}>{item.displayName}</div>                        */}
                        <div className={styles.tab_border}></div>
                      </a>
                    );
                  })}
              </Slider>
              {showSlider && (
                //  && typeof isFirstSlideDisabled === 'boolean' &&
                //   isFirstSlideDisabled === false
                <div className={styles.bg_left} />
              )}
              {showSlider && <div className={styles.bg_right} />}
            </div>

            {showSlider && (
              <div className={`${styles.button_wrapper} `}>
                <button
                  className={`${styles.previous}               
                ${styles.active}`}
                  onClick={goPrev}
                ></button>
                <button className={`${styles.next} ${styles.active}`} onClick={goNext}></button>
              </div>
            )}
          </div>
          {props &&
          props.fields &&
          props.rendering &&
          formattedData.items &&
          formattedData.items.length !== 0
            ? formattedData.items.map((lItem: any) => {
                // const incrementalIndex = index + 1;
                return (
                  <div
                    key={lItem && lItem.id}
                    // style={placeholderWidth !== 0 ? { width: placeholderWidth } : {}}
                    style={{ width: '100%' }}
                  >
                    <div
                      className={`${styles.placeholder_wrapper} ${
                        lItem.fields &&
                        lItem.fields.PlaceholderName &&
                        lItem.fields.PlaceholderName.value &&
                        activeTab &&
                        activeTab.id &&
                        lItem.id === activeTab.id &&
                        lItem.fields.PlaceholderName.value == activePlaceholder
                          ? styles.show
                          : undefined
                      }`}
                      // data-id="tab-container"
                      id="tab-container"
                    >
                      {lItem.fields &&
                        lItem.fields.PlaceholderName &&
                        lItem.fields.PlaceholderName.value && (
                          <Placeholder
                            name={lItem.fields.PlaceholderName.value}
                            rendering={props.rendering}
                          />
                        )}
                    </div>
                  </div>
                );
              })
            : ''}
        </div>
      )}
    </>
  );
};

export default Tab;
