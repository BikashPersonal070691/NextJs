import { useRef, useState, useEffect } from 'react';
import 'overlayscrollbars/styles/overlayscrollbars.css';
//import { OverlayScrollbarsComponent } from 'overlayscrollbars-react';
import Dropdown from 'components/Elements/Dropdown/Dropdown';
import { Loader } from 'components/Elements/Loader/Loader';
import MultiSelectDropdown from 'components/Elements/MultiselectDropdown/MultiSelectDropdown';
import Toggle from 'components/Elements/Toggle/Toggle';
import styles from './ProfilePopup.module.scss';
import {
  getUserData,
  getDivisionData,
  getCountryData,
  getUserAdditionalData,
  saveProfileSettings,
} from 'src/services/userSettings.service';
import {
  formatData,
  formatSelectOption,
  formatAdditionalData,
  formatSettings,
} from 'src/helpers/profile.helper';
import { KEY_COOKIE_CURRENT_LANGUAGE1, MODAL_TYPE_LOADER } from 'src/constants/general';
import { Modal } from 'components/Elements/Modal/Modal';
import UploadImage from 'components/UploadImage/UploadImage';
import { redirectWithLanguage, setCookie } from 'src/core/utils/utils.helper';
import { useLanguageTranslate } from 'src/hooks/useLanguageTranslate';

import {
  KEY_PROFILE_ADD_CHANNEL,
  KEY_PROFILE_ADD_TAGS,
  KEY_PROFILE_DIVISION_BUSINESS_UNTI,
  KEY_PROFILE_ERROR_MESSAGE,
  KEY_PROFILE_FUNCTION_UNIT,
  KEY_PROFILE_LOCATION,
  KEY_PROFILE_PLEASE_ENTER_VALID_ENTRY,
  KEY_PROFILE_CHANNELS_PROFILE_NOT_SELECTED_ERROR,
  KEY_PROFILE_SAVE,
  KEY_PROFILE_SSUCCESS,
} from 'src/constants/dictonary';

export default function ProfilePopup(props: any) {
  const { translatedKey } = useLanguageTranslate();
  const [navWidth, setNavWidth] = useState(0);
  const [navLeft, setNavLeft] = useState(0);
  const [activeTab, setActiveTab] = useState<any>();
  const [userData, setUserData] = useState<any>();
  const [userAdditionalData, setUserAdditionalData] = useState<any>();
  const [saveFunctionError, setSaveFunctionError] = useState(false);
  const [saveFunctionSuccess, setSaveFunctionSuccess] = useState(false);
  const [showImageUploadTab, setShowImageUploadTab] = useState(false);
  const [userProfileImage, setUserProfileImage] = useState<any>();
  const [isDataLoaded, setIsDataLoaded] = useState<any>(false);
  const [isChannelInteractionOn, setIsChannelInteractionOn] = useState(false);
  const [isTopicInteractionOn, setIsTopicInteractionOn] = useState(false);
  const [noDivisionData, setNoDivisionData] = useState(false);
  const [noLanguageData, setNoLanguageData] = useState(false);
  const firstTabRef = useRef<any>(null);
  const secondTabRef = useRef<any>(null);
  const thirdTabRef = useRef<any>(null);
  const fourthTabRef = useRef<any>(null);
  const getData = () => {
    getUserData().then((data: any) => {
      if (data && data.data) {
        const formattedData = formatData(data.data);
        setUserData(formattedData);
        setIsDataLoaded(true);
      }
    });
    getUserAdditionalData().then((data: any) => {
      if (data && data.data) {
        const refinedData = formatAdditionalData(data.data);
        setUserAdditionalData(refinedData);
      }
    });
  };

  useEffect(() => {
    let body = document.body;
    body.classList.add('noScroll');
    if (props && props.userImage) {
      setUserProfileImage(props.userImage);
    }
    getData();
  }, []);
  useEffect(() => {
    if (firstTabRef && firstTabRef.current && firstTabRef.current.clientWidth) {
      setNavWidth(firstTabRef.current.clientWidth);
      setNavLeft(0);
      setActiveTab('profile');
    }
  }, [isDataLoaded]);

  const handleFirstTabClick = () => {
    if (firstTabRef && firstTabRef.current && firstTabRef.current.clientWidth) {
      setNavWidth(firstTabRef.current.clientWidth);
      setNavLeft(0);
      setActiveTab('profile');
    }
  };
  const handleSecondTabClick = () => {
    if (
      secondTabRef &&
      secondTabRef.current &&
      secondTabRef.current.clientWidth &&
      secondTabRef.current.offsetLeft
    ) {
      setNavWidth(secondTabRef.current.clientWidth);
      setNavLeft(secondTabRef.current.offsetLeft);
      setActiveTab('channel');
    }
  };
  const handleThirdTabClick = () => {
    if (
      thirdTabRef &&
      thirdTabRef.current &&
      thirdTabRef.current.clientWidth &&
      thirdTabRef.current.offsetLeft
    ) {
      setNavWidth(thirdTabRef.current.clientWidth);
      setNavLeft(thirdTabRef.current.offsetLeft);
      setActiveTab('topic');
    }
  };
  const handleFourthTabClick = () => {
    if (
      fourthTabRef &&
      fourthTabRef.current &&
      fourthTabRef.current.clientWidth &&
      fourthTabRef.current.offsetLeft
    ) {
      setNavWidth(fourthTabRef.current.clientWidth);
      setNavLeft(fourthTabRef.current.offsetLeft);
      setActiveTab('newsletter');
    }
  };
  const handleDivisionChange = (value: any, label: any, options: any) => {
    if (noDivisionData) {
      setNoDivisionData(false);
    }
    getDivisionData(value).then((data: any) => {
      if (data && data.data) {
        const newFunctionData = data.data;
        if (Array.isArray(newFunctionData) && newFunctionData.length > 0) {
          const newOptions: any = formatSelectOption(data.data);
          setUserData({
            ...userData,
            DivisionData: {
              options: options,
              value: { value: value, label: label },
            },
            FunctionData: {
              options: newOptions,
              value: { value: newOptions[0].value, label: newOptions[0].label },
            },
            isProfileDataEmpty:
              userData &&
              userData.CountryData &&
              userData.CountryData.value &&
              userData.LocationData &&
              userData.LocationData.value &&
              userData.LanguageData &&
              userData.LanguageData.value
                ? false
                : true,
          });
        } else {
          setUserData({
            ...userData,
            DivisionData: {
              options: options,
              value: { value: value, label: label },
            },
            isProfileDataEmpty:
              userData &&
              userData.CountryData &&
              userData.CountryData.value &&
              userData.LocationData &&
              userData.LocationData.value &&
              userData.LanguageData &&
              userData.LanguageData.value
                ? false
                : true,
          });
        }
      } else {
        setUserData({
          ...userData,
          DivisionData: {
            options: options,
            value: { value: value, label: label },
          },
          isProfileDataEmpty:
            userData &&
            userData.CountryData &&
            userData.CountryData.value &&
            userData.LocationData &&
            userData.LocationData.value &&
            userData.LanguageData &&
            userData.LanguageData.value
              ? false
              : true,
        });
      }
    });
  };
  const handleFunctionChange = (value: any, label: any, options: any) => {
    setUserData({
      ...userData,
      FunctionData: {
        options: options,
        value: { value: value, label: label },
      },
    });
  };
  const handleLanguageChange = (value: any, label: any, options: any) => {
    if (noLanguageData) {
      setNoLanguageData(false);
    }
    setUserData({
      ...userData,
      LanguageData: {
        options: options,
        value: { value: value, label: label },
      },
      isProfileDataEmpty:
        userData &&
        userData.CountryData &&
        userData.CountryData.value &&
        userData.LocationData &&
        userData.LocationData.value &&
        userData.DivisionData &&
        userData.DivisionData.value
          ? false
          : true,
    });
  };
  const handleCountryChange = (value: any, label: any, options: any) => {
    getCountryData(value).then((data: any) => {
      if (data && data.data) {
        const newData = data.data;
        if (
          newData.lstLocation &&
          Array.isArray(newData.lstLocation) &&
          newData.lstLocation.length > 0
        ) {
          if (
            newData.lstLanguage &&
            Array.isArray(newData.lstLanguage) &&
            newData.lstLanguage.length > 0
          ) {
            const newLocationOptions: any = formatSelectOption(newData.lstLocation);
            const newLanguageOptions: any = formatSelectOption(newData.lstLanguage);
            setUserData({
              ...userData,
              CountryData: {
                options: options,
                value: { value: value, label: label },
              },
              LocationData: {
                options: newLocationOptions,
                value: { value: newLocationOptions[0].value, label: newLocationOptions[0].label },
              },
              LanguageData: {
                options: newLanguageOptions,
                value: { value: newLanguageOptions[0].value, label: newLanguageOptions[0].label },
              },
              isProfileDataEmpty:
                userData && userData.DivisionData && userData.DivisionData.value ? false : true,
            });
          } else {
            const newOptions: any = formatSelectOption(newData.lstLocation);
            setUserData({
              ...userData,
              CountryData: {
                options: options,
                value: { value: value, label: label },
              },
              LocationData: {
                options: newOptions,
                value: { value: newOptions[0].value, label: newOptions[0].label },
              },
              isProfileDataEmpty:
                userData &&
                userData.LanguageData &&
                userData.LanguageData.value &&
                userData.DivisionData &&
                userData.DivisionData.value
                  ? false
                  : true,
            });
          }
        } else {
          if (
            newData.lstLanguage &&
            Array.isArray(newData.lstLanguage) &&
            newData.lstLanguage.length > 0
          ) {
            const newOptions: any = formatSelectOption(newData.lstLanguage);
            setUserData({
              ...userData,
              CountryData: {
                options: options,
                value: { value: value, label: label },
              },
              LanguageData: {
                options: newOptions,
                value: { value: newOptions[0].value, label: newOptions[0].label },
              },
              isProfileDataEmpty:
                userData &&
                userData.LocationData &&
                userData.LocationData.value &&
                userData.DivisionData &&
                userData.DivisionData.value
                  ? false
                  : true,
            });
          } else {
            setUserData({
              ...userData,
              CountryData: {
                options: options,
                value: { value: value, label: label },
              },
              isProfileDataEmpty:
                userData &&
                userData.LocationData &&
                userData.LocationData.value &&
                userData.DivisionData &&
                userData.DivisionData.value &&
                userData.LanguageData &&
                userData.LanguageData.value
                  ? false
                  : true,
            });
          }
        }
      } else {
        setUserData({
          ...userData,
          CountryData: {
            options: options,
            value: { value: value, label: label },
          },
          isProfileDataEmpty:
            userData &&
            userData.LocationData &&
            userData.LocationData.value &&
            userData.DivisionData &&
            userData.DivisionData.value &&
            userData.LanguageData &&
            userData.LanguageData.value
              ? false
              : true,
        });
      }
    });
    //
  };
  const handleLocationChange = (value: any, label: any, options: any) => {
    setUserData({
      ...userData,
      LocationData: {
        options: options,
        value: { value: value, label: label },
      },
      isProfileDataEmpty:
        userData &&
        userData.CountryData &&
        userData.CountryData.value &&
        userData.LanguageData &&
        userData.LanguageData.value &&
        userData.DivisionData &&
        userData.DivisionData.value
          ? false
          : true,
    });
  };
  const removeObjectWithId = (arr: any, id: any) => {
    const valueCopy = [...arr];
    const objWithIdIndex = valueCopy.findIndex((obj: { value: any }) => obj.value === id);
    if (objWithIdIndex > -1) {
      valueCopy.splice(objWithIdIndex, 1);
    }
    return valueCopy;
  };
  const handleChannelDeselection = (event: any) => {
    let userEditedData = null;
    if (
      userAdditionalData &&
      userAdditionalData.channelData &&
      userAdditionalData.channelData.value
    ) {
      const newValues = removeObjectWithId(
        userAdditionalData.channelData.value,
        event.target.dataset.value
      );
      if (userAdditionalData && userAdditionalData.channelData) {
        if (newValues && Array.isArray(newValues) && newValues.length > 4) {
          userEditedData = {
            ...userAdditionalData.channelData,
            value: newValues,
            deactivateSelection: true,
          };
        } else {
          userEditedData = {
            ...userAdditionalData.channelData,
            value: newValues,
            deactivateSelection: false,
          };
        }
      }
      const editedUserAdditionalData = { ...userAdditionalData, channelData: userEditedData };
      setUserAdditionalData(editedUserAdditionalData);
    }
  };
  const handleTopicDeselection = (event: any) => {
    let userEditedData = null;
    if (userAdditionalData && userAdditionalData.topicData && userAdditionalData.topicData.value) {
      const newValues = removeObjectWithId(
        userAdditionalData.topicData.value,
        event.target.dataset.value
      );
      if (userAdditionalData && userAdditionalData.topicData) {
        if (newValues && Array.isArray(newValues) && newValues.length > 9) {
          userEditedData = {
            ...userAdditionalData.topicData,
            value: newValues,
            deactivateSelection: true,
          };
        } else {
          userEditedData = {
            ...userAdditionalData.topicData,
            value: newValues,
            deactivateSelection: false,
          };
        }
      }
      const editedUserAdditionalData = { ...userAdditionalData, topicData: userEditedData };
      setUserAdditionalData(editedUserAdditionalData);
    }
  };
  const handleSubscriptionChange = (data: any) => {
    setUserData({
      ...userData,
      SubscribeToNewsLetter: data,
    });
  };
  const handleCloseIconClick = () => {
    if (props && props.onClose) {
      props.onClose();
    }
  };
  const saveData = (dataToSave: any) => {
    

    saveProfileSettings(dataToSave).then((data: any) => {
      if (data && data.status && data.status === 200) {
        setSaveFunctionSuccess(true);
        getUserData().then((response: any) => {
          if (response && response.data) {
            const languageCode =
              response.data.UserProfile && response.data.UserProfile.LanguageCode
                ? response.data.UserProfile.LanguageCode
                : '';
            setCookie(KEY_COOKIE_CURRENT_LANGUAGE1, languageCode);
            if (languageCode == '') {
              window.location.reload();
            } else {
              redirectWithLanguage(languageCode);
            }
          } else {
            window.location.reload();
          }
        });
      } else {
        setSaveFunctionError(true);
      }
    });
  };
  const saveAll = () => {
    const dataToSave = formatSettings(userData, userAdditionalData);
    if (userData && userData.DivisionData && !userData.DivisionData.value) {
      setNoDivisionData(true);
      if (userData && userData.DivisionData && !userData.LanguageData.value) {
        setNoLanguageData(true);
      }
    } else {
      saveData(dataToSave);
    }
  };
  const handleChannelError = () => {
    if (typeof isChannelInteractionOn === 'boolean' && isChannelInteractionOn === false) {
      setIsChannelInteractionOn(true);
    }
  };
  const handleChannelChange = (data: any) => {
    let userEditedData = null;
    if (userAdditionalData && userAdditionalData.channelData) {
      if (data && Array.isArray(data) && data.length > 4) {
        userEditedData = {
          ...userAdditionalData.channelData,
          value: data,
          deactivateSelection: true,
        };
      } else {
        userEditedData = {
          ...userAdditionalData.channelData,
          value: data,
          deactivateSelection: false,
        };
      }
    }
    const editedUserAdditionalData = { ...userAdditionalData, channelData: userEditedData };
    setUserAdditionalData(editedUserAdditionalData);
  };
  const handleTopicError = () => {
    if (typeof isTopicInteractionOn === 'boolean' && isTopicInteractionOn === false) {
      setIsTopicInteractionOn(true);
    }
  };
  const handleTopicChange = (data: any) => {
    let userEditedData = null;
    if (userAdditionalData && userAdditionalData.topicData) {
      if (data && Array.isArray(data) && data.length > 9) {
        userEditedData = {
          ...userAdditionalData.topicData,
          value: data,
          deactivateSelection: true,
        };
      } else {
        userEditedData = {
          ...userAdditionalData.topicData,
          value: data,
          deactivateSelection: false,
        };
      }
    }
    const editedUserAdditionalData = { ...userAdditionalData, topicData: userEditedData };
    setUserAdditionalData(editedUserAdditionalData);
  };
  const handleShowUploadScreen = () => {
    setShowImageUploadTab(!showImageUploadTab);
  };
  const handleNewUserImageUpload = (data: any) => {
    setUserProfileImage(data);
  };
  return (
    <>
      {isDataLoaded ? (
        <div className={styles.popup_container}>
          {/* <div className={styles.popup_bg} onClick={handleCloseIconClick}></div> */}
          <Modal
            showModal={true}
            type={MODAL_TYPE_LOADER}
            closeOnClickBackground={handleCloseIconClick}
            showHeader={true}
          >
            <div className={styles.popup_wrapper}>
              <div className={styles.content_container}>
                <div onClick={handleCloseIconClick} className={styles.go_back}>
                  <i className={styles.go_back_icon}></i> Go back
                </div>
                <i className={styles.close_icon} onClick={handleCloseIconClick}></i>
                <div className={styles.tabs_container}>
                  <div className={styles.section_tabs}>
                    <div
                      className={`${styles.section_tab} ${
                        activeTab === 'profile' ? styles.active : undefined
                      }`}
                      ref={firstTabRef}
                      onClick={handleFirstTabClick}
                    >
                      {userData && userData.tab1 ? userData.tab1 : ''}
                    </div>
                    <div
                      className={`${styles.section_tab} ${
                        activeTab === 'channel' ? styles.active : undefined
                      }`}
                      ref={secondTabRef}
                      onClick={handleSecondTabClick}
                    >
                      {userData && userData.tab2 ? userData.tab2 : ''}
                    </div>
                    <div
                      className={`${styles.section_tab} ${
                        activeTab === 'topic' ? styles.active : undefined
                      }`}
                      ref={thirdTabRef}
                      onClick={handleThirdTabClick}
                    >
                      {userData && userData.tab3 ? userData.tab3 : ''}
                    </div>
                    <div
                      className={`${styles.section_tab} ${
                        activeTab === 'newsletter' ? styles.active : undefined
                      }`}
                      ref={fourthTabRef}
                      onClick={handleFourthTabClick}
                    >
                      {userData && userData.tab4 ? userData.tab4 : ''}
                    </div>
                    <span
                      className={styles.active_indicator}
                      style={{ left: navLeft, width: navWidth }}
                    ></span>
                  </div>
                </div>
                <div className={styles.user_details_container}>
                  <div
                    className={`${styles.profile_container} ${
                      activeTab === 'profile' ? styles.active : undefined
                    }`}
                  >
                    {showImageUploadTab ? (
                      <UploadImage
                        userImage={userProfileImage}
                        onCancel={handleShowUploadScreen}
                        onUpload={handleNewUserImageUpload}
                      />
                    ) : (
                      <>
                        <div className={styles.settings_msg}>
                          {userData && userData.welcomeText && (
                            <div
                              className={styles.welcome_note}
                              dangerouslySetInnerHTML={{ __html: userData.welcomeText }}
                            />
                          )}
                          <div className={styles.image_container}>
                            <div className={styles.image_holder}>
                              {userProfileImage ? (
                                <img className={styles.has_image} src={userProfileImage} alt="" />
                              ) : (
                                <div className={styles.no_image}></div>
                              )}
                              <div
                                className={styles.edit_profile_icon_mobile}
                                onClick={handleShowUploadScreen}
                              ></div>
                            </div>
                            <div
                              className={styles.edit_profile_icon}
                              onClick={handleShowUploadScreen}
                            ></div>
                          </div>
                        </div>
                        <div className={styles.select_group_container}>
                          <div className={styles.select_group_one}>
                            {userData && userData.DivisionData && (
                              <div className={styles.dropdown_wrapper}>
                                <Dropdown
                                  userSelection={userData.DivisionData}
                                  onChange={handleDivisionChange}
                                  subHeadline={translatedKey(KEY_PROFILE_DIVISION_BUSINESS_UNTI)}
                                  showError={noDivisionData}
                                />
                                {noDivisionData && (
                                  <div className={styles.save_error_msg}>
                                    {translatedKey(KEY_PROFILE_PLEASE_ENTER_VALID_ENTRY)}
                                  </div>
                                )}
                              </div>
                            )}
                            {userData && userData.FunctionData && (
                              <div className={styles.dropdown_wrapper}>
                                <Dropdown
                                  userSelection={userData.FunctionData}
                                  onChange={handleFunctionChange}
                                  subHeadline={translatedKey(KEY_PROFILE_FUNCTION_UNIT)}
                                />
                              </div>
                            )}
                            {userData && userData.LanguageData && (
                              <div className={styles.dropdown_wrapper}>
                                <Dropdown
                                  userSelection={userData.LanguageData}
                                  onChange={handleLanguageChange}
                                  subHeadline="Language"
                                  showError={noLanguageData}
                                />
                                {noLanguageData && (
                                  <div className={styles.save_error_msg}>
                                    {translatedKey(KEY_PROFILE_PLEASE_ENTER_VALID_ENTRY)}
                                  </div>
                                )}
                              </div>
                            )}
                          </div>
                          <div className={styles.select_group_two}>
                            {userData && userData.CountryData && (
                              <div className={styles.dropdown_wrapper}>
                                <Dropdown
                                  userSelection={userData.CountryData}
                                  onChange={handleCountryChange}
                                  subHeadline="Country/Region"
                                />
                                {noDivisionData && (
                                  <div className={styles.save_error_dummy_msg}></div>
                                )}
                              </div>
                            )}
                            {userData && userData.LocationData && (
                              <div className={styles.dropdown_wrapper}>
                                <Dropdown
                                  userSelection={userData.LocationData}
                                  onChange={handleLocationChange}
                                  subHeadline={translatedKey(KEY_PROFILE_LOCATION)}
                                />
                              </div>
                            )}
                          </div>
                        </div>
                      </>
                    )}
                  </div>
                  <div
                    className={`${styles.channels_container} ${
                      activeTab === 'channel' ? styles.active : undefined
                    }`}
                  >
                    {userData && userData.channelText && (
                      <div className={styles.settings_msg}>{userData.channelText}</div>
                    )}
                    {userData && userData.isProfileDataEmpty && (
                      <p className={styles.profile_not_selected_error}>
                        {translatedKey(KEY_PROFILE_CHANNELS_PROFILE_NOT_SELECTED_ERROR)}
                      </p>
                    )}
                    <div className={styles.selected_container}>
                      {userAdditionalData &&
                        userAdditionalData.channelData &&
                        userAdditionalData.channelData.value && (
                          <>
                            {userAdditionalData.channelData.value.map(
                              (optionItem: any, index: number) => {
                                return (
                                  <div className={styles.channel} key={index}>
                                    <span className={styles.channel_name}>
                                      {optionItem.label}
                                      {optionItem.path ? ' / ' + optionItem.path : ''}
                                    </span>
                                    <i
                                      className={styles.icon_small_close_grey}
                                      data-value={optionItem.value}
                                      data-label={optionItem.label}
                                      onClick={handleChannelDeselection}
                                    ></i>
                                  </div>
                                );
                              }
                            )}
                          </>
                        )}
                    </div>
                    {userData && userData.ChannelSelectedMsg && (
                      <div
                        className={`${styles.channel_select_msg} ${
                          userData && userData.isProfileDataEmpty ? styles.disabled : undefined
                        }`}
                      >
                        {userData.ChannelSelectedMsg}
                      </div>
                    )}
                    {userAdditionalData &&
                      userAdditionalData.channelData &&
                      userAdditionalData.channelData.deactivateSelection &&
                      isChannelInteractionOn &&
                      userData &&
                      userData.ChannelMaxMsg && (
                        <div className={styles.error_message_selection}>
                          {userData.ChannelMaxMsg}
                        </div>
                      )}
                    {userAdditionalData &&
                      userAdditionalData.channelData &&
                      userData &&
                      userData.noChannelFoundMsg && (
                        <MultiSelectDropdown
                          userSelection={userAdditionalData.channelData}
                          handleSelect={handleChannelChange}
                          handleError={handleChannelError}
                          placeholder={translatedKey(KEY_PROFILE_ADD_CHANNEL)}
                          noItemFoundMsg={userData.noChannelFoundMsg}
                          isDisabled={userData.isProfileDataEmpty ? true : false}
                        />
                      )}
                  </div>
                  <div
                    className={`${styles.topics_container} ${
                      activeTab === 'topic' ? styles.active : undefined
                    }`}
                  >
                    {userData && userData.TopicText && (
                      <div className={styles.settings_msg}>{userData.TopicText}</div>
                    )}
                    {userData && userData.isProfileDataEmpty && (
                      <p className={styles.profile_not_selected_error}>
                        {translatedKey(KEY_PROFILE_CHANNELS_PROFILE_NOT_SELECTED_ERROR)}
                      </p>
                    )}
                    <div className={styles.selected_container}>
                      {userAdditionalData &&
                        userAdditionalData.topicData &&
                        userAdditionalData.topicData.value && (
                          <>
                            {userAdditionalData.topicData.value.map(
                              (optionItem: any, index: number) => {
                                return (
                                  <div className={styles.channel} key={index}>
                                    <span className={styles.channel_name}>
                                      {optionItem.label}
                                      {optionItem.path ? ' / ' + optionItem.path : ''}
                                    </span>
                                    <i
                                      className={styles.icon_small_close_grey}
                                      data-value={optionItem.value}
                                      data-label={optionItem.label}
                                      onClick={handleTopicDeselection}
                                    ></i>
                                  </div>
                                );
                              }
                            )}
                          </>
                        )}
                    </div>
                    {userData && userData.TagsSelectedMsg && (
                      <div
                        className={`${styles.channel_select_msg} ${
                          userData && userData.isProfileDataEmpty ? styles.disabled : undefined
                        }`}
                      >
                        {userData.TagsSelectedMsg}
                      </div>
                    )}
                    {userAdditionalData &&
                      userAdditionalData.topicData &&
                      userAdditionalData.topicData.deactivateSelection &&
                      isTopicInteractionOn &&
                      userData &&
                      userData.MaxTagsErrorMsg && (
                        <div className={styles.error_message_selection}>
                          {userData.MaxTagsErrorMsg}
                        </div>
                      )}
                    {userAdditionalData &&
                      userAdditionalData.topicData &&
                      userData &&
                      userData.noChannelFoundMsg && (
                        <MultiSelectDropdown
                          userSelection={userAdditionalData.topicData}
                          handleSelect={handleTopicChange}
                          handleError={handleTopicError}
                          placeholder={translatedKey(KEY_PROFILE_ADD_TAGS)}
                          noItemFoundMsg={userData.noChannelFoundMsg}
                          isDisabled={userData.isProfileDataEmpty ? true : false}
                        />
                      )}
                  </div>
                  <div
                    className={`${styles.newsletter_container} ${
                      activeTab === 'newsletter' ? styles.active : undefined
                    }`}
                  >
                    {userData && userData.NewsletterWelcomeText && (
                      <div className={styles.settings_msg}>{userData.NewsletterWelcomeText}</div>
                    )}
                    <div className={styles.checkbox_container}>
                      {userData && userData.NewsletterTitle && (
                        <div className={styles.newsletter_label}>{userData.NewsletterTitle}</div>
                      )}
                      <div className={styles.checkbox}>
                        {userData && userData.NewsletterSuscribeText && (
                          <span className={styles.ch_label}>{userData.NewsletterSuscribeText}</span>
                        )}
                        <Toggle
                          isChecked={
                            userData && userData.SubscribeToNewsLetter
                              ? userData.SubscribeToNewsLetter
                              : false
                          }
                          onChange={handleSubscriptionChange}
                        />
                      </div>
                    </div>
                  </div>
                  {!showImageUploadTab && (
                    <div className={styles.button_container}>
                      <div
                        className={`${styles.button_wrapper} ${
                          saveFunctionError ? styles.isError : undefined
                        }`}
                      >
                        {saveFunctionError && (
                          <span className={styles.user_settings_error_message}>
                            {translatedKey(KEY_PROFILE_ERROR_MESSAGE)}
                          </span>
                        )}
                        {saveFunctionSuccess ? (
                          <button className={styles.user_submit_success}>
                            <span>{translatedKey(KEY_PROFILE_SSUCCESS)}</span>
                            <div className={styles.success}></div>
                          </button>
                        ) : (
                          <button className={styles.user_submit} onClick={saveAll}>
                            {translatedKey(KEY_PROFILE_SAVE)}
                            {/* SAVE ALL SETTINGS */}
                          </button>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>
              {/* </OverlayScrollbarsComponent> */}
            </div>
          </Modal>
        </div>
      ) : (
        <Loader />
      )}
    </>
  );
}
