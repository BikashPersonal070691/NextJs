import React, { useContext } from 'react';
import { MenuContext } from 'src/contexts/MenuContext';
import styles from './MegaMenu.module.scss';
import { getChildMenus } from 'src/services/menu.service';
// import useSWR from 'swr';

// const fetcher = (url: any) => fetch(url).then(res => res.json());
export function MegaMenu() {
  // const { data } = useSWR('/api/getChildMenus', fetcher);

  const {
    selectedItems,
    setSelectedItems,
    activeMenu,
    secondLevelItems,
    setSecondLevelItems,
    thirdLevelItems,
    setThirdLevelItems,
    fourthLevelItems,
    setFourthLevelItems,
    fifthLevelItems,
    setFifthLevelItems,
    sixthLevelItems,
    setSixthLevelItems,
  } = useContext(MenuContext);

  const addSelectedClass = (id: any, level: any) => {
    for (let i = level; i < 7; i++) {
      const cusid_ele = document.getElementsByClassName(`level_${level}`);
      for (let i = 0; i < cusid_ele.length; ++i) {
        cusid_ele[i].classList.remove(styles.selected_menu);
      }
    }
    let element: any = document.getElementById(id);
    element.classList.add(styles.selected_menu);
  };

  const getSecondLevelItems = (item: any, id: any, level: any) => {
    setSecondLevelItems({});
    setThirdLevelItems({});
    setFourthLevelItems({});
    setSixthLevelItems({});
    getChildMenus(item.RootID, activeMenu.TemplateID).then((data: any) => {
      if (data && data.data) {
        setSecondLevelItems(data.data);
      }
    });
    // setSecondLevelItems(data);
    addSelectedClass(id, level);
  };

  const getThirdLevelItems = (item: any, id: any, level: any) => {
    setThirdLevelItems({});
    setFourthLevelItems({});
    setFifthLevelItems({});
    setSixthLevelItems({});
    setThirdLevelItems(item.Children && item.Children);
    addSelectedClass(id, level);
  };

  const getFourthLevelItems = (item: any, id: any, level: any) => {
    setFourthLevelItems({});
    setFifthLevelItems({});
    setSixthLevelItems({});
    setFourthLevelItems(item.Children && item.Children);
    addSelectedClass(id, level);
  };

  const getFifthLevelItems = (item: any, id: any, level: any) => {
    setFifthLevelItems({});
    setSixthLevelItems({});
    setFifthLevelItems(item.Children && item.Children);
    addSelectedClass(id, level);
  };

  const getSixthLevelItems = (item: any, id: any, level: any) => {
    setSixthLevelItems({});
    setSixthLevelItems(item.Children && item.Children);
    addSelectedClass(id, level);
  };

  const getListItem = (item: any, index: any, fn: any, level: any) => {
    const id = `${item.RootID}_${index}`;
    return (
      <li
        // className={`${styles.sub_level_li} ${item.HasChildren ? styles.has_child : styles.no_child}`}
        className={`${styles.sub_level_li} `}
        key={index}
      >
        <a
          href={item.URL}
          className={`${styles.sub_menu_link} ${
            item.InActiveInNavigation ? styles.inactive_sub_menu_link : styles.active_sub_menu_link
          }`}
          target={item.NewWindow ? '_blank' : '_self'}
        >
          {item.Text}
        </a>

        {item && item.HasChildren ? (
          <>
            <span className={styles.icon_seperation_bar}></span>
            <div
              className={styles.arrow_container}
              onClick={() => {
                fn(item, id, level);
              }}
            >
              <span
                id={id}
                className={`${styles.right} ${styles.arrow_span} level_${level}`}
              ></span>
            </div>
          </>
        ) : (
          ''
        )}
      </li>
    );
  };

  return (
    <div className={styles.mega_menu}>
      <div className={styles.sub_level_menu}>
        <div className={styles.first_level_sub}>
          <ul className={`${styles.sub_level_ul} ${styles.sub_first}`}>
            {selectedItems &&
            selectedItems['Personalized'] &&
            Array.isArray(selectedItems['Personalized'])
              ? selectedItems['Personalized'].map((item, index) =>
                  getListItem(item, index, getSecondLevelItems, 2)
                )
              : null}
          </ul>
          <ul className={`${styles.sub_level_ul} ${styles.sub_first}`}>
            {selectedItems &&
            selectedItems['Personalized'] &&
            Array.isArray(selectedItems['Personalized']) &&
            selectedItems['Personalized'].length > 1 &&
            selectedItems['General'] &&
            Array.isArray(selectedItems['General']) ? (
              <li className={styles.group_border}></li>
            ) : null}

            {selectedItems && selectedItems['General'] && Array.isArray(selectedItems['General'])
              ? selectedItems['General'].map((item, index) =>
                  getListItem(item, index, getSecondLevelItems, 2)
                )
              : null}
          </ul>
        </div>
      </div>

      {secondLevelItems && Object.keys(secondLevelItems).length !== 0 ? (
        <div className={`${styles.child_level_menu_container} ${styles.active}`}>
          <ul className={styles.sub_level_ul}>
            {secondLevelItems && Array.isArray(secondLevelItems)
              ? secondLevelItems.map((item, index) =>
                  getListItem(item, index, getThirdLevelItems, 3)
                )
              : null}
          </ul>
        </div>
      ) : (
        ''
      )}

      {thirdLevelItems && Object.keys(thirdLevelItems).length !== 0 ? (
        <div className={`${styles.child_level_menu_container} ${styles.active}`}>
          <ul className={styles.sub_level_ul}>
            {thirdLevelItems && Array.isArray(thirdLevelItems)
              ? thirdLevelItems.map((item, index) =>
                  getListItem(item, index, getFourthLevelItems, 4)
                )
              : null}
          </ul>
        </div>
      ) : (
        ''
      )}

      {fourthLevelItems && Object.keys(fourthLevelItems).length !== 0 ? (
        <div className={`${styles.child_level_menu_container} ${styles.active}`}>
          <ul className={styles.sub_level_ul}>
            {fourthLevelItems && Array.isArray(fourthLevelItems)
              ? fourthLevelItems.map((item, index) =>
                  getListItem(item, index, getFifthLevelItems, 5)
                )
              : null}
          </ul>
        </div>
      ) : (
        ''
      )}

      {fifthLevelItems && Object.keys(fifthLevelItems).length !== 0 ? (
        <div className={`${styles.child_level_menu_container} ${styles.active}`}>
          <ul className={styles.sub_level_ul}>
            {fifthLevelItems && Array.isArray(fifthLevelItems)
              ? fifthLevelItems.map((item, index) =>
                  getListItem(item, index, getSixthLevelItems, 6)
                )
              : null}
          </ul>
        </div>
      ) : (
        ''
      )}

      {sixthLevelItems && Object.keys(sixthLevelItems).length !== 0 ? (
        <div className={`${styles.child_level_menu_container} ${styles.active}`}>
          <ul className={styles.sub_level_ul}>
            {sixthLevelItems && Array.isArray(sixthLevelItems)
              ? sixthLevelItems.map((item, index) =>
                  getListItem(item, index, getSixthLevelItems, 6)
                )
              : null}
          </ul>
        </div>
      ) : (
        ''
      )}
      {/* &nbsp;&nbsp; */}
      <div
        onClick={() => {
          setSelectedItems({});
        }}
        className={`${styles.common_close_button}`}
      ></div>
    </div>
  );
}
