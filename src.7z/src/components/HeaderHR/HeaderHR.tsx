export default function HeaderHR() {
  return <></>;
}
