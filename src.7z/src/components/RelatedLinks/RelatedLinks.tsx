import styles from './RelatedLinks.module.scss';
import { useState, useEffect, useRef } from 'react';
import { ComponentProps } from 'lib/component-props';
import { Image, Text, RichText } from '@sitecore-jss/sitecore-jss-nextjs';
import { getParentClassReference, getParentAttributeReference } from 'src/core/utils/utils.helper';
//import { StyleguideSpecimenFields } from 'lib/component-props/styleguide';
import { CONTENT_100 } from 'src/constants/contentDivider';
type RelatedLinksComponentProps = ComponentProps;
const RelatedLinks = (props: RelatedLinksComponentProps) => {
  //export function RelatedLinks() {
  

  //   let data= {
  //     "uid": "1b1d33c0-3ed8-4493-a985-7b8cddb0ddb5",
  //     "componentName": "RelatedLinks",
  //     "dataSource": "{710EF6D6-A441-4F25-9D6F-DD5AAAA79E81}",
  //     "params": {

  //     },
  //     "fields": {
  //       "Relatedlinks Image": {
  //         "value": {

  //         }
  //       },
  //       "Select links for headless": [
  //         {
  //           "id": "42173634-9c9c-41f6-bb98-2e1b4cb3b295",
  //           "url": "/en/my_hr/global/home/my_hr/hr-pagecontent/content-folder/relatedlinkscomponent-folder/relatedlinks/test1",
  //           "name": "test1",
  //           "displayName": "test1",
  //           "fields": {
  //             "Link Item": {
  //               "value": {
  //                 "href": "https://cd.uat1.bayernet.int.bayer.com/en/",
  //                 "text": "group",
  //                 "anchor": "",
  //                 "linktype": "internal",
  //                 "class": "",
  //                 "title": "",
  //                 "target": "",
  //                 "querystring": "",
  //                 "id": "{87297F94-CA86-446E-8046-E6B9AAE703A6}"
  //               }
  //             },
  //             "Is Active": {
  //               "value": true
  //             }
  //           }
  //         },
  //         {
  //           "id": "a8a1278f-2490-4fce-90de-ef04493b7508",
  //           "url": "/en/my_hr/global/home/my_hr/hr-pagecontent/content-folder/relatedlinkscomponent-folder/relatedlinks/test2",
  //           "name": "test2",
  //           "displayName": "test2",
  //           "fields": {
  //             "Link Item": {
  //               "value": {
  //                 "href": "",
  //                 "text": "feed",
  //                 "anchor": "",
  //                 "linktype": "internal",
  //                 "class": "",
  //                 "title": "",
  //                 "target": "",
  //                 "querystring": "",
  //                 "id": "{52821074-5414-41D9-89B0-8168356427E6}"
  //               }
  //             },
  //             "Is Active": {
  //               "value": true
  //             }
  //           }
  //         }
  //       ],
  //       "Relatedlinks Default Text": {
  //         "value": "Please select"
  //       },
  //       "Relatedlinks Headline": {
  //         "value": ""
  //       },
  //       "Relatedlinks Text": {
  //         "value": ""
  //       }
  //     }
  //   }
  let [data, setData] = useState<any>(props);
  let [shownData, setShownData] = useState<any>([]);
  const nodeRef = useRef(null);
  const [parentRef, setParentRef] = useState<any>(null);
  const [parentAttr, setParentAttr] = useState<any>(null);

  let handleInputClick = (e: any) => {
    e.target.closest('.related_links')?.classList.contains(styles.open)
      ? handleClose(e)
      : handleOpen(e);
  };

  let handleOpen = (e: any) => {
    e.target.closest('.related_links')?.classList.add(styles.open);
    e.target.closest('.related_links')?.classList.add('open');
    e.target
      .closest('.related_links')
      ?.querySelector('.arrow_icon')
      ?.classList.add(styles.arrow_open);
    document.addEventListener('click', closeLinks);
  };
  let handleClose = (e: any) => {
    e.target.closest('.related_links')?.classList.remove(styles.open);
    e.target.closest('.related_links')?.classList.remove('open');
    e.target
      .closest('.related_links')
      ?.querySelector('.arrow_icon')
      ?.classList.remove(styles.arrow_open);
    document.removeEventListener('click', closeLinks);
  };
  let closeLinks = (e: any) => {
    e.target.closest('.related_links')
      ? ''
      : document.querySelector('.related_links.open')?.classList.remove(styles.open);
    e.target.closest('.related_links')
      ? ''
      : document
          .querySelector('.related_links.open')
          ?.querySelector('.arrow_icon')
          ?.classList.remove(styles.arrow_open);
  };
  let handleChange = (e: any) => {
    let inputValue = e.target.value;

    let linksTemp: any = [];
    data.fields['Select links for headless'].map((linkItem: any) => {
      let itemText=linkItem.fields['Link Item'].value.text
      ? linkItem.fields['Link Item'].value.text
      : linkItem.displayName
      itemText && itemText.toLowerCase().includes(inputValue.toLowerCase())
        ? linksTemp.push(linkItem)
        : '';
      
    });
    setShownData(linksTemp);
  };

  useEffect(() => {
    setData(props);
    setShownData(data && data.fields && data.fields['Select links for headless']);
  }, []);

  useEffect(() => {
    const child: any = nodeRef.current;

    if (child !== null || child !== undefined) {
      setParentRef(getParentClassReference(child));
      setParentAttr(getParentAttributeReference(child, 'data-id'));
    } else {
      setParentRef(CONTENT_100);
    }
  }, []);

  
  return (
    <div ref={nodeRef} className={` ${parentRef && styles[parentRef]}`}>
      <div
        className={` ${styles.relatedlinks_wrapper} ${parentAttr && styles[parentAttr]} ${
          data &&
          data.params &&
          data.params['Is Highlighted'] &&
          data.params['Is Highlighted'] == '1'
            ? styles.highlighted
            : ''
        } related_links`}
      >
        {(data &&
          data.fields &&
          data.fields['Relatedlinks Image'] &&
          data.fields['Relatedlinks Image'].value &&
          data.fields['Relatedlinks Image'].value.src) ||
        (data &&
          data.fields &&
          data.fields['Relatedlinks Headline'] &&
          data.fields['Relatedlinks Headline'].value &&
          data.fields['Relatedlinks Headline'].value.length) ? (
          <div className={styles.image_text_wrapper}>
            {data &&
            data.fields &&
            data.fields['Relatedlinks Image'] &&
            data.fields['Relatedlinks Image'].value &&
            data.fields['Relatedlinks Image'].value.src ? (
              <div className={styles.image_wrapper}>
                <Image
                  className={styles.image_container}
                  field={
                    data &&
                    data.fields &&
                    data.fields['Relatedlinks Image'] &&
                    data.fields['Relatedlinks Image']
                  }
                  editable={true}
                />
              </div>
            ) : (
              ''
            )}
             
            {data &&
            data.fields &&
            data.fields['Relatedlinks Headline'] &&
            data.fields['Relatedlinks Headline'].value &&
            data.fields['Relatedlinks Headline'].value.length ? (
              <div className={styles.text_wrapper}>
                <div className={styles.heading_wrapper}>
                  <Text
                    className={styles.heading}
                    field={
                      data &&
                      data.fields &&
                      data.fields['Relatedlinks Headline'] &&
                      data.fields['Relatedlinks Headline']
                    }
                  />
                </div>
                {data &&
            data.fields &&
            data.fields['Relatedlinks Image'] &&
            data.fields['Relatedlinks Image'].value &&
            data.fields['Relatedlinks Image'].value.src ? (
              <div className={styles.image_wrapper}>
                <Image
                  className={styles.image_container}
                  field={
                    data &&
                    data.fields &&
                    data.fields['Relatedlinks Image'] &&
                    data.fields['Relatedlinks Image']
                  }
                  editable={true}
                />
               </div>
            ) : (
              ''
            )}
                <div className={styles.text_content_wrapper}>
                  <RichText
                    className={styles.text}
                    field={
                      data &&
                      data.fields &&
                      data.fields['Relatedlinks Text'] &&
                      data.fields['Relatedlinks Text']
                    }
                    editable={true}
                  />
                </div>
              </div>
            ) : (
              ''
            )}
          </div>
        ) : (
          ''
        )}

        <div className={styles.dropdown_wrapper}>
          <input
            className={styles.relatedlinks_input}
            placeholder={
              data &&
              data.fields['Relatedlinks Default Text'] &&
              data.fields['Relatedlinks Default Text'].value
            }
            onChange={handleChange}
            onClick={handleInputClick}
          ></input>
          <i className={`${styles.arrow_icon} arrow_icon`} onClick={handleInputClick}></i>
          <ul className={styles.links_wrapper}>
            {shownData && shownData.length > 0 ? (
              <div className={styles.teaser__links}>
                {shownData.map((item: any) => {
                  return (
                    <li className={styles.link_items}>
                      <a
                        href={item.fields['Link Item'].value.href}
                        target={item.fields['Link Item'].value.target}
                      >
                        {item.fields['Link Item'].value.text
                          ? item.fields['Link Item'].value.text
                          : item.displayName}
                      </a>
                    </li>
                  );
                })}
              </div>
            ) : (
              ''
            )}
          </ul>
        </div>
      </div>
    </div>
  );
};
export default RelatedLinks;
