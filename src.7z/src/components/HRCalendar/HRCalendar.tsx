import { useState, useEffect } from 'react';
import {
  KEY_BREAKPOINT_SMALL_CALENDAR,
  KEY_HR_CALENDAR_TABS,
  KEY_BREAKPOINT_XXX_LARGE,
  KEY_DEEP_LINK_EMPLOYEE,
  KEY_DEEP_LINK_LEADER,
  KEY_CALENDAR_TASKS,
  KEY_CALENDAR_PDF,
  KEY_CALENDAR_LINKS,
  KEY_ROLE_PEOPLE_LEADER,
  KEY_ROLE_EMPLOYEE,
  KEY_CALENDAR_BANNER,
  KEY_ROLE_EMP_AND_PEOPLE_LEADER,
} from '../../constants/general';
import { MonthlyTabMobile } from '../Elements/MonthlyTabMobile/MonthlyTabMobile';
import { MonthlyTabDesktop } from '../Elements/MonthlyTabDesktop/MonthlyTabDesktop';
import { MonthlyTabXL } from '../Elements/MonthlyTabXL/MonthlyTabXL';
import { isLeader } from 'src/services/userRole.service';
import styles from './HRCalendar.module.scss';
import { getHashString, getMonthNameById, setToLocalStorage } from 'src/core/utils/utils.helper';
import CalendarBanner from './../CalendarBanner/CalendarBanner';
import { useLanguageTranslate } from 'src/hooks/useLanguageTranslate';
import { Text } from '@sitecore-jss/sitecore-jss-nextjs';
import { KEY_CALENDAR_EMPLOYEE, KEY_CALENDAR_PEOPLE_LEADER } from 'src/constants/dictonary';

export default function HRCalendar(props: any) {
  const { fields } = props;
  const { translatedKey } = useLanguageTranslate();
  const dataArray = fields && fields.items ? fields.items : [];

  const getDataFromResponseObj = (key: any) => {
    let data: any = dataArray.filter(function (item: any) {
      return item.name === key;
    });
    return data[0] && data[0];
  };

  const calendarData: any = getDataFromResponseObj(KEY_CALENDAR_TASKS);
  const pdfData: any = getDataFromResponseObj(KEY_CALENDAR_PDF);
  const linkboxData: any = getDataFromResponseObj(KEY_CALENDAR_LINKS);
  const bannerData: any = getDataFromResponseObj(KEY_CALENDAR_BANNER);

  const employeeData =
    calendarData &&
    calendarData.fields &&
    calendarData.fields.items &&
    calendarData.fields.items[0];

  const peopleLeaderData =
    calendarData &&
    calendarData.fields &&
    calendarData.fields.items &&
    calendarData.fields.items[1];

  const [view, setView] = useState<any>();
  const [windowWidth, setWindowWidth] = useState<any>();
  const [activeTab, setActiveTab] = useState<any>();
  const [activeData, setActiveData] = useState<any>(employeeData);
  const [activeLinks, setActiveLinks] = useState<any>(linkboxData);
  const [isTheLeader, setIsTheLeader] = useState<any>(false);
  const [pdfLink, setPdfLink] = useState<any>('');
  const [pdfTest, setPdfText] = useState<any>('');
  const [bannerImage, setBannerImage] = useState<any>('');
  const firstLevelTabs = KEY_HR_CALENDAR_TABS;

  const handleTabChange = (id: any) => {
    if (id === 1) {
      window.location.hash = KEY_DEEP_LINK_EMPLOYEE;
      deepLink();
      getPdf(KEY_ROLE_EMPLOYEE);
      getBanner(KEY_ROLE_EMPLOYEE);
      setActiveTab(1);
    } else {
      window.location.hash = KEY_DEEP_LINK_LEADER;
      deepLink();
      getPdf(KEY_ROLE_PEOPLE_LEADER);
      getBanner(KEY_ROLE_PEOPLE_LEADER);
      setActiveTab(2);
    }
  };

  const deepLink = (isALeader?:string) => {
    let currentIsLeader: boolean = isTheLeader;
    if(isALeader){
      currentIsLeader = isALeader === 'True' ? true : false;
    }

   
    const hash = getHashString();
    if (hash.category === KEY_DEEP_LINK_LEADER) {
      if (!currentIsLeader) {
        window.location.hash = KEY_DEEP_LINK_EMPLOYEE;
        setActiveTab(1);
        setActiveData(employeeData);
        getPdf(KEY_ROLE_EMPLOYEE);
        getBanner(KEY_ROLE_EMPLOYEE);
      
      } else {
        setActiveTab(2);
        setActiveData(peopleLeaderData);
        getPdf(KEY_ROLE_PEOPLE_LEADER);
        getBanner(KEY_ROLE_PEOPLE_LEADER);
      }
    } else if (hash.category === KEY_DEEP_LINK_EMPLOYEE) {
      setActiveTab(1);
      setActiveData(employeeData);
      getPdf(KEY_ROLE_EMPLOYEE);
      getBanner(KEY_ROLE_EMPLOYEE);
    } else if (hash.category === '') {
      const d = new Date();
      const currentMonth = getMonthNameById(d.getMonth() + 1);
      window.location.hash = `${KEY_DEEP_LINK_EMPLOYEE}/${currentMonth}`;
      setActiveTab(1);
      setActiveData(employeeData);
      getPdf(KEY_ROLE_EMPLOYEE);
      getBanner(KEY_ROLE_EMPLOYEE);
    }
    setActiveLinks(linkboxData);
  };

  const handleResize = () => {
    if (window.innerWidth != windowWidth) {
      setWindowWidth(window.innerWidth);
    }
  };

  const getIsLeader = () => {
    isLeader().then((data: any) => {
      if (data && data.data) {
        if (data.data === 'True') {
          setIsTheLeader(true);
          setToLocalStorage('IsLeader', data.data);
          // getPdf();
        } else {
          setIsTheLeader(false);
          setToLocalStorage('IsLeader', data.data);
          // getPdf();
        }
      }
      deepLink(data?.data);
    });
    // setIsTheLeader(true);
  };

  // const deepLinkCheck =() =>{
  //   console.log("deepLinkCheckstart",window.location.hash);


  // }

  useEffect(() => {
    getIsLeader();
    //deepLinkCheck();
  }, []);


  const getPdfLink = (item: any) => {
    let link =
      item.fields['PDF Link'] &&
      item.fields['PDF Link'].value &&
      item.fields['PDF Link'].value.href;
    link = link.replace('/sitecore/media-library/', '/~/media/');

    let text = item.fields['Title'] && item.fields['Title'].value;
    setPdfLink(link);
    setPdfText(text);
  };

  const getBanner = (activeTab: any) => {
    setBannerImage('');
    let isBroken = false;
    bannerData &&
      bannerData.fields &&
      bannerData.fields.items &&
      bannerData.fields.items.map((item: any) => {
        if (isBroken) {
          return;
        }
        const showTo =
          item.fields &&
          item.fields.ShowTo &&
          item.fields.ShowTo &&
          item.fields.ShowTo.value &&
          item.fields.ShowTo.value;

        if (showTo === KEY_ROLE_EMP_AND_PEOPLE_LEADER) {
          setBannerImage(item.fields && item.fields);
          isBroken = true;
          return;
        }

        if (showTo === activeTab) {
          if (
            item.fields.BannerImage &&
            item.fields.BannerImage.value &&
            item.fields.BannerImage.value &&
            item.fields.BannerImage.value.src &&
            item.fields.BannerImage.value.src != ''
          ) {
            setBannerImage(item.fields && item.fields);
          }

          // isBroken = true;
          // return;
        }
      });
  };

  const getPdf = (activeTab: any) => {
    let isBroken = false;
    pdfData &&
      pdfData.fields &&
      pdfData.fields.items &&
      pdfData.fields.items.map((item: any) => {
        if (isBroken) {
          return;
        }
        const showTo =
          item.fields &&
          item.fields.ShowTo &&
          item.fields.ShowTo &&
          item.fields.ShowTo.value &&
          item.fields.ShowTo.value;

        if (showTo === KEY_ROLE_EMP_AND_PEOPLE_LEADER) {
          getPdfLink(item);
          isBroken = true;
          return;
        }

        if (showTo === activeTab) {
          getPdfLink(item);
          // isBroken = true;
          // return;
        }
      });
  };

  useEffect(() => {
    let width = window.innerWidth;
    setWindowWidth(width);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    if (windowWidth && windowWidth >= KEY_BREAKPOINT_XXX_LARGE) {
      setView('xl');
    }
    if (windowWidth && windowWidth <= KEY_BREAKPOINT_SMALL_CALENDAR) {
      setView('mobile');
    }
    if (
      windowWidth &&
      windowWidth > KEY_BREAKPOINT_SMALL_CALENDAR &&
      windowWidth &&
      windowWidth < KEY_BREAKPOINT_XXX_LARGE
    ) {
      setView('desktop');
    }
  }, [windowWidth]);

  return (
    <div className={styles.tab_container}>
      <div className={`${styles.tabs_header} ${isTheLeader ? styles.show_tab : undefined}`}>
        {isTheLeader && (
          <div className={styles.tabs_section}>
            {firstLevelTabs &&
              Array.isArray(firstLevelTabs) &&
              firstLevelTabs.length > 0 &&
              firstLevelTabs.map((tab: any) => {
                return (
                  <div
                    className={`${styles.tabs} ${
                      activeTab && activeTab === tab.id ? styles.active : undefined
                    }`}
                    id={tab.id}
                    onClick={() => {
                      handleTabChange(tab.id);
                    }}
                    key={tab.id}
                  >
                    {tab.id === 1 ? (
                      <Text field={{ value: translatedKey(KEY_CALENDAR_EMPLOYEE) }} />
                    ) : (
                      <Text field={{ value: translatedKey(KEY_CALENDAR_PEOPLE_LEADER) }} />
                    )}
                    {/* {tab.label} */}
                  </div>
                );
              })}
          </div>
        )}
        {bannerImage ? (
          <div className={styles.banner_wrapper}>
            <CalendarBanner bannerData={bannerImage} />
          </div>
        ) : (
          ''
        )}

        <div className={styles.tab_links_wrapper}>
          {/* {fields && fields.DownloadPDFText && fields.DownloadPDFText.value && ( */}
          <div className={styles.download_link}>
            <a href={pdfLink} target="_blank">
              <div className={styles.download_icon}></div>
            </a>
            <a href={pdfLink} target="_blank" className={styles.link}>
              {/* {fields.DownloadPDFText.value} */} {pdfTest}
            </a>
          </div>
          {/* )} */}
        </div>
      </div>
      <div className={styles.tab_area_container}>
        {view === 'xl' && (
          <MonthlyTabXL calendarData={activeData} linkboxData={activeLinks} activeTab={activeTab} />
        )}
        {view === 'desktop' && (
          <MonthlyTabDesktop
            calendarData={activeData}
            linkboxData={activeLinks}
            activeTab={activeTab}
          />
        )}
        {view === 'mobile' && (
          <MonthlyTabMobile
            calendarData={activeData}
            linkboxData={activeLinks}
            activeTab={activeTab}
          />
        )}
      </div>
      {fields && fields.DisclaimerText && fields.DisclaimerText.value && (
        <div className={styles.disclaimer}>{fields.DisclaimerText.value}</div>
      )}
    </div>
  );
}
