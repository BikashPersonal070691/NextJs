export const COLOR_CODES = [
  {
    key: 'light green',
    value: '#66b512',
  },
  {
    key: 'light blue',
    value: '#00bcff',
  },
  {
    key: 'light grey',
    value: '#c5d1d6',
  },
];
