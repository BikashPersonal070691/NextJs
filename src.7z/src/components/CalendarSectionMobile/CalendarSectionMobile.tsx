import { useState, useEffect, useRef } from 'react';
import styles from './CalendarSectionMobile.module.scss';
import CalendarTaskContainerMobile from 'components/CalendarTaskContainerMobile/CalendarTaskContainerMobile';
import { Image } from '@sitecore-jss/sitecore-jss-nextjs';
import { getHashString, getTaskDetails, groupByTaskType } from 'src/core/utils/utils.helper';
import LightBoxOverLay from 'components/LightBoxOverlay/LightBoxOverlay';
export default function CalendarSectionMobile(props: any) {
  const { taskList, page, monthsWidth, id } = props;
  const [formattedTaskList, setFormattedTaskList] = useState([]);
  const taskListByType = groupByTaskType(formattedTaskList);
  const [windowWidth, setWindowWidth] = useState<any>();
  const [isOpen, setIsOpen] = useState(false);
  const [selectedTask, setSelectedTask] = useState({});
  const containerRef = useRef<any>(null);
  const hashString: any = getHashString();
  useEffect(() => {
    if (hashString && hashString.popupId != '') {
      const selectedTask = formattedTaskList.filter(function (item: any) {
        return item.id === hashString.popupId;
      });
      if (selectedTask && selectedTask[0]) {
        setIsOpen(true);
        setSelectedTask(selectedTask && selectedTask[0]);
      }
    }

    setFormattedTaskList(getTaskDetails(taskList));
  }, [taskList]);

  const handleResize = () => {
    if (containerRef && containerRef.current && containerRef.current.clientWidth) {
      setWindowWidth(containerRef.current.clientWidth - 8 - 76 - 8 - 8);
    }
  };

  useEffect(() => {
    if (containerRef && containerRef.current && containerRef.current.clientWidth) {
      setWindowWidth(containerRef.current.clientWidth - 8 - 76 - 8 - 8);
    }
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const closeOverlay = () => {
    setIsOpen(false);
    setSelectedTask({});
  };

  return (
    <>
      <div className={styles.calendar_row_wrapper} ref={containerRef}>
        {taskList && taskList.length > 0 ? (
          <div className={styles.calendar_row_title}>
            <div className={styles.title_image}>
              <Image
                field={
                  taskList[0].fields.CalenderSection &&
                  taskList[0].fields.CalenderSection.fields.icon
                }
              />
            </div>
            <div className={styles.title_text}>
              {/* {taskList[0].fields.CalenderSection && taskList[0].fields.CalenderSection.displayName} */}
              {taskList[0].fields.CalenderSection &&
                taskList[0].fields.CalenderSection.fields &&
                taskList[0].fields.CalenderSection.fields['Section Name'] &&
                taskList[0].fields.CalenderSection.fields['Section Name'].value}
            </div>
          </div>
        ) : (
          ''
        )}

        <div
          className={styles.calendar_task_section}
          style={{
            width: windowWidth ? windowWidth : 0,
          }}
        >
          {Object.keys(taskListByType).map((key) => (
            // <div
            //   className={styles.calendar_row_container}
            //   key={key}
            //   style={{
            //     width: windowWidth ? 4 * windowWidth : 0,
            //     left:
            //       windowWidth && page && page === 4
            //         ? -3 * windowWidth
            //         : windowWidth && page && page === 3
            //         ? -2 * windowWidth
            //         : windowWidth && page && page === 2
            //         ? -windowWidth
            //         : 0
            //   }}
            // >
            //   {taskListByType[key] &&
            //     taskListByType[key].length > 0 &&
            //     taskListByType[key].map((item: any, index: any) => {
            //       return (
            //         <>
            //           <CalendarTaskMobile
            //             {...item}
            //             width={monthsWidth ? monthsWidth : 0}
            //             key={index}
            //             order={id ? id : 0}
            //           />
            //         </>
            //       );
            //     })}
            // </div>
            <CalendarTaskContainerMobile
              key={key}
              windowWidth={windowWidth}
              page={page}
              tasks={taskListByType[key]}
              order={id ? id : 0}
              monthsWidth={monthsWidth}
            />
          ))}
        </div>
      </div>
      {isOpen ? (
        <LightBoxOverLay taskDetails={selectedTask} isOpen={isOpen} closeOverlay={closeOverlay} />
      ) : (
        ''
      )}
    </>
  );
}
