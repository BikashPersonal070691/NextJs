import { OptimizedImage } from 'src/components/Elements/OptimizedImage/OptimizedImage';
import styles from './HeaderImage.module.scss';
const HeaderImage = (props: any) => {
  const { imageData } = props;

  return (
    <div className={styles.header_image__container}>
      <OptimizedImage
        imageData={imageData}
        scaleData={[
          { mWidth: 767, width: 767, height: null },
          { mWidth: 1019, width: 1000, height: null },
          { mWidth: 1020, width: 1400, height: null },
        ]}
        customClass={styles.header__image}
      />
    </div>
  );
};

export default HeaderImage;
