import { useRef, useEffect, useState } from 'react';
import { CONTENT_25, CONTENT_50 } from 'src/constants/contentDivider';
import { formatContentDividerData } from 'src/helpers/contentDivider.helper';
import styles from './MonthlyView.module.scss';
import MonthlyViewTaskList from '../MonthlyViewTaskList/MonthlyViewTaskList';
import {
  getHashString,
  getSelectedMonthLinks,
  getSelectedMonthTaskList,
} from 'src/core/utils/utils.helper';
import MonthlyViewTaskDetails from '../MonthlyViewTaskDetails/MonthlyViewTaskDetails';
import CalendarLinks from 'components/CalendarLinks/CalendarLinks';
import { KEY_HR_TASK_LAYOUT_SERVICE_RESPONSE } from 'src/constants/general';

const MonthlyView = (props: any): JSX.Element => {
  const { taskList, monthSelected, linkboxData, activeTab, selectedMonthName } = props;
  const [selectedMonthTaskList, setSelectedMonthTaskList] = useState<any>([]);
  const [isParentIdExists, setIsParentIdExists] = useState<boolean>(false);

  useEffect(() => {
    const dataList: any = getSelectedMonthTaskList(
      taskList && taskList.fields && taskList.fields[KEY_HR_TASK_LAYOUT_SERVICE_RESPONSE]
        ? taskList.fields[KEY_HR_TASK_LAYOUT_SERVICE_RESPONSE]
        : [],
      monthSelected
    );

    setSelectedMonthTaskList(dataList);
  }, [props]);

  const hashString = getHashString();
  const selectedMonthLinkList: any =
    linkboxData && linkboxData.fields
      ? getSelectedMonthLinks(
          linkboxData.fields.items,
          hashString.month ? hashString.month : monthSelected
        )
      : [];
  const currentElement: any = useRef(null);
  const contentDividerBg = formatContentDividerData(props);
  /**
   * @description to check if parent node has id . If parent has id it this current content divider is a nested content divider.
   */
  useEffect(() => {
    currentElement &&
    currentElement.current &&
    currentElement.current.parentNode &&
    currentElement.current.parentNode.id &&
    currentElement.current.parentNode.id !== undefined &&
    currentElement.current.parentNode.id !== ''
      ? setIsParentIdExists(true)
      : setIsParentIdExists(false);

  }, []);

  return (
    <section
      className={`${styles.divider_25_50_25__container} ${
        !isParentIdExists ? styles.divider_25_50_25_container__bg : ''
      }`}
      ref={currentElement}
      style={{
        backgroundColor:
          contentDividerBg && contentDividerBg.bgColor && contentDividerBg.bgColor !== ''
            ? contentDividerBg.bgColor
            : 'white',
      }}
    >
      <div className={styles.divider_25_50_25_wrapper}>
        <div
          className={styles.divider_left_25_container}
          id={CONTENT_25}
          data-nested={isParentIdExists}
          data-cd-bg={
            contentDividerBg && contentDividerBg.bgColor && contentDividerBg.bgColor !== ''
              ? contentDividerBg.bgColor
              : 'white'
          }
        >
          <MonthlyViewTaskList
            selectedMonthTaskList={selectedMonthTaskList}
            monthSelected={selectedMonthName}
          ></MonthlyViewTaskList>
        </div>
        <div
          className={styles.divider_50_container}
          id={CONTENT_50}
          data-nested={isParentIdExists}
          data-cd-bg={
            contentDividerBg && contentDividerBg.bgColor && contentDividerBg.bgColor !== ''
              ? contentDividerBg.bgColor
              : 'white'
          }
        >
          {selectedMonthTaskList &&
            selectedMonthTaskList.map((item: any, index: any) => (
              <MonthlyViewTaskDetails taskDetails={item} key={index}></MonthlyViewTaskDetails>
            ))}
        </div>
        <div
          className={styles.divider_right_25_container}
          id={CONTENT_25}
          data-nested={isParentIdExists}
          data-cd-bg={
            contentDividerBg && contentDividerBg.bgColor && contentDividerBg.bgColor !== ''
              ? contentDividerBg.bgColor
              : 'white'
          }
        >
          <CalendarLinks
            selectedMonthLinkList={selectedMonthLinkList}
            activeTab={activeTab}
          ></CalendarLinks>
        </div>
      </div>
    </section>
  );
};
export default MonthlyView;
