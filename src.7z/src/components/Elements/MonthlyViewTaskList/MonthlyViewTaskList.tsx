import { KEY_CALENDAR_DUE } from 'src/constants/general';
import styles from './MonthlyViewTaskList.module.scss';
import { useLanguageTranslate } from 'src/hooks/useLanguageTranslate';
import { KEY_CALENDAR_DUE_TEXT, KEY_CALENDAR_MY_HR_TASKS } from 'src/constants/dictonary';

const MonthlyViewTaskList = (props: any): JSX.Element => {
  const { selectedMonthTaskList, monthSelected } = props;
  const { translatedKey } = useLanguageTranslate();
  return (
    <div className={styles.task_container}>
      <span className={styles.heading_text}>
      {translatedKey(KEY_CALENDAR_MY_HR_TASKS)}  - {monthSelected} {new Date().getFullYear()}
      </span>
      {selectedMonthTaskList && selectedMonthTaskList.length > 0 ? (
        <section className={styles.task_list_wrapper}>
          {selectedMonthTaskList &&
            selectedMonthTaskList.map((item: any, index: any) => (
              <div className={styles.task_details} key={index}>
                <div className={styles.task} key={index}>
                  <div className={styles.task_name}>
                    {item.fields.Name && item.fields.Name.value}
                  </div>
                  <div
                    className={
                      item.fields &&
                      item.fields.IsTaskCompleted &&
                      item.fields.IsTaskCompleted.value === true
                        ? styles.completed_task
                        : styles.pending_task
                    }
                  ></div>
                </div>
                <p className={styles.due_date}>
                {translatedKey(KEY_CALENDAR_DUE_TEXT)} :
                  <span>
                    {' '}
                    {item.fields && item.fields[KEY_CALENDAR_DUE] && item.fields[KEY_CALENDAR_DUE].value} 
                    {/* {item.endMonthName && item.endMonthName} {item.endDay && item.endDay} */}
                  </span>
                </p>
              </div>
            ))}
        </section>
      ) : (
        ''
      )}
    </div>
  );
};
export default MonthlyViewTaskList;
