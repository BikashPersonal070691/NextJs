import { KEY_GRAPH_API_ENDPOINT } from 'src/constants/general';
import { getGraphApiData } from 'src/core/api/httpRequest';

const getUserId = (email: any) => {
  const data = getGraphApiData(`${KEY_GRAPH_API_ENDPOINT}/users('${email}')`);
  return data;
};

const getUserStatus = (id: any) => {
  const data = getGraphApiData(`${KEY_GRAPH_API_ENDPOINT}/communications/presences/${id}`);
  return data;
};

export { getUserStatus, getUserId };
