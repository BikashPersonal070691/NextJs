import { apiEndpoints } from 'src/core/api/apiEndpoints';
import { httpRequest } from 'src/core/api/httpRequest';

const getFooterData = (id: any) => {
  // return httpRequest(apiEndpoints.getFooterContents, 'get');

  const url = {
    url: `${apiEndpoints.getFooterContents.url}?itemID=${id}`,
    isMock: apiEndpoints.getBreadcrumbData.isMock,
  };
  return httpRequest(url, 'get');
};

const setCookieConsent = (status: boolean) => {
  const url = {
    url: `${apiEndpoints.saveCookieData.url}?status=${status}`,
  };
  return httpRequest(url, 'get');
};
export { getFooterData, setCookieConsent };
