import styles from './CalendarSectionXL.module.scss';
import CalendarTaskContainerXL from 'components/CalendarTaskContainerXL/CalendarTaskContainerXL';
import { Image } from '@sitecore-jss/sitecore-jss-nextjs';
import { getHashString, getTaskDetails, groupByTaskType } from 'src/core/utils/utils.helper';
import { useState, useEffect } from 'react';
import LightBoxOverLay from 'components/LightBoxOverlay/LightBoxOverlay';

export default function CalendarSectionXL(props: any) {
  const { taskList, id } = props;
  // console.log(JSON.stringify(taskList));
  // const formattedTaskList = getTaskDetails(taskList);

  const [isOpen, setIsOpen] = useState(false);
  const [selectedTask, setSelectedTask] = useState({});
  const [formattedTaskList, setFormattedTaskList] = useState([]);
  const taskListByType = groupByTaskType(formattedTaskList);

  const hashString: any = getHashString();
  useEffect(() => {
    if (hashString && hashString.popupId != '') {
      const selectedTask = formattedTaskList.filter(function (item: any) {
        return item.id === hashString.popupId;
      });
      if (selectedTask && selectedTask[0]) {
        setIsOpen(true);
        setSelectedTask(selectedTask && selectedTask[0]);
      }
    }

    setFormattedTaskList(getTaskDetails(taskList));
  }, [taskList]);

  const closeOverlay = () => {
    setIsOpen(false);
    setSelectedTask({});
  };
  return (
    <>
      <div className={styles.calendar_row_wrapper}>
        {taskList && taskList.length > 0 ? (
          <div className={styles.calendar_row_title}>
            <div className={styles.title_image}>
              <Image
                field={
                  taskList[0].fields.CalenderSection &&
                  taskList[0].fields.CalenderSection.fields.icon
                }
              />
            </div>
            <div className={styles.title_text}>
              {taskList[0].fields.CalenderSection &&
                taskList[0].fields.CalenderSection.fields &&
                taskList[0].fields.CalenderSection.fields['Section Name'] &&
                taskList[0].fields.CalenderSection.fields['Section Name'].value}
            </div>
          </div>
        ) : (
          ''
        )}

        <div className={styles.calendar_task_section}>
          {Object.keys(taskListByType).map((key) => (
            <CalendarTaskContainerXL key={key} tasks={taskListByType[key]} order={id ? id : 0} />
          ))}
        </div>
      </div>

      {isOpen ? (
        <LightBoxOverLay taskDetails={selectedTask} isOpen={isOpen} closeOverlay={closeOverlay} />
      ) : (
        ''
      )}
    </>
  );
}
