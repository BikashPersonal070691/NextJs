import React, { useContext, useEffect, useState } from 'react';
import { MenuContext } from 'src/contexts/MenuContext';
import styles from './MegaMenuMobileView.module.scss';
import { getChildMenus, getUtilityMenus } from 'src/services/menu.service';
// import { HeaderContext } from 'src/contexts/HeaderContext';
//import { MY_HR_MENU_TEMPLETE_ID } from 'src/constants/general';
// import useSWR from 'swr';
import HeaderProfileMobile from 'components/HeaderProfile/HeaderProfileMobile';
import {
  COLOR_SELECTED_MAIN_MENU_SMALL_SCREEN,
  COLOR_NON_SELECT_MAIN_MENU_SMALL_SCREEN,
  MY_HR_MENU_TEMPLETE_ID,
  URL_MY_HR,
} from 'src/constants/general';
import { useRouter } from 'next/router';

// const fetcher = (url: any) => fetch(url).then(res => res.json());
export function MegaMenuMobileView() {
  const { setCurrentLevel } = useContext(MenuContext);
  const [utilityMenuData, setUtilityMenuData] = useState<any>({});

  const { menuData } = useContext(MenuContext);
  const { asPath, pathname } = useRouter();

  const [mainMenuListData, setMainMenuListData] = useState({});
  const [level, setLevel] = useState<any>(1);
  const [selectedMenuName, setSelectedMenuName] = useState<any>('');
  const [selectedMainMenu, setSelectedMainMenu] = useState<any>();
  const [secondLevelMenu, setSecondLevelMenu] = useState<any>({});
  const [thirdLevelMenu, setThirdLevelMenu] = useState<any>({});
  const [fourthLevelMenu, setFourthLevelMenu] = useState<any>({});
  const [fifthLevelMenu, setFifthLevelMenu] = useState<any>({});
  const [sixthLevelMenu, setSixthLevelMenu] = useState<any>({});
  const [seventhLevelMenu, setSeventhLevelMenu] = useState<any>({});

  // const sampleData = [
  //   {
  //     Name: 'myServices',
  //     NavigationLink: 'https://bayernet.int.bayer.com/en/',
  //     IsExternal: true,
  //   },
  //   {
  //     Name: 'IT4U',
  //     NavigationLink: 'https://bayernet.int.bayer.com/en/',
  //     IsExternal: true,
  //   },
  //   {
  //     Name: 'IDNet',
  //     NavigationLink: 'https://bayernet.int.bayer.com/en/',
  //     IsExternal: true,
  //   },
  // ];

  useEffect(() => {
    getUtilityMenus().then((data: any) => {
      if (data && data.data) {
        setUtilityMenuData(data.data);
      }
    });
    // setUtilityMenuData(sampleData);
  }, []);

  const loadNextLevel = (item: any) => {
    if (level === 1) {
      setSelectedMenuName(item.NavigationTitle);
      setSelectedMainMenu(item);
      setLevel(level + 1);
      setCurrentLevel(level + 1);
      const { SubNavigation } = menuData;
      if (SubNavigation) {
        const obj = SubNavigation[item.TemplateID];
        const general: any = obj['General'] && Array.isArray(obj['General']) ? obj['General'] : [];
        const personalized: any =
          obj['Personalized'] && Array.isArray(obj['Personalized']) ? obj['Personalized'] : [];

        setSecondLevelMenu({
          name: item.NavigationTitle,
          data: [...personalized, ...general],
        });
        setLevel(level + 1);
        setCurrentLevel(level + 1);
      }
    } else if (level === 2) {
      setThirdLevelMenu({});
      getChildMenus(item.RootID, selectedMainMenu.TemplateID).then((data: any) => {
        if (data && data.data) {
          setThirdLevelMenu({
            name: item.Text,
            data: data.data,
          });
          setLevel(level + 1);
          setCurrentLevel(level + 1);
        }
      });
      setSelectedMenuName(item.Text);
      // setThirdLevelMenu({
      //     name: item.Text,
      //     data: data
      // });
    } else if (level === 3) {
      setSelectedMenuName(item.Text);
      setFourthLevelMenu({
        name: item.Text,
        data: item.Children,
      });
      setLevel(level + 1);
      setCurrentLevel(level + 1);
    } else if (level === 4) {
      setSelectedMenuName(item.Text);
      setFifthLevelMenu({
        name: item.Text,
        data: item.Children,
      });
      setLevel(level + 1);
      setCurrentLevel(level + 1);
    } else if (level === 5) {
      setSelectedMenuName(item.Text);
      setSixthLevelMenu({
        name: item.Text,
        data: item.Children,
      });
      setLevel(level + 1);
      setCurrentLevel(level + 1);
    } else if (level === 6) {
      setSelectedMenuName(item.Text);
      setSeventhLevelMenu({
        name: item.Text,
        data: item.Children,
      });
      setLevel(level + 1);
      setCurrentLevel(level + 1);
    }
  };

  const goBack = () => {
    if (level === 3) {
      setSelectedMenuName(secondLevelMenu.name);
    } else if (level === 4) {
      setSelectedMenuName(thirdLevelMenu.name);
    } else if (level === 5) {
      setSelectedMenuName(fourthLevelMenu.name);
    } else if (level === 6) {
      setSelectedMenuName(fifthLevelMenu.name);
    } else if (level === 7) {
      setSelectedMenuName(sixthLevelMenu.name);
    }
    setLevel(level > 1 ? level - 1 : 1);
    setCurrentLevel(level > 1 ? level - 1 : 1);
  };

  const getList = (dataArr: any) => {
    return (
      <div className={styles.sub_level_menu}>
        <div className={styles.first_level_sub}>
          <ul className={styles.sub_level_ul}>
            {dataArr && Array.isArray(dataArr['data'])
              ? dataArr['data'].map((item, index) => getListItem(item, index))
              : null}
          </ul>
        </div>
      </div>
    );
  };

  const getListItem = (item: any, index: any) => {
    const id = `${item.RootID}_${index}`;
    return (
      <li
        className={`${styles.sub_level_li} ${
          item.HasChildren ? styles.has_child : styles.no_child
        }`}
        key={index}
      >
        <a
          href={item.URL}
          className={styles.sub_menu_link}
          target={item.NewWindow ? '_blank' : '_self'}
        >
          {item.Text}
        </a>
 
        {item && item.HasChildren ? (
          <>
            <span className={styles.icon_seperation_bar}></span>
            <div
              className={styles.arrow_container}
              onClick={() => {
                loadNextLevel(item);
              }}
            >
              <span
                id={id}
                className={`${styles.right} ${styles.arrow_span} level_${level}`}
              ></span>
            </div>
          </>
        ) : (
          ''
        )}
      </li>
    );
  };

  useEffect(() => {
    if (menuData) {
      const { MainNavigation } = menuData;
      setMainMenuListData(MainNavigation);
    }
  }, [menuData]);

  return (
    <div className={`${styles.mega_menu}`}>
      {/* <div
        onClick={() => {
          setMobileView(false);
        }}
        className={` ${level === 1 ? styles.upper_shadow : ''}`}
      ></div> */}

      <div className={styles.left_side}>
        <div className={styles.header_profile_mobile}>
          <HeaderProfileMobile />
        </div>

        <nav>
          {level > 1 ? (
            <>
              <div
                className={styles.go_back_button}
                onClick={() => {
                  goBack();
                }}
              >
                <span className={`${styles.left} ${styles.left_arrow_span}`}></span>
                <span className={`${styles.left} ${styles.go_back_text}`}>Go Back</span>
              </div>
              <div className={`${styles.main_menu_item} ${styles.current_heading}`}>
                <span className={`${styles.nav_link}`}>{selectedMenuName}</span>
              </div>
            </>
          ) : (
            ''
          )}

          {level === 1 ? (
            <div className={`${styles.sub_level_menu}`}>
              <div className={styles.first_level_sub}>
                <ul className={styles.sub_level_ul}>
                  {mainMenuListData && Array.isArray(mainMenuListData)
                    ? mainMenuListData.map((menuItem, index) => (
                        <li className={`${styles.sub_level_li} ${styles.has_child}`} key={index}>
                          {menuItem.TemplateID === MY_HR_MENU_TEMPLETE_ID ||
                          menuItem.HasChildren === false ? (
                            <a
                              className={styles.sub_menu_link}
                              href={
                                menuItem.ExternalURL != '' ? menuItem.ExternalURL : menuItem.URL
                              }
                              style={
                                ((asPath &&
                                  asPath.toLowerCase().includes(URL_MY_HR.toLowerCase())) ||
                                  (pathname &&
                                    pathname.toLowerCase().includes(URL_MY_HR.toLowerCase()))) &&
                                menuItem.TemplateID === MY_HR_MENU_TEMPLETE_ID
                                  ? { color: COLOR_SELECTED_MAIN_MENU_SMALL_SCREEN }
                                  : { color: COLOR_NON_SELECT_MAIN_MENU_SMALL_SCREEN }
                              }
                            >
                              {menuItem.NavigationTitle}
                            </a>
                          ) : (
                            <a href={'#'} className={styles.sub_menu_link}>
                              {' '}
                              {menuItem.NavigationTitle}
                            </a>
                          )}

                          {menuItem && menuItem.HasChildren && menuItem.NavigationTitle !=="MyHR" ? (
                            <>
                              <span className={styles.icon_seperation_bar}></span>
                              <div
                                className={styles.arrow_container}
                                onClick={() => {
                                  loadNextLevel(menuItem);
                                }}
                              >
                                <span className={`${styles.right} ${styles.arrow_span}`}></span>
                              </div>
                            </>
                          ) : (
                            ''
                          )}
                        </li>
                      ))
                    : null}
                </ul>
              </div>
            </div>
          ) : (
            ''
          )}

          {level === 2 ? getList(secondLevelMenu) : ''}
          {level === 3 ? getList(thirdLevelMenu) : ''}
          {level === 4 ? getList(fourthLevelMenu) : ''}
          {level === 5 ? getList(fifthLevelMenu) : ''}
          {level === 6 ? getList(sixthLevelMenu) : ''}
          {level === 7 ? getList(seventhLevelMenu) : ''}

          <div className={styles.first_level_sub}>
            <ul className={styles.sub_level_ul}>
              {utilityMenuData && Array.isArray(utilityMenuData)
                ? utilityMenuData.map((item, index) => (
                    <li
                      className={`${styles.sub_level_li} ${
                        item.HasChildren ? styles.has_child : styles.no_child
                      }`}
                      key={index}
                    >
                      <a
                        href={item.NavigationLink}
                        className={`${styles.sub_menu_link} ${styles.utility_menu}`}
                        target={item.IsExternal ? '_blank' : '_self'}
                      >
                        {item.Name}
                      </a>

                      <a href={item.NavigationLink} target={item.IsExternal ? '_blank' : '_self'}>
                        <i className={styles.link_icon}></i>
                      </a>
                    </li>
                  ))
                : null}
            </ul>
          </div>
        </nav>
      </div>
    </div>
  );
}
