import styles from './MultiSelectDropdown.module.scss';
import { useState, useEffect } from 'react';

export default function MultiSelectDropdown(props: any) {
  const [dropDownData, setdropDownData] = useState<any>({});
  const [showDropdown, setshowDropdown] = useState<any>(false);
  const [inputValue, setinputValue] = useState<any>('');
  const [dropDownitems, setdropDownitems] = useState<any>([]);

  const dataSetter = (valueSet: any) => {
    const newData = { ...dropDownData, value: valueSet };
    setdropDownData(newData);
    formatOptionsData(newData);
    if (props && props.handleSelect) {
      props.handleSelect(valueSet);
    }
  };
  const handleSelect = (e: any) => {
    let itemId = e.target && e.target.closest('li') && e.target.closest('li').getAttribute('id');
    let selectedValuesTemp = [...dropDownData.value];
    if (
      e.target &&
      e.target.closest('li') &&
      e.target
        .closest('li')
        .querySelector('.options_check_box')
        .classList.contains('options_select_check_selected')
    ) {
      const newValueSet = selectedValuesTemp.filter((item) => item.value !== itemId);
      dataSetter(newValueSet);
    } else {
      if (props && props.userSelection && !props.userSelection.deactivateSelection) {
        dropDownData.options.filter((item: any) => {
          if (item.value == itemId) {
            selectedValuesTemp.push(item);
          }
        });
        dataSetter(selectedValuesTemp);
      }
      if (props && props.handleError) {
        props.handleError();
      }
    }
  };

  const formatOptionsData = (dataToProcess: any) => {
    if (
      dataToProcess &&
      dataToProcess.options &&
      Array.isArray(dataToProcess.options) &&
      dataToProcess.options.length > 0
    ) {
      if (
        dataToProcess &&
        dataToProcess.value &&
        Array.isArray(dataToProcess.value) &&
        dataToProcess.value.length > 0
      ) {
        let options = [...dataToProcess.options];
        let data = [...dataToProcess.value];
        const formattedValue: any = options.map((item: any) => {
          let newOption = { ...item };
          for (let i = 0; i < data.length; i++) {
            if (item.value === data[i].value) {
              newOption = {
                ...newOption,
                isSelected: true,
              };
              break;
            }
          }
          return newOption;
        });
        setdropDownitems(formattedValue);
      } else {
        setdropDownitems(dataToProcess.options);
      }
    }
  };
  const handleHidedropdown = (e: any) => {
    if (!e.target.closest('.multiselect_dd_check')) {
      setshowDropdown(false);
      document.body.removeEventListener('click', handleHidedropdown);
    }
  };

  const handleShowdropdown = (e: any) => {
    e.stopPropagation();
    setshowDropdown(true);
    document.body.addEventListener('click', handleHidedropdown);
  };

  // const setDropDownItems = () => {
  //   setdropDownitems(dropDownData.options);
  // };

  const handleInput = (e: any) => {
    setinputValue(e.target.value);
    let userInput = e.target.value;
    let searchResultTemp: any = [];

    dropDownData.options &&
      dropDownData.options.map((item: any) => {
        let addedFlag = false;
        if (
          item.label &&
          item.label.toLowerCase().includes(userInput.toLowerCase()) &&
          item.path &&
          item.path.toLowerCase().includes(userInput.toLowerCase())
        ) {
          const dummyItem = { ...item };
          const itemLabel = dummyItem.label;
          const itemPath = dummyItem.path;
          const reg = new RegExp(userInput, 'gi');
          const final_str_label = itemLabel.replace(reg, function (str: any) {
            return '<b>' + str + '</b>';
          });
          const final_str_path = itemPath.replace(reg, function (str: any) {
            return '<b>' + str + '</b>';
          });
          const formattedItem = { ...item, label: final_str_label, path: final_str_path };
          searchResultTemp.push(formattedItem);
          addedFlag = true;
        }
        if (
          item.label &&
          item.label.toLowerCase().includes(userInput.toLowerCase()) &&
          !addedFlag
        ) {
          const dummyItem = { ...item };
          const itemLabel = dummyItem.label;
          const reg = new RegExp(userInput, 'gi');
          const final_str = itemLabel.replace(reg, function (str: any) {
            return '<b>' + str + '</b>';
          });
          const formattedItem = { ...item, label: final_str };
          searchResultTemp.push(formattedItem);
        }
        if (item.path && item.path.toLowerCase().includes(userInput.toLowerCase()) && !addedFlag) {
          const dummyItem = { ...item };
          const itemPath = dummyItem.path;
          const reg = new RegExp(userInput, 'gi');
          const final_str = itemPath.replace(reg, function (str: any) {
            return '<b>' + str + '</b>';
          });
          const formattedItem = { ...item, path: final_str };
          searchResultTemp.push(formattedItem);
        }
      });
    if (
      dropDownData &&
      dropDownData.value &&
      Array.isArray(dropDownData.value) &&
      dropDownData.value.length > 0
    ) {
      let options = [...searchResultTemp];
      let data = [...dropDownData.value];
      const formattedValue: any = options.map((item: any) => {
        let newOption = { ...item };
        for (let i = 0; i < data.length; i++) {
          if (item.value === data[i].value) {
            newOption = {
              ...newOption,
              isSelected: true,
            };
            break;
          }
        }
        return newOption;
      });
      setdropDownitems(formattedValue);
    } else {
      setdropDownitems(searchResultTemp);
    }
  };
  useEffect(() => {
    if (props && props.userSelection) {
      setdropDownData(props.userSelection);
      formatOptionsData(props.userSelection);
    }
  }, []);
  useEffect(() => {
    if (props && props.userSelection) {
      setdropDownData(props.userSelection);
      formatOptionsData(props.userSelection);
    }
  }, [props.userSelection]);

  return (
    <div className={`${styles.multiselect_dd_wrapper}` + ' multiselect_dd_check'}>
      <div>
        <input
          className={`${styles.input}` + ' multiselect_dd_input'}
          value={inputValue}
          onClick={handleShowdropdown}
          onChange={handleInput}
          placeholder={props && props.placeholder ? props.placeholder : ''}
          disabled={props.isDisabled ? true : false}
        />
        <div className={styles.options_container}>
          <ul
            className={`${styles.options_list}  ${
              showDropdown ? styles.options_list_shown : styles.options_list_hidden
            } `}
          >
            {dropDownitems && dropDownitems.length && dropDownitems.length > 0
              ? dropDownitems.map((item: any) => {
                  return (
                    <li className={styles.options_list_item} id={item.value} key={item.value}>
                      <div
                        className={
                          `${styles.options_select_box}  ${
                            item.isSelected
                              ? styles.options_select_box_selected +
                                ' options_select_check_selected'
                              : styles.options_text_unselected + ' options_check_box_unselected'
                          } ` + ' options_check_box'
                        }
                        onClick={handleSelect}
                      ></div>
                      <div className={styles.options_text} onClick={handleSelect}>
                        {/* <div>{item.label}</div> */}
                        <div dangerouslySetInnerHTML={{ __html: item.label }}></div>
                        {/* <div
                          className={` ${
                            item.path ? styles.options_text_path : styles.options_text_path_hidden
                          } `}
                        >
                          / {item.path && item.path}
                        </div> */}
                        {item.path && (
                          <div className={styles.options_text_path}>
                            /{' '}
                            <div
                              className={styles.path}
                              dangerouslySetInnerHTML={{ __html: item.path }}
                            ></div>
                          </div>
                        )}
                      </div>
                    </li>
                  );
                })
              : ''}

            {dropDownitems && dropDownitems.length == 0 && props && props.noItemFoundMsg ? (
              <li className={styles.options_list_item}>
                <div className={styles.options_text}>{props.noItemFoundMsg}</div>
              </li>
            ) : (
              ''
            )}
          </ul>
        </div>
      </div>
    </div>
  );
}
