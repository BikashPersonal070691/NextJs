import { useState, useEffect, useRef } from 'react';
import { getClusterData, getSecondLevelClusterData } from 'src/services/cluster.service';
import { formatLink } from 'src/helpers/link.helper';
import 'overlayscrollbars/styles/overlayscrollbars.css';
import { OverlayScrollbarsComponent } from 'overlayscrollbars-react';
import { useSelector } from 'react-redux';
import { formatClusterNavData } from 'src/helpers/component.helper';
import styles from './ClusterNavDesktop.module.scss';

export default function ClusterNavigationDesktop() {
  const [showOverlay, setShowOverlay] = useState<any>('');
  const [showThirdLevelMenu, setShowThirdLevelMenu] = useState<any>('');
  const [showFourthLevelMenu, setShowFourthLevelMenu] = useState<any>('');
  const [showFifthLevelMenu, setShowFifthLevelMenu] = useState<any>('');
  const [levelOneData, setLevelOneData] = useState<any>(null);
  const [levelTwoData, setLevelTwoData] = useState<any>(null);
  const [levelThreeData, setLevelThreeData] = useState<any>(null);
  const [levelFourData, setLevelFourData] = useState<any>(null);
  const [levelFiveData, setLevelFiveData] = useState<any>(null);
  const [activeFirstLevelMenu, setActiveFirstLevelMenu] = useState<any>(null);
  const [activeSecondLevelMenu, setActiveSecondLevelMenu] = useState<any>(null);
  const [activeThirdLevelMenu, setActiveThirdLevelMenu] = useState<any>(null);
  const [activeFourthLevelMenu, setActiveFourthLevelMenu] = useState<any>(null);
  const { breadcrumbData } = useSelector((state: any) => state.common);
  const levelTowRef = useRef<any>(null);

  const getChildLevels = (menu: any) => {
    getSecondLevelClusterData(menu.RootID, menu.TemplateID).then((data: any) => {
      if (data && data.data) {
        const mainElement = document.querySelectorAll('[class^="ClusterNavDesktop_main_wrapper"]');
        if (mainElement && mainElement[0] && mainElement[0].matches(':hover')) {
          setLevelTwoData({
            parent: menu.RootID,
            child: data.data,
          });
          setShowOverlay('show');
        } else {
          setLevelTwoData(null);
          setShowOverlay('hide');
        }
      } else {
        setLevelTwoData(null);
        setShowOverlay('hide');
      }
    });
  };
  const getData = () => {
    getClusterData().then((data: any) => {
      if (data && data.data) {
        if (breadcrumbData && Array.isArray(breadcrumbData) && breadcrumbData.length > 0) {
          const formattedLevelOneData = formatClusterNavData(data.data, breadcrumbData);
          setLevelOneData(formattedLevelOneData);
        } else {
          setLevelOneData(data.data);
        }
      }
    });
  };

  // const navigationHandler = (menu: any, e: any) => {
  //   e.preventDefault();
  //   const refinedLink = formatLink(menu.URL);
  //   if (menu.NewWindow === true) {
  //     window.open(refinedLink, '_blank');
  //   } else {
  //     window.open(refinedLink, '_self');
  //   }
  // };

  useEffect(() => {
    if (breadcrumbData && Array.isArray(breadcrumbData) && breadcrumbData.length > 0) {
      getData();
    }
  }, [breadcrumbData]);

  const levelOneActivate = (menu: any) => {
    getChildLevels(menu);
  };

  const levelOnDeactivate = () => {
    setShowOverlay('hide');
  };

  const levelTwoActivate = (levelTwoMenu: any) => {
    if (levelTwoMenu.HasChildren) {
      const childMenu = levelTwoMenu.Children ? levelTwoMenu.Children : null;
      if (childMenu) {
        setLevelThreeData({
          parent: levelTwoMenu.RootID,
          child: childMenu,
        });
      } else {
        setLevelThreeData(null);
      }
      setShowThirdLevelMenu('show');
    } else {
      setLevelThreeData(null);
      setShowThirdLevelMenu('hide');
    }
  };

  const levelTwoDeactivate = () => {
    setShowThirdLevelMenu('hide');
  };
  const levelThreeActivate = (menu: any, menuTree: any) => {
    if (menu.HasChildren) {
      const childMenu = menu.Children ? menu.Children : null;
      if (childMenu) {
        setLevelFourData({
          levelTwoParent: menuTree.parent,
          parent: menu.RootID,
          child: childMenu,
        });
      } else {
        setLevelFourData(null);
      }
      setShowFourthLevelMenu('show');
    } else {
      setLevelFourData(null);
      setShowFourthLevelMenu('hide');
    }
  };

  const levelThreeDeactivate = () => {
    setShowFourthLevelMenu('hide');
  };
  const levelFourActivate = (menu: any, menuTree: any) => {
    if (menu.HasChildren) {
      const childMenu = menu.Children ? menu.Children : null;
      if (childMenu) {
        setLevelFiveData({
          levelTwoParent: menuTree.levelTwoParent,
          levelThreeParent: menuTree.parent,
          parent: menu.RootID,
          child: childMenu,
        });
      } else {
        setLevelFiveData(null);
      }
      setShowFifthLevelMenu('show');
    } else {
      setLevelFiveData(null);
      setShowFifthLevelMenu('hide');
    }
  };
  const levelFourDeactivate = () => {
    setShowFifthLevelMenu('hide');
  };
  return (
      <div
        className={`${styles.cluster_container} ${
          levelOneData ? styles.showContainer : styles.hideContainer
        }`}
      >
        <div className={`${styles.container} ${styles.nav_container}`}>
          <div className={styles.nav_wrapper}>
            <div className={styles.main_wrapper}>
              {levelOneData?.map((menu: any, index: any) => {
                return (
                  <div
                    className={`${styles.item_wrapper} ${
                      activeFirstLevelMenu === menu.RootID ? styles.highlight : undefined
                    }`}
                    key={index}
                    onMouseEnter={() => {
                      levelOneActivate(menu);
                    }}
                    onMouseLeave={levelOnDeactivate}
                  >
                    <a  href={menu.InActiveInNavigation &&
                        menu.URL &&
                        menu.InActiveInNavigation === 'false'
                          ?  menu.URL && formatLink(menu.URL)
                          : ''} target={menu.NewWindow && menu.NewWindow === true ? '_blank':'_self'}
                      className={`clusternav ${styles.item} ${styles.active} ${
                        menu.isSelected && styles.menu_highlight
                      } ${menu.InActiveInNavigation === 'true' ? styles.disabled:""}`}
                      
                    >
                      {menu.NavigationTitle}
                    </a>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
        {levelTwoData && levelTwoData.child && (
          <div className={`${styles.overlay_wrapper} ${styles[showOverlay]}`}>
            <div
              ref={levelTowRef}
              className={styles.menu_wrapper}
              onMouseEnter={() => {
                setActiveFirstLevelMenu(levelTwoData.parent);
                setShowOverlay('show');
              }}
              onMouseLeave={() => {
                setActiveFirstLevelMenu(null);
                setShowOverlay('hide');
                setLevelTwoData(null);
              }}
            >
              <span
                className={styles.close_icon}
                onClick={() => {
                  setShowOverlay('hide');
                }}
              />
              <div className={styles.second_level_menu_container}>
                <OverlayScrollbarsComponent>
                  <div className={styles.second_level_menu_wrapper}>
                    {levelTwoData.child.map((levelTwoMenu: any, index: any) => {
                      return (
                        <div
                          key={index}
                          className={`${levelTwoMenu.InActiveInNavigation === true ? styles.disabled:""} ${styles.second_level_menu_item} ${styles.active} ${
                            levelTwoMenu.HasChildren ? styles.hasChild : undefined
                          } ${
                            activeSecondLevelMenu === levelTwoMenu.RootID
                              ? styles.highlight
                              : undefined
                          }`}
                          onMouseEnter={() => {
                            levelTwoActivate(levelTwoMenu);
                          }}
                          onMouseLeave={levelTwoDeactivate}
                        >
                          <a className={`clusternav  ${levelTwoMenu.InActiveInNavigation === true ? styles.disabled:""}` }  href={levelTwoMenu.URL &&
                        levelTwoMenu.InActiveInNavigation === false
                          ?  levelTwoMenu.URL && formatLink(levelTwoMenu.URL)
                          : ''} target={levelTwoMenu.NewWindow && levelTwoMenu.NewWindow === true ? '_blank':'_self'}
                           
                          >
                            {levelTwoMenu.Text}
                          </a>
                          {levelTwoMenu.HasChildren && <div className={styles.right_arrow} />}
                        </div>
                      );
                    })}
                  </div>
                </OverlayScrollbarsComponent>
              </div>
              {levelThreeData && levelThreeData.child && (
                <div
                  className={`${styles.third_level_menu_container} ${styles[showThirdLevelMenu]}`}
                  onMouseEnter={() => {
                    setActiveSecondLevelMenu(levelThreeData.parent);
                    setShowThirdLevelMenu('retain');
                  }}
                  onMouseLeave={() => {
                    setActiveSecondLevelMenu(null);
                    setShowThirdLevelMenu('hide');
                  }}
                >
                  <div className={styles.third_level_overlay_wrapper}>
                    <OverlayScrollbarsComponent>
                      <div className={styles.third_level_menu_wrapper}>
                        {levelThreeData.child.map((levelThreeMenu: any, index: any) => {
                          return (
                            <div
                              key={index}
                              className={` ${levelThreeMenu.InActiveInNavigation === true ? styles.disabled:""} ${styles.third_level_menu_item} ${styles.active} ${
                                levelThreeMenu.HasChildren ? styles.hasChild : undefined
                              } ${
                                activeThirdLevelMenu === levelThreeMenu.RootID
                                  ? styles.highlight
                                  : undefined
                              }`}
                              onMouseEnter={() => {
                                levelThreeActivate(levelThreeMenu, levelThreeData);
                              }}
                              onMouseLeave={levelThreeDeactivate}
                            >
                              <a className={`clusternav ${levelThreeMenu.InActiveInNavigation === true ? styles.disabled:""}`}  href={levelThreeMenu.URL &&
                        levelThreeMenu.InActiveInNavigation === false
                          ?  levelThreeMenu.URL && formatLink(levelThreeMenu.URL)
                          : ''} target={levelThreeMenu.NewWindow && levelThreeMenu.NewWindow === true ? '_blank':'_self'}
                               
                              >
                                {levelThreeMenu.Text}
                              </a>
                              {levelThreeMenu.HasChildren && <div className={styles.right_arrow} />}
                            </div>
                          );
                        })}
                      </div>
                    </OverlayScrollbarsComponent>
                  </div>
                </div>
              )}
              {levelFourData && levelFourData.child && (
                <div
                  className={`${styles.fourth_level_menu_container} ${styles[showFourthLevelMenu]} `}
                  onMouseEnter={() => {
                    setShowFourthLevelMenu('retain');
                    setShowThirdLevelMenu('retain');
                    setActiveSecondLevelMenu(levelFourData.levelTwoParent);
                    setActiveThirdLevelMenu(levelFourData.parent);
                  }}
                  onMouseLeave={() => {
                    setActiveSecondLevelMenu(null);
                    setActiveThirdLevelMenu(null);
                    setShowFourthLevelMenu('hide');
                    setShowThirdLevelMenu('hide');
                  }}
                >
                  <div className={styles.fourth_level_overlay_wrapper}>
                    <OverlayScrollbarsComponent>
                      <div className={styles.fourth_level_menu_wrapper}>
                        {levelFourData.child.map((levelFourMenu: any, index: any) => {
                          return (
                            <div
                              key={index}
                              className={` ${levelFourMenu.InActiveInNavigation === true ? styles.disabled:""}  ${styles.fourth_level_menu_item} ${styles.active} ${
                                levelFourMenu.HasChildren ? styles.hasChild : undefined
                              } ${
                                activeFourthLevelMenu === levelFourMenu.RootID
                                  ? styles.highlight
                                  : undefined
                              }`}
                              onMouseEnter={() => {
                                levelFourActivate(levelFourMenu, levelFourData);
                              }}
                              onMouseLeave={levelFourDeactivate}
                            >
                              <a  className={`clusternav ${levelFourMenu.InActiveInNavigation === true ? styles.disabled:""} `} href={levelFourMenu.URL &&
                        levelFourMenu.InActiveInNavigation === false
                          ?  levelFourMenu.URL && formatLink(levelFourMenu.URL)
                          : ''} target={levelFourMenu.NewWindow && levelFourMenu.NewWindow === true ? '_blank':'_self'}
                                
                              >
                                {levelFourMenu.Text}
                              </a>
                              {levelFourMenu.HasChildren && <div className={styles.right_arrow} />}
                            </div>
                          );
                        })}
                      </div>
                    </OverlayScrollbarsComponent>
                  </div>
                </div>
              )}
              {levelFiveData && levelFiveData.child && (
                <div
                  className={`${styles.fifth_level_menu_container} ${styles[showFifthLevelMenu]}`}
                  onMouseEnter={() => {
                    setShowFifthLevelMenu('retain');
                    setShowFourthLevelMenu('retain');
                    setShowThirdLevelMenu('retain');
                    setActiveSecondLevelMenu(levelFiveData.levelTwoParent);
                    setActiveThirdLevelMenu(levelFiveData.levelThreeParent);
                    setActiveFourthLevelMenu(levelFiveData.parent);
                  }}
                  onMouseLeave={() => {
                    setActiveSecondLevelMenu(null);
                    setActiveThirdLevelMenu(null);
                    setActiveFourthLevelMenu(null);
                    setShowFifthLevelMenu('hide');
                    setShowFourthLevelMenu('hide');
                    setShowThirdLevelMenu('hide');
                  }}
                >
                  <div className={styles.fifth_level_overlay_wrapper}>
                    <OverlayScrollbarsComponent>
                      <div className={styles.fifth_level_menu_wrapper}>
                        {levelFiveData.child.map((levelFiveMenu: any, index: any) => {
                          return (
                            <div
                              key={index}
                              className={`${levelFiveMenu.InActiveInNavigation === true ? styles.disabled:""}  ${styles.fifth_level_menu_item} ${styles.active} ${
                                levelFiveMenu.HasChildren ? styles.hasChild : undefined
                              }`}
                            >
                              <a className={`clusternav ${levelFiveMenu.InActiveInNavigation === true ? styles.disabled:""} `} href={levelFiveMenu.URL &&
                        levelFiveMenu.InActiveInNavigation === false
                          ?  levelFiveMenu.URL && formatLink(levelFiveMenu.URL)
                          : ''} target={levelFiveMenu.NewWindow && levelFiveMenu.NewWindow === true ? '_blank':'_self'}
                                
                              >
                                {levelFiveMenu.Text}
                              </a>
                            </div>
                          );
                        })}
                      </div>
                    </OverlayScrollbarsComponent>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
  );
}
