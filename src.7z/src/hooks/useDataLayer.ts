import { useEffect } from 'react';

const useDataLayer = (data?: object | any) => {
  useEffect(() => {
    if (typeof window !== 'undefined' && data && data.clientId && data.userCountry &&
      data.userDivision && window.dataLayer) {
      window.dataLayer = window.dataLayer || [];
      const dataLayerNdx = window.dataLayer.findIndex((dataLayer: any) => dataLayer.clientId);
      if (dataLayerNdx > -1 && dataLayerNdx===0) {
        window.dataLayer[dataLayerNdx] = {
          ...data,
          urlReferrer: document.referrer,
        };
      } else {
        if(window.dataLayer.length===0){
          window.dataLayer.push({
            ...data,
            urlReferrer: document.referrer,
          });
        }else{
          window.dataLayer.unshift({
            ...data,
            urlReferrer: document.referrer,
          });
        }
      }
    }
  }, [data]);

  const addToDataLayer = (dataObject: object) => {
    if (typeof window !== 'undefined' && dataObject) {
      window?.dataLayer?.push({
        ...dataObject,
      });
    }
  };
  return [addToDataLayer];
};

export default useDataLayer;
