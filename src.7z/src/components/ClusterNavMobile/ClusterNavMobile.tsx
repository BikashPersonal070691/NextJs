import { useState, useRef, useEffect } from 'react';
import { getClusterDataMobile, getSecondLevelClusterData } from 'src/services/cluster.service';
import { formatLink } from 'src/helpers/link.helper';
import { useSelector } from 'react-redux';
import { formatClusterNavData } from 'src/helpers/component.helper';
import styles from './ClusterNavMobile.module.scss';
export default function ClusterNavMobile() {
  const [levelOneDataMobile, setLevelOneDataMobile] = useState<any>(null);
  const [levelTwoDataMobile, setLevelTwoDataMobile] = useState<any>(null);
  const [levelThreeDataMobile, setLevelThreeDataMobile] = useState<any>(null);
  const [levelFourDataMobile, setLevelFourDataMobile] = useState<any>(null);
  const [levelFiveDataMobile, setLevelFiveDataMobile] = useState<any>(null);
  const [expandMenu, setExpandMenu] = useState(false);
  const refExpandMenu = useRef<any>();
  const { breadcrumbData } = useSelector((state: any) => state.common);
  const navigationHandler = (menu: any) => {
    const refinedLink = formatLink(menu.URL);
    if (menu.NewWindow === true) {
      window.open(refinedLink, '_blank');
    } else {
      window.open(refinedLink, '_self');
    }
  };
  const switchIcon = () => {
    setExpandMenu(!expandMenu);
    setLevelTwoDataMobile(null);
    setLevelThreeDataMobile(null);
    setLevelFourDataMobile(null);
    setLevelFiveDataMobile(null);
  };
  const getData = () => {
    getClusterDataMobile().then((data: any) => {
      if (data && data.data) {
        if (breadcrumbData && Array.isArray(breadcrumbData) && breadcrumbData.length > 0) {
          const formattedLevelOneData = formatClusterNavData(data.data, breadcrumbData);
          setLevelOneDataMobile({ parent: null, child: formattedLevelOneData });
        } else {
          setLevelOneDataMobile({ parent: null, child: data.data });
        }
        // setLevelOneDataMobile({ parent: null, child: data.data });
      }
    });
  };
  useEffect(() => {
    if (breadcrumbData && Array.isArray(breadcrumbData) && breadcrumbData.length > 0) {
      getData();
    }
  }, [breadcrumbData]);
  const levelOneClickHandler = (menu: any) => {
    getSecondLevelClusterData(menu.RootID, menu.TemplateID).then((data: any) => {
      if (data && data.data) {
        setLevelTwoDataMobile({
          parent: menu,
          child: data.data,
        });
      }
    });
  };

  const levelTwoClickHandler = (menu: any) => {
    const childMenu = menu.Children ? menu.Children : null;
    if (childMenu) {
      setLevelThreeDataMobile({
        parent: menu,
        child: childMenu,
      });
    } else {
      setLevelThreeDataMobile(null);
    }
  };
  const levelThreeClickHandler = (menu: any) => {
    const childMenu = menu.Children ? menu.Children : null;
    if (childMenu) {
      setLevelFourDataMobile({
        parent: menu,
        child: childMenu,
      });
    } else {
      setLevelFourDataMobile(null);
    }
  };
  const levelFourClickHandler = (menu: any) => {
    const childMenu = menu.Children ? menu.Children : null;
    if (childMenu) {
      setLevelFiveDataMobile({
        parent: menu,
        child: childMenu,
      });
    } else {
      setLevelFiveDataMobile(null);
    }
  };
  const getMobileView = () => {
    if (levelFiveDataMobile && levelFiveDataMobile.child) {
      return (
        <>
          <div className={styles.parent_container}>
            <div className={styles.parent_wrapper}>
              <div
                className={styles.left_arrow}
                onClick={() => {
                  setLevelFiveDataMobile(null);
                }}
              ></div>
              <span
                onClick={
                  levelFiveDataMobile.parent.URL &&
                  levelFiveDataMobile.parent.InActiveInNavigation === false
                    ? () => navigationHandler(levelFiveDataMobile.parent)
                    : undefined
                }
              >
                {levelFiveDataMobile.parent.Text}
              </span>
            </div>
          </div>
          <div className={styles.child_menu_wrapper}>
            {levelFiveDataMobile.child.map((menu: any, index: any) => {
              return (
                <div className={styles.menu_item} key={index}>
                  <span
                    onClick={
                      menu.URL && menu.InActiveInNavigation === false
                        ? () => navigationHandler(menu)
                        : undefined
                    }
                  >
                    {menu.Text}
                  </span>
                </div>
              );
            })}
          </div>
        </>
      );
    } else if (levelFourDataMobile && levelFourDataMobile.child) {
      return (
        <>
          <div className={styles.parent_container}>
            <div className={styles.parent_wrapper}>
              <div
                className={styles.left_arrow}
                onClick={() => {
                  setLevelFourDataMobile(null);
                }}
              ></div>
              <span
                onClick={
                  levelFourDataMobile.parent.URL &&
                  levelFourDataMobile.parent.InActiveInNavigation === false
                    ? () => navigationHandler(levelFourDataMobile.parent)
                    : undefined
                }
              >
                {levelFourDataMobile.parent.Text}
              </span>
            </div>
          </div>
          <div className={styles.child_menu_wrapper}>
            {levelFourDataMobile.child.map((menu: any, index: any) => {
              return (
                <div className={styles.menu_item} key={index}>
                  <span
                    onClick={
                      menu.URL && menu.InActiveInNavigation === false
                        ? () => navigationHandler(menu)
                        : undefined
                    }
                  >
                    {menu.Text}
                  </span>
                  {menu.HasChildren && (
                    <div
                      className={styles.right_arrow}
                      onClick={() => {
                        levelFourClickHandler(menu);
                      }}
                    />
                  )}
                </div>
              );
            })}
          </div>
        </>
      );
    } else if (levelThreeDataMobile && levelThreeDataMobile.child) {
      return (
        <>
          <div className={styles.parent_container}>
            <div className={styles.parent_wrapper}>
              <div
                className={styles.left_arrow}
                onClick={() => {
                  setLevelThreeDataMobile(null);
                }}
              ></div>
              <span
                onClick={
                  levelThreeDataMobile.parent.URL &&
                  levelThreeDataMobile.parent.InActiveInNavigation === false
                    ? () => navigationHandler(levelThreeDataMobile.parent)
                    : undefined
                }
              >
                {levelThreeDataMobile.parent.Text}
              </span>
            </div>
          </div>
          <div className={styles.child_menu_wrapper}>
            {levelThreeDataMobile.child.map((menu: any, index: any) => {
              return (
                <div className={styles.menu_item} key={index}>
                  <span
                    onClick={
                      menu.URL && menu.InActiveInNavigation === false
                        ? () => navigationHandler(menu)
                        : undefined
                    }
                  >
                    {menu.Text}
                  </span>
                  {menu.HasChildren && (
                    <div
                      className={styles.right_arrow}
                      onClick={() => {
                        levelThreeClickHandler(menu);
                      }}
                    />
                  )}
                </div>
              );
            })}
          </div>
        </>
      );
    } else if (levelTwoDataMobile && levelTwoDataMobile.child) {
      return (
        <>
          <div className={styles.parent_container}>
            <div className={styles.parent_wrapper}>
              <div
                className={styles.left_arrow}
                onClick={() => {
                  setLevelTwoDataMobile(null);
                }}
              ></div>
              <span
                onClick={
                  levelTwoDataMobile.parent.URL &&
                  levelTwoDataMobile.parent.InActiveInNavigation === 'false'
                    ? () => navigationHandler(levelTwoDataMobile.parent)
                    : undefined
                }
              >
                {levelTwoDataMobile.parent.NavigationTitle}
              </span>
            </div>
          </div>
          <div className={styles.child_menu_wrapper}>
            {levelTwoDataMobile.child.map((menu: any, index: any) => {
              return (
                <div className={styles.menu_item} key={index}>
                  <span
                    onClick={
                      menu.URL && menu.InActiveInNavigation === false
                        ? () => navigationHandler(menu)
                        : undefined
                    }
                  >
                    {menu.Text}
                  </span>
                  {menu.HasChildren && (
                    <div
                      className={styles.right_arrow}
                      onClick={() => {
                        levelTwoClickHandler(menu);
                      }}
                    />
                  )}
                </div>
              );
            })}
          </div>
        </>
      );
    } else if (levelOneDataMobile && levelOneDataMobile.child) {
      return (
        <>
          <div className={styles.child_menu_wrapper}>
            {levelOneDataMobile.child.map((menu: any, index: any) => {
              return (
                <div className={styles.menu_item} key={index}>
                  <span
                    onClick={
                      menu.InActiveInNavigation && menu.URL && menu.InActiveInNavigation === 'false'
                        ? () => navigationHandler(menu)
                        : undefined
                    }
                    className={menu.isSelected && styles.menu_highlight}
                  >
                    {menu.NavigationTitle}
                  </span>
                  {menu.HasChildren && menu.HasChildren === 'true' && (
                    <div
                      className={styles.right_arrow}
                      onClick={() => {
                        levelOneClickHandler(menu);
                      }}
                    />
                  )}
                </div>
              );
            })}
          </div>
        </>
      );
    } else {
      return <></>;
    }
  };
  useEffect(() => {
    const checkIfTouchedOutside = (e: any) => {
      if (refExpandMenu.current && !refExpandMenu.current.contains(e.target) && expandMenu) {
        switchIcon();
      }
    };
    document.addEventListener('touchstart', checkIfTouchedOutside);
    return () => {
      // Cleanup the event listener
      document.removeEventListener('touchstart', checkIfTouchedOutside);
    };
  }, [expandMenu]);
  return (
    <div
      className={`${styles.device_cluster_container} ${expandMenu ? styles.expand : undefined}`}
      ref={refExpandMenu}
    >
      <div className={styles.menu_icon_wrapper}>
        <div className={styles.menu_icon_container}>
          <div
            className={`${styles.expand_icon} ${expandMenu ? styles.showCross : undefined}`}
            onClick={switchIcon}
          >
            <div className={styles.top}></div>
            <div className={styles.middle}></div>
            <div className={styles.bottom}></div>
          </div>
        </div>
      </div>
      <div className={`${styles.menu_wrapper} ${expandMenu ? styles.showMenu : undefined}`}>
        {getMobileView()}
      </div>
    </div>
  );
}
