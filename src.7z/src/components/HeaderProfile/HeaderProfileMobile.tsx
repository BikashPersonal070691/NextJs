import React, { useEffect, useState } from 'react';
import styles from './HeaderProfile.module.scss';
// import { Text } from '@sitecore-jss/sitecore-jss-nextjs';
import ProfilePopup from 'components/ProfilePopup/ProfilePopup';
import { useSelector } from 'react-redux';

export default function HeaderProfileMobile() {
  const [userProfileInfo, setUserProfileInfo] = useState<any>({});
  const [showPopup, setShowPopup] = useState<any>(false);
  const { userProfileData } = useSelector((state: any) => state.profile);

  // const dummyData = {
  //   'ProfileImageURL': '/api/userprofile/getprofileimage?cwid=EHEJA&timestamp=1693293289.87012',
  //   'UserId': null,
  //   'FullName': 'Waseem Khan',
  //   'CountryCode': 'Germany',
  //   'Location': 'Düsseldorf',
  //   'LanguageCode': null,
  //   'Division': 'Crop Science',
  //   'Function': null,
  //   'IsFirstTimeUser': true,
  //   'RemindUserSettings': 0,
  //   'IsEditor': false,
  //   'NewsCreationFormURL': null,
  //   'UsersettingsPopupFlag': 0,
  //   'WelcomePopUpCheck': '1',
  //   'RemindPopUpCheck': '1',
  //   'RussiaRestrictedUserProfile': '0',
  //   'EasyNewsRole': '1',
  //   'EasyNewsUrl': '/en/frontend-news-form'
  // }

  useEffect(() => {
    // setUserProfileInfo(dummyData);
    if (userProfileData !== '') {
      setUserProfileInfo(userProfileData);
    }
  }, [userProfileData]);

  const viewPopup = () => {
    setShowPopup(!showPopup);
  };


  
  return (
    <>
      <div className={`${styles.user_profile_box_wrapper} ${styles.tablet_only}  `}>
        <div className={styles.profile_info_wrapper}>
          <div className={styles.profile_image_wrapper}>
            {/* <img
              className={styles.profile_image}
              src='https://img.freepik.com/premium-photo/mountain-range-is-shown-with-lake-mountains-background_421632-878.jpg'
            /> */}
            <img
              className={styles.profile_image}
              // src='https://img.freepik.com/premium-photo/mountain-range-is-shown-with-lake-mountains-background_421632-878.jpg'
              src={userProfileInfo && userProfileInfo.ProfileImageURL}
            />
          </div>
          <div className={styles.profile_data}>
            <div className={styles.profile_welcome_text}>
              <p>Welcome</p>
            </div>
            <div className={styles.profile_name}>
              {/* <Text
            field={"Maria  Summer"}
            editable={true}
            tag='div'
            className={styles.teaser_image_text}
          /> */}
              <p>{userProfileInfo && userProfileInfo.FullName}</p>
            </div>
          </div>

          {/* <div className={styles.profile_easy_news_icon}></div> */}
          {userProfileInfo && userProfileInfo.EasyNewsRole === '1' ? (
            <a className={styles.profile_easy_news_icon} href={userProfileInfo.EasyNewsUrl}></a>
          ) : (
            ''
          )}

          <div className={styles.profile_edit_icon}>
            <a onClick={viewPopup}></a>
          </div>
        </div>

        <div className={styles.profile_details}>
          <div className={styles.profile_details_section}>
            <div className={`${styles.icon_profile} ${styles.icon_profile_building}  `}></div>
            <p><span>{userProfileInfo && userProfileInfo.Division}</span></p>
          </div>
          <div className={styles.profile_details_country}>
            <div className={`${styles.icon_profile} ${styles.icon_profile_location}  `}></div>
            <p><span>{userProfileInfo && userProfileInfo.CountryCode}</span></p>
          </div>
          <div className={styles.profile_details_country}>
            <div className={`${styles.icon_profile} ${styles.icon_profile_earth }  `}></div>
            <p><span>{userProfileInfo && userProfileInfo.LanguageCode && userProfileInfo.LanguageCode}</span></p>
          </div>
        </div>
        <div>
          {showPopup && (
            <ProfilePopup
              onClose={viewPopup}
              userImage={userProfileInfo && userProfileInfo.ProfileImageURL}
            />
          )}
        </div>
      </div>
    </>
  );
}
