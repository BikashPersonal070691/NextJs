export interface SlickSliderConfig {
  data: any;
  type: any;
  numberOfTiles: number;
  tilesToShow: number;
  isVariableWidth: boolean;
  isAdaptiveHeight: boolean;
  headingData?: any;
  placeHolderName: string;
  showButton?: boolean;
  buttonData?: any;
  parentRef?: any;
  showSideNav?: any;
  showDots?: boolean;
  showTopNav?: boolean;
  isSliderThumbnail?: boolean;
  isImageEnlarge?: boolean;
  isOverlaySlider?: boolean;
  overlayCloseEvent?(): any;
  isDummySlideNeeded?: boolean;
  isSliderSmall?: any;
}
