import { useState, useEffect } from 'react';
import styles from './Toggle.module.scss';
export default function ProfilePopup(props: any) {
  const [value, setValue] = useState(props.isChecked);
  useEffect(() => {
    setValue(props.isChecked);
  }, [props.isChecked]);
  const onCheck = () => {
    setValue(!value);
    if (props.onChange) {
      props.onChange(!value);
    }
  };
  return (
    <>
      {/* <input className='hide' type='checkbox' checked={value} readOnly /> */}
      <label
        className={value === true ? styles.checkbox_subscribe : styles.checkbox_unsubscribe}
        onClick={onCheck}
      ></label>
    </>
  );
}
