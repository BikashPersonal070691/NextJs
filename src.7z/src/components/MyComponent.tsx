import { Text, Field } from '@sitecore-jss/sitecore-jss-nextjs';
import { ComponentProps } from 'lib/component-props';
import { StyleguideSpecimenFields } from 'lib/component-props/styleguide';

type MyComponentProps = ComponentProps &
  StyleguideSpecimenFields & {
    fields: {
      Heading: Field<string>;
    };
  };

const MyComponent = (props: MyComponentProps): JSX.Element => (
  <div>
    <p>This is MyComponent created for testing of inline editing!!!!!</p>
    <Text field={props.fields.Heading} />
  </div>
);
export default MyComponent;
