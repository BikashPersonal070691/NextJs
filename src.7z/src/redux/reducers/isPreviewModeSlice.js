import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';

const isPreviewModeSlice = createSlice({
  name: 'isPreviewMode',
  initialState: {
    isPreviewMode: false,
  },
  reducers: {
    SET_PREVIEWMODE: (state, action) => {
      state.isPreviewMode = action.payload;
    },
  },
});

export const { SET_PREVIEWMODE } = isPreviewModeSlice.actions;
export default isPreviewModeSlice.reducer;
