export interface VideoConfig {
  videoData: any;
}
