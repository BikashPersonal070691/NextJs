import { useEffect, useState } from 'react';
import { ComponentProps } from 'lib/component-props';
import { StyleguideSpecimenFields } from 'lib/component-props/styleguide';
import styles from './FooterLinks.module.scss';
import Link from 'next/link';
import { getFooterData } from 'src/services/footer.service';
import { formatFooterData } from 'src/helpers/footer.helper';
import { KEY_IMPRINT_LINK, KEY_PRIVACY_LINK } from 'src/constants/general';
import { useSitecoreContext } from '@sitecore-jss/sitecore-jss-nextjs';
import { useLanguageTranslate } from 'src/hooks/useLanguageTranslate';
import {
  KEY_FOOTER_ALL_COUNT,
  KEY_FOOTER_CONTENT_OWNER,
  KEY_FOOTER_IMPRINT,
  KEY_FOOTER_LAST_30_DAYS,
  KEY_FOOTER_LAST_UPDATED,
  KEY_FOOTER_PAGE_VIEWS,
  KEY_FOOTER_PRIVACY_STATEMENT,
} from 'src/constants/dictonary';

type FooterLinksProps = ComponentProps &
  StyleguideSpecimenFields & {
    fields: {
      ImprintLink: any;
      PrivacyLink: any;
    };
  };

  

const FooterLinks = ({ fields }: FooterLinksProps) => {
  const { translatedKey } = useLanguageTranslate();
  const { sitecoreContext } = useSitecoreContext();
  const context: any = sitecoreContext;
  const itemId = context.route.itemId;
  const [footerData, setFooterData] = useState<any>({});
  const getData = () => {
    getFooterData(itemId).then((data: any) => {
      if (data && data.data) {
        const formatedFooter = formatFooterData(data.data);
        setFooterData(formatedFooter);
      }
    });
  };

  
  useEffect(() => {
    getData();
    
  }, []);

  
 

  
  const isBrowser = () => typeof window !== 'undefined';
  function scrollToTop() {
    if (!isBrowser()) return;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
  return (
    <div className={styles.footer_wrapper}>
      <div className={styles.footer_inner_wrapper}>
        <div className={styles.left_content}>
          <div className={styles.imprint_wrapper}>
            <Link
              href={`${
                fields &&
                fields.ImprintLink &&
                fields.ImprintLink.value.href &&
                fields.ImprintLink.value.href
                  ? fields.ImprintLink.value.href
                  : KEY_IMPRINT_LINK
              }`}
            >
              {translatedKey(KEY_FOOTER_IMPRINT)}
            </Link>
          </div>
          <div className={styles.privacy_wrapper}>
            <Link
              href={`${
                fields &&
                fields.PrivacyLink &&
                fields.PrivacyLink.value.href &&
                fields.PrivacyLink.value.href
                  ? fields.PrivacyLink.value.href
                  : KEY_PRIVACY_LINK
              }`}
            >
              &nbsp;&#124;&nbsp;
              {translatedKey(KEY_FOOTER_PRIVACY_STATEMENT)}
            </Link>
          </div>
        </div>
        <div className={styles.middle_content}>
          <span>{translatedKey(KEY_FOOTER_CONTENT_OWNER)}&nbsp;</span>
          <span className={styles.author}>
            <a
              href={`mailto:${footerData.ContentOwnerEmail}?subject=BayerNet: ${footerData.PageTitle}`}
            >
              {footerData.ContentOwner}
            </a>
          </span>
          <span className={styles.updation_details}>
            <span className={styles.seperation_bar}>&nbsp;&#124;&nbsp;</span>
            <span className={styles.updated_date} >
              {translatedKey(KEY_FOOTER_LAST_UPDATED)}
              <span >
                 {footerData.UpdatedDate && footerData.UpdatedDate.split('-')[0] && footerData.UpdatedDate.split('-')[0].trim()}<span className={styles.bayersans_hyphen}>-</span>{footerData.UpdatedDate && footerData.UpdatedDate.split('-')[1] && footerData.UpdatedDate.split('-')[1].trim()}<span className={styles.bayersans_hyphen}>-</span>{footerData.UpdatedDate && footerData.UpdatedDate.split('-')[2] && footerData.UpdatedDate.split('-')[2].trim()}</span>
            </span>
           
          </span>
          <span className={styles.details_wrapper}>
            <span className={styles.latest_details}>
              <span className={styles.seperation_bar}>&nbsp;&#124;&nbsp;</span>
              <span className={styles.latest_viewst}>
                {translatedKey(KEY_FOOTER_LAST_30_DAYS)}:&nbsp;{footerData.RecentViewCount}{' '}
                {translatedKey(KEY_FOOTER_PAGE_VIEWS)}
              </span>
            </span>
            <span className={styles.total_details}>
              <span className={styles.seperation_bar}>&nbsp;&#124;&nbsp;</span>
              <span className={styles.total_viewst}>
                {translatedKey(KEY_FOOTER_ALL_COUNT)}:&nbsp;{footerData.TotalViewCount}{' '}
                {translatedKey(KEY_FOOTER_PAGE_VIEWS)}
              </span>
            </span>
          </span>
        </div>
        <div className={styles.right_content}>
          <div className={styles.img_wrapper} onClick={scrollToTop}>
            <div className={styles.img_back_to_top} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default FooterLinks;
