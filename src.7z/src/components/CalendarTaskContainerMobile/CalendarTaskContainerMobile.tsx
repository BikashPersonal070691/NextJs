import { useState } from 'react';
import CalendarTaskMobile from 'components/CalendarTaskMobile/CalendarTaskMobile';
import styles from './CalendarTaskContainerMobile.module.scss';

export default function CalendarTaskContainer(props: any) {
  const { windowWidth, page, tasks, order, monthsWidth } = props;
  const [rowHeight, setRowHeight] = useState(50);
  const [isHeightUpdated, setIsHeightUpdated] = useState(false);
  let childHeightArray: any = [];
  const handleLoad = (childHeight: any) => {
    childHeightArray.push(childHeight);
    if (
      tasks &&
      tasks.length > 0 &&
      childHeightArray.length > 0 &&
      tasks.length === childHeightArray.length
    ) {
      setRowHeight(Math.max(...childHeightArray));
      setIsHeightUpdated(true);
    }
  };
  return (
    <div
      className={styles.calendar_row_container}
      style={{
        width: windowWidth ? 4 * windowWidth : 0,
        left:
          windowWidth && page && page === 4
            ? -3 * windowWidth
            : windowWidth && page && page === 3
            ? -2 * windowWidth
            : windowWidth && page && page === 2
            ? -windowWidth
            : 0,
        height: rowHeight,
      }}
    >
      {tasks &&
        tasks.length > 0 &&
        tasks.map((item: any, index: any) => {
          return (
            <>
              <CalendarTaskMobile
                {...item}
                width={monthsWidth ? monthsWidth : 0}
                key={index}
                order={order ? order : 0}
                handleLoad={handleLoad}
                commonHeight={rowHeight}
                takeHeight={isHeightUpdated}
              />
            </>
          );
        })}
    </div>
  );
}
