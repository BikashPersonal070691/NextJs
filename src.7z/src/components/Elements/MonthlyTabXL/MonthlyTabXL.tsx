import { useState, useEffect } from 'react';
import CalendarSectionXL from 'components/CalendarSectionXL/CalendarSectionXL';
import {
  setHashString,
  groupCalendarEvents,
  getHashString,
  getMonthNameById,
} from 'src/core/utils/utils.helper';
import styles from './MonthlyTabXL.module.scss';
import { KEY_HR_TASK_LAYOUT_SERVICE_RESPONSE } from 'src/constants/general';
import MonthlyView from '../MonthlyView/MonthlyView';
import { useLanguageTranslate } from 'src/hooks/useLanguageTranslate';
import {
  KEY_MONTH_APR,
  KEY_MONTH_AUG,
  KEY_MONTH_DEC,
  KEY_MONTH_FEB,
  KEY_MONTH_JAN,
  KEY_MONTH_JUL,
  KEY_MONTH_JUN,
  KEY_MONTH_MAR,
  KEY_MONTH_MAY,
  KEY_MONTH_NOV,
  KEY_MONTH_OCT,
  KEY_MONTH_SEP,
} from 'src/constants/dictonary';


export function MonthlyTabXL(props: any) {
  const [eventList, setEventList] = useState<any>(null);
  const [active, setActive] = useState<any>();
  const [selectedMonthName, setSelectedMonthName] = useState<any>();
  const handleTabChange = (id: any, month : any=null) => {
    setHashString(id);
    setActive(id);
    setSelectedMonthName(month);
  };
  const { translatedKey } = useLanguageTranslate();
  const d = new Date();
  useEffect(() => {
    //event list will change for months in future enhancement
    if (props && active && active === 'all') {
      const { calendarData } = props;
      const calendarItems =
        calendarData &&
        calendarData.fields &&
        calendarData.fields[KEY_HR_TASK_LAYOUT_SERVICE_RESPONSE]
          ? calendarData.fields[KEY_HR_TASK_LAYOUT_SERVICE_RESPONSE]
          : [];

      setEventList(groupCalendarEvents(calendarItems));
    } else {
      setEventList(null);
    }

    const hashString = getHashString();

    if (hashString.month != '') {
      setActive(hashString.month);
      const exists =  KEY_MONTH_NAMES.filter(function(el) {
        return el.id.toLowerCase() === hashString.month;
      });
      setSelectedMonthName(exists && exists[0] && exists[0].name);
    } else {
      const currentMonth = getMonthNameById(d.getMonth() + 1);
      setActive(currentMonth);
      const exists =  KEY_MONTH_NAMES.filter(function(el) {
        return el.id.toLowerCase() === currentMonth;
      });
      setSelectedMonthName(exists && exists[0] && exists[0].name);
    }
  }, [props]);


  useEffect(() => {
    if (props && active && active === 'all') {
      const { calendarData } = props;
      const calendarItems =
        calendarData &&
        calendarData.fields &&
        calendarData.fields[KEY_HR_TASK_LAYOUT_SERVICE_RESPONSE];
      setEventList(groupCalendarEvents(calendarItems));
    } else {
      setEventList(null);
    }
  }, [active, props.calendarData]);

  const KEY_MONTH_NAMES = [
    { id: KEY_MONTH_JAN, name: translatedKey(KEY_MONTH_JAN).toLowerCase() },
    { id: KEY_MONTH_FEB, name: translatedKey(KEY_MONTH_FEB).toLowerCase() },
    { id: KEY_MONTH_MAR, name: translatedKey(KEY_MONTH_MAR).toLowerCase() },
    { id: KEY_MONTH_APR, name: translatedKey(KEY_MONTH_APR).toLowerCase() },
    { id: KEY_MONTH_MAY, name: translatedKey(KEY_MONTH_MAY).toLowerCase() },
    { id: KEY_MONTH_JUN, name: translatedKey(KEY_MONTH_JUN).toLowerCase() },
    { id: KEY_MONTH_JUL, name: translatedKey(KEY_MONTH_JUL).toLowerCase() },
    { id: KEY_MONTH_AUG, name: translatedKey(KEY_MONTH_AUG).toLowerCase() },
    { id: KEY_MONTH_SEP, name: translatedKey(KEY_MONTH_SEP).toLowerCase() },
    { id: KEY_MONTH_OCT, name: translatedKey(KEY_MONTH_OCT).toLowerCase() },
    { id: KEY_MONTH_NOV, name: translatedKey(KEY_MONTH_NOV).toLowerCase() },
    { id: KEY_MONTH_DEC, name: translatedKey(KEY_MONTH_DEC).toLowerCase() }
  ];

  // const KEY_MONTH_NAMES = [
  //     { id: 1, name: (KEY_MONTH_JAN).toLowerCase() },
  //     { id: 2, name: (KEY_MONTH_FEB).toLowerCase() },
  //     { id: 3, name: (KEY_MONTH_MAR).toLowerCase() },
  //     { id: 4, name: (KEY_MONTH_APR).toLowerCase() },
  //     { id: 5, name: (KEY_MONTH_MAY).toLowerCase() },
  //     { id: 6, name: (KEY_MONTH_JUN).toLowerCase() },
  //     { id: 7, name: (KEY_MONTH_JUL).toLowerCase() },
  //     { id: 8, name: (KEY_MONTH_AUG).toLowerCase() },
  //     { id: 9, name: (KEY_MONTH_SEP).toLowerCase() },
  //     { id: 10, name: (KEY_MONTH_OCT).toLowerCase() },
  //     { id: 11, name: (KEY_MONTH_NOV).toLowerCase() },
  //     { id: 12, name: (KEY_MONTH_DEC).toLowerCase() },
  //   ];

  return (
    <div className={styles.monthy_tab_container}>
      <div className={styles.months_view}>
        <div
          className={`${styles.all_month_wrapper} ${active === 'all' ? styles.active : undefined}`}
          id="all"
          onClick={() => {
            handleTabChange('all');
          }}
        >
          <div className={styles.month}>ALL</div>
        </div>
        <div className={styles.months}>
          {KEY_MONTH_NAMES.map((item: any, index: any) => (
            <div
              className={`${styles.month_wrapper} ${
                active === item.id.toLowerCase() ? styles.active : undefined
              } `}
              id={item.name}
              onClick={() => {
                handleTabChange(item && item.id && item.id.toLowerCase(), item.name);
              }}
              key={index}
            >
              <div className={styles.month}>{item.name}</div>
            </div>
          ))}
        </div>
      </div>

      {active && active === 'all' ? (
        <div className={styles.month_content}>
          {eventList &&
            eventList.map((event: any, index: any) => (
              <CalendarSectionXL taskList={event} key={index} id={index} />
            ))}
        </div>
      ) : (
        <div className={styles.month_content}>
          <MonthlyView
            taskList={props.calendarData}
            monthSelected={active}
            linkboxData={props.linkboxData}
            activeTab={props.activeTab && props.activeTab}
            selectedMonthName={selectedMonthName}
          ></MonthlyView>
        </div>
      )}
    </div>
  );
}
