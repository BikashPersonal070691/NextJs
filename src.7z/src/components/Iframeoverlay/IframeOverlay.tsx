import { Modal } from 'components/Elements/Modal/Modal';
import { MODAL_TYPE_CALENDER } from 'src/constants/general';
import styles from './IframeOverLay.module.scss';

const IframeOverLay = (props: any) => {
  const { iframe } = props;
  const handleCloseIconClick = () => {
    props.closeIframe();
    document.body.style.overflow = 'scroll';
  };

  return (
    <Modal showModal={true} type={MODAL_TYPE_CALENDER}>
      <div className={styles.iframe_overlay}>
        <div className={styles.popup_contents} data-modal={true}>
          <div className={styles.iframe_header}>
            <div className={styles.title}>
              {iframe.fields && iframe.fields.IframeTitle && iframe.fields.IframeTitle.value}
              {/* <a href={iframe.fields && iframe.fields.IframeredirectURL && iframe.fields.IframeredirectURL.value} target='_blank' className={styles.iframe_link_icon}></a> */}
              <a
                href={
                  iframe.fields && iframe.fields.IframeSource && iframe.fields.IframeSource.value
                }
                target="_blank"
                className={styles.iframe_link_icon}
              ></a>
            </div>
            <div className={styles.iframe_close_icon} onClick={handleCloseIconClick}></div>
          </div>

          <iframe
            src={iframe.fields && iframe.fields.IframeSource && iframe.fields.IframeSource.value}
            title={iframe.fields && iframe.fields.IframeTitle && iframe.fields.IframeTitle.value}
          ></iframe>
        </div>
      </div>
    </Modal>
  );
};

export default IframeOverLay;
