import { apiEndpoints } from 'src/core/api/apiEndpoints';
import { httpRequest } from 'src/core/api/httpRequest';

const getContributionStatement = (id: any) => {
  const url = {
    url: `${apiEndpoints.getContributionStatement.url}?apiEndPoint=${id}`,
    isMock: apiEndpoints.getContributionStatement.isMock,
  };
  return httpRequest(url, 'get');
};

export { getContributionStatement };
