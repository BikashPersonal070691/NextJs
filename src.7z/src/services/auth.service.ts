import { apiEndpoints } from 'src/core/api/apiEndpoints';
import { httpRequest } from 'src/core/api/httpRequest';

/**
 * Authenticate user based on the provided credentials
 * @returns
 */
const authenticate = () => {
  return httpRequest(apiEndpoints.authenticate, 'get');
};

export { authenticate };
