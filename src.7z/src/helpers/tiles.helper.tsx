import {
  TILE_HEADLINE,
  // TILE_LINK_TEXT,
  // TILE_LINK_URL,
  TILE_IMAGE,
  TILE_DESCRIPTION,
  TILE_TEXT,
  TILE_LINK,
  TILE_IMAGE_HOVER,
  TILE_SHOW_MOUSE_HOVER,
  TILE_LINK_TEXT,
  TILE_LINK_URL,
} from 'src/constants/general';
// const getTiles = (items: any) => {
//   const formattedTiles = items.map((item: any) => ({
//     abstract:
//       item && item.fields && item.fields.Description && item.fields.Description.value
//         ? item.fields.Description.value
//         : '',
//     image:
//       item && item.fields && item.fields && item.fields.Image && item.fields.Image.value
//         ? item.fields.Image.value
//         : {},
//     hoverImage:
//       item &&
//       item.fields &&
//       item.fields &&
//       item.fields['Mouseover image'] &&
//       item.fields['Mouseover image'].value
//         ? item.fields['Mouseover image'].value
//         : {},
//     link:
//       item &&
//       item.fields &&
//       item.fields.Link &&
//       item.fields.Link.value &&
//       item.fields.Link.value.href
//         ? item.fields.Link.value.href
//         : '',
//     text:
//       item && item.fields && item.fields.Text && item.fields.Text.value
//         ? item.fields.Text.value
//         : '',
//     showHoverImg:
//       item &&
//       item.fields &&
//       item.fields['Show Mouseover effect'] &&
//       item.fields['Show Mouseover effect'].value
//         ? item.fields['Show Mouseover effect'].value
//         : '',
//   }));
//   return formattedTiles;
// };

//
/**
 * format data for Tiles Component
 * @param data
 * @returns formattedData
 *  data for buttons need to be integrated ( using dummy data till data is available)
 */
const formatTilesData = (data: any) => {
  const placeholderData = data && data.rendering && data.rendering.placeholders;
  const formattedData: any = {
    [TILE_HEADLINE]: data && data.fields && data.fields[TILE_HEADLINE],
    showSlider:
      data && data.fields && data.fields['Show as slider'] && data.fields['Show as slider'].value
        ? data.fields['Show as slider'].value
        : false,
    showButton:
      data && data.fields && data.fields['Show button'] && data.fields['Show button'].value
        ? data.fields['Show button'].value
        : false,
    [TILE_LINK_URL]: data && data.fields && data.fields['Button link'],
    [TILE_LINK_TEXT]: data && data.fields && data.fields['Button text'],
    numberOfTiles:
      placeholderData && placeholderData['tile-group'] && placeholderData['tile-group'].length,
  };
  return formattedData;
};

const formatTileItemData = (data: any) => {
  const formattedData: any = {
    [TILE_IMAGE]: data && data[TILE_IMAGE],
    // [TILE_IMAGE]: {
    //   value: {
    //     src: 'http://localhost:8080/Capture.jpg',
    //     alt: '',
    //   },
    // },
    [TILE_DESCRIPTION]: data && data[TILE_DESCRIPTION],
    [TILE_TEXT]: data && data[TILE_TEXT],
    [TILE_LINK]: data && data[TILE_LINK],
    [TILE_IMAGE_HOVER]: data && data[TILE_IMAGE_HOVER],
    // [TILE_IMAGE_HOVER]: {
    //   value: {
    //     src: 'http://localhost:8080/Capture2.png',
    //     alt: '',
    //   },
    // },
    [TILE_SHOW_MOUSE_HOVER]:
      data && data[TILE_SHOW_MOUSE_HOVER] && data[TILE_SHOW_MOUSE_HOVER].value,
  };
  return formattedData;
};
export { formatTilesData, formatTileItemData };
