const formatTabData = (data: any) => {
  const formattedData: any = {
    selectedTab:
      data && data.fields && data.fields['Selected tabs'] && data.fields['Selected tabs'].id
        ? data.fields['Selected tabs'].id
        : null,
    items: data && data.fields && data.fields.items ? data.fields.items : null,
  };
  return formattedData;
};

export { formatTabData };
