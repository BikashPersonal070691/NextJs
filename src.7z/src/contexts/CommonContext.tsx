import { createContext } from 'react';

export const CommonContext = createContext<any>(null);
const CommonProvider = CommonContext.Provider;
const CommonConsumer = CommonContext.Consumer;

export { CommonConsumer, CommonProvider };
