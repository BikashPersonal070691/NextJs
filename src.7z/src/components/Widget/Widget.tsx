import { useEffect, useRef, useState } from 'react';
import {
  ROI5_WIDGET_SCRIPT,
  ROI5_WIDGET_KEY_ITEM,
  ROI5_WIDGET_KEY_SCRIPT,
} from 'src/constants/general';
import styles from './Widget.module.scss';
import Head from 'next/head';
import { getParentClassReference } from 'src/core/utils/utils.helper';
import { CONTENT_100 } from 'src/constants/contentDivider';

declare global {
  namespace JSX {
    interface IntrinsicElements {
      'roi-portlet': any;
    }
  }
}

export default function Widget(props: any) {
  const externalJsUrl = ROI5_WIDGET_SCRIPT;
  const { fields } = props;

  /**
   * @important This code needs to be used in every components inorder to get the content dividers reference
   * @important Also set the reference (ref) and className to the html wrapper as implemented below
   */
  // starts
  const nodeRef = useRef(null);
  const [parentRef, setParentRef] = useState<any>(null);

  useEffect(() => {
    const child: any = nodeRef.current;
    if (child !== null || child !== undefined) {
      setParentRef(getParentClassReference(child));
    } else {
      setParentRef(CONTENT_100);
    }
  }, []);

  return (
    <div ref={nodeRef} className={styles[parentRef]}>
      <Head>
        {/* <script src="%PUBLIC_URL%/runtime-env.js"></script> */}
        <script type="module" src={externalJsUrl}></script>
      </Head>
      {fields[ROI5_WIDGET_KEY_ITEM] &&
      fields[ROI5_WIDGET_KEY_ITEM].fields &&
      fields[ROI5_WIDGET_KEY_ITEM].fields[ROI5_WIDGET_KEY_SCRIPT] &&
      fields[ROI5_WIDGET_KEY_ITEM].fields[ROI5_WIDGET_KEY_SCRIPT].value ? (
        <div className={styles.widget_container}>
          <roi-portlet
            pid={fields[ROI5_WIDGET_KEY_ITEM].fields[ROI5_WIDGET_KEY_SCRIPT].value}
            height="100%"
            width="100%"
          ></roi-portlet>
        </div>
      ) : (
        ''
      )}

      {/* <roi-portlet pid="hr-mgr-devdialogues"></roi-portlet> */}
    </div>
  );
}
