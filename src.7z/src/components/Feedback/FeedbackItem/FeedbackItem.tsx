import { useState } from 'react';
import { Text } from '@sitecore-jss/sitecore-jss-nextjs';
import { Button } from 'components/Elements/Button/Button';
import { KEY_FEEDBACK_QUESTION } from 'src/constants/general';
import { KEY_FEEDBACK_NO, KEY_FEEDBACK_YES } from 'src/constants/dictonary';
import { useLanguageTranslate } from 'src/hooks/useLanguageTranslate';
import styles from './FeedbackItem.module.scss';

export const FeedbackItem = (props: any) => {
  const { feedbackResponse, parentRef, itemData } = props;
  const { translatedKey } = useLanguageTranslate();
  const [switchClass, setSwitchClass] = useState<any>({
    yes: styles.yes__enabled,
    no: styles.no__enabled,
  });
  const handleFeedbackResponse = (resp: boolean) => {
    if (resp) {
      setSwitchClass({ yes: styles.yes__enabled, no: styles.no__disabled });
    } else {
      setSwitchClass({ yes: styles.yes__disabled, no: styles.no__enabled });
    }
    feedbackResponse({ id: itemData && itemData.id, response: resp });
  };

  return (
    <div className={styles[parentRef]}>
      <div className={styles.feedback_item__wrapper}>
        <div className={styles.feedback__question}>
          <Text tag="p" field={itemData[KEY_FEEDBACK_QUESTION]} />
        </div>
        <div className={styles.feedback__action}>
          <div className={styles.action__item}>
            <Button onClick={() => handleFeedbackResponse(true)}>
              <div className={`${styles.button__inner} ${switchClass && switchClass.yes}`}>
                <span className={`${styles.thumbs}`}></span>
                <span>{translatedKey(KEY_FEEDBACK_YES)}</span>
              </div>
            </Button>
          </div>
          <div className={styles.action__item}>
            <Button onClick={() => handleFeedbackResponse(false)}>
              <div className={`${styles.button__inner} ${switchClass && switchClass.no}`}>
                <span className={`${styles.thumbs} `}></span>
                <span>{translatedKey(KEY_FEEDBACK_NO)}</span>
              </div>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};
