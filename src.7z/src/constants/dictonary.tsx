//feedback
export const KEY_FEEDBACK_NO = 'Feedback_No';
export const KEY_FEEDBACK_YES = 'Feedback_Yes';
export const KEY_FEEDBACK_SUBMIT = 'Feedback_Send';
export const KEY_FEEDBACK_THANKS = 'Feedback_Thanks';
export const KEY_FEEDBACK_FAILED = 'Feedback_Something_Wrong';
export const KEY_FEEDBACK_TRY_AGAIN = 'Feedback_Try_Again';
export const KEY_FEEDBACK_CHARACTERS = 'Feedback_Characters';
export const KEY_FEEDBACK_COMMENT = 'Feedback_Leave_Comment';

// cookie
export const KEY_COOKIE_HEADING = 'Cookie_Heading';
export const KEY_COOKIE_DESCRIPTION = 'Cookie_Description';
export const KEY_COOKIE_ACCEPT = 'Cookie_Accept';
export const KEY_COOKIE_REJECT = 'Cookie_Reject';
export const KEY_COOKIE_SETTINGS = 'Cookie_Settings';

// automatic EN
export const KEY_AUTOMATIC_EN = 'Automatic_en';
export const KEY_FOOTER_IMPRINT = 'bag-intra.ws_bayernet.additionalpagefiled.imprint';
export const KEY_FOOTER_PRIVACY_STATEMENT =
  'bag-intra.ws_bayernet.additionalpagefield.privacystatement';
export const KEY_FOOTER_CONTENT_OWNER = 'bag-intra.ws_bayernet.additionalpagefiled.contentowner';
export const KEY_FOOTER_LAST_UPDATED = 'bag-intra.ws_bayernet.additionalpagefiled.lastupdateddate';
export const KEY_FOOTER_VIEWS = 'bag-intra.ws_bayernet.additionalpagefield.views';
export const KEY_FOOTER_LAST_30_DAYS = 'bag-intra.ws_bayernet.anaytics.thirtydaycount';
export const KEY_FOOTER_ALL_COUNT = 'bag-intra.ws_bayernet.anaytics.AllCount';
export const KEY_FOOTER_PAGE_VIEWS = 'bag-intra.ws_bayernet.anaytics.pageviews';

// HR Calendar
export const KEY_CALENDAR_EMPLOYEE = 'Employee';
export const KEY_CALENDAR_PEOPLE_LEADER = 'PeopleLeader';
export const KEY_MONTH_JAN = 'Jan';
export const KEY_MONTH_FEB = 'Feb';
export const KEY_MONTH_MAR = 'Mar';
export const KEY_MONTH_APR = 'Apr';
export const KEY_MONTH_MAY = 'May';
export const KEY_MONTH_JUN = 'Jun';
export const KEY_MONTH_JUL = 'Jul';
export const KEY_MONTH_AUG = 'Aug';
export const KEY_MONTH_SEP = 'Sep';
export const KEY_MONTH_OCT = 'Oct';
export const KEY_MONTH_NOV = 'Nov';
export const KEY_MONTH_DEC = 'Dec';
export const KEY_QUICK_LINKS = 'QuickLinks';
export const KEY_BAYER_TRANSLATE_TEXT = 'TranslateText';
export const KEY_BAYER_TRANSLATE_TO = 'to';
export const KEY_BAYER_TRANSLATE_BY = 'translatedBy';
export const KEY_BAYER_TRANSLATE_DISPLAY = 'DisplayOriginal'
export const KEY_CALENDAR_DUE_TEXT = 'Due';
export const KEY_CALENDAR_MY_HR_TASKS = 'MYHRtasks';

//search box
export const KEY_SEARCH_PEOPLE_FINDER = 'bag-intra.ws_bayernet.search.people';
export const KEY_SEARCH_TOOLS = 'bag-intra.ws_bayernet.search.quickLinks';
export const KEY_SEARCH_SEARCH_CENTER = 'bag-intra.ws_bayernet.search.allcategories';
export const KEY_SEARCH_SEARCH_PLACEHOLDER = 'bag-intra.ws_bayernet.search.searchplaceholder';
export const KEY_SEARCH_SEARCH_BUTTON = 'bag-intra.ws_bayernet.search.searchbutton';

// Profile Popup
export const KEY_PROFILE_ADD_CHANNEL =
  'bag-intra.ws_bayernet.userprefernces.addchannelsplaceholder';
export const KEY_PROFILE_ADD_CHANNEL_TEXT = 'bag-intra.ws_bayernet.userprefernces.addchannels';
export const KEY_PROFILE_ADD_TAGS_TEXT = 'bag-intra.ws_bayernet.userprefernces.addtags';
export const KEY_PROFILE_ADD_TAGS = 'bag-intra.ws_bayernet.userprefernces.addtagsplaceholder';
export const KEY_PROFILE_ADDITIONAL_CHANNELS =
  'bag-intra.ws_bayernet.userprefernces.additionalchannels';
export const KEY_PROFILE_ADDITIONAL_TOPICS = 'bag-intra.ws_bayernet.userprefernces.additionaltags';
export const KEY_PROFILE_CHANGE_CHANNEL_SETTINGS =
  'bag-intra.ws_bayernet.userprefernces.channels.changesettings';
export const KEY_PROFILE_CHANNELS_TEXT_MAXTAGS_REACHED =
  'bag-intra.ws_bayernet.userprefernces.maxtagsreached';
export const KEY_PROFILE_PROFILE = 'bag-intra.ws_bayernet.userprefernces.profile';
export const KEY_PROFILE_CHANGE_TAGS_SETTINGS =
  'bag-intra.ws_bayernet.userprefernces.tags.changesettings';
export const KEY_PROFILE_BUSINESS_PARTNERS =
  'bag-intra.ws_bayernet.userprefernces.businesspartners';
export const KEY_PROFILE_COMMENT = 'bag-intra.ws_bayernet.userprefernces.comment';
export const KEY_PROFILE_DESCRIPTION_USER = 'bag-intra.ws_bayernet.userprefernces.descriptionuser';
export const KEY_PROFILE_DIVISION_BUSINESS_UNTI =
  'bag-intra.ws_bayernet.userprefernces.divisionandbusinessunit';
export const KEY_PROFILE_SELECT = 'bag-intra.ws_bayernet.userprefernces.select	';
export const KEY_PROFILE_ERROR_MESSAGE = 'bag-intra.ws_bayernet.userprefernces.errormsg';
export const KEY_PROFILE_FUNCTION_UNIT = 'bag-intra.ws_bayernet.userprefernces.functionunit';
export const KEY_PROFILE_LIKES = 'bag-intra.ws_bayernet.userprefernces.likes';
export const KEY_PROFILE_LOCATION = 'bag-intra.ws_bayernet.userprefernces.location';
export const KEY_PROFILE_MACHINE_USER = 'bag-intra.ws_bayernet.userprefernces.machineUser';
export const KEY_PROFILE_NEWSLETTER_DESCRIPTION =
  'bag-intra.ws_bayernet.userprefernces.newsletter.description';
export const KEY_PROFILE_NEWSLETTER_HEADING =
  'bag-intra.ws_bayernet.userprefernces.newsletter.newslettertabheading';
export const KEY_PROFILE_NEWSLETTER_TITLE =
  'bag-intra.ws_bayernet.userprefernces.newsletter.newslettertitle';
export const KEY_PROFILE_SUBSCRIBETONEWSLETTER =
  'bag-intra.ws_bayernet.userprefernces.newsletter.subscribetonewsletter';
export const KEY_PROFILE_NO_RESULTS_FOUND = 'bag-intra.ws_bayernet.userprefernces.noresultsfound';
export const KEY_PROFILE_NOT_FOUND = 'bag-intra.ws_bayernet.userprefernces.notfound';
export const KEY_PROFILE_PLEASE_ENTER_VALID_ENTRY =
  'bag-intra.ws_bayernet.userprefernces.pleaseentervalidentry';
export const KEY_PROFILE_CHANNELS_PROFILE_NOT_SELECTED_ERROR =
  'bag-intra.ws_bayernet.userprefernces.channels.profilenotselectederror';
export const KEY_PROFILE_TAGS_PROFILE_NOT_SELECTED_ERROR =
  'bag-intra.ws_bayernet.userprefernces.tags.profilenotselectederro';
export const KEY_PROFILE_DESC = 'bag-intra.ws_bayernet.userprefernces.desc';
export const KEY_PROFILE_PROFILE_SETTINGS = 'bag-intra.ws_bayernet.userprefernces.profilesettings';
export const KEY_PROFILE_BROWSE = 'bag-intra.ws_bayernet.userprefernces.browse';
export const KEY_PROFILE_CANCEL = 'bag-intra.ws_bayernet.userprefernces.cancel';
export const KEY_PROFILE_ERROR_MESSAGE_ON_SIZE =
  'bag-intra.ws_bayernet.userprefernces.errorMessageOnSize	';
export const KEY_PROFILE_FILESIZE_VALIDATION =
  'bag-intra.ws_bayernet.userprefernces.fileSizeValidation';
export const KEY_PROFILE_SELECT_PROFILE_IMAGE =
  'bag-intra.ws_bayernet.userprefernces.selectProfileImage';
export const KEY_PROFILE_UNABLE_TO_SAVE_VALIDATION =
  'bag-intra.ws_bayernet.userprefernces.unableToSaveValidation';
export const KEY_PROFILE_UPLOAD_AND_SAVE = 'bag-intra.ws_bayernet.userprefernces.uploadAndSave';
export const KEY_PROFILE_UPLOAD_BY_BROWSING_DESKTOP =
  'bag-intra.ws_bayernet.userprefernces.uploadByBrowsingDesktop';
export const KEY_PROFILE_UPLOAD_BY_BROWSING_DEVICE =
  'bag-intra.ws_bayernet.userprefernces.uploadByBrowsingDevice';
export const KEY_PROFILE_UPLOAD_IMAGE_HEADING =
  'bag-intra.ws_bayernet.userprefernces.uploadImageHeading';
export const KEY_PROFILE_WELCOME = 'bag-intra.ws_bayernet.userprefernces.welcome';
export const KEY_PROFILE_WELCOMEBOX_CHANGE =
  'bag-intra.ws_bayernet.userpreferences.welcomebox.change';
export const KEY_PROFILE_DESCRIPTION_WELCOME1 =
  'bag-intra.ws_bayernet.userpreferences.welcomebox.descriptionwelcome1';
export const KEY_PROFILE_DESCRIPTION_WELCOME2 =
  'bag-intra.ws_bayernet.userpreferences.welcomebox.descriptionwelcome2	';
export const KEY_PROFILE_SAVE = 'bag-intra.ws_bayernet.global.captions.saveallsettings';
export const KEY_PROFILE_SSUCCESS = 'bag-intra.ws_bayernet.global.messages.successmessage';
