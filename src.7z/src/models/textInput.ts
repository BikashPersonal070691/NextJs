export interface TextInputConfig {
  name: string;
  id: string;
  value?: any;
  onChange: any;
  className: string;
  placeHolder?: any;
  onKeyPress: any;
}
