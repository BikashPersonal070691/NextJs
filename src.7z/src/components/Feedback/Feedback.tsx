import { useEffect, useRef, useState } from 'react';
import { getParentClassReference } from 'src/core/utils/utils.helper';
import { CONTENT_100 } from 'src/constants/contentDivider';
import { Text, Field } from '@sitecore-jss/sitecore-jss-nextjs';
import { FeedbackItem } from './FeedbackItem/FeedbackItem';
import { TextArea } from 'components/Elements/Textarea/TextArea';
import { TEXTAREA_CUSTOM } from 'src/constants/elements';
import { KEY_FEEDBACK_HEADING, KEY_FEEDBACK_WORD_COUNT } from 'src/constants/general';
import { Button } from 'components/Elements/Button/Button';
import styles from './Feedback.module.scss';
import { KEY_FEEDBACK_QUESTION } from 'src/constants/general';
import { ComponentProps } from 'lib/component-props';
import { StyleguideSpecimenFields } from 'lib/component-props/styleguide';
import { formatFeedbackData } from 'src/helpers/component.helper';
import { useLanguageTranslate } from 'src/hooks/useLanguageTranslate';
import {
  KEY_FEEDBACK_SUBMIT,
  // KEY_FEEDBACK_THANKS,
  // KEY_FEEDBACK_FAILED,
  // KEY_FEEDBACK_TRY_AGAIN,
  KEY_FEEDBACK_CHARACTERS,
  KEY_FEEDBACK_COMMENT,
} from 'src/constants/dictonary';

type FeedbackComponentProps = ComponentProps &
  StyleguideSpecimenFields & {
    fields: {
      [KEY_FEEDBACK_QUESTION]: Field<string>;
      [KEY_FEEDBACK_HEADING]: Field<string>;
    };
  };

const Feedback = (props: FeedbackComponentProps) => {
  const feedbackFinalData = formatFeedbackData(props);
  const { translatedKey } = useLanguageTranslate();
  /**
   * @important This code needs to be used in every components inorder to get the content dividers reference
   * @important Also set the reference (ref) and className to the html wrapper as implemented below
   */
  // starts
  const nodeRef = useRef(null);
  const [parentRef, setParentRef] = useState<any>(null);
  const [feedbackData, setFeedbackData] = useState<any>([]);
  const [counter, setCounter] = useState<number>(KEY_FEEDBACK_WORD_COUNT);
  useEffect(() => {
    const child: any = nodeRef.current;
    if (child !== null || child !== undefined) {
      setParentRef(getParentClassReference(child));
    } else {
      setParentRef(CONTENT_100);
    }
  }, []);
  //ends

  const getCharacterCount = (cnt: any) => {
    if (cnt && cnt !== '' && cnt !== null) {
      let contentCount: any = cnt && cnt.replace(/^\s+|\s+$/gm, '').length;
      let finalCount: any = KEY_FEEDBACK_WORD_COUNT - contentCount;
      if (finalCount !== '') {
        setCounter(finalCount);
      }
    }
  };
  const handleFeedbackResponseData = (response: any) => {
    setFeedbackData([...feedbackData.filter((o: any) => o.id !== response.id), { ...response }]);
  };

  return (
    <div ref={nodeRef} className={styles[parentRef]}>
      <div className={styles.feedback__container}>
        <div className={styles.feedback_inner__container}>
          <div className={styles.feedback__heading}>
            <Text tag="h3" field={feedbackFinalData && feedbackFinalData[KEY_FEEDBACK_HEADING]} />
          </div>
          <div className={styles.feedback_items__container}>
            {feedbackFinalData &&
            feedbackFinalData.feedbackItems &&
            Array.isArray(feedbackFinalData.feedbackItems) &&
            feedbackFinalData.feedbackItems.length !== 0
              ? feedbackFinalData.feedbackItems.map((item: any, index: any) => {
                  return (
                    <FeedbackItem
                      feedbackResponse={handleFeedbackResponseData}
                      parentRef={parentRef}
                      itemData={item}
                      key={index}
                    />
                  );
                })
              : ''}
          </div>
          <div className={styles.feedback_textarea__container}>
            <TextArea
              id="feedback_textarea"
              name="feedback_textarea"
              className={styles.feedback__textarea}
              type={TEXTAREA_CUSTOM}
              autoFocus={false}
              placeHolder={translatedKey(KEY_FEEDBACK_COMMENT)}
              onKeyDown={getCharacterCount}
              maxLength={KEY_FEEDBACK_WORD_COUNT}
            />
            <div className={styles.feedback_textarea__counter}>
              {counter} {translatedKey(KEY_FEEDBACK_CHARACTERS)}
            </div>
          </div>
          <div className={styles.feedback_submit__container}>
            <Button
              class={styles.feedback_submit__button}
              disabled={feedbackData && Object.keys(feedbackData).length !== 0 ? false : true}
            >
              {translatedKey(KEY_FEEDBACK_SUBMIT)}
            </Button>
          </div>
        </div>
        {/* <div className={styles.feedback_response__success}>
          <div className={styles.feedback_success__icon}></div>
          <div className={styles.feedback_success__text}>{translatedKey(KEY_FEEDBACK_THANKS)}</div>
        </div>
        <div className={styles.feedback_response__failed}>
          <div className={styles.feedback_failed__icon}></div>
          <div className={styles.feedback_failed_content__wrapper}>
            <div className={styles.feedback_failed__text}>{translatedKey(KEY_FEEDBACK_FAILED)}</div>
            <Button class={styles.feedback_failed__button}>
              {translatedKey(KEY_FEEDBACK_TRY_AGAIN)}
            </Button>
          </div>
        </div> */}
      </div>
    </div>
  );
};

export default Feedback;
