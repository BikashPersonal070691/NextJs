import { apiEndpoints } from 'src/core/api/apiEndpoints';
import { httpRequest } from 'src/core/api/httpRequest';

const isLeader = () => {
  const url = apiEndpoints.getUserRole;
  return httpRequest(url, 'get');
};

export { isLeader };
