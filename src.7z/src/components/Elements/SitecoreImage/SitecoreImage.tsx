import styles from './SitecoreImage.module.scss';
import { Image } from '@sitecore-jss/sitecore-jss-nextjs';

export function SitecoreImage(props: any) {
  const { field, editable, height, width, className } = props;
  return (
    <div className={styles.sitecore_image__container}>
      <div className={styles.sitecore_image__wrapper}>
        <Image
          field={field}
          editable={editable}
          // imageParams={{ mw: 100, mh: 50 }}
          height={height}
          width={width}
          className={className}
        />
      </div>
    </div>
  );
}
