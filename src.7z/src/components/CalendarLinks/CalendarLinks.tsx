import { useEffect, useRef, useState } from 'react';
import {
  // countryPersonalizedQuickLinks,
  getParentClassReference,
} from 'src/core/utils/utils.helper';
// import { getParentClassReference } from 'src/core/utils/utils.helper';
import styles from './CalendarLinks.module.scss';
import { CONTENT_100 } from 'src/constants/contentDivider';
import {
  CALENDAR_LINK_TEXT,
  CALENDAR_LINK_URL,
  KEY_ROLE_EMPLOYEE,
  KEY_ROLE_EMP_AND_PEOPLE_LEADER,
  KEY_ROLE_PEOPLE_LEADER,
} from 'src/constants/general';
// import { getProfileInfo } from 'src/services/menu.service';
// import { useSelector } from 'react-redux';
import { useLanguageTranslate } from 'src/hooks/useLanguageTranslate';
import { KEY_QUICK_LINKS } from 'src/constants/dictonary';

export default function CalendarLinks(props: any) {
  const { translatedKey } = useLanguageTranslate();
  const { selectedMonthLinkList, activeTab } = props;
  const [isLeader, setIsLeader] = useState<any>(null);
  const [finalLinks, setFinalLinks] = useState<any>([]);
  // const { userProfileData } = useSelector((state: any) => state.profile);

  useEffect(() => {
    const monthLinks: any =
      selectedMonthLinkList &&
      selectedMonthLinkList[0] &&
      selectedMonthLinkList[0].fields &&
      selectedMonthLinkList[0].fields.items &&
      Array.isArray(selectedMonthLinkList[0].fields.items)
        ? selectedMonthLinkList[0].fields.items
        : [];

    const defaultLinks: any =
      selectedMonthLinkList &&
      selectedMonthLinkList[1] &&
      selectedMonthLinkList[1].fields &&
      selectedMonthLinkList[1].fields.items &&
      Array.isArray(selectedMonthLinkList[1].fields.items)
        ? selectedMonthLinkList[1].fields.items
        : [];

    const linkList = [...monthLinks, ...defaultLinks];

    /**
     * Sorting links alphabatically
     */

    // linkList.sort(function (a, b) {
    //   const textA = a.fields && a.fields[CALENDAR_LINK_TEXT] && a.fields[CALENDAR_LINK_TEXT].value && a.fields[CALENDAR_LINK_TEXT].value.toUpperCase();
    //   const textB = b.fields && b.fields[CALENDAR_LINK_TEXT] && b.fields[CALENDAR_LINK_TEXT].value && b.fields[CALENDAR_LINK_TEXT].value.toUpperCase();
    //   return textA < textB ? -1 : textA > textB ? 1 : 0;
    // });

    /**
     * Code for country specific quick links in HR Calendar monthly view
     * Added on : 16 March 24
     */

    // if (userProfileData && userProfileData.CountryCode) {
    //   const CountryCode: any = userProfileData && userProfileData.CountryCode ? userProfileData.CountryCode : '';
    //   const filteredLinks = countryPersonalizedQuickLinks(CountryCode, linkList);
    //   setFinalLinks(filteredLinks);
    // } else {
    //   getProfileInfo().then((data) => {
    //     if (data && data.data) {
    //       const CountryCode: any = data.data && data.data.CountryCode ? data.data.CountryCode : '';
    //       const filteredLinks = countryPersonalizedQuickLinks(CountryCode, linkList);
    //       setFinalLinks(filteredLinks);
    //     }
    //   });
    // }
    setFinalLinks(linkList);
  }, [selectedMonthLinkList]);

  /**
   * @important This code needs to be used in every components inorder to get the content dividers reference
   * @important Also set the reference (ref) and className to the html wrapper as implemented below
   */
  // starts
  const nodeRef = useRef(null);
  const [parentRef, setParentRef] = useState<any>(null);

  /**Sorting links alphabatically */

  useEffect(() => {
    const child: any = nodeRef.current;
    if (child !== null || child !== undefined) {
      setParentRef(getParentClassReference(child));
    } else {
      setParentRef(CONTENT_100);
    }
    if (activeTab === 1) {
      setIsLeader(false);
    } else {
      setIsLeader(true);
    }
  }, [activeTab]);

  return (
    <div ref={nodeRef} className={styles[parentRef]}>
      <div className={styles.linkBox__container}>
        <div className={styles.linkBox_heading__container}>
          <div className={styles.linkBox__heading}>
            <p>{translatedKey(KEY_QUICK_LINKS)}</p>
          </div>
        </div>
        <div className={styles.linkbox_data__container}>
          {finalLinks.map((item: any, index: any) => {
            return isLeader ? (
              item &&
              item.fields &&
              item.fields.ShowTo &&
              item.fields.ShowTo.value &&
              (item.fields.ShowTo.value === KEY_ROLE_PEOPLE_LEADER ||
                item.fields.ShowTo.value === KEY_ROLE_EMP_AND_PEOPLE_LEADER) ? (
                <div className={styles.linkbox_data__wrapper} key={index}>
                  <a
                    href={
                      item.fields &&
                      item.fields[CALENDAR_LINK_URL] &&
                      item.fields[CALENDAR_LINK_URL].value &&
                      item.fields[CALENDAR_LINK_URL].value.href
                    }
                    className={styles.linkBox_data__sub_heading}
                    target={
                      item.fields &&
                      item.fields[CALENDAR_LINK_URL] &&
                      item.fields[CALENDAR_LINK_URL].value &&
                      item.fields[CALENDAR_LINK_URL].value.target
                        ? item.fields[CALENDAR_LINK_URL].value.target
                        : ''
                    }
                  >
                    {item.fields &&
                      item.fields[CALENDAR_LINK_TEXT] &&
                      item.fields[CALENDAR_LINK_TEXT].value &&
                      item.fields[CALENDAR_LINK_TEXT].value}
                  </a>
                </div>
              ) : (
                ''
              )
            ) : item &&
              item.fields &&
              item.fields.ShowTo &&
              item.fields.ShowTo.value &&
              (item.fields.ShowTo.value === KEY_ROLE_EMPLOYEE ||
                item.fields.ShowTo.value === KEY_ROLE_EMP_AND_PEOPLE_LEADER) ? (
              <div className={styles.linkbox_data__wrapper} key={index}>
                <a
                  href={
                    item.fields &&
                    item.fields[CALENDAR_LINK_URL] &&
                    item.fields[CALENDAR_LINK_URL].value &&
                    item.fields[CALENDAR_LINK_URL].value.href
                  }
                  target={
                    item.fields &&
                    item.fields[CALENDAR_LINK_URL] &&
                    item.fields[CALENDAR_LINK_URL].value &&
                    item.fields[CALENDAR_LINK_URL].value.target
                      ? item.fields[CALENDAR_LINK_URL].value.target
                      : ''
                  }
                  className={styles.linkBox_data__sub_heading}
                >
                  {item.fields &&
                    item.fields[CALENDAR_LINK_TEXT] &&
                    item.fields[CALENDAR_LINK_TEXT].value &&
                    item.fields[CALENDAR_LINK_TEXT].value}
                </a>
              </div>
            ) : (
              ''
            );
          })}
        </div>
      </div>
    </div>
  );
}
