import { useRef, useState, useEffect } from 'react';
import Slider from 'react-slick';
import { Button } from 'components/Elements/Button/Button';
import { SLIDE_WIDTH } from '../../constants/general';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import styles from './TeaserSlider.module.scss';
import Teaser from 'components/Teaser/Teaser';
import { Text } from '@sitecore-jss/sitecore-jss-nextjs';

export default function TilesSlider(props: any) {
  let refinedTilesData: any = props;
  refinedTilesData = {
    showSlider: true,
    teasers: props.teaserData,
    numberOfTiles: props.teaserData.length,
  };

  const slideRef = useRef<any>(null);
  const containerRef = useRef<any>(null);
  const [isFirstSlideDisabled, setIsFirstSlideDisabled] = useState(true);
  const [isLastSlideDisabled, setIsLastSlideDisabled] = useState(false);
  const [settings, setSettings] = useState<any>('');
  const getTilesToShow = () => {
    if (containerRef && containerRef.current && containerRef.current.clientWidth) {
      return Math.ceil(
        (containerRef && containerRef.current && containerRef.current.clientWidth) / SLIDE_WIDTH
      );
    } else {
      return 1;
    }
  };
  const getTilesToNav = () => {
    if (containerRef && containerRef.current && containerRef.current.clientWidth) {
      return Math.floor(
        (containerRef && containerRef.current && containerRef.current.clientWidth) / SLIDE_WIDTH
      );
    } else {
      return 1;
    }
  };
  const navNeeded = refinedTilesData.numberOfTiles > getTilesToNav() ? true : false;

  useEffect(() => {
    setSettings({
      arrows: false,
      infinite: false,
      draggable: false,
      speed: 500,
      slidesToShow: getTilesToShow(),
      slidesToScroll: 1,
      variableWidth: true,
      afterChange: (current: any) => {
        if (current === 0) {
          setIsFirstSlideDisabled(true);
        } else {
          setIsFirstSlideDisabled(false);
        }
        const totalSlides =
          getTilesToShow() > 1
            ? refinedTilesData.numberOfTiles + 1
            : refinedTilesData.numberOfTiles;
        if (totalSlides > current + getTilesToShow()) {
          setIsLastSlideDisabled(false);
        } else {
          setIsLastSlideDisabled(true);
        }
      },
    });
    const handleWindowResize = () => {
      setSettings({
        arrows: false,
        infinite: false,
        speed: 500,
        slidesToShow: getTilesToShow(),
        slidesToScroll: 1,
        variableWidth: true,
        afterChange: (current: any) => {
          if (current === 0) {
            setIsFirstSlideDisabled(true);
          } else {
            setIsFirstSlideDisabled(false);
          }
          const totalSlides =
            getTilesToShow() > 1
              ? refinedTilesData.numberOfTiles + 1
              : refinedTilesData.numberOfTiles;
          if (totalSlides > current + getTilesToShow()) {
            setIsLastSlideDisabled(false);
          } else {
            setIsLastSlideDisabled(true);
          }
        },
      });
    };
    window.addEventListener('resize', handleWindowResize);

    return () => {
      window.removeEventListener('resize', handleWindowResize);
    };
  }, []);

  const goPrev = () => {
    slideRef.current.slickPrev();
  };
  const goNext = () => {
    slideRef.current.slickNext();
  };
  const navigationHandler = (link: any) => {
    window.open(link, '_blank');
  };

  return (
    <div className={styles.slider_container} ref={containerRef}>
      <div className={styles.headline_container}>
        <Text
          field={props.headLine}
          editable={true}
          tag="div"
          className={styles.teasergroup_headline}
        />
        <div className={styles.left_container}>
          <div
            className={`${styles.button_wrapper} ${
              refinedTilesData && refinedTilesData.showSlider && navNeeded ? '' : styles.hide
            }`}
          >
            <button
              className={`${styles.previous}  ${isFirstSlideDisabled ? styles.disabled : ''}`}
              onClick={goPrev}
            ></button>
            <button
              className={`${styles.next} ${isLastSlideDisabled ? styles.disabled : ''}`}
              onClick={goNext}
            ></button>
          </div>
        </div>
        {refinedTilesData && refinedTilesData.showButton && (
          <div className={styles.right_container}>
            {refinedTilesData && refinedTilesData.buttonText && refinedTilesData.buttonLink && (
              <Button
                class={styles.carousel_button}
                onClick={() => navigationHandler(refinedTilesData.buttonLink)}
              >
                <span>{refinedTilesData.buttonText}</span>
              </Button>
            )}
          </div>
        )}
      </div>
      <div className={`${styles.slider_wrapper} ${styles.active}`}>
        {refinedTilesData && refinedTilesData.teasers && (
          <Slider ref={slideRef} {...settings}>
            {refinedTilesData.teasers.map((item: any, index: any) => {
              return (
                <Teaser
                  {...item}
                  groupView={{ value: true }}
                  sliderview={props.sliderview}
                  key={index}
                />
              );
            })}

            {getTilesToShow() > 1 && <div></div>}
          </Slider>
        )}
      </div>
    </div>
  );
}
