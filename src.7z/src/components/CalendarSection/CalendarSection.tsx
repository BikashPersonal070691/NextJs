import { useState, useEffect, useRef } from 'react';
import styles from './CalendarSection.module.scss';
import CalendarTaskContainer from 'components/CalendarTaskContainer/CalendarTaskContainer';
import { Image } from '@sitecore-jss/sitecore-jss-nextjs';
import { getHashString, getTaskDetails, groupByTaskType } from 'src/core/utils/utils.helper';
import LightBoxOverLay from 'components/LightBoxOverlay/LightBoxOverlay';
export default function CalendarSection(props: any) {
  const { taskList, page, monthsWidth, id } = props;
  // const formattedTaskList = getTaskDetails(taskList);
  const [formattedTaskList, setFormattedTaskList] = useState([]);
  const taskListByType = groupByTaskType(formattedTaskList);
  const [isOpen, setIsOpen] = useState(false);
  const [selectedTask, setSelectedTask] = useState({});

  const hashString: any = getHashString();

  useEffect(() => {
    if (hashString && hashString.popupId != '') {
      const selectedTask = formattedTaskList.filter(function (item: any) {
        return item.id === hashString.popupId;
      });
      if (selectedTask && selectedTask[0]) {
        setIsOpen(true);
        setSelectedTask(selectedTask && selectedTask[0]);
      }
    }

    setFormattedTaskList(getTaskDetails(taskList));
  }, [taskList]);

  const closeOverlay = () => {
    setIsOpen(false);
    setSelectedTask({});
  };
  // const dummyFormattedList = [
  //   { fields: { Name: { value: 'Test1' } }, duration: { duration: 1, startMonth: 1, endMonth: 1 } },
  //   { fields: { Name: { value: 'Test2' } }, duration: { duration: 2, startMonth: 2, endMonth: 3 } },
  //   { fields: { Name: { value: 'Test3' } }, duration: { duration: 3, startMonth: 4, endMonth: 6 } },
  //   { fields: { Name: { value: 'Test7' } }, duration: { duration: 1, startMonth: 7, endMonth: 7 } },
  //   { fields: { Name: { value: 'Test8' } }, duration: { duration: 1, startMonth: 8, endMonth: 8 } },
  //   { fields: { Name: { value: 'Test9' } }, duration: { duration: 1, startMonth: 9, endMonth: 9 } },
  //   {
  //     fields: { Name: { value: 'Test10' } },
  //     duration: { duration: 1, startMonth: 10, endMonth: 10 }
  //   },
  //   {
  //     fields: { Name: { value: 'Test11' } },
  //     duration: { duration: 1, startMonth: 11, endMonth: 11 }
  //   },
  //   {
  //     fields: { Name: { value: 'Test12' } },
  //     duration: { duration: 1, startMonth: 12, endMonth: 12 }
  //   }
  // ];
  const [windowWidth, setWindowWidth] = useState<any>();
  const containerRef = useRef<any>(null);

  const handleResize = () => {
    if (containerRef && containerRef.current && containerRef.current.clientWidth) {
      if (containerRef.current.clientWidth < 730) {
        setWindowWidth(containerRef.current.clientWidth - 105 - 20);
      } else {
        setWindowWidth(containerRef.current.clientWidth - 175);
      }
    }
  };

  useEffect(() => {
    if (containerRef && containerRef.current && containerRef.current.clientWidth) {
      if (containerRef.current.clientWidth < 730) {
        setWindowWidth(containerRef.current.clientWidth - 105 - 20);
      } else {
        setWindowWidth(containerRef.current.clientWidth - 175);
      }
    }
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <>
      <div className={styles.calendar_row_wrapper} ref={containerRef}>
        {taskList && taskList.length > 0 ? (
          <div className={styles.calendar_row_title}>
            <div className={styles.title_image}>
              <Image
                field={
                  taskList[0].fields.CalenderSection &&
                  taskList[0].fields.CalenderSection.fields.icon
                }
              />
            </div>
            <div className={styles.title_text}>
              {/* {taskList[0].fields.CalenderSection && taskList[0].fields.CalenderSection.displayName} */}
              {taskList[0].fields.CalenderSection &&
                taskList[0].fields.CalenderSection.fields &&
                taskList[0].fields.CalenderSection.fields['Section Name'] &&
                taskList[0].fields.CalenderSection.fields['Section Name'].value}
            </div>
          </div>
        ) : (
          ''
        )}

        <div className={styles.calendar_task_section}>
          {Object.keys(taskListByType).map((key) => (
            // <div
            //   className={styles.calendar_row_container}
            //   key={key}
            //   style={{
            //     width: windowWidth ? 2 * windowWidth : 0,
            //     left: windowWidth && page && page === 2 ? -windowWidth : 0
            //   }}
            // >
            //   {taskListByType[key] &&
            //     taskListByType[key].length > 0 &&
            //     taskListByType[key].map((item: any, index: any) => {
            //       return (
            //         <>
            //           <CalendarTask
            //             {...item}
            //             width={monthsWidth ? monthsWidth : 0}
            //             key={index}
            //             order={id ? id : 0}
            //           />
            //         </>
            //       );
            //     })}
            // </div>
            <CalendarTaskContainer
              key={key}
              windowWidth={windowWidth}
              page={page}
              tasks={taskListByType[key]}
              order={id ? id : 0}
              monthsWidth={monthsWidth}
            />
          ))}
        </div>
      </div>
      {isOpen ? (
        <LightBoxOverLay taskDetails={selectedTask} isOpen={isOpen} closeOverlay={closeOverlay} />
      ) : (
        ''
      )}
    </>
  );
}
