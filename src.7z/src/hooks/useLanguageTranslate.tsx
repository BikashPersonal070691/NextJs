import { useSelector } from 'react-redux';

export const useLanguageTranslate = () => {
  const { languageData } = useSelector((state: any) => state.language);

  /**
   * @description get value from dictionary daya using key
   * @param key
   * @returns string
   */
  const translatedKey = (key: any) => {
    return languageData && languageData[key] !== undefined ? languageData[key] : '';
  };

  return { translatedKey };
};
