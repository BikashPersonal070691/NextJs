import { createContext } from 'react';

export const MenuContext = createContext<any>(null);
const MenuProvider = MenuContext.Provider;
const MenuConsumer = MenuContext.Consumer;

export { MenuConsumer, MenuProvider };
