import { useSitecoreContext } from '@sitecore-jss/sitecore-jss-nextjs';
import styles from './Breadcrumb.module.scss';
import BreadcrumbItem from 'components/BreadcrumbItem/BreadcrumbItem';
import { useEffect, useState, useRef } from 'react';
import { getBreadcrumbData } from 'src/services/breadcrumb.service';
import { correctURLrouting } from 'src/core/utils/utils.helper';
// import LanguageDropdown from 'components/Languagedropdown/languagedropdown';
import { formatBreadCrumbItemsData } from 'src/helpers/component.helper';
import { useDispatch } from 'react-redux';
import { SET_BREADCRUMB_DATA } from 'src/redux/reducers/commonSlice';

export default function Breadcrumb() {
  const { sitecoreContext } = useSitecoreContext();
  const dispatch = useDispatch<any>();
  const context: any = sitecoreContext;
  const itemId = context.route.itemId;

  const [breadcrumbData, setBreadcrumbData] = useState<any>({});
  const [breadcrumbChar, setbreadcrumbChar] = useState<any>('');
  const [breadcrumblength, setbreadcrumblength] = useState<any>(0);
  const breadcrumbRef = useRef<HTMLUListElement>(null);


  useEffect(() => {
    getBreadcrumbs();
    setBreadCrumbwidthOnResize();
  }, []);

  useEffect(() => {
    const breadcrumbchar = getBreadcrumbchar();
    setbreadcrumbChar(breadcrumbchar);
    const formattedBreadCrumb = formatBreadCrumbItemsData(breadcrumbData);
    if (formattedBreadCrumb && formattedBreadCrumb.length > 0) {
      dispatch(SET_BREADCRUMB_DATA(formattedBreadCrumb));
    }
  }, [breadcrumbData]);

  useEffect(() => {
    breadcrumbData.ListData && breadcrumbData.ListData.length > 0 ? setEllipsis() : '';
    setBreadCrumbWidth();
  }, [breadcrumbChar]);

  const getBreadcrumbchar = () => {
    let tempChar = breadcrumbData.FirstBC + breadcrumbData.SecondBC + breadcrumbData.LastBC;
    breadcrumbData.ListData &&
      breadcrumbData.ListData.map((breadCrumb: { Text: string; URL: any }) => {
        tempChar = tempChar + breadCrumb.Text;
      });

    return tempChar;
  };

  const setEllipsis = () => {
    let listDataTemp = breadcrumbData.ListData;

    let emptyObj = {
      Text: '...',
      URL: '',
      ShowInMenu: true,
      isClickable: false,
    };

    if (screen.width > 811 && breadcrumbChar.length > 145) {
      listDataTemp.splice(0, listDataTemp.length - 1, emptyObj);

      setBreadcrumbData({ ...breadcrumbData, ListData: listDataTemp });
    }

    if (screen.width > 679 && screen.width <= 811 && breadcrumbChar.length > 85) {
      listDataTemp.splice(0, listDataTemp.length - 1, emptyObj);
      setBreadcrumbData({ ...breadcrumbData, ListData: listDataTemp });
    }
    if (screen.width < 679 && breadcrumbChar.length > 30) {
      listDataTemp.splice(0, listDataTemp.length - 1, emptyObj);
      setBreadcrumbData({ ...breadcrumbData, ListData: listDataTemp });
    }
  };

  const setBreadCrumbWidth = () => {
    let breadCrumbulElm = breadcrumbRef.current;
    let breadcrumbTotalElLength = 0;
    let children = breadCrumbulElm?.childNodes;
    var array = Array.prototype.slice.call(children);

    array.map((breadcrumb) => {
      breadcrumbTotalElLength = breadcrumbTotalElLength + breadcrumb.offsetWidth;
    });

    let parentbreadcrumblength = 0;

    array.map((breadcrumb, index) => {
      if (index < array.length - 1) {
        parentbreadcrumblength = parentbreadcrumblength + breadcrumb.offsetWidth;
      }
    });

    breadCrumbulElm &&
      setbreadcrumblength(breadCrumbulElm.offsetWidth - parentbreadcrumblength - 60);
  };

  const getBreadcrumbs = () => {
    getBreadcrumbData(itemId).then((data: any) => {
      if (data && data.data) {
        let response = data.data;
        if (response && response.ListData) {
          response.ListData.map((data: any) => {
            correctURLrouting(data);
          });
        }

        setBreadcrumbData(response);
      }
    });

    // setBreadcrumbData({
    //   ListData: [
    //     {
    //       Text: 'Parent 1',
    //       URL: '',
    //       ShowInMenu: true,
    //       isClickable: false,
    //     },
    //     {
    //       Text: 'Parent 2',
    //       URL: '',
    //       ShowInMenu: true,
    //       isClickable: false,
    //     },
    //     {
    //       Text: 'Parent 2',
    //       URL: '',
    //       ShowInMenu: true,
    //       isClickable: false,
    //     },
    //     {
    //       Text: 'Parent 2',
    //       URL: '',
    //       ShowInMenu: true,
    //       isClickable: false,
    //     },
    //   ],
    //   FirstBC: 'Bayernet',
    //   FirstBCLink: '/',
    //   SecondBC: 'People',
    //   SecondBCLink: '/en/',
    //   LastBC: 'Navigation Navigation',
    // });
  };

  const setBreadCrumbwidthOnResize = () => {
    window.addEventListener('resize', () => {
      setBreadCrumbWidth();
    });
  };


  
  return (
    <div className={styles.breadc_wrapper}>
      <ul className={styles.breadc_items} ref={breadcrumbRef}>
        {breadcrumbData && breadcrumbData.FirstBC ? (
          <BreadcrumbItem
            key={breadcrumbData.FirstBC}
            text={breadcrumbData.FirstBC}
            url={breadcrumbData.FirstBCLink}
            isLast={false}
          />
        ) : (
          ''
        )}

        {breadcrumbData && breadcrumbData.SecondBC ? (
          <BreadcrumbItem
            key={breadcrumbData.SecondBC}
            text={breadcrumbData.SecondBC}
            url={breadcrumbData.SecondBCLink}
            isLast={false}
          />
        ) : (
          ''
        )}

        {breadcrumbData &&
          breadcrumbData.ListData &&
          breadcrumbData.ListData.map(
            (breadCrumb: { Text: string; URL: any; isClickable: boolean }, index: number) => {
              return (
                <BreadcrumbItem
                  key={index}
                  text={breadCrumb.Text}
                  url={breadCrumb.URL}
                  isLast={false}
                  isClickable={breadCrumb.isClickable === undefined ? true : false}
                />
              );
            }
          )}

        {breadcrumbData && breadcrumbData.LastBC ? (
          <BreadcrumbItem
            key={breadcrumbData.LastBC}
            text={breadcrumbData.LastBC}
            url={''}
            isLast={true}
            width={breadcrumblength}
          />
        ) : (
          ''
        )}
      </ul>
      {/* <LanguageDropdown /> */}
    </div>
  );
}
