// import { MsalAuthProvider, LoginType } from 'react-aad-msal';

// import { ClientSecretCredential } from "@azure/identity";
// import { Client } from "@microsoft/microsoft-graph-client";
// import { TokenCredentialAuthenticationProvider } from '@microsoft/microsoft-graph-client/authProviders/azureTokenCredentials';
// /*
//  * Singleton Auth object
//  */

// const AZURE_AD_CLIENT_ID = '40353a3a-8854-4f3d-a204-d1c6e21070d5'
// const AZURE_AD_CLIENT_SECRET = 'Xtp7Q~N0BeOVJ3oDVhgCIdKrHgbONfFy7R1K~'
// const AZURE_AD_TENANT_ID = 'fcb2b37b-5da0-466b-9b83-0014b67a7c78'
// const redirect_uri = 'http://localhost:8080';

// export const authProvider = new MsalAuthProvider(
//   {
//     auth: {
//       authority: 'https://login.microsoftonline.com/' + AZURE_AD_TENANT_ID, //AD_TENANT_ID,
//       clientId: AZURE_AD_CLIENT_ID, // AD_CLIENT_ID,
//       postLogoutRedirectUri: redirect_uri, //
//       redirectUri: redirect_uri, // window.location.origin, //
//       validateAuthority: false
//     },
//     cache: {
//       cacheLocation: 'sessionStorage',
//       storeAuthStateInCookie: false
//     }
//   },
//   {
//     scopes: ['openid']
//   },
//   {
//     loginType: LoginType.Redirect // It can be Popup or Redirect as per the requirements
//   }
// );
export const authProvider = '';

// @azure/identity
// const credential = new ClientSecretCredential(
//     'fcb2b37b-5da0-466b-9b83-0014b67a7c78',
//     '40353a3a-8854-4f3d-a204-d1c6e21070d5',
//     'Xtp7Q~N0BeOVJ3oDVhgCIdKrHgbONfFy7R1K~'
//   );

//   // @microsoft/microsoft-graph-client/authProviders/azureTokenCredentials
//   const authProvider = new TokenCredentialAuthenticationProvider(credential, {
//     // The client credentials flow requires that you request the
//     // /.default scope, and pre-configure your permissions on the
//     // app registration in Azure. An administrator must grant consent
//     // to those permissions beforehand.
//     scopes: ['https://graph.microsoft.com/.default'],
//   });

//   const graphClient = Client.initWithMiddleware({ authProvider: authProvider });
