import {
  SR_TILE_HEADLINE,
  SR_TILE_LINK_TEXT,
  SR_TILE_LINK_URL,
  KEY_SRTILE_HEADLINE,
  KEY_SRTILE_IMAGE,
  KEY_SRTILE_HOVER_IMAGE,
} from '../constants/general';
const getTiles = (item: any) => {
  const formattedTile = {
    [KEY_SRTILE_HEADLINE]: item && item.fields && item.fields[KEY_SRTILE_HEADLINE],
    [KEY_SRTILE_IMAGE]: { value: item && item.fields && item.fields[KEY_SRTILE_IMAGE] },
    [KEY_SRTILE_HOVER_IMAGE]: { value: item && item.fields && item.fields[KEY_SRTILE_HOVER_IMAGE] },
    showMouseoverEffect:
      item &&
      item.fields &&
      item.fields.showMouseoverEffect &&
      item.fields.showMouseoverEffect.value
        ? item.fields.showMouseoverEffect.value
        : false,
    isCentered:
      item && item.fields && item.fields.isCentered && item.fields.isCentered.value
        ? item.fields.isCentered.value
        : false,
    isLinkURL:
      item && item.fields && item.fields.isLinkURL && item.fields.isLinkURL.value
        ? item.fields.isLinkURL.value
        : false,
    linkURL:
      item &&
      item.fields &&
      item.fields.linkURL &&
      item.fields.linkURL.value &&
      item.fields.linkURL.value.href
        ? item.fields.linkURL.value.href
        : '',
    // linkURL:
    //   item && item.fields && item.fields.linkURL && item.fields.linkURL.value
    //     ? item.fields.linkURL
    //     : '',
    linkToDownload:
      item &&
      item.fields &&
      item.fields.linkToDownload &&
      item.fields.linkToDownload.value &&
      item.fields.linkToDownload.value.href
        ? item.fields.linkToDownload.value.href
        : '',
    // linkToDownload:
    //   item && item.fields && item.fields.linkToDownload && item.fields.linkToDownload.value
    //     ? item.fields.linkToDownload
    //     : ''
  };
  return formattedTile;
};

//
/**
 * format data for SR Tiles Component
 * @param data
 * @returns formattedData
 *  data for buttons need to be integrated ( using dummy data till data is available)
 */
const formatSRTilesData = (data: any) => {
  const formattedData: any = {
    [SR_TILE_HEADLINE]: data && data.fields && data.fields[SR_TILE_HEADLINE],
    showButton:
      data && data.fields && data.fields.showButton && data.fields.showButton.value
        ? data.fields.showButton.value
        : false,
    // showBackgroundColor:
    //   data &&
    //   data.fields &&
    //   data.fields.showBackgroundImage &&
    //   data.fields.showBackgroundImage.value
    //     ? data.fields.showBackgroundImage.value
    //     : false,
    [SR_TILE_LINK_TEXT]: {
      value:
        data &&
        data.fields &&
        data.fields[SR_TILE_LINK_TEXT] &&
        data.fields[SR_TILE_LINK_TEXT].value
          ? data.fields[SR_TILE_LINK_TEXT]
          : undefined,
    },
    [SR_TILE_LINK_URL]: {
      value:
        data &&
        data.fields &&
        data.fields[SR_TILE_LINK_URL] &&
        data.fields[SR_TILE_LINK_URL].value &&
        data.fields[SR_TILE_LINK_URL].value.href
          ? data.fields[SR_TILE_LINK_URL]
          : undefined,
    },
    isExternalLink:
      data &&
      data.fields &&
      data.fields.buttonLink &&
      data.fields.buttonLink.value &&
      data.fields.buttonLink.value.linktype &&
      data.fields.buttonLink.value.linktype === 'external'
        ? true
        : false,
  };
  return formattedData;
};
export { formatSRTilesData, getTiles };
