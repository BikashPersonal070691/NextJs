import { createSlice } from '@reduxjs/toolkit';

const languageSlice = createSlice({
  name: 'language',
  initialState: {
    languageData: null,
    isLangaugeSelected : false
  },
  reducers: {
    SET_LANGUAGE_DATA: (state, action) => {
      state.languageData = action.payload;
    },
    SET_IS_LANGAUGE_SELECTED: (state, action) => {
      state.isLangaugeSelected = action.payload;
    },
  },
});

export const { SET_LANGUAGE_DATA, SET_IS_LANGAUGE_SELECTED } = languageSlice.actions;
export default languageSlice.reducer;
