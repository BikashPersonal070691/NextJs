import { useState, useEffect, useRef } from 'react';
import styles from './MonthlyTabMobile.module.scss';
import {
  groupCalendarEvents,
  setHashString,
  getHashString,
  getMonthNameById
} from 'src/core/utils/utils.helper';
import CalendarSectionMobile from 'components/CalendarSectionMobile/CalendarSectionMobile';
import MonthlyView from '../MonthlyView/MonthlyView';
import { KEY_HR_TASK_LAYOUT_SERVICE_RESPONSE } from 'src/constants/general';
import { useLanguageTranslate } from 'src/hooks/useLanguageTranslate';
import {
  KEY_MONTH_APR,
  KEY_MONTH_AUG,
  KEY_MONTH_DEC,
  KEY_MONTH_FEB,
  KEY_MONTH_JAN,
  KEY_MONTH_JUL,
  KEY_MONTH_JUN,
  KEY_MONTH_MAR,
  KEY_MONTH_MAY,
  KEY_MONTH_NOV,
  KEY_MONTH_OCT,
  KEY_MONTH_SEP,
} from 'src/constants/dictonary';

export function MonthlyTabMobile(props: any) {
  const [eventList, setEventList] = useState<any>(null);
  const [active, setActive] = useState<any>();
  const [page, setPage] = useState<any>(1);
  const containerRef = useRef<any>(null);
  const [selectedMonthName, setSelectedMonthName] = useState<any>();

  const handleTabChange = (id: any, month : any = null) => {
    setHashString(id);
    setActive(id);
    setSelectedMonthName(month);
  };
 

  const { translatedKey } = useLanguageTranslate();

  const monthSet1 = [
    { id: KEY_MONTH_JAN, name: translatedKey(KEY_MONTH_JAN).toLowerCase() },
    { id: KEY_MONTH_FEB, name: translatedKey(KEY_MONTH_FEB).toLowerCase() },
    { id: KEY_MONTH_MAR, name: translatedKey(KEY_MONTH_MAR).toLowerCase() }
  ];
  const monthSet2 = [
    { id: KEY_MONTH_APR, name: translatedKey(KEY_MONTH_APR).toLowerCase() },
    { id: KEY_MONTH_MAY, name: translatedKey(KEY_MONTH_MAY).toLowerCase() },
    { id: KEY_MONTH_JUN, name: translatedKey(KEY_MONTH_JUN).toLowerCase() }
  ];
  const monthSet3 = [
    { id: KEY_MONTH_JUL, name: translatedKey(KEY_MONTH_JUL).toLowerCase() },
    { id: KEY_MONTH_AUG, name: translatedKey(KEY_MONTH_AUG).toLowerCase() },
    { id: KEY_MONTH_SEP, name: translatedKey(KEY_MONTH_SEP).toLowerCase() }
  ];
  const monthSet4 = [
    { id: KEY_MONTH_OCT, name: translatedKey(KEY_MONTH_OCT).toLowerCase() },
    { id: KEY_MONTH_NOV, name: translatedKey(KEY_MONTH_NOV).toLowerCase() },
    { id: KEY_MONTH_DEC, name: translatedKey(KEY_MONTH_DEC).toLowerCase() }
  ];


  const [activeMonthSet, setActiveMonthSet] = useState<any>(monthSet1);

  const monthSetter = (page: any) => {
    if (page === 1) {
      setActiveMonthSet(monthSet1);
    } else if (page === 2) {
      setActiveMonthSet(monthSet2);
    } else if (page === 3) {
      setActiveMonthSet(monthSet3);
    } else if (page === 4) {
      setActiveMonthSet(monthSet4);
    }
  };


  const handlePrevNavigation = () => {
    const newPage = page - 1;
    setPage(newPage);
    monthSetter(newPage);
  };

  
  const handleNextNavigation = () => {
    const newPage = page + 1;
    setPage(newPage);
    monthSetter(newPage);
  };

  const d = new Date();
  //
  useEffect(() => {
    if (props && active && active === 'all') {
      const { calendarData } = props;
      const calendarItems =
        calendarData &&
        calendarData.fields &&
        calendarData.fields[KEY_HR_TASK_LAYOUT_SERVICE_RESPONSE];
      setEventList(groupCalendarEvents(calendarItems));
    } else {
      setEventList(null);
    }

    const hashObj = getHashString();
    if (hashObj.month != '') {
      setActive(hashObj.month);
      const exists =  monthSet1.filter(function(el) {
        return el.id.toLowerCase() === hashObj.month;
      }); 
      
      const exists2 =  monthSet2.filter(function(el) {
        return el.id.toLowerCase() === hashObj.month;
      });

      const exists3 =  monthSet3.filter(function(el) {
        return el.id.toLowerCase() === hashObj.month;
      });

      const exists4 =  monthSet4.filter(function(el) {
        return el.id.toLowerCase() === hashObj.month;
      });


      if(exists.length > 0) {  
        setPage(1);
        setActiveMonthSet(monthSet1);
        setSelectedMonthName(exists && exists[0] && exists[0].name);
      } else if (exists2.length > 0) {
        setPage(2);
        setActiveMonthSet(monthSet2);
        setSelectedMonthName(exists2 && exists2[0] && exists2[0].name);
      } else if (exists3.length > 0) {
        setPage(3);
        setActiveMonthSet(monthSet3);
        setSelectedMonthName(exists3 && exists3[0] && exists3[0].name);
      } else if (exists4.length > 0) {
        setPage(4);
        setActiveMonthSet(monthSet4);
        setSelectedMonthName(exists4 && exists4[0] && exists4[0].name);
      } else {
        setPage(1);
        setActiveMonthSet(monthSet1);
      }


      // if (monthSet1.includes(hashObj.month)) {
      //   setPage(1);
      //   setActiveMonthSet(monthSet1);
      //   setSelectedMonthName(exists && exists[0] && exists[0].name);
      // } else if (monthSet2.includes(hashObj.month)) {
      //   const exists2 =  monthSet2.filter(function(el) {
      //     return el.id.toLowerCase() === hashObj.month;
      //   }); 
      //   setSelectedMonthName(exists2 && exists2[0] && exists2[0].name);
      //   setPage(2);
      //   setActiveMonthSet(monthSet2);
      // } else if (monthSet3.includes(hashObj.month)) {
      //   const exists3 =  monthSet3.filter(function(el) {
      //     return el.id.toLowerCase() === hashObj.month;
      //   }); 
      //   setSelectedMonthName(exists3 && exists3[0] && exists3[0].name);
      //   setPage(3);
      //   setActiveMonthSet(monthSet3);
      // } else if (monthSet4.includes(hashObj.month)) {
      //   const exists4 =  monthSet4.filter(function(el) {
      //     return el.id.toLowerCase() === hashObj.month;
      //   }); 
      //   setSelectedMonthName(exists4 && exists4[0] && exists4[0].name);
      //   setPage(4);
      //   setActiveMonthSet(monthSet4);
      // }
    } else {
      const currentMonth = getMonthNameById(d.getMonth() + 1);
      setActive(currentMonth);
      const exists =  monthSet1.filter(function(el) {
        return el.id.toLowerCase() === currentMonth;
      }); 
      
      const exists2 =  monthSet2.filter(function(el) {
        return el.id.toLowerCase() === currentMonth;
      });

      const exists3 =  monthSet3.filter(function(el) {
        return el.id.toLowerCase() === currentMonth;
      });

      const exists4 =  monthSet4.filter(function(el) {
        return el.id.toLowerCase() === currentMonth;
      });


      if(exists.length > 0) {  
        setPage(1);
        setActiveMonthSet(monthSet1);
        setSelectedMonthName(exists && exists[0] && exists[0].name);
      } else if (exists2.length > 0) {
        setPage(2);
        setActiveMonthSet(monthSet2);
        setSelectedMonthName(exists2 && exists2[0] && exists2[0].name);
      } else if (exists3.length > 0) {
        setPage(3);
        setActiveMonthSet(monthSet3);
        setSelectedMonthName(exists3 && exists3[0] && exists3[0].name);
      } else if (exists4.length > 0) {
        setPage(4);
        setActiveMonthSet(monthSet4);
        setSelectedMonthName(exists4 && exists4[0] && exists4[0].name);
      } else {
        setPage(1);
        setActiveMonthSet(monthSet1);
      }


      // const exists =  monthSet1.filter(function(el) {
      //   return el.id.toLowerCase() === currentMonth;
      // }); 
      // if (monthSet1.includes(currentMonth)) {
      //   setPage(1);
      //   setActiveMonthSet(monthSet1);
      //   setSelectedMonthName(exists && exists[0] && exists[0].name);
      // } else if (monthSet2.includes(currentMonth)) {
      //   const exists2 =  monthSet2.filter(function(el) {
      //     return el.id.toLowerCase() === currentMonth;
      //   }); 
      //   setSelectedMonthName(exists2 && exists2[0] && exists2[0].name);
      //   setPage(2);
      //   setActiveMonthSet(monthSet2);
      // } else if (monthSet3.includes(currentMonth)) {
      //   const exists3 =  monthSet3.filter(function(el) {
      //     return el.id.toLowerCase() === currentMonth;
      //   }); 
      //   setSelectedMonthName(exists3 && exists3[0] && exists3[0].name);
      //   setPage(3);
      //   setActiveMonthSet(monthSet3);
      // } else if (monthSet4.includes(currentMonth)) {
      //   const exists4 =  monthSet4.filter(function(el) {
      //     return el.id.toLowerCase() === currentMonth;
      //   }); 
      //   setSelectedMonthName(exists4 && exists4[0] && exists4[0].name);
      //   setPage(4);
      //   setActiveMonthSet(monthSet4);
      // }
    }
  }, [props]);

  useEffect(() => {
    if (props && active && active === 'all') {
      const { calendarData } = props;
      const calendarItems =
        calendarData &&
        calendarData.fields &&
        calendarData.fields[KEY_HR_TASK_LAYOUT_SERVICE_RESPONSE];
      setEventList(groupCalendarEvents(calendarItems));
    } else {
      setEventList(null);
    }
  }, [active, props.calendarData]);
  //

  return (
    <div className={styles.montly_view}>
      <div className={styles.arrows_wrapper}>
        <div
          className={`${styles.prev_icon} ${page === 1 ? styles.inactive : styles.active}`}
          onClick={
            page !== 1
              ? () => {
                  handlePrevNavigation();
                }
              : undefined
          }
        ></div>
        <div
          className={`${styles.next_icon} ${page === 4 ? styles.inactive : styles.active}`}
          onClick={
            page !== 4
              ? () => {
                  handleNextNavigation();
                }
              : undefined
          }
        ></div>
      </div>
      <div className={styles.monthy_tab_container}>
        <div className={styles.months_view}>
          <div
            className={`${styles.all_month_wrapper} ${
              active === 'all' ? styles.active : undefined
            }`}
            id="all"
            onClick={() => {
              handleTabChange('all');
            }}
          >
            <div className={styles.month}>ALL</div>
          </div>
          <div className={styles.months} ref={containerRef}>
            {activeMonthSet.map((item: any) => {
              return (item && item.name && item.name != '' ?
                <div
                  className={`${styles.month_wrapper} ${
                    active === item.id.toLowerCase() ? styles.active : undefined
                  } `}
                  id={item.id}
                  key={item.id}
                  onClick={() => {
                    handleTabChange(item && item.id && item.id.toLowerCase(), item.name);
                  }}
                >
                  <div className={styles.month}>{item.name}</div>
                </div> : ''
              );
            })}
          </div>
        </div>


        {active && active === 'all' ? (
          <div className={styles.month_content}>
            {eventList &&
              eventList.map((event: any, index: any) => (
                <CalendarSectionMobile
                  taskList={event}
                  page={page}
                  key={index}
                  monthsWidth={
                    containerRef && containerRef.current && containerRef.current.clientWidth
                      ? containerRef.current.clientWidth
                      : 0
                  }
                  id={index}
                />
              ))}
          </div>
        ) : (
          <div className={styles.month_content}>
            <MonthlyView
              taskList={props.calendarData}
              monthSelected={active}
              linkboxData={props.linkboxData}
              activeTab={props.activeTab && props.activeTab}
              selectedMonthName={selectedMonthName}
            ></MonthlyView>
          </div>
        )}
      </div>
    </div>
  );
}
