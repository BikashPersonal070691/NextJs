import { Button } from 'components/Elements/Button/Button';
// import { RadioButtonConfig } from '../../../models/radio';
import { OptimizedImage } from 'src/components/Elements/OptimizedImage/OptimizedImage';
import styles from './ImageCustom.module.scss';

export function ImageCustom(props: any) {
  const { src, fromVideo, imgEvent } = props;
  return (
    <div className={styles.image__container}>
      <div className={styles.image__wrapper}>
        {fromVideo && <Button class={styles.image_video__play} onClick={imgEvent}></Button>}
        {/* <Image field={src} editable={true} /> */}
        <OptimizedImage
          imageData={src}
          scaleData={[
            { mWidth: 767, width: null, height: 237 },
            { mWidth: 1019, width: 270, height: 180 },
            { mWidth: 1020, width: 270, height: 180 },
          ]}
          isBgColorAvailable={true}
        />
      </div>
    </div>
  );
}
