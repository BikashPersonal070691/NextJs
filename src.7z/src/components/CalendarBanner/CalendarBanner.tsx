import styles from './CalendarBanner.module.scss';
import { Image } from '@sitecore-jss/sitecore-jss-nextjs';

export default function CalendarBanner(props: any) {
  const { bannerData } = props;
  return (
    <div className={styles.calendarbanner_wrapper}>
      <a
        target={
          bannerData &&
          bannerData.LinkTo &&
          bannerData.LinkTo.value &&
          bannerData.LinkTo.value.target &&
          bannerData.LinkTo.value.target != ''
            ? bannerData.LinkTo.value.target
            : '_self'
        }
        href={
          bannerData && bannerData.LinkTo && bannerData.LinkTo.value && bannerData.LinkTo.value.href
            ? bannerData.LinkTo.value.href
            : '#'
        }
      >
        <Image className={styles.banner_img} field={bannerData.BannerImage} editable={true} />
      </a>
    </div>
  );
}
