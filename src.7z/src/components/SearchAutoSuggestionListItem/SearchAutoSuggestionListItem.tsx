import { useState, useContext } from 'react';
import {
  KEY_SEARCH_TAG_ICON,
  KEY_SEARCH_LINK_ICON,
  KEY_SEARCH_SECTION_TOOLS_RESOURCES,
  KEY_SEARCH_SECTION_PEOPLE_FINDER,
  KEY_SEARCH_SECTION_SEARCH_CENTER,
} from '../../constants/general';
import { saveBookmark } from 'src/services/header.service';
import { HeaderContext } from 'src/contexts/HeaderContext';
import styles from './SearchAutoSuggestionListItem.module.scss';

export function SearchAutoSuggestionListItem(props: any) {
  const { icon, link, groupName, isBookmarked, type, displayName, paramName } = props;
  const { setSearchInputDisplayValue } = useContext(HeaderContext);
  const [bookmarked, setBookmarked] = useState<boolean>(false); // for suggestion bookmark
  /**
   * @description for handling autosuggestion bookmark
   * @param url
   * @param name
   */
  const handleBookmark = (url: any, name: any) => {
    if (url && url !== '' && name && name !== '') {
      // setBookmarked(true);
      const requestObj = {
        Link: url,
        LinkText: name,
      };
      saveBookmark(requestObj).then((data: any) => {
        if (data && data.data && data.data.Message) {
          setBookmarked(true);
        } else {
          setBookmarked(false);
        }
      });
    }
  };

  /**
   * @description for handling search button redirection
   * @param url
   */
  const handleRedirection = (url: any, displayName: any) => {
    if (displayName && displayName !== '') {
      setSearchInputDisplayValue(displayName);
      if (url && url !== '') {
        setTimeout(() => {
          //redirect after 5 milliseconds
          if (
            type === KEY_SEARCH_SECTION_PEOPLE_FINDER ||
            type === KEY_SEARCH_SECTION_SEARCH_CENTER
          ) {
            window.open(url, '_blank');
          } else {
            window.location.href = url;
          }
        }, 500);
      }
    }
  };
  return (
    <>
      <div
        className={`${
          icon && icon !== '' && icon === KEY_SEARCH_TAG_ICON ? styles.item__testing : ''
        }`}
      ></div>
      <div className={styles.search_autocomplete_list_item__container}>
        {displayName && displayName !== '' ? (
          <div
            className={`${styles.search_autocomplete_list_item__link} ${
              icon && icon !== '' && icon === KEY_SEARCH_TAG_ICON
                ? styles.search_autocomplete_list_item__link__item__tagicon
                : icon && icon !== '' && icon === KEY_SEARCH_LINK_ICON
                ? styles.search_autocomplete_list_item__link__item__linkicon
                : ''
            }`}
            onClick={() => handleRedirection(link, paramName)}
          >
            {displayName}
          </div>
        ) : (
          ''
        )}
        {type && type === KEY_SEARCH_SECTION_TOOLS_RESOURCES && groupName && groupName !== '' ? (
          <div className={styles.search_autocomplete_list_item__group}>{groupName}</div>
        ) : (
          ''
        )}
        {(type && type === KEY_SEARCH_SECTION_TOOLS_RESOURCES && isBookmarked) || bookmarked ? (
          <div
            className={`${styles.search_autocomplete_list_item__bookmark} ${styles.search_autocomplete_list_item__bookmark__item__bookmarked}`}
          >
            Saved as Bookmark
          </div>
        ) : type && type === KEY_SEARCH_SECTION_TOOLS_RESOURCES && !isBookmarked && link !== '' ? (
          <div
            className={`${styles.search_autocomplete_list_item__bookmark} ${styles.search_autocomplete_list_item__bookmark__item__tobookmark}`}
            onClick={() => handleBookmark(link, paramName)}
          >
            Add to bookmark
          </div>
        ) : (
          ''
        )}
      </div>
    </>
  );
}
