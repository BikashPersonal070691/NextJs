import { RadioButtonConfig } from '../../../models/radio';

export function Radio({
  onChange,
  className,
  id,
  value,
  name,
  label,
  isDefault,
}: RadioButtonConfig) {
  return (
    <div className={className}>
      <input
        type="radio"
        id={id}
        value={value}
        name={name}
        onChange={onChange}
        defaultChecked={isDefault}
      />
      <label htmlFor={id} className={id}>
        {label}
      </label>
    </div>
  );
}
