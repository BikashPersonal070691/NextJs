const jssConfig = require('./src/temp/config');
const { getPublicUrl } = require('@sitecore-jss/sitecore-jss-nextjs/utils');
const plugins = require('./src/temp/next-config-plugins') || {};

const publicUrl = getPublicUrl();
// const publicUrl = process.env.PUBLIC_URL;

const apiUrl = process.env.SITECORE_API_URL;
const apiHost = process.env.SITECORE_API_HOST;
const mockApiUrl = process.env.MOCK_API_URL;
const imgBaseUrl = process.env.IMAGE_BASE_URL;
const cmAppUrl = process.env.CM_APP_URL;
const nextAuthUrl = process.env.NEXTAUTH_URL;
const azureAdTenantId = process.env.AZURE_AD_TENANT_ID;
const azureAdClientId = process.env.NEXT_PUBLIC_AZURE_AD_CLIENT_ID;
const azureAdClientSecret = process.env.AZURE_AD_CLIENT_SECRET;
const gtmId = process.env.GTM_ID
/**
 * @type {import('next').NextConfig}
 */
const nextConfig = {
  // Set assetPrefix to our public URL
  assetPrefix: publicUrl,

  // Allow specifying a distinct distDir when concurrently running app in a container
  distDir: process.env.NEXTJS_DIST_DIR || '.next',

  // Make the same PUBLIC_URL available as an environment variable on the client bundle
  env: {
    PUBLIC_URL: publicUrl,
    SITECORE_API_URL: apiUrl,
    SITECORE_API_HOST: apiHost,
    MOCK_API_URL: mockApiUrl,
    IMAGE_BASE_URL: imgBaseUrl,
    CM_APP_URL: cmAppUrl,
    NEXTAUTH_URL: nextAuthUrl,
    AZURE_AD_TENANT_ID: azureAdTenantId,
    NEXT_PUBLIC_AZURE_AD_CLIENT_ID: azureAdClientId,
    AZURE_AD_CLIENT_SECRET: azureAdClientSecret,
    GTM_ID: gtmId
  },
  output: 'standalone',
  i18n: {
    // These are all the locales you want to support in your application.
    // These should generally match (or at least be a subset of) those in Sitecore.
    locales: [
      'en',
      'de-DE',
      'es-ES',
      'zh-CN',
      'ko-KR',
      'pl-PL',
      'ja-JP',
      'fr-FR',
      'pt-PT',
      'ru-RU',
      'it-IT',
      'nl-NL',
      'fi-FI',
      'tr-TR',
      'el-GR',
    ],
    // This is the locale that will be used when visiting a non-locale
    // prefixed path e.g. `/styleguide`.
    defaultLocale: jssConfig.defaultLanguage,
  },

  // Enable React Strict Mode
  reactStrictMode: true,
  // eslint: {
  //   // Warning: This allows production builds to successfully complete even if
  //   // your project has ESLint errors.
  //   ignoreDuringBuilds: true,
  // },

  async rewrites() {
    // When in connected mode we want to proxy Sitecore paths off to Sitecore
    return [
      // API endpoints
      {
        source: '/sitecore/api/:path*',
        destination: `${jssConfig.sitecoreApiHost}/sitecore/api/:path*`,
      },
      // media items
      {
        source: '/-/:path*',
        destination: `${jssConfig.sitecoreApiHost}/-/:path*`,
      },
      // healthz check
      {
        source: '/healthz',
        destination: '/api/healthz',
      },
      // rewrite for Sitecore service pages
      {
        source: '/sitecore/service/:path*',
        destination: `${jssConfig.sitecoreApiHost}/sitecore/service/:path*`,
      },
    ];
  }
};

module.exports = () => {
  // Run the base config through any configured plugins
  return Object.values(plugins).reduce((acc, plugin) => plugin(acc), nextConfig);
};
