import { useRef, useState, useEffect } from 'react';
// import Slider from 'react-slick';
// import { Button } from 'components/Elements/Button/Button';
// import { Tiles } from 'components/Elements/Tiles/Tiles';
import { SLIDE_WIDTH, KEY_SLIDER_TYPE } from '../../constants/general';
import { formatTilesData } from 'src/helpers/tiles.helper';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import { Field, Placeholder, Text, Link } from '@sitecore-jss/sitecore-jss-nextjs';
import { ComponentProps } from 'lib/component-props';
import { StyleguideSpecimenFields } from 'lib/component-props/styleguide';
import {
  TILE_HEADLINE,
  TILE_LINK_TEXT,
  TILE_LINK_URL,
  KEY_BREAKPOINT_MEDIUM,
} from 'src/constants/general';
import SlickSlider from 'src/components/Elements/SlickSlider/SlickSlider';
import { getCurrentWindowWidth } from 'src/core/utils/utils.helper';
import { getParentClassReference } from 'src/core/utils/utils.helper';
import { CONTENT_100, CONTENT_25, CONTENT_33, CONTENT_34 } from 'src/constants/contentDivider';
import styles from './TilesContainer.module.scss';

type TileComponentProps = ComponentProps &
  StyleguideSpecimenFields & {
    fields: {
      [TILE_HEADLINE]: Field<string>;
      [TILE_LINK_TEXT]: Field<string>;
      [TILE_LINK_URL]: Field<string>;
    };
  };

export default function TilesContainer(props: TileComponentProps) {
  /**
   * @important This code needs to be used in every components inorder to get the content dividers reference
   * @important Also set the reference (ref) and className to the html wrapper as implemented below
   */
  // starts
  const nodeRef = useRef(null);
  const [parentRef, setParentRef] = useState<any>(null);
  const smallDividers: any = [CONTENT_25, CONTENT_33, CONTENT_34];
  const [navNeeded, setNavNeeded] = useState<any>(true);

  useEffect(() => {
    // setMounted(true);
    const child: any = nodeRef.current;
    if (child !== null || child !== undefined) {
      const parRef: any = getParentClassReference(child);
      setParentRef(parRef);
    } else {
      setParentRef(CONTENT_100);
    }
  }, []);
  //ends
  const isMobileDevice: any = getCurrentWindowWidth() <= KEY_BREAKPOINT_MEDIUM ? true : false;
  useEffect(() => {
    if (parentRef) {
      const isSmallDivider = smallDividers.includes(parentRef) ? true : false;
      if (refinedTilesData.numberOfTiles > getTilesToNav() && refinedTilesData.showSlider) {
        setNavNeeded(true);
      } else if (isMobileDevice && refinedTilesData.numberOfTiles > getTilesToNav()) {
        setNavNeeded(true);
      } else if (isSmallDivider && refinedTilesData.numberOfTiles > getTilesToNav()) {
        setNavNeeded(true);
      } else {
        setNavNeeded(false);
      }
    }
  }, [parentRef]);

  const refinedTilesData: any = formatTilesData(props);
  const containerRef = useRef<any>(null);
  const getTilesToShow = () => {
    if (containerRef && containerRef.current && containerRef.current.clientWidth) {
      return Math.ceil(
        (containerRef && containerRef.current && containerRef.current.clientWidth) / SLIDE_WIDTH
      );
    } else {
      return 1;
    }
  };
  const getTilesToNav = () => {
    if (containerRef && containerRef.current && containerRef.current.clientWidth) {
      const res: any = Math.floor(
        (containerRef && containerRef.current && containerRef.current.clientWidth) / SLIDE_WIDTH
      );
      return res == 0 ? 1 : res;
    } else {
      return 1;
    }
  };

  return (
    <div ref={nodeRef} className={styles.slider_parent_wrapper}>
      <div className={styles.slider_container} ref={containerRef}>
        {refinedTilesData && refinedTilesData.numberOfTiles !== 0 && navNeeded ? (
          <div className={`${styles.slider_wrapper}`}>
            <SlickSlider
              data={props}
              headingData={refinedTilesData && refinedTilesData[TILE_HEADLINE]}
              numberOfTiles={refinedTilesData && refinedTilesData.numberOfTiles}
              type={KEY_SLIDER_TYPE.TILES}
              tilesToShow={getTilesToShow()}
              placeHolderName="tile-group"
              showButton={refinedTilesData && refinedTilesData.showButton}
              buttonData={{
                url: refinedTilesData && refinedTilesData[TILE_LINK_URL],
                text: refinedTilesData && refinedTilesData[TILE_LINK_TEXT],
              }}
              parentRef={parentRef}
              showTopNav={true}
              isVariableWidth={true}
              isAdaptiveHeight={false}
            />
          </div>
        ) : (
          <>
            <div className={styles.tiles_heading_container}>
              <Text
                field={refinedTilesData && refinedTilesData[TILE_HEADLINE]}
                editable={true}
                tag="div"
                className={styles.tiles_heading}
              />
              {refinedTilesData &&
                refinedTilesData.showButton &&
                refinedTilesData[TILE_LINK_URL] &&
                refinedTilesData[TILE_LINK_URL].value &&
                refinedTilesData[TILE_LINK_URL].value.href &&
                refinedTilesData[TILE_LINK_TEXT] &&
                refinedTilesData[TILE_LINK_TEXT].value && (
                  <div className={styles.tiles_heading_button__container}>
                    <Link field={refinedTilesData && refinedTilesData[TILE_LINK_URL]}>
                      <Text
                        field={refinedTilesData && refinedTilesData[TILE_LINK_TEXT]}
                        tag="div"
                        className={styles.tiles_button}
                        editable={true}
                      />
                    </Link>
                  </div>
                )}
            </div>
            <div className={`${styles.row_wrapper}`}>
              <Placeholder name="tile-group" rendering={props && props.rendering} />
            </div>
            {refinedTilesData &&
              refinedTilesData.showButton &&
              refinedTilesData[TILE_LINK_URL] &&
              refinedTilesData[TILE_LINK_URL].value &&
              refinedTilesData[TILE_LINK_URL].value.href &&
              refinedTilesData[TILE_LINK_TEXT] &&
              refinedTilesData[TILE_LINK_TEXT].value && (
                <div className={styles.tiles_bottom_button__container}>
                  <Link field={refinedTilesData && refinedTilesData[TILE_LINK_URL]}>
                    <Text
                      field={refinedTilesData && refinedTilesData[TILE_LINK_TEXT]}
                      className={styles.tiles_button}
                      editable={true}
                    />
                  </Link>
                </div>
              )}
          </>
        )}
      </div>
    </div>
  );
}
