import { useState, useRef, useEffect } from 'react';
import {
  KEY_VIDEOBOX_EXTERNAL,
  KEY_VIDEOBOX_INTERNAL,
  KEY_VIDEOBOX_TARGET_BLANK,
  MODAL_TYPE_VIDEO,
  KEY_VIDEOBOX_CAPTION,
  KEY_VIDEOBOX_HEADING,
  KEY_VIDEOBOX_DESCRIPTION,
  KEY_VIDEO_THUMBNAIL,
} from 'src/constants/general';
import { VideoBox } from 'components/Elements/VideoBox/VideoBox';
import { Modal } from 'components/Elements/Modal/Modal';
import { ImageCustom } from 'components/Elements/ImageCustom/ImageCustom';
import { formatVideoBoxData } from 'src/helpers/component.helper';
import { getParentClassReference, getParentAttributeReference } from 'src/core/utils/utils.helper';
import { Text, RichText, Field, useSitecoreContext } from '@sitecore-jss/sitecore-jss-nextjs';
import { CONTENT_100 } from 'src/constants/contentDivider';
import { ComponentProps } from 'lib/component-props';
import { StyleguideSpecimenFields } from 'lib/component-props/styleguide';
import styles from './Video.module.scss';

type VideoComponentProps = ComponentProps &
  StyleguideSpecimenFields & {
    fields: {
      [KEY_VIDEOBOX_CAPTION]: Field<string>;
      [KEY_VIDEOBOX_HEADING]: Field<string>;
      [KEY_VIDEOBOX_DESCRIPTION]: Field<string>;
      [KEY_VIDEO_THUMBNAIL]: Field<string>;
    };
    'data-type': any;
    'data-slider': any;
  };

export default function Video(props: VideoComponentProps) {
  const [modal, showModal] = useState<boolean>(false);
  const videoData = formatVideoBoxData(props);
  const isVideoGallery: any =
    props &&
    props['data-type'] &&
    props['data-type'].key &&
    props['data-type'].key === 'video-gallery'
      ? true
      : false;
  const isSlider: any = props && props['data-slider'] ? true : false;
  const { sitecoreContext } = useSitecoreContext();
  const isExperienceEditor = sitecoreContext && sitecoreContext.pageEditing;
  const videoLinkTarget =
    videoData.videoTarget && videoData.videoTarget !== '' ? videoData.videoTarget : '';
  const videoSrc = videoData.videoSrc && videoData.videoSrc !== '' ? videoData.videoSrc : '';
  const [parentAttr, setParentAttr] = useState<any>(null);

  /**
   * @important This code needs to be used in every components inorder to get the content dividers reference
   * @important Also set the reference (ref) and className to the html wrapper as implemented below
   */
  // starts
  const [parentRef, setParentRef] = useState<any>(null);
  const nodeRef = useRef(null);
  useEffect(() => {
    const child: any = nodeRef.current;
    if (child !== null || child !== undefined) {
      setParentRef(getParentClassReference(child));
      setParentAttr(getParentAttributeReference(child, 'data-id'));
    } else {
      setParentRef(CONTENT_100);
    }
  }, []);
  //ends
  /**
   * @description click event inside image play button
   */
  const handleThumbnailClick = () => {
    if (videoSrc !== '') {
      if (videoLinkTarget !== '' && videoLinkTarget === '_blank') {
        window.open(videoSrc, KEY_VIDEOBOX_TARGET_BLANK);
      } else {
        showModal(true);
      }
    } else {
      return;
    }
  };
  /**
   * @description Modal CloseEvent handler
   */

  const handleModalCloseEvent = () => {
    showModal(false);
  };
  
  return (
    <div ref={nodeRef} className={styles[parentRef]} id={videoData && videoData.videoAnchor}>
      <div
        className={`${
          isVideoGallery ? styles.video_gallery__container : styles.video__container
        }   ${parentAttr && styles[parentAttr]}`}
      >
        <div
          className={`${styles.video_thumbnail__container} ${
            videoData.videoHighlight ? styles.video__highlight : ''
          } ${isSlider ? styles.video_thumbnail__container__slider : ''}`}
        >
          <div className={styles.video_thumbnail__wrapper}>
            <ImageCustom
              src={videoData[KEY_VIDEO_THUMBNAIL]}
              fromVideo={true}
              imgEvent={handleThumbnailClick}
            />
            {videoData && videoData.videoDuration && videoData.videoDuration !== '' ? (
              <div className={styles.video_time__wrapper}>
                <span className={styles.video__time}>{videoData.videoDuration}</span>
              </div>
            ) : (
              ''
            )}
          </div>
          {!isExperienceEditor &&
          videoData &&
          videoData[KEY_VIDEOBOX_CAPTION] &&
          videoData[KEY_VIDEOBOX_CAPTION] &&
          videoData[KEY_VIDEOBOX_CAPTION].value !== '' ? (
            <div className={styles.video_thumbnail_caption__wrapper}>
              <Text tag="span" field={videoData[KEY_VIDEOBOX_CAPTION]} editable={true} />
            </div>
          ) : isExperienceEditor ? (
            <div className={styles.video_thumbnail_caption__wrapper}>
              <Text tag="span" field={videoData[KEY_VIDEOBOX_CAPTION]} editable={true} />
            </div>
          ) : (
            ''
          )}
        </div>
        {!isVideoGallery && (
          <div className={styles.video_content__container}>
            <div className={styles.video_content_heading__wrapper}>
              <Text
                className={`${styles.video_content__heading} ${
                  videoData.videoHighlight
                    ? styles.video_text__highlight
                    : styles.video_text_not__highlight
                }`}
                field={videoData[KEY_VIDEOBOX_HEADING]}
                tag="h4"
              />
            </div>
            <div className={styles.video_content_description__wrapper}>
              <RichText
                className={styles.video_content__description}
                field={videoData[KEY_VIDEOBOX_DESCRIPTION]}
              />
            </div>
          </div>
        )}
      </div>
      <Modal showModal={modal} modalCloseEvent={handleModalCloseEvent} type={MODAL_TYPE_VIDEO}>
        <div className={styles.video_modal__wrapper}>
          {/* <div className={styles.video_close__wrapper} onClick={handleModalCloseEvent}>
            <span className={styles.video__close}></span>
          </div> */}
          <VideoBox
            linkType={
              videoData &&
              videoData.videoType &&
              videoData.videoType !== '' &&
              videoData.videoType === KEY_VIDEOBOX_EXTERNAL
                ? KEY_VIDEOBOX_EXTERNAL
                : KEY_VIDEOBOX_INTERNAL
            }
            linkSrc={videoData.videoSrc}
            caption={videoData[KEY_VIDEOBOX_CAPTION]}
            thumbnail={videoData[KEY_VIDEO_THUMBNAIL]}
          />
        </div>
      </Modal>
    </div>
  );
}
