import { useEffect, useState, useRef } from 'react';
import { getParentClassReference, getParentAttributeReference } from 'src/core/utils/utils.helper';
import { formatWideImageData } from 'src/helpers/component.helper';
import { Image, Text, Field, RichText } from '@sitecore-jss/sitecore-jss-nextjs';
import { CONTENT_100 } from 'src/constants/contentDivider';
import styles from './WideImage.module.scss';
import { ComponentProps } from 'lib/component-props';
import { StyleguideSpecimenFields } from 'lib/component-props/styleguide';

type WideImageComponentProps = ComponentProps &
  StyleguideSpecimenFields & {
    fields: {
      imageSrc: Field<string>;
      headline: Field<string>;
      caption: Field<string>;
    };
  };

const WideImage = (props: WideImageComponentProps) => {
  const wideImageData: any = formatWideImageData(props);
  /**
   * @important This code needs to be used in every components inorder to get the content dividers reference
   * @important Also set the reference (ref) and className to the html wrapper as implemented below
   */
  // starts
  const nodeRef = useRef(null);
  const [parentRef, setParentRef] = useState<any>(null);
  const [parentAttr, setParentAttr] = useState<any>(null);

  useEffect(() => {
    const child: any = nodeRef.current;
    if (child !== null || child !== undefined) {
      setParentRef(getParentClassReference(child));
      setParentAttr(getParentAttributeReference(child, 'data-id'));
    } else {
      setParentRef(CONTENT_100);
    }
  }, [parentRef]);
  //ends

  return (
    <div ref={nodeRef} className={styles[parentRef]}>
      <div className={`${styles.wideImage__container} ${parentAttr && styles[parentAttr]}`}>
        <Text
          className={styles.wideImage__heading}
          tag="div"
          field={wideImageData && wideImageData.headline}
          editable={true}
        />
        <div
          className={`${styles.wideImage_image__wrapper} ${
            wideImageData &&
            wideImageData.caption &&
            wideImageData.caption.value !== '' &&
            styles.wideImage_caption_conditional__bg
          }`}
        >
          <figure>
            <Image field={wideImageData && wideImageData.imageSrc} />
          </figure>
        </div>
        {/* {wideImageData && wideImageData.caption && wideImageData.caption.value !== '' && ( */}
        <RichText
          className={styles.wideImage__caption}
          field={wideImageData && wideImageData.caption}
          tag="div"
          editable={true}
        />
        {/* )} */}
      </div>
    </div>
  );
};

export default WideImage;
