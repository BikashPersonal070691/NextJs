import styles from './CalendarTaskXL.module.scss';
import { Text } from '@sitecore-jss/sitecore-jss-nextjs';
import LightBoxOverLay from 'components/LightBoxOverlay/LightBoxOverlay';
import { useState } from 'react';
import { setHashString } from 'src/core/utils/utils.helper';
import { useRef, useEffect } from 'react';
import { IframeButton } from 'components/Elements/IframeButton/IframeButton';
import {
  IFRAME_BUTTON_TYPE
} from 'src/constants/general';
export default function CalendarTaskXL(props: any) {
  const { fields, duration, order, handleLoad, commonHeight, takeHeight } = props;
  const [isOpen, setIsOpen] = useState(false);
  const rowView = duration && duration.duration && duration.duration > 2 ? true : false;
  const containerRef = useRef<any>(null);
  const getWidth = (duration: any) => {
    let durationWidth = 'calc(' + 8.33 * duration.duration + '% - 4px)';
    if (
      duration.startMonth &&
      duration.startMonth === 1 &&
      duration.endMonth &&
      duration.endMonth === 12
    ) {
      durationWidth = '100%';
    }
    return durationWidth;
  };

  const handleOpenOverlay = () => {
    setIsOpen(true);
    const hash = `all/${props.id}`;
    setHashString(hash);
  };

  const closeOverlay = () => {
    setIsOpen(false);
  };
  useEffect(() => {
    if (containerRef && containerRef.current && containerRef.current.clientHeight) {
      handleLoad(containerRef.current.clientHeight);
    }
  }, []);

  return (
    <>
      <div
        className={`${styles.task_wrapper} ${
          order === 3 || order === 7
            ? styles.group_three
            : order === 2 || order === 6
            ? styles.group_two
            : order === 1 || order === 5
            ? styles.group_one
            : styles.default
        } ${rowView && styles.row_button}`}
        style={
          takeHeight
            ? {
                width: getWidth(duration),
                height: commonHeight,
                left: 8.33 * (duration.startMonth - 1) + '%',
              }
            : {
                width: getWidth(duration),
                left: 8.33 * (duration.startMonth - 1) + '%',
              }
        }
        onClick={handleOpenOverlay}
        ref={containerRef}
      >
        <Text field={fields.Name} editable={true} className={styles.task_text} tag="p" />
        {fields['IsTaskCompleted'] &&
        fields['IsTaskCompleted'].value &&
        fields['IsTaskCompleted'].value === true ? (
          <div className={styles.check_icon} />
        ) : fields['CTA link'] &&
          fields['CTA link'].value &&
          fields['CTA link'].value.text &&
          fields['CTA link'].value.text != '' ? (
          <a
            className={styles.task_link}
            // href={fields['CTA link'] && fields['CTA link'].value && fields['CTA link'].value.href}
            // target="_blank"
          >
            <button className={styles.task_button}>{fields['CTA link'].value.text}</button>
          </a>
        ) : (
          ''
        )}
        {fields['IFrameButtonText'] &&
        fields['IFrameButtonText'].value && !(fields['IsTaskCompleted'] &&
          fields['IsTaskCompleted'].value &&
          fields['IsTaskCompleted'].value === true) ?
         <div>
        <div className={`iframe_hr_all ${styles.float_right}`}>
          <IframeButton data={fields} type={IFRAME_BUTTON_TYPE.HR_ALL_TASK} group={
            order === 3 || order === 7
            ? "group_three"
            : order === 2 || order === 6
            ? 'group_two'
            : order === 1 || order === 5
            ? 'group_one'
            : ''} />
        </div>
      </div> : (
          ''
        )}
      </div>
      {isOpen ? (
        <LightBoxOverLay taskDetails={props} isOpen={isOpen} closeOverlay={closeOverlay} />
      ) : (
        ''
      )}
    </>
  );
}


