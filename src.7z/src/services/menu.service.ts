import { apiEndpoints } from 'src/core/api/apiEndpoints';
import { httpRequest } from 'src/core/api/httpRequest';

const getMainMenus = () => {
  const url = {
    url: `${apiEndpoints.getMainMenus.url}`,
    isMock: apiEndpoints.getMainMenus.isMock,
  };
  return httpRequest(url, 'get');
};

const getUtilityMenus = () => {
  const url = {
    url: `${apiEndpoints.getUtilityMenus.url}`,
    isMock: apiEndpoints.getUtilityMenus.isMock,
  };
  return httpRequest(url, 'get');
};

/** API to get profile data to show/hide Easy news template link in header
 *
 * @returns
 */
const getProfileInfo = () => {
  const url = {
    url: `${apiEndpoints.getProfileInfo.url}`,
    isMock: apiEndpoints.getProfileInfo.isMock,
  };
  return httpRequest(url, 'get');
};

const getChildMenus = (rootId: any, templateId: any) => {
  const url = {
    url: `${apiEndpoints.getChildMenus.url}?rootid=${rootId}&level=2&template=${templateId}&customQueryParam=1688987903725`,
    isMock: apiEndpoints.getChildMenus.isMock,
  };
  return httpRequest(url, 'get');
};


const getNotifications = () => {
  return httpRequest(apiEndpoints.getNotifications, 'get');
};
export { getMainMenus, getUtilityMenus, getChildMenus, getProfileInfo, getNotifications };
