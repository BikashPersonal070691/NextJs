import LightBoxOverLay from 'components/LightBoxOverlay/LightBoxOverlay';
import styles from './CalendarTask.module.scss';
import { Text } from '@sitecore-jss/sitecore-jss-nextjs';
import { useState, useRef, useEffect } from 'react';
import { setHashString } from 'src/core/utils/utils.helper';
import { IframeButton } from 'components/Elements/IframeButton/IframeButton';
import {
  IFRAME_BUTTON_TYPE
} from 'src/constants/general';

export default function CalendarTask(props: any) {
  const { fields, duration, width, order, handleLoad, commonHeight, takeHeight } = props;
  const rowView = duration && duration.duration && duration.duration > 2 ? true : false;
  const unitWidth = (width - 40) / 6;
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<any>(null);

  //console.log("fields",fields);
  useEffect(() => {
    if (containerRef && containerRef.current && containerRef.current.clientHeight) {
      handleLoad(containerRef.current.clientHeight);
    }
  }, []);
  const getWidth = (duration: any) => {
    let endPadding = 32;
    if (unitWidth < 93) {
      endPadding = 8;
    }
    let durationWidth = duration.duration * unitWidth + (duration.duration - 1) * 8 + 4;
    if (duration.startMonth === 1 && duration.endMonth === 12) {
      durationWidth = 2 * (width + endPadding);
    }
    if (
      duration.startMonth === 1 &&
      (duration.endMonth === 2 ||
        duration.endMonth === 3 ||
        duration.endMonth === 4 ||
        duration.endMonth === 5)
    ) {
      durationWidth = duration.duration * unitWidth + (duration.duration - 1) * 8 + 2;
    }
    if (duration.startMonth === 1 && duration.endMonth === 6) {
      durationWidth = width + endPadding;
    }
    if (
      duration.startMonth === 1 &&
      (duration.endMonth === 7 ||
        duration.endMonth === 8 ||
        duration.endMonth === 9 ||
        duration.endMonth === 10 ||
        duration.endMonth === 11)
    ) {
      durationWidth =
        duration.duration * unitWidth + (duration.duration - 1) * 8 + 2 + endPadding - 8;
    }
    if (
      (duration.startMonth === 8 ||
        duration.startMonth === 9 ||
        duration.startMonth === 10 ||
        duration.startMonth === 11) &&
      duration.endMonth === 12
    ) {
      durationWidth = duration.duration * unitWidth + (duration.duration - 1) * 8 + endPadding + 2;
    }
    if (duration.startMonth === 7 && duration.endMonth === 12) {
      durationWidth = width + endPadding;
    }
    if (
      (duration.startMonth === 2 ||
        duration.startMonth === 3 ||
        duration.startMonth === 4 ||
        duration.startMonth === 5 ||
        duration.startMonth === 6) &&
      duration.endMonth === 12
    ) {
      durationWidth =
        duration.duration * unitWidth +
        (duration.duration - 1) * 8 +
        2 +
        endPadding +
        endPadding -
        8;
    }
    if (
      duration.startMonth < 7 &&
      duration.endMonth > 6 &&
      duration.startMonth !== 1 &&
      duration.endMonth !== 12
    ) {
      durationWidth =
        duration.duration * unitWidth + (duration.duration - 1) * 8 + 4 + endPadding - 8;
    }
    if (
      (duration.startMonth === 2 ||
        duration.startMonth === 3 ||
        duration.startMonth === 4 ||
        duration.startMonth === 5 ||
        duration.startMonth === 6) &&
      duration.endMonth === 6
    ) {
      durationWidth = duration.duration * unitWidth + (duration.duration - 1) * 8 + 2 + endPadding;
    }
    if (
      duration.startMonth === 7 &&
      (duration.endMonth === 7 ||
        duration.endMonth === 8 ||
        duration.endMonth === 9 ||
        duration.endMonth === 10 ||
        duration.endMonth === 11)
    ) {
      durationWidth = duration.duration * unitWidth + (duration.duration - 1) * 8 + 2;
    }
    return durationWidth;
  };
  const getPosition = (duration: any) => {
    let endPadding = 32;
    if (unitWidth < 93) {
      endPadding = 8;
    }
    if (duration.startMonth && duration.startMonth === 1) {
      return 0;
    } else if (duration.startMonth && duration.startMonth === 2) {
      return unitWidth + 6;
    } else if (
      duration.startMonth &&
      (duration.startMonth === 3 ||
        duration.startMonth === 4 ||
        duration.startMonth === 5 ||
        duration.startMonth === 6)
    ) {
      return (duration.startMonth - 1) * unitWidth + (duration.startMonth - 2) * 8 + 6;
    } else if (duration.startMonth && duration.startMonth === 7) {
      return width + endPadding;
    } else if (duration.startMonth && duration.startMonth === 8) {
      return width + endPadding + unitWidth + 6;
    } else {
      return (
        width +
        endPadding +
        (duration.startMonth - 6 - 1) * unitWidth +
        (duration.startMonth - 6 - 2) * 8 +
        6
      );
    }
  };

  const handleOpenOverlay = () => {
    setIsOpen(true);
    const hash = `all/${props.id}`;
    setHashString(hash);
  };

  const closeOverlay = () => {
    setIsOpen(false);
  };
  return (
    <>
      <div
        className={`${styles.task_wrapper} ${
          order === 3 || order === 7
            ? styles.group_three
            : order === 2 || order === 6
            ? styles.group_two
            : order === 1 || order === 5
            ? styles.group_one
            : styles.default
        } ${rowView && styles.row_button}`}
        style={
          takeHeight
            ? {
                width: getWidth(duration),
                height: commonHeight,
                left: getPosition(duration),
              }
            : {
                width: getWidth(duration),
                left: getPosition(duration),
              }
        }
        onClick={handleOpenOverlay}
        ref={containerRef}
      >
        <Text field={fields && fields.Name} editable={true} className={styles.task_text} tag="p" />
        {fields['IsTaskCompleted'] &&
        fields['IsTaskCompleted'].value &&
        fields['IsTaskCompleted'].value === true ? (
          <div className={styles.check_icon} />
        ) : fields['CTA link'] &&
          fields['CTA link'].value &&
          fields['CTA link'].value.text &&
          fields['CTA link'].value.text != '' ? (
          <a
            className={styles.task_link}
            // href={fields['CTA link'] && fields['CTA link'].value && fields['CTA link'].value.href}
            onClick={handleOpenOverlay}
            target="_blank"
          >
            <button className={styles.task_button}>{fields['CTA link'].value.text}</button>
          </a>
        ) : (
          ''
        )}

        {fields['IFrameButtonText'] &&
        fields['IFrameButtonText'].value && !(fields['IsTaskCompleted'] &&
          fields['IsTaskCompleted'].value &&
          fields['IsTaskCompleted'].value === true) ?
         <div>
        <div className={`iframe_hr_all ${styles.float_right}`}>
          <IframeButton data={fields} type={IFRAME_BUTTON_TYPE.HR_ALL_TASK} group={
            order === 3 || order === 7
            ? "group_three"
            : order === 2 || order === 6
            ? 'group_two'
            : order === 1 || order === 5
            ? 'group_one'
            : ''} />
        </div>
      </div> : (
          ''
        )}

      </div>
      {isOpen ? (
        <LightBoxOverLay taskDetails={props} isOpen={isOpen} closeOverlay={closeOverlay} />
      ) : (
        ''
      )}
    </>
  );
}
