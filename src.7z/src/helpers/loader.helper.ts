import { BehaviorSubject } from 'rxjs';

// this subject value is subscribed in Loader component
// and the loader spinner is displayed based on this value
export const loaderSubject = new BehaviorSubject(false);
