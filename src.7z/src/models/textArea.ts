export interface TextAreaConfig {
  name: string;
  id: string;
  value?: any;
  onChange?: any;
  className?: string;
  placeHolder?: any;
  onKeyPress?: any;
  onKeyDown?: any;
  type: string;
  autoFocus: boolean;
  maxLength?: number; // maxlength will only work in type normal
}
