import { apiEndpoints } from 'src/core/api/apiEndpoints';
import { httpRequest } from 'src/core/api/httpRequest';

const getBreadcrumbData = (id: any) => {
  const url = {
    url: `${apiEndpoints.getBreadcrumbData.url}?itemID=${id}`,
    isMock: apiEndpoints.getBreadcrumbData.isMock,
  };
  //const url=apiEndpoints.getBreadcrumbData;
  return httpRequest(url, 'get');
};

export { getBreadcrumbData };
