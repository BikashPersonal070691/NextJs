/**
 * Modify  API response into a helpful format
 * @param data
 * @returns
 */
const formatBreadcrumbData = (data: any) => {
  const refinedData: any = {
    data: data,
  };
  return refinedData;
};

export { formatBreadcrumbData };
