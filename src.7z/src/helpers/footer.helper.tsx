// import { format, parseISO } from 'date-fns';

const dateFormater = (footerDate: any) => {
  // 121626-fix
  //const parsedDate = parseISO(footerDate);
  //const formattedData = format(parsedDate, 'MMMM dd, yyyy');
  return footerDate;
};
/**
 * Modify  API response into a helpful format
 * @param data
 * @returns
 */

//  {"TotalView":"10","RecentView":"10","ContentOwner":"","ContentOwnerEmail":"","UpdatedDate":"2023-00-08","PageTitle":""}
const formatFooterData = (data: any) => {
  const refinedData: any = {
    ContentOwner: data && data.ContentOwner ? data.ContentOwner : '',
    ContentOwnerEmail: data && data.ContentOwnerEmail ? data.ContentOwnerEmail : '',
    PageTitle: data && data.PageTitle ? data.PageTitle : '',
    UpdatedDate: data && data.UpdatedDate ? dateFormater(data.UpdatedDate) : '',
    RecentViewCount: data && data.RecentView ? data.RecentView : '',
    TotalViewCount: data && data.TotalView ? data.TotalView : '',
  };
  return refinedData;
};

export { formatFooterData, dateFormater };
