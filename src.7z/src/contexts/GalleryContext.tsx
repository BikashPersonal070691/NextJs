import { createContext } from 'react';

export const GalleryContext = createContext<any>(null);
const GalleryProvider = GalleryContext.Provider;
const GalleryConsumer = GalleryContext.Consumer;

export { GalleryConsumer, GalleryProvider };
