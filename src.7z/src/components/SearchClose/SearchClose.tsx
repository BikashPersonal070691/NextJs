//import { useState, useEffect } from 'react';
import styles from './SearchClose.module.scss';

export function SearchClose(props: any) {
  const { closeAction } = props;
  return <div className={styles.search_box__close} onClick={closeAction}></div>;
}
