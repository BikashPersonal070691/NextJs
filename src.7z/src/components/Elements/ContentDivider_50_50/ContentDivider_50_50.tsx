import { useRef, useEffect, useState } from 'react';
import { Field } from '@sitecore-jss/sitecore-jss-nextjs';
import { ComponentProps } from 'lib/component-props';
import { StyleguideSpecimenFields } from 'lib/component-props/styleguide';
import { Placeholder } from '@sitecore-jss/sitecore-jss-nextjs';
import { CONTENT_50, CD_50_50 } from 'src/constants/contentDivider';
import { formatContentDividerData } from 'src/helpers/contentDivider.helper';
import styles from './ContentDivider_50_50.module.scss';

type TwoColumnContainerProps = ComponentProps &
  StyleguideSpecimenFields & {
    fields: {
      heading: Field<string>;
    };
  };

const ContentDivider_50_50 = (props: TwoColumnContainerProps): JSX.Element => {
  const [isParentIdExists, setIsParentIdExists] = useState<boolean>(false);
  const currentElement: any = useRef(null);
  const contentDividerBg = formatContentDividerData(props);
  /**
   * @description to check if parent node has id . If parent has id it this current content divider is a nested content divider.
   */
  useEffect(() => {
    currentElement &&
    currentElement.current &&
    currentElement.current.parentNode &&
    currentElement.current.parentNode.id &&
    currentElement.current.parentNode.id !== undefined &&
    currentElement.current.parentNode.id !== ''
      ? setIsParentIdExists(true)
      : setIsParentIdExists(false);
  }, []);

  return (
    <section
      className={`${styles.divider_50_50__container} ${
        !isParentIdExists ? styles.divider_50_50_container__bg : ''
      }`}
      ref={currentElement}
      style={{
        backgroundColor:
          contentDividerBg && contentDividerBg.bgColor && contentDividerBg.bgColor !== ''
            ? contentDividerBg.bgColor
            : 'white',
      }}
    >
      <div className={styles.divider_50_50__wrapper}>
        <div
          className={styles.divider_50_left__container}
          id={CONTENT_50}
          data-nested={isParentIdExists}
          data-cd-bg={
            contentDividerBg && contentDividerBg.bgColor && contentDividerBg.bgColor !== ''
              ? contentDividerBg.bgColor
              : 'white'
          }
        >
          <Placeholder name={CD_50_50.PH_50_50_LEFT_50} rendering={props.rendering} />
        </div>

        <div
          className={styles.divider_50_right__container}
          id={CONTENT_50}
          data-nested={isParentIdExists}
          data-cd-bg={
            contentDividerBg && contentDividerBg.bgColor && contentDividerBg.bgColor !== ''
              ? contentDividerBg.bgColor
              : 'white'
          }
        >
          <Placeholder name={CD_50_50.PH_50_50_RIGHT_50} rendering={props.rendering} />
        </div>
      </div>
    </section>
  );
};

export default ContentDivider_50_50;
